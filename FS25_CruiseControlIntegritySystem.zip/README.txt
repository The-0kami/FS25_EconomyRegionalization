Cruise Control Integrity System v0.1.0.0
Agriculture Science

Purpose:
A tiny troll mod for Farming Simulator 25.

Behavior:
- Listens to the normal TOGGLE_CRUISE_CONTROL action.
- Only activation attempts can trigger an incident.
- Default chance: 2% per activation attempt.
- On a hit, the server disables cruise control and force-detaches the first
  directly attached implement.
- After a successful incident, the same vehicle has a 30 second cooldown.
- Multiplayer decision and detach are server-authoritative.

Configuration:
Edit scripts/CCIS_Config.lua inside the ZIP before distributing it.

CCIS_CONFIG.TROLL_CHANCE = 0.02   -- 2%
CCIS_CONFIG.COOLDOWN_MS = 30000   -- 30 seconds
CCIS_CONFIG.LOGGING = true

Scientific assessment:
The tractor is not broken. It is participating in attachment-integrity research.
