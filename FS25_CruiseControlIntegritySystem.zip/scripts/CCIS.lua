-- FS25 Cruise Control Integrity System
-- Agriculture Science
--
-- A deliberately questionable quality-assurance system:
-- on a small percentage of cruise-control activation attempts, the server
-- immediately disables cruise control and force-detaches one directly
-- attached implement.

CruiseControlIntegritySystem = CruiseControlIntegritySystem or {}
local CCIS = CruiseControlIntegritySystem

CCIS.modName = g_currentModName or "FS25_CruiseControlIntegritySystem"
CCIS.cooldowns = CCIS.cooldowns or {}
CCIS.hookInstalled = false

local function cfg(name, fallback)
    if CCIS_CONFIG ~= nil and CCIS_CONFIG[name] ~= nil then
        return CCIS_CONFIG[name]
    end
    return fallback
end

local function log(message)
    if cfg("LOGGING", true) then
        print("[TROLLSCIENCE] " .. tostring(message))
    end
end

local function safeName(object)
    if object == nil then return "<nil>" end
    if object.getName ~= nil then
        local ok, value = pcall(object.getName, object)
        if ok and value ~= nil and value ~= "" then return tostring(value) end
    end
    if object.configFileName ~= nil then return tostring(object.configFileName) end
    return tostring(object)
end

function CCIS:getPrimaryDirectImplement(vehicle)
    if vehicle == nil or vehicle.getAttachedImplements == nil then return nil, nil end
    local implements = vehicle:getAttachedImplements() or {}
    for index, implement in ipairs(implements) do
        if implement ~= nil and implement.object ~= nil then
            return implement.object, index
        end
    end
    return nil, nil
end

function CCIS:forceDetach(vehicle, tool, fallbackIndex)
    if vehicle == nil or tool == nil then return false end

    if vehicle.detachImplementByObject ~= nil then
        local ok, result = pcall(vehicle.detachImplementByObject, vehicle, tool, false)
        if ok and result ~= false then
            return true
        end
    end

    if vehicle.detachImplement ~= nil then
        local index = fallbackIndex
        if vehicle.getAttachedImplements ~= nil then
            for i, implement in ipairs(vehicle:getAttachedImplements() or {}) do
                if implement ~= nil and implement.object == tool then
                    index = i
                    break
                end
            end
        end
        if index ~= nil then
            local ok, result = pcall(vehicle.detachImplement, vehicle, index, false)
            return ok and result ~= false
        end
    end

    return false
end

function CCIS:isCoolingDown(vehicle)
    local now = g_currentMission ~= nil and g_currentMission.time or 0
    local untilTime = self.cooldowns[vehicle]
    return untilTime ~= nil and now < untilTime
end

function CCIS:setCooldown(vehicle)
    local now = g_currentMission ~= nil and g_currentMission.time or 0
    self.cooldowns[vehicle] = now + math.max(0, cfg("COOLDOWN_MS", 30000))
end

function CCIS:serverHandleRequest(vehicle, connection)
    if g_server == nil or vehicle == nil then return end

    -- Do not allow a client to troll vehicles it does not own/control.
    if connection ~= nil and not connection:getIsServer() and vehicle.getOwnerConnection ~= nil then
        local owner = vehicle:getOwnerConnection()
        if owner ~= nil and owner ~= connection then
            log("Rejected integrity request for non-owned vehicle: " .. safeName(vehicle))
            return
        end
    end

    local tool, implementIndex = self:getPrimaryDirectImplement(vehicle)
    if tool == nil then return end
    if self:isCoolingDown(vehicle) then return end

    local chance = math.max(0, math.min(1, cfg("TROLL_CHANCE", 0.02)))
    if math.random() >= chance then return end

    self:setCooldown(vehicle)

    if vehicle.setCruiseControlState ~= nil and Drivable ~= nil and Drivable.CRUISECONTROL_STATE_OFF ~= nil then
        pcall(vehicle.setCruiseControlState, vehicle, Drivable.CRUISECONTROL_STATE_OFF)
    end

    log("Cruise control integrity test failed.")
    log("Implement separation initiated: " .. safeName(tool))

    local success = self:forceDetach(vehicle, tool, implementIndex)
    if success then
        log("Attached equipment has been reassigned to an independent career.")
    else
        log("Separation test failed. Attachment has demonstrated suspicious competence.")
    end
end

function CCIS:sendActivationRequest(vehicle)
    if vehicle == nil then return end

    -- Dedicated / multiplayer clients ask the authoritative server to roll.
    if g_client ~= nil then
        local connection = g_client:getServerConnection()
        if connection ~= nil then
            connection:sendEvent(CCISIntegrityRequestEvent.new(vehicle))
            return
        end
    end

    -- Fallback for a local server context without a client connection.
    if g_server ~= nil then
        self:serverHandleRequest(vehicle, nil)
    end
end

function CCIS:installHook()
    if self.hookInstalled then return end
    if Drivable == nil or Drivable.actionEventCruiseControlState == nil then
        log("Drivable cruise-control action not available; hook not installed.")
        return
    end

    local original = Drivable.actionEventCruiseControlState
    Drivable.actionEventCruiseControlState = function(vehicle, actionName, inputValue, callbackState, isAnalog)
        local wasActive = false
        if vehicle ~= nil and vehicle.getCruiseControlState ~= nil and Drivable.CRUISECONTROL_STATE_ACTIVE ~= nil then
            local ok, state = pcall(vehicle.getCruiseControlState, vehicle)
            wasActive = ok and state == Drivable.CRUISECONTROL_STATE_ACTIVE
        end

        original(vehicle, actionName, inputValue, callbackState, isAnalog)

        -- Only activation attempts are candidates. Turning cruise control off
        -- remains entirely vanilla.
        if inputValue ~= nil and inputValue ~= 0 and not wasActive and vehicle ~= nil then
            local tool = self:getPrimaryDirectImplement(vehicle)
            if tool ~= nil then
                self:sendActivationRequest(vehicle)
            end
        end
    end

    self.hookInstalled = true
    log(string.format("Cruise Control Integrity System online. Incident chance: %.2f%%", cfg("TROLL_CHANCE", 0.02) * 100))
end

function CCIS:loadMap(mapName)
    self:installHook()
end

function CCIS:deleteMap()
    self.cooldowns = {}
end

function CCIS:keyEvent() end
function CCIS:mouseEvent() end
function CCIS:update(dt) end
function CCIS:draw() end

CCISIntegrityRequestEvent = {}
local CCISIntegrityRequestEvent_mt = Class(CCISIntegrityRequestEvent, Event)
InitEventClass(CCISIntegrityRequestEvent, "CCISIntegrityRequestEvent")

function CCISIntegrityRequestEvent.emptyNew()
    return Event.new(CCISIntegrityRequestEvent_mt)
end

function CCISIntegrityRequestEvent.new(vehicle)
    local self = CCISIntegrityRequestEvent.emptyNew()
    self.vehicle = vehicle
    return self
end

function CCISIntegrityRequestEvent:writeStream(streamId, connection)
    NetworkUtil.writeNodeObjectId(streamId, NetworkUtil.getObjectId(self.vehicle))
end

function CCISIntegrityRequestEvent:readStream(streamId, connection)
    self.vehicle = NetworkUtil.getObject(NetworkUtil.readNodeObjectId(streamId))
    self:run(connection)
end

function CCISIntegrityRequestEvent:run(connection)
    if g_server ~= nil and CCIS ~= nil then
        CCIS:serverHandleRequest(self.vehicle, connection)
    end
end

addModEventListener(CCIS)
