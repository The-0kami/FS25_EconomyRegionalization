-- Cruise Control Integrity System
-- Agriculture Science
--
-- 0.02 = 2 % chance per attempted cruise-control activation.
CCIS_CONFIG = CCIS_CONFIG or {}
CCIS_CONFIG.TROLL_CHANCE = 0.02

-- After a successful incident, this vehicle is protected from another
-- incident for this many milliseconds.
CCIS_CONFIG.COOLDOWN_MS = 30000

-- If true, diagnostic messages are written to log.txt.
CCIS_CONFIG.LOGGING = true
