-- One persisted discovery catalogue. Never executes a native activatable.
SmartGateInteractionDiscovery={}
local D=SmartGateInteractionDiscovery
local LIMIT=512
local PROFILE={"interactionDepth","interactionHalfWidth","interactionOffsetX","interactionOffsetZ","interactionYaw"}
local function prepare(r)
    if (r.kind=="LIGHT_STATE" or r.kind=="ANIMATED_CYCLE") and r.present=="KNOWN" and type(r.x)=="number" and type(r.z)=="number" then
        r.configured=true; r.interactionDepth=.75; r.interactionHalfWidth=1; r.interactionOffsetX=0; r.interactionOffsetZ=0; r.interactionYaw=0
    end
end
local function text(de,en) return tostring(g_languageShort or 'en'):sub(1,2)=='de' and de or en end
local function call(o,m,...) if o~=nil and type(o[m])=='function' then local ok,a=pcall(o[m],o,...); if ok then return a end end end
local function finite(n) return type(n)=='number' and n==n and math.abs(n)<1000000 end
local function sorted(t) local out={}; for _,v in pairs(t) do out[#out+1]=v end; table.sort(out,function(a,b) return a.id<b.id end); return out end
local function admin(connection)
    if g_server==nil then return false end
    if connection==nil then return g_dedicatedServer==nil end
    if call(connection,'getIsServer')~=false then return false end
    local user=call(g_currentMission~=nil and g_currentMission.userManager,'getUserByConnection',connection)
    return call(user,'getIsMasterUser')==true
end
local function localAdmin() return g_dedicatedServer==nil and g_currentMission~=nil and (g_server~=nil or g_currentMission.isMasterUser==true) end
local function identity(p)
    local uid=call(p,'getUniqueId')
    if type(uid)=='string' and uid~='' then return 'uid:'..uid end
    local node=p.rootNode or (p.components~=nil and p.components[1]~=nil and p.components[1].node)
    if node~=nil and type(getWorldTranslation)=='function' then
        local ok,x,y,z=pcall(getWorldTranslation,node)
        if ok and finite(x) and finite(z) then return 'pose:'..tostring(p.configFileName or p.className or 'map')..string.format('|%.2f|%.2f',x,z) end
    end
end
function D.new(owner)
    return setmetatable({owner=owner,records={},completed=false,dismissed=false,auto=false,safe=true,revision=1,
        epoch=tostring({}),shown=false,started=false,scanCount=0,scannedSources=setmetatable({},{__mode='k'})},{__index=D})
end
function D:hasData() return self.completed or self.staged~=nil or next(self.records)~=nil end
function D:readXML(xml)
    local base='smartGate.interactionDiscovery'
    if not hasXMLProperty(xml,base) then return end
    if getXMLInt(xml,base..'#schemaVersion')~=1 then self.safe=false; return end
    local records={}; local i=0
    while hasXMLProperty(xml,base..string.format('.candidate(%d)',i)) do
        local key=base..string.format('.candidate(%d)',i)
        local r={id=getXMLString(xml,key..'#id'),source=getXMLString(xml,key..'#source'),name=getXMLString(xml,key..'#name'),kind=getXMLString(xml,key..'#kind'),configured=getXMLBool(xml,key..'#configured')==true,executionEnabled=false,mode=0}
        if getXMLBool(xml,key..'#executionEnabled')==true then self.safe=false; return end
        if i>=LIMIT or type(r.id)~='string' or #r.id>1024 or r.id=='' or records[r.id]~=nil or type(r.source)~='string' or #r.source>900 or type(r.name)~='string' or #r.name>128 or type(r.kind)~='string' or #r.kind>64 then self.safe=false; return end
        r.x=getXMLFloat(xml,key..'#x'); r.z=getXMLFloat(xml,key..'#z')
        if r.configured then
            for _,f in ipairs(PROFILE) do r[f]=getXMLFloat(xml,key..'#'..f) end
            if not finite(r.x) or not finite(r.z) or not finite(r.interactionDepth) or not finite(r.interactionHalfWidth) or r.interactionDepth<=0 or r.interactionHalfWidth<=0 or not finite(r.interactionOffsetX) or not finite(r.interactionOffsetZ) or not finite(r.interactionYaw) then self.safe=false; return end
        end
        r.present='UNKNOWN'; records[r.id]=r; i=i+1
    end
    self.records=records; self.completed=getXMLBool(xml,base..'#initialScanCompleted')==true
    self.dismissed=getXMLBool(xml,base..'#promptDismissed')==true; self.auto=getXMLBool(xml,base..'#autoConfigureNew')==true
    self.safe=true
end
function D:writeXML(xml)
    if not self.safe then error('Unvalidated interaction discovery XML') end
    local base='smartGate.interactionDiscovery'
    setXMLInt(xml,base..'#schemaVersion',1); setXMLBool(xml,base..'#initialScanCompleted',self.completed)
    setXMLBool(xml,base..'#promptDismissed',self.dismissed); setXMLBool(xml,base..'#autoConfigureNew',self.auto)
    for i,r in ipairs(sorted(self.records)) do
        local k=base..string.format('.candidate(%d)',i-1)
        for _,f in ipairs({'id','source','name','kind'}) do setXMLString(xml,k..'#'..f,r[f]) end
        setXMLBool(xml,k..'#configured',r.configured==true); setXMLBool(xml,k..'#executionEnabled',false)
        if finite(r.x) and finite(r.z) then setXMLFloat(xml,k..'#x',r.x); setXMLFloat(xml,k..'#z',r.z) end
        if r.configured then for _,f in ipairs(PROFILE) do setXMLFloat(xml,k..'#'..f,r[f]) end end
    end
end
function D:scanSource(p)
    if p==nil or p.isDeleted==true or self.scannedSources[p] then return end
    local source=identity(p); if source==nil or #source>900 then return end
    self.scannedSources[p]=true
    local function add(key,kind,name,node)
        local id=source..'|'..key
        if #id>1024 then self.overflow=true; return end
        if self.records[id]==nil and #sorted(self.records)>=LIMIT then self.overflow=true; return end
        local old=self.records[id]
        local x,z
        node=node or p.rootNode
        if node~=nil and type(getWorldTranslation)=='function' then local ok,px,py,pz=pcall(getWorldTranslation,node); if ok and finite(px) and finite(pz) then x,z=px,pz end end
        local r={id=id,source=source,name=tostring(name or call(p,'getName') or p.configFileName or source):gsub('[%c]',' '):sub(1,128),kind=kind,
            configured=false,present='KNOWN',x=x,z=z,executionEnabled=false,mode=0}
        if old~=nil and old.configured then r=old; r.present='KNOWN'
        elseif self.auto then prepare(r) end
        self.records[id]=r
    end
    local lights=p.spec_lights
    for index,group in pairs(lights~=nil and lights.groups or {}) do
        if group.triggerNode~=nil then
            local verified=PlaceableLights~=nil and p.setGroupIsActive==PlaceableLights.setGroupIsActive and type(p.setGroupIsActive)=='function'
            add('LIGHT:'..tostring(index),verified and 'LIGHT_STATE' or 'UNKNOWN_LIGHT',group.name or call(p,'getName'),group.triggerNode)
        end
    end
    if p.spec_objectStorage~=nil then add('OBJECT_STORAGE','REVIEW_STORAGE',call(p,'getName')) end
    local existing={}
    for _,gate in ipairs(self.owner.gates or {}) do if gate.animatedObject~=nil then existing[gate.animatedObject]=true end end
    for index,ao in pairs(p.spec_animatedObjects~=nil and p.spec_animatedObjects.animatedObjects or {}) do
        if not existing[ao] then
            local verified=AnimatedObject~=nil and ao.setDirection==AnimatedObject.setDirection and type(ao.setDirection)=='function' and ao.animation~=nil and ao.triggerNode~=nil
            add('ANIMATION:'..tostring(ao.saveId or ao.id or index),verified and 'ANIMATED_CYCLE' or 'REVIEW_ANIMATION',ao.activatable~=nil and ao.activatable.activateText or call(p,'getName'),ao.triggerNode)
        end
    end
    -- Hints only. No localized text is interpreted as an execution contract.
    if p.activatable~=nil and lights==nil and p.spec_objectStorage==nil then add('ACTIVATABLE','UNKNOWN',p.activatable.activateText) end
end
function D:commit()
    if not self.owner:saveConfig(nil,'INTERACTION_DISCOVERY') then return false end
    self.revision=self.revision+1; self:broadcast(); return true
end
function D:validateSavedSources()
    local system=g_currentMission~=nil and g_currentMission.placeableSystem
    local index=system~=nil and system.placableByUniqueId
    if type(index)~="table" then return end -- UNKNOWN, never infer absence from a missing API
    local changed=false
    for id,r in pairs(self.records) do
        if r.source:sub(1,4)=="uid:" then
            local p=index[r.source:sub(5)]
            if p==nil then self.records[id]=nil; changed=true
            else
                r.present="KNOWN"
                if r.kind=="LIGHT_STATE" and (PlaceableLights==nil or p.setGroupIsActive~=PlaceableLights.setGroupIsActive or p.spec_lights==nil) then
                    r.kind="UNKNOWN_LIGHT"; r.configured=false; changed=true
                end
            end
        end
    end
    if changed and not self:commit() then self.dirty=true end
end
function D:tryInitial()
    if g_server==nil or self.disposed or not self.started or not self.safe then return end
    if self.dirty and self:commit() then self.dirty=false end
    if self.completed then return end
    local system=g_currentMission~=nil and g_currentMission.placeableSystem
    if system==nil or type(system.placeables)~='table' then return end
    if type(system.pendingPlaceableLoadingData)=='table' and next(system.pendingPlaceableLoadingData)~=nil then return end
    if not self.staged then
        local previous=self.records; self.records={}; self.overflow=false
        for _,p in pairs(system.placeables) do self:scanSource(p) end
        local map=g_currentMission.onCreateObjectSystem
        for _,p in pairs(map~=nil and map.objects or {}) do self:scanSource(p) end
        self.scanCount=self.scanCount+1; self.staged=true
        if self.overflow then self.records=previous; self.safe=false; print('[SmartGate][DISCOVERY] catalogue limit reached; completion not persisted'); return end
    end
    self.completed=true
    if not self:commit() then self.completed=false; return end
    self.staged=nil
    print('[SmartGate][DISCOVERY] initial scan persisted; candidates='..tostring(#sorted(self.records)))
end
function D:onAdded(p)
    if g_server==nil or not self.completed or not self.auto or self.scannedSources[p] then return end
    local before={}; for k,v in pairs(self.records) do before[k]=v end
    self:scanSource(p)
    if not self:commit() then self.records=before; self.scannedSources[p]=nil end
end
function D:onRemoved(p)
    -- GIANTS also publishes PLACEABLE_REMOVED while unloading the map.
    -- Placeable:delete uses isExitingGame to distinguish this from demolition.
    -- Never persist teardown as a user-disabled gate or a removed service source.
    if g_server==nil or self.disposed or g_currentMission==nil or g_currentMission.isExitingGame==true then return end
    local infrastructureChanged=self.owner.serviceInfrastructure~=nil and self.owner.serviceInfrastructure:invalidateSource(p) or false
    local source=identity(p); if source==nil then if infrastructureChanged then self:commit() end; return end
    local before={}; local changed=infrastructureChanged
    for k,v in pairs(self.records) do before[k]=v; if v.source==source then self.records[k]=nil; changed=true end end
    self.scannedSources[p]=nil
    if changed and not self:commit() then self.dirty=true; self.revision=self.revision+1; self:broadcast() end
end
function D:onMissionStarted()
    if self.started or self.disposed then return end
    -- Refresh the existing gate inventory at the verified mission-start boundary
    -- before counting additional interactions. Early loadMap inventories can be empty.
    self.owner:rescan()
    self.started=true
    if self.completed then self:validateSavedSources() end
    self:tryInitial()
    if g_server~=nil then self:broadcast() end
end
function D:start()
    if self.subscriptionsActive then return end
    self.subscriptionsActive=true; self.mission=g_currentMission
    if type(addConsoleCommand)=='function' then
        addConsoleCommand('sgInteractionDiscovery','Read-only interaction catalogue / review','consoleInteractionDiscovery',self.owner)
        self.consoleRegistered=true
    end
    if g_server~=nil and g_messageCenter~=nil and MessageType~=nil then
        if MessageType.CURRENT_MISSION_START~=nil then
            if type(g_messageCenter.subscribeOneshot)=='function' then g_messageCenter:subscribeOneshot(MessageType.CURRENT_MISSION_START,self.onMissionStarted,self)
            else g_messageCenter:subscribe(MessageType.CURRENT_MISSION_START,self.onMissionStarted,self) end
        end
        if MessageType.PLACEABLE_ADDED~=nil then g_messageCenter:subscribe(MessageType.PLACEABLE_ADDED,self.onAdded,self) end
        if MessageType.PLACEABLE_REMOVED~=nil then g_messageCenter:subscribe(MessageType.PLACEABLE_REMOVED,self.onRemoved,self) end
    end
end
function D:dispose()
    if self.disposed then return end
    self.disposed=true
    if self.consoleRegistered and type(removeConsoleCommand)=='function' then removeConsoleCommand('sgInteractionDiscovery') end
    self.consoleRegistered=false
    if g_messageCenter~=nil and type(g_messageCenter.unsubscribeAll)=='function' then g_messageCenter:unsubscribeAll(self) end
end
function D:snapshot()
    local records={}; for _,r in ipairs(sorted(self.records)) do local item={id=r.id,source=r.source,name=r.name,kind=r.kind,configured=r.configured==true,x=r.x,z=r.z,present=r.present or 'UNKNOWN',executionEnabled=false,mode=0}; for _,f in ipairs(PROFILE) do item[f]=r[f] end; records[#records+1]=item end
    return {epoch=self.epoch,revision=self.revision,completed=self.completed,dismissed=self.dismissed,auto=self.auto,records=records}
end
function D:broadcast(connection)
    local event=SGInteractionDiscoveryStateEvent.new(self:snapshot())
    if connection~=nil then connection:sendEvent(event)
    elseif g_server~=nil and type(g_server.broadcastEvent)=='function' then g_server:broadcastEvent(event,false) end
end
function D:receive(state)
    if g_server~=nil or self.disposed then return end
    if self.remoteEpoch~=nil and self.remoteEpoch~=state.epoch then return end
    if self.remoteEpoch==state.epoch and state.revision<(self.revision or 0) then return end
    self.remoteEpoch=state.epoch; self.epoch=state.epoch; self.revision=state.revision
    self.completed,self.dismissed,self.auto=state.completed,state.dismissed,state.auto
    self.records={}; for _,r in ipairs(state.records) do r.executionEnabled=false; r.mode=0; self.records[r.id]=r end
    local settings=self.owner.settings
    if settings~=nil and settings.discoveryAutoControl~=nil then settings.discoveryAutoControl:setState(self.auto and 2 or 1,false) end
end
function D:command(op,revision,epoch,connection)
    if op=='STATE' then self:broadcast(connection); return true end
    if not admin(connection) or not self.safe or revision~=self.revision or epoch~=self.epoch or not self.completed then return false end
    if op=='OPEN' then self:broadcast(connection); return true end
    local oldDismissed,oldAuto=self.dismissed,self.auto
    local configured={}; for id,r in pairs(self.records) do configured[id]={configured=r.configured}; for _,f in ipairs(PROFILE) do configured[id][f]=r[f] end end
    if op=='YES' or op=='NO' then
        self.dismissed=true
        if op=='YES' then for _,r in pairs(self.records) do prepare(r) end end
    elseif op=='AUTO_ON' then self.auto=true
    elseif op=='AUTO_OFF' then self.auto=false
    else return false end
    if not self:commit() then
        self.dismissed,self.auto=oldDismissed,oldAuto
        for id,r in pairs(self.records) do r.configured=configured[id].configured; for _,f in ipairs(PROFILE) do r[f]=configured[id][f] end end
        return false
    end
    return true
end
function D:request(op)
    if op=='STATE' then if self.stateRequested then return end; self.stateRequested=true end
    if op=='OPEN' then self.forcePrompt=true end
    if g_server~=nil then
        if op=='OPEN' then self.forcePrompt=true; self:maybePrompt(); return end
        local result=self:command(op,self.revision,self.epoch,nil)
        local control=self.owner.settings~=nil and self.owner.settings.discoveryAutoControl
        if control~=nil then control:setState(self.auto and 2 or 1,false) end
        return result
    elseif g_client~=nil then g_client:getServerConnection():sendEvent(SGInteractionDiscoveryRequestEvent.new(op,self.revision,self.remoteEpoch or '')) end
end
function D:maybePrompt()
    -- Queue the explanation until the first dialog has closed. Never replace
    -- another menu/dialog or persist acknowledgement as gameplay configuration.
    if self.disposed then return end
    if self.activationHintPending then
        if not localAdmin() or g_dedicatedServer~=nil or g_gui==nil or call(g_gui,'getIsGuiVisible')==true then return end
        if InfoDialog==nil or type(InfoDialog.show)~='function' then return end
        self.activationHintPending=nil
        InfoDialog.show(text(
            'Wichtig: Vorkonfiguriert bedeutet nicht automatisch aktiviert.\n\nZusätzlich erkannte Interaktionspunkte werden deaktiviert vorbereitet.\n\nBei normalen Toren entscheidet die Einstellung „Neue Tore standardmäßig aktivieren“. Bereits gespeicherte Torzustände bleiben erhalten.\n\nÖffne den L.E.G.S.-Konfigurationsmodus mit Strg+G (Standardbelegung), wähle das Objekt und prüfe bzw. ändere dort den Aktivierungsmodus. Bei eigener Tastenbelegung verwende deine Config-Taste.\n\nHast du den Unterschied verstanden?',
            'Important: Preconfigured does not mean automatically enabled.\n\nAdditional discovered interaction points are prepared disabled.\n\nNormal gates follow the setting "Enable new gates by default". Previously saved gate states are retained.\n\nOpen L.E.G.S. configuration with Ctrl+G (default binding), select the object and check or change its activation mode. If rebound, use your configured key.\n\nDo you understand the difference?'),nil,nil,nil,text('Verstanden','Understood'))
        return
    end
    if not localAdmin() or not self.completed or (not self.forcePrompt and (self.dismissed or self.shown)) then return end
    if YesNoDialog==nil or type(YesNoDialog.show)~='function' or g_gui==nil or (call(g_gui,'getIsGuiVisible')==true and not self.forcePrompt) then return end
    local list=sorted(self.records); local preview={}
    for i=1,math.min(#list,6) do preview[#preview+1]=list[i].name..' ['..list[i].kind..']' end
    local body=text('Willkommen bei L.E.G.S. von Agriculture Science!\n\nAuf dieser Karte wurden zusätzlich zu den Toren %d weitere mögliche Interaktionspunkte entdeckt.\n\nMöchtest du diese Punkte automatisch vorkonfigurieren lassen?',
        'Welcome to L.E.G.S. by Agriculture Science!\n\n%d additional possible interaction points were discovered.\n\nWould you like these points to be preconfigured?')
    body=string.format(body,#list)..'\n\n'..table.concat(preview,'\n')..'\n\n'..text('Vorschau: deaktivierte Auslöseprofile (0,75 m halbe Länge / 1 m halbe Breite, ungedreht) vorbereiten. Keine automatische Ausführung. Unbekannte/Lageraktionen bleiben deaktiviert. Liste: sgInteractionDiscovery.',
        'Preview: prepare disabled activation profiles (0.75 m half-length / 1 m half-width, no rotation). No automatic execution. Unknown/storage actions remain disabled. Full list: sgInteractionDiscovery.')
    self.shown=true; self.forcePrompt=false
    local revision,epoch=self.revision,self.epoch
    YesNoDialog.show(function(_,yes)
        if self.disposed or epoch~=self.epoch then return end
        if g_server~=nil then self:command(yes and 'YES' or 'NO',revision,epoch,nil)
        elseif g_client~=nil then g_client:getServerConnection():sendEvent(SGInteractionDiscoveryRequestEvent.new(yes and 'YES' or 'NO',revision,epoch)) end
        self.activationHintPending=true
    end,self,body)
end
function SmartGate:consoleInteractionDiscovery()
    local d=self.interactionDiscovery
    if d==nil then return 'Discovery unavailable' end
    for _,r in ipairs(sorted(d.records)) do print('[SmartGate][DISCOVERY] '..r.id..' '..r.kind..' configured='..tostring(r.configured==true)..' execution=DISABLED '..r.name) end
    d:request('OPEN'); return 'Read-only catalogue; native actions were not executed'
end
SGInteractionDiscoveryRequestEvent={}; local Request_mt=Class(SGInteractionDiscoveryRequestEvent,Event); InitEventClass(SGInteractionDiscoveryRequestEvent,'SGInteractionDiscoveryRequestEvent')
function SGInteractionDiscoveryRequestEvent.new(op,revision,epoch) local e=Event.new(Request_mt); e.op,e.revision,e.epoch=op,revision,epoch; return e end
function SGInteractionDiscoveryRequestEvent.emptyNew() return Event.new(Request_mt) end
function SGInteractionDiscoveryRequestEvent:writeStream(s) streamWriteString(s,self.op); streamWriteInt32(s,self.revision); streamWriteString(s,self.epoch) end
function SGInteractionDiscoveryRequestEvent:readStream(s,c)
    self.op=streamReadString(s); self.revision=streamReadInt32(s); self.epoch=streamReadString(s)
    if g_server~=nil and c~=nil and call(c,'getIsServer')==false then local d=g_smartGate.interactionDiscovery; if not d:command(self.op,self.revision,self.epoch,c) then d:broadcast(c) end end
end
SGInteractionDiscoveryStateEvent={}; local State_mt=Class(SGInteractionDiscoveryStateEvent,Event); InitEventClass(SGInteractionDiscoveryStateEvent,'SGInteractionDiscoveryStateEvent')
function SGInteractionDiscoveryStateEvent.new(state) local e=Event.new(State_mt); e.state=state; return e end
function SGInteractionDiscoveryStateEvent.emptyNew() return Event.new(State_mt) end
function SGInteractionDiscoveryStateEvent:writeStream(s)
    local v=self.state; streamWriteString(s,v.epoch); streamWriteInt32(s,v.revision)
    streamWriteBool(s,v.completed); streamWriteBool(s,v.dismissed); streamWriteBool(s,v.auto); streamWriteUInt16(s,#v.records)
    for _,r in ipairs(v.records) do for _,f in ipairs({'id','source','name','kind'}) do streamWriteString(s,r[f]) end; streamWriteString(s,r.present or 'UNKNOWN'); streamWriteBool(s,r.configured); streamWriteBool(s,finite(r.x) and finite(r.z)); if finite(r.x) and finite(r.z) then streamWriteFloat32(s,r.x); streamWriteFloat32(s,r.z) end; if r.configured then for _,f in ipairs(PROFILE) do streamWriteFloat32(s,r[f]) end end end
end
function SGInteractionDiscoveryStateEvent:readStream(s,c)
    local v={epoch=streamReadString(s),revision=streamReadInt32(s),completed=streamReadBool(s),dismissed=streamReadBool(s),auto=streamReadBool(s),records={}}
    local count=streamReadUInt16(s)
    if count>LIMIT then return end
    for i=1,count do local r={}; for _,f in ipairs({'id','source','name','kind'}) do r[f]=streamReadString(s) end; r.present=streamReadString(s); r.configured=streamReadBool(s); if streamReadBool(s) then r.x=streamReadFloat32(s); r.z=streamReadFloat32(s) end; if r.configured then for _,f in ipairs(PROFILE) do r[f]=streamReadFloat32(s) end end; v.records[i]=r end
    if g_server==nil and call(c,'getIsServer')==true then g_smartGate.interactionDiscovery:receive(v) end
end
local oldLoad=SmartGate.loadMap
function SmartGate:loadMap(...)
    if self.interactionDiscovery~=nil then self.interactionDiscovery:dispose() end
    self.interactionDiscovery=D.new(self); oldLoad(self,...); self.interactionDiscovery:start()
    if g_server==nil and g_client~=nil then self.interactionDiscovery:request('STATE') end
end
local oldStart=SmartGate.onStartMission
function SmartGate:onStartMission(...)
    oldStart(self,...)
    if self.interactionDiscovery~=nil then self.interactionDiscovery:onMissionStarted() end
end
local oldRescan=SmartGate.rescan
function SmartGate:rescan(...)
    local result=oldRescan(self,...)
    if self.interactionDiscovery~=nil then self.interactionDiscovery:tryInitial() end
    return result
end
local oldDraw=SmartGate.draw
function SmartGate:draw(...) oldDraw(self,...); if self.interactionDiscovery~=nil then self.interactionDiscovery:maybePrompt() end end
local oldDelete=SmartGate.deleteMap
function SmartGate:deleteMap(...)
    oldDelete(self,...)
    if self.interactionDiscovery~=nil then self.interactionDiscovery:dispose() end
end
g_smartGate.interactionDiscovery=D.new(g_smartGate)

-- Independent lifecycle listener: do not rely on late replacement of a callback
-- already registered by the base SmartGate file. All state stays in the same D.
D.Listener={}
function D.Listener:loadMap()
    local owner=g_smartGate
    if owner==nil then return end
    local d=owner.interactionDiscovery
    local fresh=d==nil or d.disposed or (d.mission~=nil and d.mission~=g_currentMission)
    if fresh then
        if d~=nil then d:dispose() end
        d=D.new(owner); owner.interactionDiscovery=d
        if g_server~=nil then owner:loadConfig() end
    end
    d:start()
    if g_server==nil and g_client~=nil then d:request('STATE') end
end
function D.Listener:draw()
    local d=g_smartGate~=nil and g_smartGate.interactionDiscovery
    if d~=nil and not d.disposed then d:maybePrompt() end
end
function D.Listener:deleteMap()
    local d=g_smartGate~=nil and g_smartGate.interactionDiscovery
    if d~=nil then d:dispose() end
end
addModEventListener(D.Listener)
