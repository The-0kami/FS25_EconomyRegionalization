-- Agriculture Science settings host, protocol 1.
-- Identical in APS and L.E.G.S.; no third mod, foreign templates or class hooks.
-- The native menu instance is the rendezvous across GIANTS' isolated mod environments.
AgricultureScienceSettings = {}
local API = AgricultureScienceSettings
local directory = g_currentModDirectory or ""
local KEY = "agricultureScienceSettingsV1"
local applyView, updateNavigation, resizeContent
local function lang(de, en) return tostring(g_languageShort or ""):lower() == "de" and de or en end
local function helpText(element)
    return element ~= nil and element.toolTipText or ""
end
local function contains(element, x, y)
    return element ~= nil and element:getIsVisible() and element.absPosition ~= nil and element.absSize ~= nil
        and x >= element.absPosition[1] and x <= element.absPosition[1] + element.absSize[1]
        and y >= element.absPosition[2] and y <= element.absPosition[2] + element.absSize[2]
end
local function bindHelp(element, target)
    if element.toolTipText ~= nil then element.toolTipElement = target end
    for _, child in ipairs(element.elements or {}) do
        -- The old native inline tooltip must not render beside the scroll rows.
        if child.name == "tooltip" then child:setVisible(false) end
        bindHelp(child, target)
    end
end
local Frame, Frame_mt
if TabbedMenuFrameElement ~= nil then
    Frame = {}
    Frame_mt = Class(Frame, TabbedMenuFrameElement)
    function Frame.new()
        return TabbedMenuFrameElement.new(nil, Frame_mt)
    end
    function Frame:getMainElementSize() return self.elements[1].size end
    function Frame:getMainElementPosition() return self.elements[1].absPosition end
    function Frame:onFrameOpen()
        TabbedMenuFrameElement.onFrameOpen(self)
        self:updateAbsolutePosition()
        if self.host ~= nil then
            resizeContent(self.host)
            applyView(self.host, self.host.category or "OVERVIEW", true)
        end
    end
    function Frame:selectView(category) return applyView(self.host, category, true) end
    function Frame:onFrameClose()
        if self.asHelpText ~= nil then self.asHelpText:setText("") end
        TabbedMenuFrameElement.onFrameClose(self)
    end
    function Frame:mouseEvent(x, y, isDown, isUp, button, used)
        local result = TabbedMenuFrameElement.mouseEvent(self, x, y, isDown, isUp, button, used)
        local host = self.host
        if host ~= nil and host.category == "OVERVIEW" then
            local reason
            for _, card in ipairs({self.asCardAPS,self.asCardLEGS,self.asCardASS}) do
                if card.disabled and contains(card,x,y) then reason=card.toolTipText; break end
            end
            self.asOverviewHint:setText(reason or self.asOverviewDefaultHint or "")
        elseif host ~= nil and host.layout ~= nil then
            local text
            if contains(host.layout, x, y) then
                for _, row in ipairs(host.layout.elements) do
                    if row.visible and contains(row, x, y) then text = helpText(row); break end
                end
            end
            if text == nil then
                local focused = FocusManager ~= nil and FocusManager:getFocusedElement() or nil
                text = focused ~= nil and focused.toolTipElement == self.asHelpText
                    and focused:getIsVisible() and helpText(focused) or ""
            end
            self.asHelpText:setText(text)
        end
        return result -- presentation only; never consume an additional input
    end
end

-- A.S.S. is currently delivered inside APS, not as an invented standalone mod.
-- Session load state and a completed GUI section are separate prerequisites.
local MODULE_MODS = {APS="FS25_APS_AgricultureScience", LEGS="FS25_SmartGate_AgricultureScience",
    ASS="FS25_APS_AgricultureScience"}
-- Keep installed identity separate from proof of loading in this session.
local function modPresence(category)
    local name=MODULE_MODS[category]
    local flag
    if type(g_modIsLoaded)=="table" then flag=g_modIsLoaded[name] end
    local hasLoadInfo=type(g_modIsLoaded)=="table" and (flag==nil or type(flag)=="boolean")
    local known,installed=false,false
    if name~=nil and g_modManager~=nil and type(g_modManager.getModByName)=="function" then
        local ok,mod=pcall(g_modManager.getModByName,g_modManager,name)
        if ok and (mod==nil or type(mod)=="table") then known,installed=true,mod~=nil end
    end
    return {loaded=flag==true,hasLoadInfo=hasLoadInfo,known=known,installed=installed}
end
local function missingDependency(label, presence)
    if presence.known and not presence.installed then
        return label..lang(": nicht installiert.",": not installed.")
    elseif presence.hasLoadInfo then
        return label..(presence.installed and
            lang(": installiert, aber in dieser Sitzung nicht geladen.",": installed but not loaded in this session.") or
            lang(": in dieser Sitzung nicht geladen; Installationsstatus unbekannt.",": not loaded in this session; installation status unknown."))
    end
    return label..lang(": Ladestatus dieser Sitzung nicht zuverlässig feststellbar.",": this session's load status cannot be determined reliably.")
end
local function moduleState(host, category)
    if category == "AUDIO" then category="APS" end
    local section=host.sections[category]
    local ready=section~=nil and section.before==nil and #section.rows>0
    if category=="ASS" then
        local aps,legs=modPresence("APS"),modPresence("LEGS")
        if not aps.loaded or not legs.loaded then
            local reason
            if not aps.loaded and not legs.loaded then reason=lang("A.S.S. benötigt APS und L.E.G.S.","A.S.S. requires APS and L.E.G.S.")
            elseif not aps.loaded then reason=lang("A.S.S. benötigt APS.","A.S.S. requires APS.")
            else reason=lang("A.S.S. benötigt L.E.G.S.","A.S.S. requires L.E.G.S.") end
            if not aps.loaded then reason=reason.." "..missingDependency("APS",aps) end
            if not legs.loaded then reason=reason.." "..missingDependency("L.E.G.S.",legs) end
            local absent=(not aps.loaded and aps.known and not aps.installed) or (not legs.loaded and legs.known and not legs.installed)
            return absent and "NOT_INSTALLED" or "INACTIVE",reason
        end
        if not ready then
            return "INACTIVE",lang("A.S.S. hat noch keine verfügbare Einstellungsansicht.","A.S.S. does not yet have an available settings view.")
        end
        return "AVAILABLE",lang("Einstellungen öffnen","Open settings")
    end
    local presence=modPresence(category)
    local loaded,hasLoadInfo,known,installed=presence.loaded,presence.hasLoadInfo,presence.known,presence.installed
    if ready and (loaded or not hasLoadInfo) then
        return "AVAILABLE",lang("Einstellungen öffnen", "Open settings")
    end
    if not loaded and not ready and known and not installed then
        return "NOT_INSTALLED",lang("Das Modul ist nicht installiert.","The module is not installed.")
    end
    if loaded or ready then
        if hasLoadInfo and not loaded then
            return "INACTIVE",lang("Das Modul ist in dieser Spielsitzung nicht aktiv.","The module is not active in this session.")
        end
        return "INACTIVE",lang("Das Modul ist geladen; seine Einstellungen sind noch nicht verfügbar.","The module is loaded; its settings are not available yet.")
    end
    return "INACTIVE",installed and
        lang("Installiert, aber in dieser Spielsitzung nicht aktiv.","Installed but not active in this session.") or
        lang("Verfügbarkeit derzeit nicht zuverlässig feststellbar.","Availability cannot currently be determined reliably.")
end
local function available(host, category)
    if category == "OVERVIEW" then return true end
    return moduleState(host,category)=="AVAILABLE"
end

local function link(source, direction, target)
    if source ~= nil and FocusManager ~= nil and FocusManager.linkElements ~= nil then
        FocusManager:linkElements(source, direction, target)
    end
end

updateNavigation = function(host)
    local f = host.frame
    local aps, legs = available(host, "APS"), available(host, "LEGS")
    f.asNavAPS:setDisabled(not aps); f.asNavAudio:setDisabled(not aps); f.asNavLEGS:setDisabled(not legs); f.asNavASS:setDisabled(not available(host,"ASS"))
    for _, id in ipairs({"APS","LEGS","ASS"}) do
        local card,status=f["asCard"..id],f["asStatus"..id]
        local state,reason=moduleState(host,id)
        card.asModuleState,card.asModuleCategory,card.toolTipText=state,id,reason
        card:setDisabled(state~="AVAILABLE")
        status:setText(state=="AVAILABLE" and reason or state=="NOT_INSTALLED" and
            lang("Nicht installiert","Not installed") or lang("Nicht aktiv","Inactive"))
    end
    local nav = {f.asNavOverview}
    if aps then table.insert(nav, f.asNavAPS) end
    if legs then table.insert(nav, f.asNavLEGS) end
    if available(host,"ASS") then table.insert(nav, f.asNavASS) end
    if aps then table.insert(nav, f.asNavAudio) end
    local current = host.buttons[host.category] or f.asNavOverview
    for key, button in pairs(host.buttons) do button:setSelected(key == host.category) end
    for i, button in ipairs(nav) do
        link(button, FocusManager.LEFT, nav[i-1]); link(button, FocusManager.RIGHT, nav[i+1])
        link(button, FocusManager.TOP, nil)
    end
    local controls = {}
    if host.category == "OVERVIEW" then
        if aps then table.insert(controls, f.asCardAPS) end
        if legs then table.insert(controls, f.asCardLEGS) end
        if available(host,"ASS") then table.insert(controls,f.asCardASS) end
        for i, card in ipairs(controls) do
            link(card, FocusManager.LEFT, controls[i-1]); link(card, FocusManager.RIGHT, controls[i+1])
            link(card, FocusManager.TOP, host.buttons[card.asModuleCategory] or f.asNavOverview)
            link(card, FocusManager.BOTTOM, f.asNavOverview)
        end
    elseif host.layout ~= nil then
        for _, row in ipairs(host.layout.elements) do
            if row.visible then
                for _, control in ipairs(row.elements or {}) do
                    if type(control.onClickCallback) == "function" and control.disabled ~= true then
                        table.insert(controls, control)
                    end
                end
            end
        end
        -- Native scrolling layout handles focus scrolling. Explicit boundary
        -- links make the fixed navigation reachable without mouse input.
        for i, control in ipairs(controls) do
            link(control, FocusManager.TOP, controls[i-1] or current)
            link(control, FocusManager.BOTTOM, controls[i+1] or current)
        end
    end
    for _, button in ipairs(nav) do link(button, FocusManager.BOTTOM, controls[1] or current) end
    host.firstControl = controls[1] or current
end

resizeContent = function(host)
    local f = host.frame
    -- Derive the current pixel scale from an actual native-sized element;
    -- avoid treating screen pixels as normalized GUI coordinates.
    local headerSize, canvasSize = f.asHeader.absSize, f.asCanvas.absSize
    if headerSize ~= nil and canvasSize ~= nil and headerSize[1] > 0 and headerSize[2] > 0 and canvasSize[1] > 0 then
        local pxY = headerSize[2] / 220
        local pxX = headerSize[1] / 660
        local width = math.max(800 * pxX, canvasSize[1] - 40 * pxX)
        local totalHeight = math.max(260 * pxY, canvasSize[2] - 306 * pxY)
        local height = totalHeight - 96 * pxY
        f.asContent:setSize(width, height)
        if host.layout ~= nil then host.layout:setSize(width, height) end
        f.asHelpPanel:setPosition(f.asContent.position[1], f.asContent.position[2] - height - 12 * pxY)
        f.asHelpPanel:setSize(width, 84 * pxY)
        f.asHelpText:setSize(width - 40 * pxX, 64 * pxY)
    end
end

applyView = function(host, category, focus)
    if host == nil then return false end
    if not available(host, category) then category = "OVERVIEW" end
    if host.layout ~= nil and host.category ~= nil and host.category ~= "OVERVIEW" then
        host.scrollOffsets[host.category] = host.layout.contentOffsetY or 0
    end
    host.category = category
    host.frame.asOverview:setVisible(category == "OVERVIEW")
    host.frame.asContent:setVisible(category ~= "OVERVIEW")
    host.frame.asHelpPanel:setVisible(category ~= "OVERVIEW")
    host.frame.asHelpText:setText("")
    host.frame.asOverviewHint:setText(host.frame.asOverviewDefaultHint or "")
    if host.layout ~= nil then
        for _, row in ipairs(host.layout.elements) do row:setVisible(row.asMenuCategory == category) end
        host.layout:invalidateLayout() -- honor hidden rows; no blank gaps
        host.layout:updateAbsolutePosition()
        if host.layout.scrollTo ~= nil then host.layout:scrollTo(host.scrollOffsets[category] or 0) end
    end
    host.frame.asPageHint:setText(category == "OVERVIEW" and "" or
        lang("Scrollen / Steuerkreuz: Einstellungen   |   Zurück: Übersicht", "Scroll / D-pad: settings   |   Back: overview"))
    updateNavigation(host)
    local f = host.frame
    if f.setMenuButtonInfo ~= nil and InputAction ~= nil then
        if category == "OVERVIEW" then
            -- Dirty-button updates call assignMenuButtonInfo directly, without
            -- the page-open default fallback. Always supply a real table.
            -- An omitted callback preserves the native MENU_BACK/exit action.
            f:setMenuButtonInfo({{inputAction=InputAction.MENU_BACK}})
        else
            f:setMenuButtonInfo({{inputAction=InputAction.MENU_BACK,
                text=lang("Übersicht", "Overview"), callback=function() f:selectView("OVERVIEW") end}})
        end
        f:setMenuButtonInfoDirty()
    end
    if focus and FocusManager ~= nil then
        FocusManager:setGui(f.name)
        FocusManager:setFocus(host.firstControl)
    end
    return true
end

local function restoreFocus(context)
    if context ~= nil and FocusManager ~= nil then
        FocusManager:setGui(context.gui)
        if context.element ~= nil then FocusManager:setFocus(context.element) end
    end
end
local function enterFocus(frame)
    if FocusManager == nil then return nil end
    local context = {gui=FocusManager.currentGui, element=FocusManager:getFocusedElement()}
    FocusManager:setGui(frame.name)
    return context
end
local function refresh(host)
    applyView(host, host.category or "OVERVIEW", false)
end

local function obtainHost()
    if g_currentMission == nil or g_dedicatedServer ~= nil or g_gui == nil or Frame == nil then return nil end
    local menu = g_inGameMenu
    if menu == nil or menu.pagingElement == nil or menu.pagingTabList == nil
        or menu.registerPage == nil or menu.addPageTab == nil or menu.unregisterPage == nil
        or GuiElement == nil or menu.pagingElement.getPageIdByElement == nil then return nil end
    local host = menu[KEY]
    if host ~= nil then
        -- Fail closed on a future incompatible host, rather than register a second page.
        if host.protocol ~= 1 or host.designVersion ~= 1 then return nil end
        return host
    end
    -- A malformed GUI must not be rebuilt by both participants every 500 ms.
    -- Share a bounded failure budget on the menu, scoped to this mission.
    -- Preflight readiness checks below remain cheap and do not consume it.
    local failure = menu.asSettingsRegistrationFailureV1
    if failure ~= nil and failure.mission ~= g_currentMission then
        menu.asSettingsRegistrationFailureV1 = nil
        failure = nil
    end
    if failure ~= nil then
        if failure.attempts >= 3 then return nil end
        if type(g_time) == "number" and failure.retryAt ~= nil and g_time < failure.retryAt then return nil end
    end
    -- During map loading the menu object may exist before its native pages are
    -- ready. Never rebuild the tab list while one of those mappings is absent.
    for _, page in ipairs(menu.pageFrames or {}) do
        local id = menu.pagingElement:getPageIdByElement(page)
        if id == nil or menu.pagingElement:getPageById(id) == nil then return nil end
    end
    local context = enterFocus({name="AgricultureScienceSettingsV1"})
    local frame = Frame.new()
    local root
    local ok, problem = pcall(function()
        if not g_gui.asDesignProfilesLoadedV1 then
            if not g_gui:loadProfiles(directory .. "gui/AS_Profiles.xml") then error("own profiles unavailable") end
            g_gui.asDesignProfilesLoadedV1 = true
        end
        root = g_gui:loadGui(directory .. "gui/AS_Settings.xml", "AgricultureScienceSettingsV1", frame, true)
        if root == nil then return end
        if frame.asContent == nil or frame.asLayoutTemplate == nil or frame.asBinaryTemplate == nil
            or frame.asMultiTemplate == nil or frame.asSectionTemplate == nil or frame.asButtonTemplate == nil then
            error("incomplete GUI")
        end
        if frame.asNavOverview == nil or frame.asOverview == nil or frame.asCanvas == nil
            or frame.asHelpPanel == nil or frame.asHelpText == nil then error("navigation/help unavailable") end
        host = {protocol=1, designVersion=1, frame=frame, sections={}, mission=nil,
            category="OVERVIEW", scrollOffsets={}, buttons={OVERVIEW=frame.asNavOverview,
            APS=frame.asNavAPS, LEGS=frame.asNavLEGS, ASS=frame.asNavASS, AUDIO=frame.asNavAudio}}
        frame.host = host
        for key, button in pairs(host.buttons) do
            local category = key
            button.target = frame; button.fitToContent = false; button:setHandleFocus(true)
            button.onClickCallback = function() frame:selectView(category) end
        end
        frame.asCardAPS.onClickCallback = function() frame:selectView("APS") end
        frame.asCardLEGS.onClickCallback = function() frame:selectView("LEGS") end
        frame.asCardASS.onClickCallback = function() frame:selectView("ASS") end
        for _, card in ipairs({frame.asCardAPS, frame.asCardLEGS,frame.asCardASS}) do
            card.target = frame
            card:setHandleFocus(true)
        end
        frame.asCardAPS.fitToContent, frame.asCardLEGS.fitToContent, frame.asCardASS.fitToContent = false, false, false
        frame.asNavOverview:setText(lang("Übersicht", "Overview")); frame.asNavAPS:setText("A.P.S.")
        frame.asNavLEGS:setText("L.E.G.S."); frame.asNavASS:setText("A.S.S."); frame.asNavAudio:setText("Audio")
        frame.asIntro:setText(lang("Automation für deinen Hof.\nWähle einen Bereich und passe die vorhandenen\nEinstellungen an deine Arbeitsweise an.",
            "Automation for your farm.\nChoose a section and adjust the existing\nsettings to the way you work."))
        frame.asDescriptionAPS:setText(lang("Parkvorgänge und AutoDrive-Übernahme.\nGlobale Einstellungen für APS.", "Parking and AutoDrive takeover.\nGlobal APS preferences."))
        frame.asDescriptionLEGS:setText(lang("Tore und Sicherheitsbereiche.\nGlobale L.E.G.S.-Einstellungen.", "Gates and safety zones.\nGlobal L.E.G.S. preferences."))
        frame.asLongNameAPS:setText("Advanced Parking Sequence")
        frame.asLongNameLEGS:setText("Logical Entrance Guidance System")
        frame.asLongNameASS:setText("Autonomous Service Supervisor")
        frame.asDescriptionASS:setText(lang("Wäsche vor dem Parken.\nService-Einstellungen für APS-Aufträge.", "Wash before parking.\nService preferences for APS jobs."))
        frame.asOverviewDefaultHint=lang(
            "Musik und Sprachausgabe findest du im Bereich Audio.\nTore und Serviceplätze bearbeitest du weiterhin im separaten L.E.G.S.-Konfigurationsmodus.",
            "Music and voice preferences are in Audio.\nGates and service bays are still edited in the separate L.E.G.S. configuration mode.")
        frame.asOverviewHint:setText(frame.asOverviewDefaultHint)
        local fullUVs = {0,0, 0,1, 1,0, 1,1}
        for _, artwork in ipairs({{frame.asHeader,"gui/art/header.dds"}, {frame.asIconAPS,"gui/art/aps.dds"},
            {frame.asIconLEGS,"gui/art/legs.dds"}, {frame.asIconASS,"gui/art/ass.dds"}}) do
            artwork[1]:setImageFilename(directory .. artwork[2])
            artwork[1]:setImageUVs(nil, unpack(fullUVs))
        end
        frame.asHeader:setImageUVs(nil, 0,1-683/1024, 0,1, 1,1-683/1024, 1,1)
        root.title = "Agriculture Science"
        local position = #menu.pageFrames + 1
        -- Paging identifies the controller, not its inner XML root. Attach that
        -- controller once, then explicitly create one titled page. Calling the
        -- base addElement avoids PagingElement's second, automatically named page.
        GuiElement.addElement(menu.pagingElement, frame)
        menu.pagingElement:addPage(string.upper(frame.name), frame, "Agriculture Science", position)
        menu:registerPage(frame, position, function()
            return host.mission ~= nil and host.mission == g_currentMission and next(host.sections) ~= nil
        end)
        -- addPageTab consumes four UV corner pairs, not an x/y/width/height
        -- rectangle. The clipped tab-list renderer reads all eight values.
        menu:addPageTab(frame, directory .. "gui/art/suite.dds", {0,0, 0,1, 1,0, 1,1})
        local id = menu.pagingElement:getPageIdByElement(frame)
        if id == nil or menu.pagingElement:getPageById(id) == nil then error("controller paging entry missing") end
        menu:rebuildTabList()
        menu[KEY] = host
    end)
    restoreFocus(context)
    if not ok then
        menu.asSettingsRegistrationFailureV1 = {mission=g_currentMission,
            attempts=(failure ~= nil and failure.attempts or 0) + 1,
            retryAt=type(g_time) == "number" and g_time + 10000 or nil}
        -- Do not propagate a presentation failure into loadMap / streaming.
        -- Roll back our own controller and paging entry, leaving native pages.
        menu:unregisterPage(Frame)
        local ownedRoot = root or frame.elements[1]
        if frame.name ~= nil and ownedRoot ~= nil and g_gui.frames ~= nil
            and g_gui.frames[frame.name] == ownedRoot then g_gui.frames[frame.name] = nil end
        frame:delete()
        if menu.asSettingsLastRegistrationError ~= tostring(problem) then
            menu.asSettingsLastRegistrationError = tostring(problem)
            print("[AgricultureScience][SETTINGS] page registration deferred: " .. tostring(problem))
        end
        return nil
    end
    if root == nil then return nil end
    menu.asSettingsLastRegistrationError = nil
    menu.asSettingsRegistrationFailureV1 = nil
    print("[AgricultureScience][SETTINGS] independent menu page registered (protocol 1)")
    return host
end

local function reset(host, mission)
    if host.layout ~= nil then host.layout:delete() end
    host.layout, host.sections, host.mission = nil, {}, mission
    host.category, host.scrollOffsets = "OVERVIEW", {}
    host.frame.asHelpText:setText("")
    host.frame.asHelpPanel:setVisible(false)
    if mission == nil then return end
    local context = enterFocus(host.frame)
    local layout = host.frame.asLayoutTemplate:clone(host.frame.asContent)
    layout:onGuiSetupFinished()
    layout.asTemplates = {
        binary=host.frame.asBinaryTemplate, multi=host.frame.asMultiTemplate,
        section=host.frame.asSectionTemplate, button=host.frame.asButtonTemplate
    }
    host.layout = layout
    applyView(host, "OVERVIEW", false)
    restoreFocus(context)
end

-- Extension point: stable participant id and existing settings object. A.S.S.
-- can register a section later; no placeholder or unfinished controls are shown.
function API.getLayout(id, owner)
    local host = obtainHost()
    if host == nil then return nil end
    if host.mission ~= g_currentMission then reset(host, g_currentMission) end
    local section = host.sections[id]
    if section ~= nil and section.owner ~= owner then
        for _, row in ipairs(section.rows) do row:delete() end
        host.sections[id] = nil
        refresh(host)
    end
    return host.layout
end

-- Section construction is a transaction: failed attempts remove their rows and
-- focus entries. Retrying late GUI initialization cannot leave duplicate controls.
function API.beginSection(id, owner)
    local layout = API.getLayout(id, owner)
    if layout == nil then return nil end
    local host = g_inGameMenu[KEY]
    local section = host.sections[id]
    if section ~= nil then
        for _, row in ipairs(section.rows) do row:delete() end
    end
    local before = {}
    for _, row in ipairs(layout.elements) do before[row] = true end
    host.sections[id] = {owner=owner, rows={}, before=before, category=id, context=enterFocus(host.frame)}
    return layout
end

-- Switch category boundaries while the existing settings builder runs. This
-- tags the already-created rows without changing their callbacks or values.
function API.setCategory(id, owner, category)
    local host = g_inGameMenu ~= nil and g_inGameMenu[KEY] or nil
    local section = host ~= nil and host.sections[id] or nil
    if section == nil or section.owner ~= owner or section.before == nil then return end
    for _, row in ipairs(host.layout.elements) do
        if not section.before[row] and row.asMenuCategory == nil then row.asMenuCategory = section.category end
    end
    section.category = category
end

function API.finishSection(id, owner, success)
    local host = g_inGameMenu ~= nil and g_inGameMenu[KEY] or nil
    local section = host ~= nil and host.sections[id] or nil
    if section == nil or section.owner ~= owner or section.before == nil then return end
    for _, row in ipairs(host.layout.elements) do
        if not section.before[row] then
            row.asMenuCategory = row.asMenuCategory or section.category
            bindHelp(row, host.frame.asHelpText)
            table.insert(section.rows, row)
        end
    end
    section.before = nil
    if not success then
        for _, row in ipairs(section.rows) do row:delete() end
        host.sections[id] = nil
    else
        -- Stable display order, regardless of mod load order. Other future
        -- participants follow lexically; no shared numeric category indices.
        local ids = {}
        for key in pairs(host.sections) do table.insert(ids, key) end
        table.sort(ids)
        for _, key in ipairs(ids) do
            for _, row in ipairs(host.sections[key].rows) do host.layout:addElement(row) end
        end
    end
    refresh(host)
    restoreFocus(section.context)
    section.context = nil
end

-- Native menu pages live across missions. Keep one registered page but delete
-- all mission controls/callbacks. Next mission gets a new layout identity.
local listener = {}
function listener:deleteMap()
    local host = g_inGameMenu ~= nil and g_inGameMenu[KEY] or nil
    if host ~= nil and host.protocol == 1 then reset(host, nil) end
end
if addModEventListener ~= nil then addModEventListener(listener) end
