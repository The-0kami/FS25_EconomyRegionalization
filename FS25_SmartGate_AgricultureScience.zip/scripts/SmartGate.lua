-- FS25_SmartGate_AgricultureScience
-- Agriculture Science release 0.1.2.9
-- Gate discovery portions are independently adapted from FS25_OpenTheGate
-- (c) 2026 bisdat, MPL-2.0. See LICENSE-MPL-2.0.txt and NOTICE.txt.

SmartGate = {}
SmartGate_mt = Class(SmartGate)

local MOD_DIR = g_currentModDirectory
local MODE_DISABLED = 0
local MODE_ALL = 1
local MODE_VEHICLES = 2
local MODE_PLAYERS = 3
local OBJECT_GATE = 0
local OBJECT_INTERACTION = 1

local AUTO_OPEN_DISTANCE = 11.0
local AUTO_CLOSE_DISTANCE = 14.0
local CONFIG_ZONE_LENGTH = 4.0
local CONFIG_ZONE_HALF_WIDTH = 3.5
local CONFIG_FALLBACK_RADIUS = 12.0
local DEFAULT_TRIGGER_SIDE_DISTANCE = 5.0
local DEFAULT_SAFETY_DEPTH = 4.5
local DEFAULT_SAFETY_HALF_WIDTH = 4.5
local DEFAULT_SAFETY_CLEAR_DELAY_MS = 1800
local VISUAL_TRIGGER_R, VISUAL_TRIGGER_G, VISUAL_TRIGGER_B = 0.15, 0.85, 1.00
local VISUAL_CLOSE_R, VISUAL_CLOSE_G, VISUAL_CLOSE_B = 0.72, 0.35, 1.00
local VISUAL_CONFIG_R, VISUAL_CONFIG_G, VISUAL_CONFIG_B = 1.00, 0.75, 0.15
local VISUAL_SAFETY_R, VISUAL_SAFETY_G, VISUAL_SAFETY_B = 1.00, 0.20, 0.20
local STATE_SYNC_INTERVAL_MS = 15000
local DOUBLE_HONK_MS = 900
local SHORT_HONK_MAX_MS = 650
local SCAN_INTERVAL_MS = 350
local GATE_RESCAN_MS = 10000
local AD_PREOPEN_DISTANCE = 55.0
local AD_PREOPEN_GATE_DEPTH = 3.5
local AD_PREOPEN_MIN_HALF_WIDTH = 5.5
local AD_PREOPEN_MAX_POINTS = 120
local MARKER_TIME_MS = 5000
local BLACKLIST_TEXT = "BLACKLIST"
local DEBUG_LOG = false
local CONFIG_RESOLVE_MAX_DISTANCE = 8.0


local PANEL_LENGTH_CHOICES = {0.5, 0.75, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 8, 10, 11, 12, 14, 16, 18, 20, 22, 24}
local PANEL_WIDTH_CHOICES  = {0.5, 0.75, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 8, 10, 12}
local PANEL_DELAY_CHOICES = {500, 1000, 1500, 1800, 2000, 2500, 3000, 4000, 5000}

local CONFIG_PANEL_X = 0.735
local CONFIG_PANEL_Y = 0.835
local CONFIG_PANEL_W = 0.245
local CONFIG_PANEL_ROW_H = 0.030

local MODE_TEXT_DE = {
    [MODE_DISABLED] = "DEAKTIVIERT",
    [MODE_ALL] = "FAHRZEUGE + PERSONEN",
    [MODE_VEHICLES] = "NUR FAHRZEUGE",
    [MODE_PLAYERS] = "NUR PERSONEN"
}

local function debugLog(fmt, ...)
    if not DEBUG_LOG then return end
    if select("#", ...) > 0 then
        print(string.format("[SmartGate][DEBUG] " .. fmt, ...))
    else
        print("[SmartGate][DEBUG] " .. tostring(fmt))
    end
end

local function showNotification(text, duration, notificationType)
    local mission = g_currentMission
    if mission ~= nil and mission.hud ~= nil and mission.hud.addSideNotification ~= nil then
        mission.hud:addSideNotification(notificationType or FSBaseMission.INGAME_NOTIFICATION_OK, text, duration or 4000)
    end
end

local function nowMs()
    if g_time ~= nil then return g_time end
    return math.floor(os.clock() * 1000)
end

local function validNode(node)
    return node ~= nil and node ~= 0 and entityExists(node)
end

local function sqrDistance2D(ax, az, bx, bz)
    local dx, dz = ax - bx, az - bz
    return dx * dx + dz * dz
end

local function firstValidNode(...)
    for i = 1, select("#", ...) do
        local node = select(i, ...)
        if validNode(node) then return node end
    end
    return nil
end

local function getAnimatedObjectNode(animatedObject, owner)
    local controls = animatedObject ~= nil and animatedObject.controls or nil
    local node = firstValidNode(
        animatedObject ~= nil and animatedObject.triggerNode or nil,
        controls ~= nil and controls.triggerNode or nil,
        animatedObject ~= nil and animatedObject.node or nil,
        animatedObject ~= nil and animatedObject.rootNode or nil,
        animatedObject ~= nil and animatedObject.saveIdNode or nil,
        owner ~= nil and owner.rootNode or nil
    )
    if node ~= nil then return node end
    local animation = animatedObject ~= nil and animatedObject.animation or nil
    if animation ~= nil and animation.parts ~= nil then
        for _, part in pairs(animation.parts) do
            if part ~= nil and validNode(part.node) then return part.node end
        end
    end
    return nil
end

local function isOperable(animatedObject, extraName)
    if animatedObject == nil or animatedObject.animation == nil then return false end
    if type(animatedObject.setDirection) ~= "function" then return false end
    local triggerNode = animatedObject.triggerNode
    if not validNode(triggerNode) and animatedObject.controls ~= nil then
        triggerNode = animatedObject.controls.triggerNode
    end
    if not validNode(triggerNode) then return false end

    local animation = animatedObject.animation
    local duration = tonumber(animation.duration)
    local hasDuration = duration ~= nil and duration > 0
    local hasStateAndParts = animation.time ~= nil and animation.direction ~= nil and animation.parts ~= nil and next(animation.parts) ~= nil
    if not hasDuration and not hasStateAndParts then return false end
    if extraName == "fenceGate" then return true end

    local a = animatedObject.activatable
    local hasActivatable = a ~= nil and (type(a.onAnimationInputToggle) == "function" or type(a.run) == "function" or type(a.getIsActivatable) == "function")
    local c = animatedObject.controls
    local hasControls = c ~= nil and (c.posAction ~= nil or c.negAction ~= nil or c.posActionEventId ~= nil or c.negActionEventId ~= nil)
    local hasContract = type(animatedObject.getCanBeTriggered) == "function" or type(animatedObject.onActivateObject) == "function" or type(animatedObject.registerInteraction) == "function"
    return hasActivatable or hasControls or hasContract
end

local function makeLegacyGateId(node, owner, x, y, z)
    local ownerName = "map"
    if owner ~= nil then
        ownerName = tostring(owner.configFileName or owner.configFileNameClean or owner.typeName or owner.className or "placeable")
    end
    local nodeName = validNode(node) and tostring(getName(node) or "node") or "node"
    return string.format("%s|%s|%.2f|%.2f|%.2f", ownerName, nodeName, x or 0, y or 0, z or 0)
end

local function makeGateId(animatedObject, node, owner, x, y, z)
    local ownerName = "map"
    if owner ~= nil then
        ownerName = tostring(owner.configFileNameClean or owner.configFileName or owner.typeName or owner.className or "placeable")
    end
    local nodeName = validNode(node) and tostring(getName(node) or "node") or "node"
    local objectKey = animatedObject ~= nil and (animatedObject.saveId or animatedObject.id or animatedObject.name) or nil
    if objectKey ~= nil and tostring(objectKey) ~= "" then
        return string.format("%s|%s|%s", ownerName, tostring(objectKey), nodeName)
    end
    return makeLegacyGateId(node, owner, x, y, z)
end

local function getOwnerKey(owner)
    if owner == nil then return "map" end
    local value = owner.configFileNameClean or owner.configFileName or owner.typeName or owner.className or "placeable"
    return tostring(value):lower():gsub("\\", "/")
end

local function getNodeKey(node)
    if not validNode(node) then return "node" end
    return tostring(getName(node) or "node"):lower()
end

local function getGateDisplayName(animatedObject, owner, node)
    if owner ~= nil then
        if type(owner.getName) == "function" then
            local ok, name = pcall(owner.getName, owner)
            if ok and name ~= nil and tostring(name) ~= "" then return tostring(name) end
        end
        local candidates = {owner.name, owner.customName, owner.typeName, owner.className}
        for _, name in ipairs(candidates) do
            if name ~= nil and tostring(name) ~= "" then return tostring(name) end
        end
        local cfg = owner.configFileNameClean or owner.configFileName
        if cfg ~= nil and tostring(cfg) ~= "" then
            local clean = tostring(cfg):gsub("\\", "/")
            clean = clean:match("([^/]+)$") or clean
            clean = clean:gsub("%.xml$", "")
            if clean ~= "" then return clean end
        end
    end
    if animatedObject ~= nil then
        local candidates = {animatedObject.name, animatedObject.id, animatedObject.typeName}
        for _, name in ipairs(candidates) do
            if name ~= nil and tostring(name) ~= "" then return tostring(name) end
        end
    end
    if validNode(node) then
        local name = getName(node)
        if name ~= nil and tostring(name) ~= "" then return tostring(name) end
    end
    return "Unbekannter Trigger"
end

local function isDefaultExcludedOwner(owner)
    if owner == nil then return false end
    local values = {
        owner.configFileName, owner.configFileNameClean, owner.typeName, owner.className, owner.name, owner.customName
    }
    for _, value in ipairs(values) do
        if value ~= nil then
            local text = tostring(value):lower():gsub("\\", "/")
            if text:find("fs25_schneidwerklager_wobbytec", 1, true) ~= nil
                or text:find("schneidwerklager", 1, true) ~= nil
                or text:find("schneidewerklager", 1, true) ~= nil
                or text:find("cuttingstoragexp", 1, true) ~= nil then
                return true
            end
        end
    end
    return false
end

local function addGate(result, seen, animatedObject, owner, extraName, segment)
    if animatedObject == nil or seen[animatedObject] or not isOperable(animatedObject, extraName) then return end
    -- WobbyTec Schneidwerklager contains several animated storage controls which
    -- look like gates to generic AnimatedObject discovery. They are explicitly
    -- excluded: SmartGate must never operate or configure them.
    if isDefaultExcludedOwner(owner) then return end
    local node = getAnimatedObjectNode(animatedObject, owner)
    if not validNode(node) then return end
    local x, y, z = getWorldTranslation(node)
    if segment ~= nil and tonumber(segment.startPosX) ~= nil and tonumber(segment.endPosX) ~= nil then
        x = (segment.startPosX + segment.endPosX) * 0.5
        y = (segment.startPosY + segment.endPosY) * 0.5
        z = (segment.startPosZ + segment.endPosZ) * 0.5
    end
    -- Keep the marker anchored to the concrete gate trigger. Using a placeable
    -- root works for many vanilla buildings, but becomes ambiguous on modded
    -- halls with several gates because every gate then points to the building centre.
    local markerX, markerY, markerZ = x, y, z

    local forwardX, forwardZ = 0, 1
    local rightX, rightZ = 1, 0
    if validNode(node) then
        local fx, _, fz = localDirectionToWorld(node, 0, 0, 1)
        local fl = math.sqrt(fx*fx + fz*fz)
        if fl > 0.001 then
            forwardX, forwardZ = fx/fl, fz/fl
            rightX, rightZ = forwardZ, -forwardX
        end
    end
    seen[animatedObject] = true
    table.insert(result, {
        animatedObject = animatedObject,
        owner = owner,
        node = node,
        x = x, y = y, z = z,
        markerX = markerX, markerY = markerY, markerZ = markerZ,
        forwardX = forwardX, forwardZ = forwardZ,
        rightX = rightX, rightZ = rightZ,
        triggerOpenDistance = AUTO_OPEN_DISTANCE,
        triggerOpenHalfWidth = DEFAULT_TRIGGER_SIDE_DISTANCE,
        triggerCloseDistance = AUTO_CLOSE_DISTANCE,
        triggerCloseHalfWidth = DEFAULT_TRIGGER_SIDE_DISTANCE,
        triggerSideDistance = DEFAULT_TRIGGER_SIDE_DISTANCE, -- legacy compatibility
        safetyDepth = DEFAULT_SAFETY_DEPTH,
        safetyHalfWidth = DEFAULT_SAFETY_HALF_WIDTH,
        configDepth = CONFIG_ZONE_LENGTH,
        configHalfWidth = CONFIG_ZONE_HALF_WIDTH,
        axisSwapped = false,
        objectType = OBJECT_GATE,
        safetyClearDelayMs = DEFAULT_SAFETY_CLEAR_DELAY_MS,
        clearSince = nil,
        id = makeGateId(animatedObject, node, owner, x, y, z),
        legacyId = makeLegacyGateId(node, owner, x, y, z),
        ownerKey = getOwnerKey(owner),
        nodeKey = getNodeKey(node),
        displayName = getGateDisplayName(animatedObject, owner, node),
        mode = MODE_ALL,
        blacklisted = false,
        occupied = false,
        preOpenReserved = false,
        interactionLatched = false
    })
end

local function collectGates()
    local result = {}
    local seen = setmetatable({}, {__mode="k"})
    local mission = g_currentMission
    if mission == nil then return result end

    local placeables = mission.placeableSystem ~= nil and (mission.placeableSystem.placeables or mission.placeableSystem.placeablesById) or mission.placeables
    if placeables ~= nil then
        for _, p in pairs(placeables) do
            if p ~= nil and p.spec_animatedObjects ~= nil then
                for _, ao in pairs(p.spec_animatedObjects.animatedObjects or {}) do addGate(result, seen, ao, p, nil, nil) end
            end
            local fenceSpecs = { p ~= nil and p.spec_newFence or nil, p ~= nil and p.spec_fence or nil }
            for _, fenceSpec in pairs(fenceSpecs) do
                local segments = fenceSpec ~= nil and ((fenceSpec.fence ~= nil and fenceSpec.fence.segments) or fenceSpec.segments) or nil
                for _, segment in pairs(segments or {}) do
                    local containers = {segment, segment.gate, segment.fenceGate, segment.gateData, segment.object}
                    for _, c in pairs(containers) do
                        if c ~= nil then
                            if c.animatedObjects ~= nil then
                                for _, ao in pairs(c.animatedObjects) do addGate(result, seen, ao, p, "fenceGate", segment) end
                            end
                            if c.animatedObject ~= nil then addGate(result, seen, c.animatedObject, p, "fenceGate", segment) end
                        end
                    end
                end
            end
            if p ~= nil and p.animatedObjects ~= nil then
                for _, ao in pairs(p.animatedObjects) do addGate(result, seen, ao, p, nil, nil) end
            end
        end
    end

    local containers = {}
    if mission.animatedMapObjects ~= nil then table.insert(containers, mission.animatedMapObjects) end
    if mission.animatedObjects ~= nil then table.insert(containers, mission.animatedObjects) end
    if mission.onCreateObjectSystem ~= nil then
        if mission.onCreateObjectSystem.animatedObjects ~= nil then table.insert(containers, mission.onCreateObjectSystem.animatedObjects) end
        if mission.onCreateObjectSystem.objects ~= nil then table.insert(containers, mission.onCreateObjectSystem.objects) end
    end
    for _, container in ipairs(containers) do
        for _, object in pairs(container or {}) do
            addGate(result, seen, object.animatedObject or object, object, nil, nil)
        end
    end
    return result
end

local function getLocalVehicle()
    if g_localPlayer ~= nil and g_localPlayer.getCurrentVehicle ~= nil then
        local ok, v = pcall(g_localPlayer.getCurrentVehicle, g_localPlayer)
        if ok and v ~= nil then return v end
    end
    if g_currentMission ~= nil and g_currentMission.player ~= nil and g_currentMission.player.getCurrentVehicle ~= nil then
        local ok, v = pcall(g_currentMission.player.getCurrentVehicle, g_currentMission.player)
        if ok and v ~= nil then return v end
    end
    if g_currentMission ~= nil and g_currentMission.playerSystem ~= nil and g_currentMission.playerSystem.getLocalPlayer ~= nil then
        local okP, p = pcall(g_currentMission.playerSystem.getLocalPlayer, g_currentMission.playerSystem)
        if okP and p ~= nil and p.getCurrentVehicle ~= nil then
            local ok, v = pcall(p.getCurrentVehicle, p)
            if ok and v ~= nil then return v end
        end
    end
    return g_currentMission ~= nil and g_currentMission.controlledVehicle or nil
end

local function resolveAutoDriveApi()
    -- FS25 gives every script mod its own Lua environment. AutoDrive therefore
    -- is not necessarily available as a direct global inside SmartGate.
    if AutoDrive ~= nil then return AutoDrive, "DIRECT" end

    local okEnv, env = pcall(getfenv, 0)
    if okEnv and env ~= nil then
        local adEnv = rawget(env, "FS25_AutoDrive")
        if type(adEnv) == "table" and adEnv.AutoDrive ~= nil then
            return adEnv.AutoDrive, "MOD_ENV"
        end

        local root = rawget(env, "_G")
        if type(root) == "table" then
            adEnv = rawget(root, "FS25_AutoDrive")
            if type(adEnv) == "table" and adEnv.AutoDrive ~= nil then
                return adEnv.AutoDrive, "ROOT_MOD_ENV"
            end
        end
    end

    return nil, "NO_AUTODRIVE_ENV"
end

local function resolveCourseplayApi()
    if g_Courseplay ~= nil then return g_Courseplay, "DIRECT_G_COURSEPLAY" end
    if Courseplay ~= nil then return Courseplay, "DIRECT_COURSEPLAY" end

    local okEnv, env = pcall(getfenv, 0)
    if okEnv and env ~= nil then
        local cpEnv = rawget(env, "FS25_Courseplay")
        if type(cpEnv) == "table" then
            if cpEnv.g_Courseplay ~= nil then return cpEnv.g_Courseplay, "MOD_ENV_G" end
            if cpEnv.Courseplay ~= nil then return cpEnv.Courseplay, "MOD_ENV" end
        end

        local root = rawget(env, "_G")
        if type(root) == "table" then
            cpEnv = rawget(root, "FS25_Courseplay")
            if type(cpEnv) == "table" then
                if cpEnv.g_Courseplay ~= nil then return cpEnv.g_Courseplay, "ROOT_MOD_ENV_G" end
                if cpEnv.Courseplay ~= nil then return cpEnv.Courseplay, "ROOT_MOD_ENV" end
            end
            local rootCp = rawget(root, "g_Courseplay")
            if rootCp ~= nil then return rootCp, "ROOT_G_COURSEPLAY" end
        end
    end

    if g_modManager ~= nil and g_modManager.CP_MOD_NAME ~= nil then
        return true, "MOD_MANAGER"
    end

    return nil, "NO_COURSEPLAY_ENV"
end

local function hasExternalCursorProvider()
    local ad = resolveAutoDriveApi()
    if ad ~= nil then return true, "AutoDrive" end
    local cp = resolveCourseplayApi()
    if cp ~= nil then return true, "Courseplay" end
    return false, "SmartGate"
end

local function getAutoDriveEditorState()
    local ad, envSource = resolveAutoDriveApi()
    if ad == nil then return nil, envSource end

    -- Prefer AutoDrive's public getter. The setting is user-specific and can be
    -- OFF(1), ON(2), EXTENDED(3) or SHOW(4).
    if ad.getEditorMode ~= nil then
        local ok, mode = pcall(ad.getEditorMode)
        mode = ok and tonumber(mode) or nil
        if mode ~= nil then return mode, envSource .. ":getEditorMode" end
    end

    if ad.getSetting ~= nil then
        local ok, mode = pcall(ad.getSetting, "EditorMode")
        mode = ok and tonumber(mode) or nil
        if mode ~= nil then return mode, envSource .. ":getSetting" end
    end

    local settings = ad.settings
    local setting = settings ~= nil and settings.EditorMode or nil
    if setting ~= nil then
        local current = tonumber(setting.current)
        if current ~= nil and setting.values ~= nil and setting.values[current] ~= nil then
            return tonumber(setting.values[current]) or current, envSource .. ":settings.current"
        end
        if current ~= nil then return current, envSource .. ":settings.currentRaw" end
    end

    return nil, envSource .. ":UNKNOWN"
end

local function editorModeName(mode)
    local ad = resolveAutoDriveApi()
    if ad ~= nil then
        if mode == ad.EDITOR_OFF then return "OFF" end
        if mode == ad.EDITOR_ON then return "ON" end
        if mode == ad.EDITOR_EXTENDED then return "EXTENDED" end
        if mode == ad.EDITOR_SHOW then return "SHOW" end
    end
    if mode == 1 then return "OFF" end
    if mode == 2 then return "ON" end
    if mode == 3 then return "EXTENDED" end
    if mode == 4 then return "SHOW" end
    return tostring(mode or "UNKNOWN")
end

local function isEditorMode()
    local mode = getAutoDriveEditorState()
    if mode == nil then return false end
    local ad = resolveAutoDriveApi()
    local off = ad ~= nil and ad.EDITOR_OFF or 1
    return mode ~= off and mode >= 2 and mode <= 4
end

local function getRootVehicle(v)
    if v ~= nil and v.getRootVehicle ~= nil then
        local ok, root = pcall(v.getRootVehicle, v)
        if ok and root ~= nil then return root end
    end
    return v
end

local function getVehiclePoints(vehicle)
    vehicle = getRootVehicle(vehicle)
    if vehicle == nil or not validNode(vehicle.rootNode) then return {} end
    local points = {}
    local seen = setmetatable({}, {__mode="k"})
    local function walk(obj)
        if obj == nil or seen[obj] then return end
        seen[obj] = true
        if validNode(obj.rootNode) then
            local x, y, z = getWorldTranslation(obj.rootNode)
            table.insert(points, {x=x, y=y, z=z})
            local fx, _, fz = localDirectionToWorld(obj.rootNode, 0, 0, 1)
            local len = math.sqrt(fx*fx + fz*fz)
            if len > 0.001 then fx, fz = fx/len, fz/len end
            local size = obj.size or {}
            local half = (tonumber(size.length) or 8) * 0.5
            local halfWidth = (tonumber(size.width) or 3) * 0.5
            local off = tonumber(size.lengthOffset) or 0
            local rx, rz = fz, -fx
            local front = half + off
            local rear = half - off
            table.insert(points, {x=x + fx*front, y=y, z=z + fz*front})
            table.insert(points, {x=x - fx*rear, y=y, z=z - fz*rear})
            table.insert(points, {x=x + fx*front + rx*halfWidth, y=y, z=z + fz*front + rz*halfWidth})
            table.insert(points, {x=x + fx*front - rx*halfWidth, y=y, z=z + fz*front - rz*halfWidth})
            table.insert(points, {x=x - fx*rear + rx*halfWidth, y=y, z=z - fz*rear + rz*halfWidth})
            table.insert(points, {x=x - fx*rear - rx*halfWidth, y=y, z=z - fz*rear - rz*halfWidth})
        end
        if obj.getAttachedImplements ~= nil then
            local ok, impls = pcall(obj.getAttachedImplements, obj)
            if ok and impls ~= nil then for _, impl in ipairs(impls) do walk(impl.object) end end
        end
    end
    walk(vehicle)
    return points
end

local function getGateAxes(gate)
    local fx, fz = tonumber(gate.forwardX) or 0, tonumber(gate.forwardZ) or 1
    local fl = math.sqrt(fx*fx + fz*fz)
    if fl < 0.001 then fx, fz, fl = 0, 1, 1 end
    fx, fz = fx/fl, fz/fl
    local rx, rz = tonumber(gate.rightX) or fz, tonumber(gate.rightZ) or -fx
    local rl = math.sqrt(rx*rx + rz*rz)
    if rl < 0.001 then rx, rz, rl = fz, -fx, 1 end
    rx, rz = rx/rl, rz/rl
    if gate.axisSwapped == true then
        return rx, rz, -fx, -fz
    end
    return fx, fz, rx, rz
end

local function pointInGateBox(gate, x, z, halfDepth, halfWidth)
    local fx, fz, rx, rz = getGateAxes(gate)
    local dx, dz = x - gate.x, z - gate.z
    local forward = dx*fx + dz*fz
    local lateral = dx*rx + dz*rz
    return math.abs(forward) <= halfDepth and math.abs(lateral) <= halfWidth
end

local function getGateVehicleLists()
    local mission = g_currentMission
    local lists = {}
    if mission ~= nil and mission.vehicleSystem ~= nil and mission.vehicleSystem.vehicles ~= nil then
        table.insert(lists, mission.vehicleSystem.vehicles)
    end
    if mission ~= nil and mission.vehicles ~= nil then table.insert(lists, mission.vehicles) end
    return lists
end

local function isVehicleOperational(vehicle)
    local root = getRootVehicle(vehicle)
    if root == nil then return false end

    -- A parked, empty vehicle must not hold a gate open. Count only vehicles
    -- that are currently controlled by a player or driven by AI/AutoDrive.
    if root.getIsEntered ~= nil then
        local ok, entered = pcall(root.getIsEntered, root)
        if ok and entered == true then return true end
    end
    if root.getIsControlled ~= nil then
        local ok, controlled = pcall(root.getIsControlled, root)
        if ok and controlled == true then return true end
    end
    local ad = resolveAutoDriveApi()
    if ad ~= nil and ad.getIsEntered ~= nil then
        local ok, entered = pcall(ad.getIsEntered, ad, root)
        if ok and entered == true then return true end
    end
    if root.getIsAIActive ~= nil then
        local ok, aiActive = pcall(root.getIsAIActive, root)
        if ok and aiActive == true then return true end
    end
    if root.ad ~= nil and root.ad.stateModule ~= nil and root.ad.stateModule.isActive ~= nil then
        local ok, adActive = pcall(root.ad.stateModule.isActive, root.ad.stateModule)
        if ok and adActive == true then return true end
    end

    -- Multiplayer fallback when the server knows a controller user id but the
    -- convenience methods above are unavailable for a specific vehicle type.
    local enterable = root.spec_enterable
    if enterable ~= nil and enterable.controllerUserId ~= nil and enterable.controllerUserId ~= 0 then
        return true
    end

    return getRootVehicle(getLocalVehicle()) == root
end

local function vehicleNearGate(gate, depth, sideDistance, operationalOnly)
    local lists = getGateVehicleLists()
    if #lists == 0 then return false end

    local roots = setmetatable({}, {__mode="k"})
    for _, list in ipairs(lists) do
        for _, vehicle in pairs(list) do
            local root = getRootVehicle(vehicle)
            if root ~= nil and not roots[root] then
                roots[root] = true
                if (not operationalOnly) or isVehicleOperational(root) then
                    for _, p in ipairs(getVehiclePoints(root)) do
                        if pointInGateBox(gate, p.x, p.z, depth, sideDistance) then return true end
                    end
                end
            end
        end
    end
    return false
end

local function getVehicleWorldXZ(vehicle)
    local root = getRootVehicle(vehicle)
    if root == nil then return nil, nil end

    local node = nil
    if root.components ~= nil and root.components[1] ~= nil then
        node = root.components[1].node
    end
    node = node or root.rootNode
    if not validNode(node) then return nil, nil end

    local x, _, z = getWorldTranslation(node)
    return x, z
end

-- Clips a route segment against the gate's oriented rectangle.
-- Returns true plus the entry position [0..1] on the segment.
local function segmentIntersectsGateBox(gate, ax, az, bx, bz, halfDepth, halfWidth)
    local fx, fz, rx, rz = getGateAxes(gate)

    local adx, adz = ax - gate.x, az - gate.z
    local bdx, bdz = bx - gate.x, bz - gate.z

    local aForward = adx * fx + adz * fz
    local aSide = adx * rx + adz * rz
    local bForward = bdx * fx + bdz * fz
    local bSide = bdx * rx + bdz * rz

    local dForward = bForward - aForward
    local dSide = bSide - aSide
    local tMin, tMax = 0.0, 1.0

    local function clipAxis(startValue, delta, minValue, maxValue)
        if math.abs(delta) < 0.000001 then
            return startValue >= minValue and startValue <= maxValue
        end

        local t1 = (minValue - startValue) / delta
        local t2 = (maxValue - startValue) / delta
        if t1 > t2 then t1, t2 = t2, t1 end

        if t1 > tMin then tMin = t1 end
        if t2 < tMax then tMax = t2 end
        return tMin <= tMax
    end

    if not clipAxis(aForward, dForward, -halfDepth, halfDepth) then return false, nil end
    if not clipAxis(aSide, dSide, -halfWidth, halfWidth) then return false, nil end

    return true, math.max(0.0, math.min(1.0, tMin))
end

local function isAutoDriveActive(root)
    return root ~= nil
        and root.ad ~= nil
        and root.ad.stateModule ~= nil
        and root.ad.drivePathModule ~= nil
        and root.ad.stateModule.isActive ~= nil
        and root.ad.drivePathModule.getWayPoints ~= nil
        and select(1, pcall(root.ad.stateModule.isActive, root.ad.stateModule)) == true
        and select(2, pcall(root.ad.stateModule.isActive, root.ad.stateModule)) == true
end

-- Returns true when an active AutoDrive route will cross this gate within the
-- look-ahead distance. This follows AutoDrive's current drivePathModule path
-- rather than using a giant proximity box, so traffic merely passing nearby
-- should not pre-open the gate.
local function autoDriveRouteWillCrossGate(gate, maxDistance)
    local lists = getGateVehicleLists()
    if #lists == 0 then return false, nil, nil end

    local roots = setmetatable({}, {__mode="k"})
    local halfWidth = math.max(gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE, AD_PREOPEN_MIN_HALF_WIDTH)

    for _, list in ipairs(lists) do
        for _, vehicle in pairs(list) do
            local root = getRootVehicle(vehicle)
            if root ~= nil and not roots[root] then
                roots[root] = true

                local stateModule = root.ad ~= nil and root.ad.stateModule or nil
                local drivePathModule = root.ad ~= nil and root.ad.drivePathModule or nil
                local adActive = false

                if stateModule ~= nil and stateModule.isActive ~= nil then
                    local ok, active = pcall(stateModule.isActive, stateModule)
                    adActive = ok and active == true
                end

                if adActive and drivePathModule ~= nil and drivePathModule.getWayPoints ~= nil then
                    local okPath, wayPoints, currentIndex = pcall(drivePathModule.getWayPoints, drivePathModule)
                    currentIndex = tonumber(currentIndex)

                    if okPath and type(wayPoints) == "table" and currentIndex ~= nil then
                        local prevX, prevZ = getVehicleWorldXZ(root)
                        local travelled = 0.0
                        local checked = 0

                        if prevX ~= nil then
                            for i = math.max(1, math.floor(currentIndex)), #wayPoints do
                                local wp = wayPoints[i]
                                if wp ~= nil and tonumber(wp.x) ~= nil and tonumber(wp.z) ~= nil then
                                    local wx, wz = tonumber(wp.x), tonumber(wp.z)
                                    local dx, dz = wx - prevX, wz - prevZ
                                    local segmentLength = math.sqrt(dx * dx + dz * dz)

                                    if segmentLength > 0.001 then
                                        local hit, tEnter = segmentIntersectsGateBox(
                                            gate,
                                            prevX, prevZ,
                                            wx, wz,
                                            AD_PREOPEN_GATE_DEPTH,
                                            halfWidth
                                        )

                                        if hit then
                                            local distanceToGate = travelled + segmentLength * (tEnter or 0)
                                            if distanceToGate <= maxDistance then
                                                return true, root, distanceToGate
                                            end
                                        end

                                        travelled = travelled + segmentLength
                                        if travelled > maxDistance + 20.0 then break end
                                    end

                                    prevX, prevZ = wx, wz
                                    checked = checked + 1
                                    if checked >= AD_PREOPEN_MAX_POINTS then break end
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    return false, nil, nil
end

local function vehicleInSafetyZone(gate)
    -- Deliberately ignores player/helper/AutoDrive control state. A parked or
    -- completely unattended vehicle/implement is still a physical obstacle.
    return vehicleNearGate(gate, gate.safetyDepth or DEFAULT_SAFETY_DEPTH, gate.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH, false)
end

local function eachPlayer(callback)
    local mission = g_currentMission
    if mission == nil then return end
    local used = setmetatable({}, {__mode="k"})
    local function add(p)
        if p ~= nil and not used[p] then used[p] = true; callback(p) end
    end
    if mission.playerSystem ~= nil and mission.playerSystem.players ~= nil then
        for _, p in pairs(mission.playerSystem.players) do add(p) end
    end
    if mission.players ~= nil then for _, p in pairs(mission.players) do add(p) end end
    add(mission.player)
    add(g_localPlayer)
end

local function playerNearGate(gate, depth, sideDistance)
    local found = false
    eachPlayer(function(p)
        if found then return end
        local node = p.rootNode or p.node
        if validNode(node) then
            local x, _, z = getWorldTranslation(node)
            if pointInGateBox(gate, x, z, depth, sideDistance) then found = true end
        end
    end)
    return found
end

local function triggerInteractiveObject(gate)
    local ao = gate ~= nil and gate.animatedObject or nil
    if ao == nil or ao.animation == nil or type(ao.setDirection) ~= "function" then
        return false, "missing AnimatedObject API"
    end

    -- Start exactly one complete cycle toward the opposite animation endpoint.
    -- A resting AnimatedObject reports direction=0; blindly negating that gives
    -- -0, which is not a useful server-side start command. Use animation time to
    -- select the next endpoint instead, while leaving foreign work/wash logic alone.
    local currentDirection = tonumber(ao.animation.direction) or 0
    if currentDirection ~= 0 then
        return false, "animation already running"
    end

    local time = tonumber(ao.animation.time) or 0
    local direction = time >= 0.5 and -1 or 1
    local ok, err = pcall(ao.setDirection, ao, direction)
    if not ok then
        return false, "setDirection failed: " .. tostring(err)
    end

    return true, string.format("AnimatedObject:setDirection(%s)", tostring(direction))
end

local function setGateOpen(gate, shouldOpen)
    local ao = gate.animatedObject
    if ao == nil or ao.animation == nil then return end

    -- AnimatedObjectExtender proves that automatic open/close is driven by the
    -- animation direction directly. AnimatedObject:setDirection(0) is a toggle
    -- command in FS25 and +/-1 is not a reliable open/close API.
    local time = tonumber(ao.animation.time) or 0
    local desired = shouldOpen and 1 or -1
    local needsMove = (shouldOpen and time < 0.999) or ((not shouldOpen) and time > 0.001)
    if needsMove and ao.animation.direction ~= desired then
        ao.animation.direction = desired
        if ao.raiseActive ~= nil then
            pcall(ao.raiseActive, ao)
        end
        debugLog("%s gate '%s' (time=%.3f)", shouldOpen and "OPEN" or "CLOSE", tostring(gate.id), time)
    end
end

local function getSavePath()
    local mi = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    local dir = mi ~= nil and mi.savegameDirectory or nil
    if dir == nil or dir == "" then return nil end
    return dir .. "/smartGate.xml"
end

function SmartGate.new()
    local self = setmetatable({}, SmartGate_mt)
    self.gates = {}
    self.savedModes = {}
    self.savedBlacklist = {}
    self.savedGateSettings = {}
    self.savedCustomGeometry = {}
    self.savedGateRecords = {}
    self.scanTimer = 0
    self.rescanTimer = 0
    self.stateSyncTimer = 0
    self.hornStates = setmetatable({}, {__mode="k"})
    self.lastPolledVehicle = nil
    self.lastPolledHorn = nil
    self.markerGate = nil
    self.markerUntil = 0
    self.markerMode = MODE_DISABLED
    self.markerBlacklisted = false
    self.markerOverlay = nil
    self.lastEditorRawMode = nil
    self.lastEditorSource = nil
    self.configModeEnabled = false
    self.configCursorOwned = false
    self.configCursorWasVisible = false
    self.configPanelGate = nil
    self.configPanelRefreshTimer = 0
    self.showZonesAlways = false
    self.configInputHookInstalled = false
    self.lastGateCount = nil
    return self
end

function SmartGate:loadConfig()
    self.savedModes = {}
    self.savedBlacklist = {}
    self.savedGateSettings = {}
    self.savedCustomGeometry = {}
    self.savedGateRecords = {}
    local path = getSavePath()
    if path == nil or not fileExists(path) then return end
    local xml = loadXMLFile("smartGate", path)
    if xml == 0 then return end
    local i = 0
    while hasXMLProperty(xml, string.format("smartGate.gates.gate(%d)", i)) do
        local key = string.format("smartGate.gates.gate(%d)", i)
        local id = getXMLString(xml, key .. "#id")
        local mode = getXMLInt(xml, key .. "#mode")
        local blacklisted = getXMLBool(xml, key .. "#blacklisted")
        if id ~= nil then
            if mode ~= nil then self.savedModes[id] = math.max(0, math.min(3, mode)) end
            if blacklisted == true then self.savedBlacklist[id] = true end
            local customGeometry = getXMLBool(xml, key .. "#customGeometry") == true
            self.savedCustomGeometry[id] = customGeometry
            local settings = {
                triggerOpenDistance = getXMLFloat(xml, key .. "#triggerOpenDistance"),
                triggerOpenHalfWidth = getXMLFloat(xml, key .. "#triggerOpenHalfWidth"),
                triggerCloseDistance = getXMLFloat(xml, key .. "#triggerCloseDistance"),
                triggerCloseHalfWidth = getXMLFloat(xml, key .. "#triggerCloseHalfWidth"),
                triggerSideDistance = getXMLFloat(xml, key .. "#triggerSideDistance"),
                safetyDepth = getXMLFloat(xml, key .. "#safetyDepth"),
                safetyHalfWidth = getXMLFloat(xml, key .. "#safetyHalfWidth"),
                configDepth = getXMLFloat(xml, key .. "#configDepth"),
                configHalfWidth = getXMLFloat(xml, key .. "#configHalfWidth"),
                axisSwapped = getXMLBool(xml, key .. "#axisSwapped") == true,
                objectType = getXMLInt(xml, key .. "#objectType"),
                washPoint = getXMLBool(xml, key .. "#washPoint") == true,
                safetyClearDelayMs = getXMLInt(xml, key .. "#safetyClearDelayMs")
            }
            self.savedGateSettings[id] = settings

            local ownerKey = getXMLString(xml, key .. "#ownerKey")
            local nodeKey = getXMLString(xml, key .. "#nodeKey")
            local savedX = getXMLFloat(xml, key .. "#x")
            local savedZ = getXMLFloat(xml, key .. "#z")

            -- Backward compatibility for configs written before descriptor
            -- persistence existed. Stable IDs are owner|objectKey|node; legacy
            -- IDs are owner|node|x|y|z.
            if ownerKey == nil or ownerKey == "" then
                ownerKey = tostring(id):match("^([^|]+)")
            end
            if nodeKey == nil or nodeKey == "" then
                local parts = {}
                for part in tostring(id):gmatch("([^|]+)") do table.insert(parts, part) end
                if #parts >= 3 then nodeKey = parts[#parts] end
                if #parts >= 5 then
                    savedX = savedX or tonumber(parts[#parts-2])
                    savedZ = savedZ or tonumber(parts[#parts])
                end
            end

            table.insert(self.savedGateRecords, {
                id=id,
                ownerKey=tostring(ownerKey or ""):lower():gsub("\\", "/"),
                nodeKey=tostring(nodeKey or ""):lower(),
                x=savedX,
                z=savedZ,
                mode=mode,
                blacklisted=blacklisted == true,
                customGeometry=customGeometry,
                settings=settings
            })
        end
        i = i + 1
    end
    delete(xml)
end

function SmartGate:saveConfig()
    if g_server == nil then return end
    local path = getSavePath()
    if path == nil then return end
    local xml = createXMLFile("smartGate", path, "smartGate")
    setXMLInt(xml, "smartGate#configVersion", 3)
    local i = 0
    for _, gate in ipairs(self.gates) do
        local key = string.format("smartGate.gates.gate(%d)", i)
        setXMLString(xml, key .. "#id", gate.id)
        setXMLString(xml, key .. "#ownerKey", gate.ownerKey or "")
        setXMLString(xml, key .. "#nodeKey", gate.nodeKey or "")
        setXMLFloat(xml, key .. "#x", gate.x or 0)
        setXMLFloat(xml, key .. "#z", gate.z or 0)
        setXMLInt(xml, key .. "#mode", gate.mode or MODE_ALL)
        setXMLBool(xml, key .. "#blacklisted", gate.blacklisted == true)
        setXMLBool(xml, key .. "#customGeometry", gate.customGeometry == true)
        setXMLFloat(xml, key .. "#triggerOpenDistance", gate.triggerOpenDistance or AUTO_OPEN_DISTANCE)
        setXMLFloat(xml, key .. "#triggerOpenHalfWidth", gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
        setXMLFloat(xml, key .. "#triggerCloseDistance", gate.triggerCloseDistance or AUTO_CLOSE_DISTANCE)
        setXMLFloat(xml, key .. "#triggerCloseHalfWidth", gate.triggerCloseHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
        setXMLFloat(xml, key .. "#triggerSideDistance", gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
        setXMLFloat(xml, key .. "#safetyDepth", gate.safetyDepth or DEFAULT_SAFETY_DEPTH)
        setXMLFloat(xml, key .. "#safetyHalfWidth", gate.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH)
        setXMLFloat(xml, key .. "#configDepth", gate.configDepth or CONFIG_ZONE_LENGTH)
        setXMLFloat(xml, key .. "#configHalfWidth", gate.configHalfWidth or CONFIG_ZONE_HALF_WIDTH)
        setXMLBool(xml, key .. "#axisSwapped", gate.axisSwapped == true)
        setXMLInt(xml, key .. "#objectType", gate.objectType or OBJECT_GATE)
        setXMLBool(xml, key .. "#washPoint", gate.objectType == OBJECT_INTERACTION and gate.washPoint == true)
        setXMLInt(xml, key .. "#safetyClearDelayMs", gate.safetyClearDelayMs or DEFAULT_SAFETY_CLEAR_DELAY_MS)
        i = i + 1
    end
    saveXMLFile(xml)
    delete(xml)
end

function SmartGate:findSavedGateRecord(gate)
    if gate == nil then return nil end
    local exactId = tostring(gate.id or "")
    local legacyId = tostring(gate.legacyId or "")

    for _, record in ipairs(self.savedGateRecords or {}) do
        if record.id == exactId or (legacyId ~= "" and record.id == legacyId) then
            return record, "id"
        end
    end

    local best = nil
    local bestScore = -math.huge
    local bestDistance = math.huge
    for _, record in ipairs(self.savedGateRecords or {}) do
        local score = 0
        if record.ownerKey ~= "" and record.ownerKey == gate.ownerKey then score = score + 100 end
        if record.nodeKey ~= "" and record.nodeKey == gate.nodeKey then score = score + 40 end

        local distance = math.huge
        if record.x ~= nil and record.z ~= nil and gate.x ~= nil and gate.z ~= nil then
            distance = math.sqrt(sqrDistance2D(gate.x, gate.z, record.x, record.z))
            if distance <= CONFIG_RESOLVE_MAX_DISTANCE then
                score = score + math.max(0, 30 - distance * 5)
            elseif score < 100 then
                score = score - 100
            end
        end

        if score > bestScore or (score == bestScore and distance < bestDistance) then
            best = record
            bestScore = score
            bestDistance = distance
        end
    end

    if best ~= nil and (bestScore >= 140 or (bestScore >= 100 and bestDistance <= CONFIG_RESOLVE_MAX_DISTANCE) or bestScore >= 40 and bestDistance <= 1.5) then
        print(string.format("[SmartGate][PERSIST] restored gate by descriptor oldId=%s newId=%s score=%.1f distance=%.2f",
            tostring(best.id), tostring(gate.id), bestScore, bestDistance))
        return best, "descriptor"
    end
    return nil, "missing"
end

function SmartGate:rescan()
    local oldModes = {}
    local oldBlacklist = {}
    local oldSettings = {}
    local oldCustomGeometry = {}
    local oldRuntime = {}
    for _, g in ipairs(self.gates) do
        oldModes[g.id] = g.mode
        oldBlacklist[g.id] = g.blacklisted == true
        oldCustomGeometry[g.id] = g.customGeometry == true
        oldSettings[g.id] = {
            triggerOpenDistance=g.triggerOpenDistance, triggerOpenHalfWidth=g.triggerOpenHalfWidth,
            triggerCloseDistance=g.triggerCloseDistance, triggerCloseHalfWidth=g.triggerCloseHalfWidth,
            triggerSideDistance=g.triggerSideDistance, safetyDepth=g.safetyDepth,
            safetyHalfWidth=g.safetyHalfWidth, configDepth=g.configDepth, configHalfWidth=g.configHalfWidth,
            axisSwapped=g.axisSwapped == true, objectType=g.objectType or OBJECT_GATE, washPoint=g.washPoint == true, safetyClearDelayMs=g.safetyClearDelayMs
        }
        oldRuntime[g.id] = {
            occupied = g.occupied == true,
            clearSince = g.clearSince,
            preOpenReserved = g.preOpenReserved == true,
            interactionLatched = g.interactionLatched == true
        }
    end
    self.gates = collectGates()
    for _, gate in ipairs(self.gates) do
        local legacyId = gate.legacyId
        gate.mode = self.savedModes[gate.id] or (legacyId ~= nil and self.savedModes[legacyId]) or oldModes[gate.id] or (legacyId ~= nil and oldModes[legacyId]) or MODE_ALL
        gate.blacklisted = self.savedBlacklist[gate.id] == true or (legacyId ~= nil and self.savedBlacklist[legacyId] == true) or oldBlacklist[gate.id] == true or (legacyId ~= nil and oldBlacklist[legacyId] == true)
        local runtime = oldRuntime[gate.id] or (legacyId ~= nil and oldRuntime[legacyId])
        if runtime ~= nil then
            gate.occupied = runtime.occupied == true
            gate.clearSince = runtime.clearSince
            gate.preOpenReserved = runtime.preOpenReserved == true
            gate.interactionLatched = runtime.interactionLatched == true
        else
            gate.preOpenReserved = false
            gate.interactionLatched = false
        end
        local savedRecord = self:findSavedGateRecord(gate)
        local recordCfg = savedRecord ~= nil and savedRecord.settings or nil
        local cfg = recordCfg or self.savedGateSettings[gate.id] or (legacyId ~= nil and self.savedGateSettings[legacyId]) or oldSettings[gate.id] or (legacyId ~= nil and oldSettings[legacyId]) or {}
        gate.customGeometry = (savedRecord ~= nil and savedRecord.customGeometry == true)
            or self.savedCustomGeometry[gate.id] == true
            or (legacyId ~= nil and self.savedCustomGeometry[legacyId] == true)
            or oldCustomGeometry[gate.id] == true
            or (legacyId ~= nil and oldCustomGeometry[legacyId] == true)

        if savedRecord ~= nil then
            if savedRecord.mode ~= nil then gate.mode = math.max(0, math.min(3, savedRecord.mode)) end
            gate.blacklisted = savedRecord.blacklisted == true
            self.savedModes[gate.id] = gate.mode
            if gate.blacklisted then self.savedBlacklist[gate.id] = true else self.savedBlacklist[gate.id] = nil end
            if gate.customGeometry then self.savedCustomGeometry[gate.id] = true end
            self.savedGateSettings[gate.id] = cfg
        end

        local defaults = self.settings ~= nil and self.settings.values or nil
        if gate.customGeometry then
            local legacyWidth = tonumber(cfg.triggerSideDistance) or DEFAULT_TRIGGER_SIDE_DISTANCE
            gate.triggerOpenDistance = tonumber(cfg.triggerOpenDistance) or AUTO_OPEN_DISTANCE
            gate.triggerOpenHalfWidth = tonumber(cfg.triggerOpenHalfWidth) or legacyWidth
            gate.triggerCloseDistance = tonumber(cfg.triggerCloseDistance) or AUTO_CLOSE_DISTANCE
            gate.triggerCloseHalfWidth = tonumber(cfg.triggerCloseHalfWidth) or legacyWidth
            gate.triggerSideDistance = gate.triggerOpenHalfWidth
            gate.safetyDepth = tonumber(cfg.safetyDepth) or DEFAULT_SAFETY_DEPTH
            gate.safetyHalfWidth = tonumber(cfg.safetyHalfWidth) or DEFAULT_SAFETY_HALF_WIDTH
            gate.configDepth = tonumber(cfg.configDepth) or CONFIG_ZONE_LENGTH
            gate.configHalfWidth = tonumber(cfg.configHalfWidth) or CONFIG_ZONE_HALF_WIDTH
            gate.axisSwapped = cfg.axisSwapped == true
            gate.objectType = tonumber(cfg.objectType) == OBJECT_INTERACTION and OBJECT_INTERACTION or OBJECT_GATE
            gate.washPoint = gate.objectType == OBJECT_INTERACTION and cfg.washPoint == true
            gate.safetyClearDelayMs = tonumber(cfg.safetyClearDelayMs) or DEFAULT_SAFETY_CLEAR_DELAY_MS
        else
            local defaultWidth = tonumber(defaults and defaults.triggerSideDistance) or DEFAULT_TRIGGER_SIDE_DISTANCE
            gate.triggerOpenDistance = tonumber(defaults and defaults.triggerOpenDistance) or AUTO_OPEN_DISTANCE
            gate.triggerOpenHalfWidth = defaultWidth
            gate.triggerCloseDistance = tonumber(defaults and defaults.triggerCloseDistance) or AUTO_CLOSE_DISTANCE
            gate.triggerCloseHalfWidth = defaultWidth
            gate.triggerSideDistance = defaultWidth
            gate.safetyDepth = tonumber(defaults and defaults.safetyDepth) or DEFAULT_SAFETY_DEPTH
            gate.safetyHalfWidth = tonumber(defaults and defaults.safetyHalfWidth) or DEFAULT_SAFETY_HALF_WIDTH
            gate.configDepth = CONFIG_ZONE_LENGTH
            gate.configHalfWidth = CONFIG_ZONE_HALF_WIDTH
            gate.axisSwapped = false
            gate.objectType = OBJECT_GATE
            gate.washPoint = false
            gate.safetyClearDelayMs = tonumber(defaults and defaults.safetyClearDelayMs) or DEFAULT_SAFETY_CLEAR_DELAY_MS
        end
    end
    if self.lastGateCount == nil or self.lastGateCount ~= #self.gates then
        print(string.format("[SmartGate] gate inventory: %d gate(s) found", #self.gates))
        self.lastGateCount = #self.gates
    else
        debugLog("periodic gate rescan complete: %d gate(s)", #self.gates)
    end
end

function SmartGate:findGateById(id)
    for _, gate in ipairs(self.gates) do if gate.id == id then return gate end end
    return nil
end

function SmartGate:resolveGate(id, ownerKey, nodeKey, x, z)
    local exact = self:findGateById(id)
    if exact ~= nil then return exact, "exact" end

    ownerKey = tostring(ownerKey or ""):lower():gsub("\\", "/")
    nodeKey = tostring(nodeKey or ""):lower()
    x = tonumber(x)
    z = tonumber(z)

    local best, bestScore, bestDistance = nil, -math.huge, math.huge
    for _, gate in ipairs(self.gates) do
        local score = 0
        if ownerKey ~= "" and gate.ownerKey == ownerKey then score = score + 100 end
        if nodeKey ~= "" and gate.nodeKey == nodeKey then score = score + 30 end
        local distance = math.huge
        if x ~= nil and z ~= nil then
            distance = math.sqrt(sqrDistance2D(gate.x, gate.z, x, z))
            if distance <= CONFIG_RESOLVE_MAX_DISTANCE then
                score = score + math.max(0, 25 - distance * 3)
            elseif score < 100 then
                score = score - 50
            end
        end
        if score > bestScore or (score == bestScore and distance < bestDistance) then
            best, bestScore, bestDistance = gate, score, distance
        end
    end

    if best ~= nil and (bestScore >= 100 or (bestScore >= 30 and bestDistance <= CONFIG_RESOLVE_MAX_DISTANCE) or bestDistance <= 2.5) then
        debugLog("resolved remote gate '%s' -> '%s' score=%.1f distance=%.2f", tostring(id), tostring(best.id), bestScore, bestDistance)
        return best, "descriptor"
    end
    print(string.format("[SmartGate][WARN] unable to resolve remote gate: id=%s owner=%s node=%s", tostring(id), tostring(ownerKey), tostring(nodeKey)))
    return nil, "missing"
end

function SmartGate:getGateDescriptor(gate)
    if gate == nil then return "", "", "", 0, 0 end
    return gate.id or "", gate.ownerKey or "", gate.nodeKey or "", gate.x or 0, gate.z or 0
end

function SmartGate:getGateName(gate)
    if gate == nil then return "Unbekannter Trigger" end
    return gate.displayName or "Unbekannter Trigger"
end

function SmartGate:getMarkerWorldPosition(gate)
    if gate == nil then return 0, 0, 0 end
    local fx, fz = getGateAxes(gate)
    local side = 1
    local vehicle = getLocalVehicle()
    if vehicle ~= nil and validNode(getRootVehicle(vehicle).rootNode) then
        local vx, _, vz = getWorldTranslation(getRootVehicle(vehicle).rootNode)
        local dot = (vx - gate.x) * fx + (vz - gate.z) * fz
        -- Put the icon on the opposite side of the gate from the local vehicle.
        side = dot >= 0 and -1 or 1
    end
    local offset = math.min(3.0, math.max(1.75, (gate.triggerOpenDistance or AUTO_OPEN_DISTANCE) * 0.25))
    return gate.x + fx * offset * side, (gate.y or 0), gate.z + fz * offset * side
end

function SmartGate:showMarker(gate, mode, blacklisted)
    self.markerGate = gate
    self.markerMode = mode or MODE_DISABLED
    self.markerBlacklisted = blacklisted == true
    self.markerUntil = nowMs() + MARKER_TIME_MS
end

function SmartGate:notifyMode(gate, mode)
    self:showMarker(gate, mode, gate.blacklisted)
    local txt = string.format("SmartGate: %s -> %s", self:getGateName(gate), MODE_TEXT_DE[mode] or tostring(mode))
    showNotification(txt, 4500, FSBaseMission.INGAME_NOTIFICATION_OK)
end

function SmartGate:notifyBlacklist(gate, blacklisted)
    self:showMarker(gate, gate.mode, blacklisted)
    local state = blacklisted and "BLACKLIST" or "BLACKLIST ENTFERNT"
    local txt = string.format("SmartGate: %s -> %s", self:getGateName(gate), state)
    showNotification(txt, 5000, FSBaseMission.INGAME_NOTIFICATION_OK)
end

function SmartGate:cycleGate(id, ownerKey, nodeKey, x, z)
    if g_server == nil then return end
    local gate = self:resolveGate(id, ownerKey, nodeKey, x, z)
    if gate == nil then return end
    if gate.blacklisted then
        print(string.format("[SmartGate][CONFIG] mode change ignored; blacklisted: %s (%s)", self:getGateName(gate), tostring(id)))
        SmartGateBlacklistEvent.sendToClients(gate, true)
        return
    end
    gate.mode = ((gate.mode or MODE_ALL) + 1) % 4
    print(string.format("[SmartGate][CONFIG] mode changed: %s (%s) -> %s", self:getGateName(gate), tostring(id), MODE_TEXT_DE[gate.mode] or tostring(gate.mode)))
    self.savedModes[gate.id] = gate.mode
    self:saveConfig()
    SmartGateModeEvent.sendToClients(gate, gate.mode)
end

function SmartGate:toggleBlacklist(id, ownerKey, nodeKey, x, z)
    if g_server == nil then return end
    local gate = self:resolveGate(id, ownerKey, nodeKey, x, z)
    if gate == nil then return end
    gate.blacklisted = not gate.blacklisted
    gate.occupied = false
    if gate.blacklisted then self.savedBlacklist[gate.id] = true else self.savedBlacklist[gate.id] = nil end
    print(string.format("[SmartGate][CONFIG] blacklist changed: %s (%s) -> %s", self:getGateName(gate), tostring(id), tostring(gate.blacklisted)))
    self:saveConfig()
    SmartGateBlacklistEvent.sendToClients(gate, gate.blacklisted)
end

function SmartGate:findConfigGate(vehicle)
    vehicle = getRootVehicle(vehicle)
    if vehicle == nil or not validNode(vehicle.rootNode) then return nil end
    local x, _, z = getWorldTranslation(vehicle.rootNode)
    local fx, _, fz = localDirectionToWorld(vehicle.rootNode, 0, 0, 1)
    local fl = math.sqrt(fx*fx + fz*fz)
    if fl < 0.001 then return nil end
    fx, fz = fx/fl, fz/fl
    local rx, rz = fz, -fx

    -- Find the actual front/rear of the whole vehicle combination. The config
    -- zones sit just outside those endpoints, not around the tractor centre.
    local minProj, maxProj = 0, 0
    for _, point in ipairs(getVehiclePoints(vehicle)) do
        local projection = (point.x - x) * fx + (point.z - z) * fz
        minProj = math.min(minProj, projection)
        maxProj = math.max(maxProj, projection)
    end
    local frontX, frontZ = x + fx * maxProj, z + fz * maxProj
    local rearX, rearZ = x + fx * minProj, z + fz * minProj

    local best, bestD = nil, math.huge
    for _, gate in ipairs(self.gates) do
        local function testZone(originX, originZ, outwardSign)
            local dx, dz = gate.x - originX, gate.z - originZ
            local outward = (dx*fx + dz*fz) * outwardSign
            local lateral = math.abs(dx*rx + dz*rz)
            if outward >= -0.5 and outward <= (gate.configDepth or CONFIG_ZONE_LENGTH) and lateral <= (gate.configHalfWidth or CONFIG_ZONE_HALF_WIDTH) then
                local d = dx*dx + dz*dz
                if d < bestD then best, bestD = gate, d end
            end
        end
        testZone(frontX, frontZ, 1)
        testZone(rearX, rearZ, -1)
    end
    if best ~= nil then return best end

    -- Fallback for animated objects whose interaction trigger is offset from the
    -- visible object: select the nearest known SmartGate object around the whole
    -- vehicle combination, but only while the user explicitly configures it.
    local fallbackR2 = CONFIG_FALLBACK_RADIUS * CONFIG_FALLBACK_RADIUS
    for _, gate in ipairs(self.gates) do
        for _, point in ipairs(getVehiclePoints(vehicle)) do
            local d = sqrDistance2D(gate.x, gate.z, point.x, point.z)
            if d <= fallbackR2 and d < bestD then
                best, bestD = gate, d
            end
        end
    end
    if best ~= nil then
        debugLog("fallback target selected: %s (%s)", self:getGateName(best), tostring(best.id))
    end
    return best
end

function SmartGate:isLocalVehicle(vehicle)
    if vehicle == nil then return false end
    if vehicle.getIsActiveForInputIgnoreSelection ~= nil then
        local ok, active = pcall(vehicle.getIsActiveForInputIgnoreSelection, vehicle)
        if ok and active == true then return true end
    end
    if vehicle.getIsActiveForInput ~= nil then
        local ok, active = pcall(vehicle.getIsActiveForInput, vehicle)
        if ok and active == true then return true end
    end
    return getRootVehicle(vehicle) == getRootVehicle(getLocalVehicle())
end

function SmartGate:installHornHook()
    if self.hornHookInstalled then return true end
    if Honk == nil or Honk.playHonk == nil then return false end
    Honk.playHonk = Utils.appendedFunction(Honk.playHonk, function(vehicle, isPlaying, noEventSend)
        if g_smartGate ~= nil then g_smartGate:onHonk(vehicle, isPlaying) end
    end)
    self.hornHookInstalled = true
    print("[SmartGate][CONFIG] horn hook installed")
    return true
end

function SmartGate:onHonk(vehicle, isPlaying)
    if not self.configModeEnabled then return end
    if not self:isLocalVehicle(vehicle) then return end
    local root = getRootVehicle(vehicle)
    local state = self.hornStates[root]
    if state == nil then state = {pressed=false, started=0, previousRelease=nil}; self.hornStates[root] = state end
    local t = nowMs()
    if isPlaying and not state.pressed then
        state.pressed = true
        state.started = t
    elseif not isPlaying and state.pressed then
        state.pressed = false
        local duration = t - state.started
        if duration <= SHORT_HONK_MAX_MS then
            if state.previousRelease ~= nil and t - state.previousRelease <= DOUBLE_HONK_MS then
                local gap = t - state.previousRelease
                state.previousRelease = nil
                print(string.format("[SmartGate][CONFIG] double honk detected (gap=%dms)", gap))
                local gate = self:findConfigGate(root)
                if gate ~= nil then
                    print(string.format("[SmartGate][CONFIG] gate selected: %s", tostring(gate.id)))
                    showNotification("SmartGate: Tor erkannt - Konfiguration wird geaendert", 2500, FSBaseMission.INGAME_NOTIFICATION_OK)
                    SmartGateConfigEvent.send(gate)
                else
                    print("[SmartGate][CONFIG] no gate in front/rear config zone")
                    showNotification("SmartGate: Kein Tor im Config-Bereich", 3000, FSBaseMission.INGAME_NOTIFICATION_WARNING)
                end
            else
                state.previousRelease = t
            end
        else
            state.previousRelease = nil
        end
    end
end


function SmartGate:setConfigCursorEnabled(enabled)
    if g_inputBinding == nil or g_inputBinding.getShowMouseCursor == nil or g_inputBinding.setShowMouseCursor == nil then
        return
    end

    if enabled then
        local external, source = hasExternalCursorProvider()
        if external then
            self.configCursorOwned = false
            print("[SmartGate][CONFIG] cursor provider detected: " .. tostring(source))
            return
        end

        self.configCursorWasVisible = g_inputBinding:getShowMouseCursor() == true
        if not self.configCursorWasVisible then
            g_inputBinding:setShowMouseCursor(true)
            self.configCursorOwned = true
            print("[SmartGate][CONFIG] SmartGate enabled mouse cursor")
        end
    else
        if self.configCursorOwned then
            g_inputBinding:setShowMouseCursor(false)
            print("[SmartGate][CONFIG] SmartGate released mouse cursor")
        end
        self.configCursorOwned = false
        self.configCursorWasVisible = false
    end
end

local function nearestChoiceIndex(choices, value)
    local best, bestDistance = 1, math.huge
    value = tonumber(value) or choices[1]
    for i, v in ipairs(choices) do
        local d = math.abs(v - value)
        if d < bestDistance then
            best, bestDistance = i, d
        end
    end
    return best
end

function SmartGate:applyLocalGateGeometry(gate, field, value)
    if gate == nil then return end
    gate[field] = value
    gate.customGeometry = true
    self.savedCustomGeometry[gate.id] = true
end

function SmartGate:requestGateGeometry(gate, resetToDefaults)
    if gate == nil then return end

    if resetToDefaults then
        local defaults = self.settings ~= nil and self.settings.values or nil
        gate.customGeometry = false
        local defaultWidth = tonumber(defaults and defaults.triggerSideDistance) or DEFAULT_TRIGGER_SIDE_DISTANCE
        gate.triggerOpenDistance = tonumber(defaults and defaults.triggerOpenDistance) or AUTO_OPEN_DISTANCE
        gate.triggerOpenHalfWidth = defaultWidth
        gate.triggerCloseDistance = tonumber(defaults and defaults.triggerCloseDistance) or AUTO_CLOSE_DISTANCE
        gate.triggerCloseHalfWidth = defaultWidth
        gate.triggerSideDistance = defaultWidth
        gate.safetyDepth = tonumber(defaults and defaults.safetyDepth) or DEFAULT_SAFETY_DEPTH
        gate.safetyHalfWidth = tonumber(defaults and defaults.safetyHalfWidth) or DEFAULT_SAFETY_HALF_WIDTH
        gate.configDepth = CONFIG_ZONE_LENGTH
        gate.configHalfWidth = CONFIG_ZONE_HALF_WIDTH
        gate.axisSwapped = false
        gate.objectType = OBJECT_GATE
        gate.washPoint = false
        gate.interactionLatched = false
        gate.safetyClearDelayMs = tonumber(defaults and defaults.safetyClearDelayMs) or DEFAULT_SAFETY_CLEAR_DELAY_MS
        self.savedCustomGeometry[gate.id] = nil
    end

    SmartGateGateSettingsEvent.send(gate, resetToDefaults == true)
end

function SmartGate:stepGateSetting(gate, field, choices, delta)
    if gate == nil then return end
    local index = nearestChoiceIndex(choices, gate[field])
    index = math.max(1, math.min(#choices, index + delta))
    self:applyLocalGateGeometry(gate, field, choices[index])
    self:requestGateGeometry(gate, false)
end

function SmartGate:onToggleConfigAction(actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory)
    if inputValue ~= nil and inputValue <= 0 then return end
    self.configModeEnabled = not self.configModeEnabled
    self.hornStates = setmetatable({}, {__mode="k"})
    if self.configModeEnabled then
        print("[SmartGate][CONFIG] SmartGate config mode: true")
        self:setConfigCursorEnabled(true)
        showNotification("SmartGate Config: AKTIV - Tor anfahren und Panel benutzen", 5000, FSBaseMission.INGAME_NOTIFICATION_OK)
    else
        print("[SmartGate][CONFIG] SmartGate config mode: false")
        self:setConfigCursorEnabled(false)
        self.configPanelGate = nil
        showNotification("SmartGate Config: AUS", 2500, FSBaseMission.INGAME_NOTIFICATION_OK)
        self.markerGate = nil
        self.markerUntil = 0
    end
end

function SmartGate:onToggleVisualizationAction(actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory)
    if inputValue ~= nil and inputValue <= 0 then return end

    -- The selected gate visualization is intentionally forced while config mode
    -- is active. Do not change the user's normal visualization preference here,
    -- otherwise pressing the toggle in config mode would appear to do nothing
    -- and then unexpectedly change the state after leaving config mode.
    if self.configModeEnabled then
        showNotification("SmartGate: Visualisierung bleibt im Config-Modus aktiv", 3000, FSBaseMission.INGAME_NOTIFICATION_WARNING)
        return
    end

    self.showZonesAlways = not self.showZonesAlways
    showNotification(self.showZonesAlways and "SmartGate: Triggerbereiche sichtbar" or "SmartGate: Triggerbereiche ausgeblendet", 3000, FSBaseMission.INGAME_NOTIFICATION_OK)
end

function SmartGate:onToggleBlacklistAction(actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory)
    if inputValue ~= nil and inputValue <= 0 then return end
    if not self.configModeEnabled then
        showNotification("SmartGate: Erst Config-Modus aktivieren", 3000, FSBaseMission.INGAME_NOTIFICATION_WARNING)
        return
    end
    local vehicle = getLocalVehicle()
    local gate = self:findConfigGate(vehicle)
    if gate == nil then
        showNotification("SmartGate: Kein Trigger im Config-Bereich", 3000, FSBaseMission.INGAME_NOTIFICATION_WARNING)
        return
    end
    print(string.format("[SmartGate][CONFIG] blacklist target: %s (%s)", self:getGateName(gate), tostring(gate.id)))
    SmartGateBlacklistRequestEvent.send(gate)
end

local function installConfigInputHook()
    if PlayerInputComponent == nil or PlayerInputComponent.registerGlobalPlayerActionEvents == nil then
        print("[SmartGate][CONFIG] PlayerInputComponent unavailable; config input hook not installed")
        return false
    end
    PlayerInputComponent.registerGlobalPlayerActionEvents = Utils.appendedFunction(
        PlayerInputComponent.registerGlobalPlayerActionEvents,
        function(playerInputComponent, controlling)
            if g_smartGate == nil or g_inputBinding == nil or InputAction == nil or InputAction.SMARTGATE_CONFIG_TOGGLE == nil then return end
            local _, eventId = g_inputBinding:registerActionEvent(
                InputAction.SMARTGATE_CONFIG_TOGGLE,
                g_smartGate,
                SmartGate.onToggleConfigAction,
                false,
                true,
                false,
                true
            )
            if eventId ~= nil then
                g_inputBinding:setActionEventTextVisibility(eventId, false)
            end
            if InputAction.SMARTGATE_BLACKLIST_TOGGLE ~= nil then
                local _, blacklistEventId = g_inputBinding:registerActionEvent(
                    InputAction.SMARTGATE_BLACKLIST_TOGGLE,
                    g_smartGate,
                    SmartGate.onToggleBlacklistAction,
                    false,
                    true,
                    false,
                    true
                )
                if blacklistEventId ~= nil then
                    g_inputBinding:setActionEventTextVisibility(blacklistEventId, false)
                end
            end
            if InputAction.SMARTGATE_VISUALIZATION_TOGGLE ~= nil then
                local _, visualEventId = g_inputBinding:registerActionEvent(
                    InputAction.SMARTGATE_VISUALIZATION_TOGGLE,
                    g_smartGate,
                    SmartGate.onToggleVisualizationAction,
                    false,
                    true,
                    false,
                    true
                )
                if visualEventId ~= nil then g_inputBinding:setActionEventTextVisibility(visualEventId, false) end
            end
        end
    )
    print("[SmartGate][CONFIG] global config input hook installed")
    return true
end

function SmartGate:update(dt)
    self.scanTimer = self.scanTimer + dt
    self.rescanTimer = self.rescanTimer + dt
    self.stateSyncTimer = self.stateSyncTimer + dt
    if self.rescanTimer >= GATE_RESCAN_MS then self.rescanTimer = 0; self:rescan() end
    if g_server ~= nil and self.stateSyncTimer >= STATE_SYNC_INTERVAL_MS then
        self.stateSyncTimer = 0
        SmartGateStateSyncEvent.sendToClients(self.gates)
    end

    if not self.hornHookInstalled then self:installHornHook() end

    -- Config mode is deliberately SmartGate-owned. No cross-mod editor-state
    -- dependency is required; AutoDrive can remain installed or absent.

    self.configPanelRefreshTimer = (self.configPanelRefreshTimer or 0) + dt
    local localVehicle = getLocalVehicle()
    if self.configModeEnabled and self.configPanelRefreshTimer >= 150 then
        self.configPanelRefreshTimer = 0
        self.configPanelGate = self:findConfigGate(localVehicle)
    elseif not self.configModeEnabled then
        self.configPanelGate = nil
    end
    if localVehicle ~= self.lastPolledVehicle then
        self.lastPolledVehicle = localVehicle
        self.lastPolledHorn = nil
    end
    if localVehicle ~= nil and localVehicle.spec_honk ~= nil then
        local horn = localVehicle.spec_honk.isPlaying == true
        if self.lastPolledHorn == nil or horn ~= self.lastPolledHorn then
            self.lastPolledHorn = horn
            self:onHonk(localVehicle, horn)
        end
    end

    if g_server ~= nil and self.scanTimer >= SCAN_INTERVAL_MS then
        self.scanTimer = 0
        for _, gate in ipairs(self.gates) do
            local mode = gate.mode or MODE_ALL
            if gate.blacklisted or mode == MODE_DISABLED then
                gate.occupied = false
                gate.clearSince = nil
                gate.preOpenReserved = false
            else
                local depth = gate.occupied and (gate.triggerCloseDistance or AUTO_CLOSE_DISTANCE) or (gate.triggerOpenDistance or AUTO_OPEN_DISTANCE)
                local sideDistance = gate.occupied and (gate.triggerCloseHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE) or (gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
                local vehicleModeEnabled = mode == MODE_ALL or mode == MODE_VEHICLES
                local vehicleHit = vehicleModeEnabled and vehicleNearGate(gate, depth, sideDistance, true)
                local playerHit = (mode == MODE_ALL or mode == MODE_PLAYERS) and playerNearGate(gate, depth, sideDistance)

                if gate.objectType == OBJECT_INTERACTION then
                    local interactionHit = vehicleHit or playerHit
                    gate.preOpenReserved = false
                    gate.clearSince = nil
                    gate.occupied = interactionHit

                    if interactionHit then
                        gate.interactionClearSince = nil
                        if not gate.interactionLatched then
                            local triggered, method = triggerInteractiveObject(gate)
                            if triggered then
                                gate.interactionLatched = true
                                print(string.format("[SmartGate][INTERACTION] triggered '%s' via %s", tostring(gate.displayName or gate.id), tostring(method)))
                            else
                                print(string.format("[SmartGate][INTERACTION][WARN] could not trigger '%s': %s", tostring(gate.displayName or gate.id), tostring(method)))
                            end
                        end
                    elseif gate.interactionLatched then
                        local now = g_currentMission ~= nil and g_currentMission.time or 0
                        gate.interactionClearSince = gate.interactionClearSince or now
                        if now - gate.interactionClearSince >= 750 then
                            gate.interactionLatched = false
                            gate.interactionClearSince = nil
                            print(string.format("[SmartGate][INTERACTION] re-armed '%s'", tostring(gate.displayName or gate.id)))
                        end
                    end
                else
                    local preOpenHit, preOpenVehicle, preOpenDistance = false, nil, nil
                    if vehicleModeEnabled then
                        preOpenHit, preOpenVehicle, preOpenDistance = autoDriveRouteWillCrossGate(gate, AD_PREOPEN_DISTANCE)
                    end

                    if preOpenHit ~= gate.preOpenReserved then
                        gate.preOpenReserved = preOpenHit
                        if preOpenHit then
                            print(string.format("[SmartGate][AD] pre-open reserved gate '%s' at %.1fm", tostring(gate.displayName or gate.id), tonumber(preOpenDistance) or -1))
                            SmartGatePreOpenNotifyEvent.send(preOpenVehicle, gate.displayName or gate.id, preOpenDistance)
                        else
                            print(string.format("[SmartGate][AD] pre-open reservation released for gate '%s'", tostring(gate.displayName or gate.id)))
                        end
                    end

                    local triggerHit = vehicleHit or playerHit or preOpenHit
                    local safetyHit = vehicleInSafetyZone(gate)
                    local animationTime = gate.animatedObject ~= nil and gate.animatedObject.animation ~= nil and tonumber(gate.animatedObject.animation.time) or 0
                    local gateIsOpenOrMoving = animationTime > 0.001 or gate.occupied == true

                    if triggerHit then
                        gate.clearSince = nil
                        if not gate.occupied then
                            gate.occupied = true
                            setGateOpen(gate, true)
                        end
                    elseif safetyHit and gateIsOpenOrMoving then
                        gate.clearSince = nil
                        gate.occupied = true
                        setGateOpen(gate, true)
                    elseif gate.occupied then
                        local now = nowMs()
                        if gate.clearSince == nil then gate.clearSince = now end
                        if now - gate.clearSince >= (gate.safetyClearDelayMs or DEFAULT_SAFETY_CLEAR_DELAY_MS) then
                            gate.clearSince = nil
                            gate.occupied = false
                            setGateOpen(gate, false)
                        end
                    else
                        gate.clearSince = nil
                    end
                end
            end
        end
    end
end

local function getTerrainY(x, z, fallbackY)
    if g_currentMission ~= nil and g_currentMission.terrainRootNode ~= nil and getTerrainHeightAtWorldPos ~= nil then
        local ok, y = pcall(getTerrainHeightAtWorldPos, g_currentMission.terrainRootNode, x, 0, z)
        if ok and y ~= nil then return y + 0.08 end
    end
    return (fallbackY or 0) + 0.08
end

local function drawGateRectangle(gate, halfDepth, halfWidth, r, g, b)
    if drawDebugLine == nil or gate == nil then return end
    local fx, fz, rx, rz = getGateAxes(gate)
    local corners = {
        {gate.x + fx*halfDepth + rx*halfWidth, gate.z + fz*halfDepth + rz*halfWidth},
        {gate.x + fx*halfDepth - rx*halfWidth, gate.z + fz*halfDepth - rz*halfWidth},
        {gate.x - fx*halfDepth - rx*halfWidth, gate.z - fz*halfDepth - rz*halfWidth},
        {gate.x - fx*halfDepth + rx*halfWidth, gate.z - fz*halfDepth + rz*halfWidth}
    }
    for i=1,4 do
        local a, c = corners[i], corners[(i % 4) + 1]
        local ay = getTerrainY(a[1], a[2], gate.y)
        local cy = getTerrainY(c[1], c[2], gate.y)
        drawDebugLine(a[1], ay, a[2], r,g,b, c[1], cy, c[2], r,g,b, false)
    end
end

function SmartGate:drawGateZones(gate)
    if gate == nil then return end
    if gate.objectType == OBJECT_INTERACTION then
        -- Interaction mode visualizes only SmartGate's activation area plus the
        -- config zone. The foreign object's own work/vehicle triggers remain its
        -- responsibility and are never resized or moved by SmartGate.
        drawGateRectangle(gate, gate.triggerOpenDistance or AUTO_OPEN_DISTANCE, gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE, VISUAL_TRIGGER_R, VISUAL_TRIGGER_G, VISUAL_TRIGGER_B)
        drawGateRectangle(gate, gate.configDepth or CONFIG_ZONE_LENGTH, gate.configHalfWidth or CONFIG_ZONE_HALF_WIDTH, VISUAL_CONFIG_R, VISUAL_CONFIG_G, VISUAL_CONFIG_B)
        return
    end
    drawGateRectangle(gate, gate.triggerCloseDistance or AUTO_CLOSE_DISTANCE, gate.triggerCloseHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE, VISUAL_CLOSE_R, VISUAL_CLOSE_G, VISUAL_CLOSE_B)
    drawGateRectangle(gate, gate.triggerOpenDistance or AUTO_OPEN_DISTANCE, gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE, VISUAL_TRIGGER_R, VISUAL_TRIGGER_G, VISUAL_TRIGGER_B)
    drawGateRectangle(gate, gate.configDepth or CONFIG_ZONE_LENGTH, gate.configHalfWidth or CONFIG_ZONE_HALF_WIDTH, VISUAL_CONFIG_R, VISUAL_CONFIG_G, VISUAL_CONFIG_B)
    drawGateRectangle(gate, gate.safetyDepth or DEFAULT_SAFETY_DEPTH, gate.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH, VISUAL_SAFETY_R, VISUAL_SAFETY_G, VISUAL_SAFETY_B)
end


local CONFIG_PANEL_GATE_ROWS = {
    {label="Open-Länge", field="triggerOpenDistance", choices=PANEL_LENGTH_CHOICES},
    {label="Open-Breite", field="triggerOpenHalfWidth", choices=PANEL_WIDTH_CHOICES},
    {label="Close-Länge", field="triggerCloseDistance", choices=PANEL_LENGTH_CHOICES},
    {label="Close-Breite", field="triggerCloseHalfWidth", choices=PANEL_WIDTH_CHOICES},
    {label="Safety-Länge", field="safetyDepth", choices=PANEL_LENGTH_CHOICES},
    {label="Safety-Breite", field="safetyHalfWidth", choices=PANEL_WIDTH_CHOICES},
    {label="Config-Länge", field="configDepth", choices=PANEL_LENGTH_CHOICES},
    {label="Config-Breite", field="configHalfWidth", choices=PANEL_WIDTH_CHOICES},
    {label="Safety-Delay", field="safetyClearDelayMs", choices=PANEL_DELAY_CHOICES}
}

local CONFIG_PANEL_INTERACTION_ROWS = {
    {label="Auslösebereich-Länge", field="triggerOpenDistance", choices=PANEL_LENGTH_CHOICES},
    {label="Auslösebereich-Breite", field="triggerOpenHalfWidth", choices=PANEL_WIDTH_CHOICES},
    {label="Config-Länge", field="configDepth", choices=PANEL_LENGTH_CHOICES},
    {label="Config-Breite", field="configHalfWidth", choices=PANEL_WIDTH_CHOICES}
}

local function getConfigPanelRows(gate)
    return gate ~= nil and gate.objectType == OBJECT_INTERACTION and CONFIG_PANEL_INTERACTION_ROWS or CONFIG_PANEL_GATE_ROWS
end

local function pointInUiRect(px, py, x, y, w, h)
    return px >= x and px <= x + w and py >= y and py <= y + h
end

function SmartGate:drawConfigPanel()
    local gate = self.configPanelGate
    if not self.configModeEnabled or gate == nil then return end

    local x = CONFIG_PANEL_X
    local y = CONFIG_PANEL_Y
    local w = CONFIG_PANEL_W
    local rowH = CONFIG_PANEL_ROW_H
    local rows = getConfigPanelRows(gate)
    local interactionExtra = gate.objectType == OBJECT_INTERACTION and 0.034 or 0
    local totalH = 0.078 + (#rows * rowH) + 0.114 + interactionExtra

    if drawFilledRect ~= nil then
        drawFilledRect(x, y - totalH, w, totalH, 0.03, 0.03, 0.03, 0.82)
        drawFilledRect(x, y - 0.038, w, 0.038, 0.09, 0.09, 0.09, 0.95)
    end

    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(true)
    renderText(x + 0.010, y - 0.026, 0.014, "SmartGate - Objekt konfigurieren")
    setTextBold(false)
    renderText(x + 0.010, y - 0.050, 0.010, self:getGateName(gate))

    local status = gate.customGeometry and "CUSTOM" or "GLOBAL DEFAULTS"
    renderText(x + w - 0.082, y - 0.050, 0.009, status)

    for i, row in ipairs(rows) do
        local ry = y - 0.075 - (i - 1) * rowH
        local value = gate[row.field]
        local display
        if row.field == "safetyClearDelayMs" then
            display = value >= 1000 and string.format("%.1f s", value / 1000) or tostring(value) .. " ms"
        else
            display = string.format("%g m", tonumber(value) or 0)
        end

        renderText(x + 0.010, ry, 0.010, row.label)
        renderText(x + 0.150, ry, 0.010, "<")
        setTextAlignment(RenderText.ALIGN_CENTER)
        renderText(x + 0.184, ry, 0.010, display)
        setTextAlignment(RenderText.ALIGN_LEFT)
        renderText(x + 0.222, ry, 0.010, ">")
    end

    local typeY = y - 0.088 - (#rows * rowH)
    if drawFilledRect ~= nil then
        drawFilledRect(x + 0.010, typeY, w - 0.020, 0.028, 0.12, 0.12, 0.12, 0.95)
    end
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(x + w/2, typeY + 0.007, 0.010, gate.objectType == OBJECT_INTERACTION and "Objekttyp: INTERAKTIV" or "Objekttyp: TOR")

    local axisY = typeY - 0.034
    if gate.objectType == OBJECT_INTERACTION then
        local washY = axisY
        if drawFilledRect ~= nil then
            drawFilledRect(x + 0.010, washY, w - 0.020, 0.028, gate.washPoint and 0.10 or 0.12, gate.washPoint and 0.28 or 0.12, gate.washPoint and 0.10 or 0.12, 0.95)
        end
        renderText(x + w/2, washY + 0.007, 0.010, gate.washPoint and "[X] Ist Waschpunkt" or "[ ] Ist Waschpunkt")
        axisY = washY - 0.034
    end

    if drawFilledRect ~= nil then
        drawFilledRect(x + 0.010, axisY, w - 0.020, 0.028, 0.12, 0.12, 0.12, 0.95)
    end
    renderText(x + w/2, axisY + 0.007, 0.010, gate.axisSwapped and "Achsen tauschen: 90°" or "Achsen tauschen: NORMAL")

    local by = axisY - 0.034
    if drawFilledRect ~= nil then
        drawFilledRect(x + 0.010, by, w - 0.020, 0.028, 0.15, 0.15, 0.15, 0.95)
    end
    renderText(x + w/2, by + 0.007, 0.010, "Auf globale Defaults zurücksetzen")
    setTextAlignment(RenderText.ALIGN_LEFT)
end

function SmartGate:mouseEvent(posX, posY, isDown, isUp, button)
    if not self.configModeEnabled or self.configPanelGate == nil or not isDown then return end
    if Input ~= nil and Input.MOUSE_BUTTON_LEFT ~= nil and button ~= nil and button ~= Input.MOUSE_BUTTON_LEFT then return end

    local x = CONFIG_PANEL_X
    local y = CONFIG_PANEL_Y
    local rowH = CONFIG_PANEL_ROW_H
    local gate = self.configPanelGate
    local rows = getConfigPanelRows(gate)

    for i, row in ipairs(rows) do
        local ry = y - 0.075 - (i - 1) * rowH - 0.004
        if pointInUiRect(posX, posY, x + 0.137, ry, 0.030, 0.024) then
            self:stepGateSetting(gate, row.field, row.choices, -1)
            return
        elseif pointInUiRect(posX, posY, x + 0.207, ry, 0.030, 0.024) then
            self:stepGateSetting(gate, row.field, row.choices, 1)
            return
        end
    end

    local typeY = y - 0.088 - (#rows * rowH)
    if pointInUiRect(posX, posY, x + 0.010, typeY, CONFIG_PANEL_W - 0.020, 0.028) then
        local switchingToInteraction = gate.objectType ~= OBJECT_INTERACTION
        local hadCustomGeometry = gate.customGeometry == true
        gate.objectType = switchingToInteraction and OBJECT_INTERACTION or OBJECT_GATE
        if gate.objectType ~= OBJECT_INTERACTION then gate.washPoint = false end
        gate.interactionLatched = false
        gate.interactionClearSince = nil
        if switchingToInteraction and not hadCustomGeometry then
            gate.triggerOpenDistance = 0.75
        end
        gate.customGeometry = true
        self.savedCustomGeometry[gate.id] = true
        self:requestGateGeometry(gate, false)
        return
    end

    local axisY = typeY - 0.034
    if gate.objectType == OBJECT_INTERACTION then
        local washY = axisY
        if pointInUiRect(posX, posY, x + 0.010, washY, CONFIG_PANEL_W - 0.020, 0.028) then
            gate.washPoint = not (gate.washPoint == true)
            gate.customGeometry = true
            self.savedCustomGeometry[gate.id] = true
            print(string.format("[SmartGate][CONFIG] wash point '%s' -> %s", tostring(gate.displayName or gate.id), tostring(gate.washPoint)))
            self:requestGateGeometry(gate, false)
            return
        end
        axisY = washY - 0.034
    end

    if pointInUiRect(posX, posY, x + 0.010, axisY, CONFIG_PANEL_W - 0.020, 0.028) then
        gate.axisSwapped = not (gate.axisSwapped == true)
        gate.customGeometry = true
        self.savedCustomGeometry[gate.id] = true
        self:requestGateGeometry(gate, false)
        return
    end

    local by = axisY - 0.034
    if pointInUiRect(posX, posY, x + 0.010, by, CONFIG_PANEL_W - 0.020, 0.028) then
        self:requestGateGeometry(gate, true)
        showNotification("SmartGate: Objekt nutzt wieder globale Defaults", 3000, FSBaseMission.INGAME_NOTIFICATION_OK)
    end
end

function SmartGate:draw()
    -- Keep a subtle persistent reminder on screen while SmartGate configuration
    -- mode is active. This also explains why the selected gate visualization
    -- cannot be hidden until config mode is left.
    if self.configModeEnabled then
        setTextAlignment(RenderText.ALIGN_CENTER)
        setTextBold(true)
        renderText(0.5, 0.025, 0.012, "SmartGate Config-Modus aktiv")
        setTextBold(false)
        setTextAlignment(RenderText.ALIGN_LEFT)
    end

    local showZones = self.configModeEnabled or self.showZonesAlways
    local visualGate = nil
    if showZones then
        visualGate = self.markerGate
        if visualGate == nil or (self.markerUntil > 0 and nowMs() > self.markerUntil) then
            visualGate = self:findConfigGate(getLocalVehicle())
        end
        if visualGate ~= nil then self:drawGateZones(visualGate) end
    end

    if self.configModeEnabled then
        self:drawConfigPanel()
    end

    if not self.configModeEnabled then return end
    if self.markerGate == nil or nowMs() > self.markerUntil then return end
    local gate = self.markerGate
    local mx, my, mz = self:getMarkerWorldPosition(gate)
    local sx, sy, depth = project(mx, my + 2.5, mz)
    if depth == nil or depth <= 0 or depth >= 1 then return end
    local w, h = 0.035, 0.035 * g_screenAspectRatio
    if self.markerOverlay ~= nil then renderOverlay(self.markerOverlay, sx - w/2, sy, w, h) end
    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextBold(true)
    local stateText = self.markerBlacklisted and BLACKLIST_TEXT or (MODE_TEXT_DE[self.markerMode] or "SMARTGATE")
    renderText(sx, sy - 0.018, 0.013, stateText)
    renderText(sx, sy - 0.034, 0.010, self:getGateName(gate))
    setTextBold(false)
    setTextAlignment(RenderText.ALIGN_LEFT)
end

function SmartGate:loadMap()
    print("[SmartGate] Agriculture Science SmartGate v0.1.3.4 Persistence Fix RC loaded")
    if g_currentMission ~= nil then
        g_currentMission.agricultureScienceSmartGateAPI = SmartGateAPI
        print("[SmartGate][API] shared API registered on mission")
    end
    self:loadConfig()
    self:rescan()
    self.configModeEnabled = false
    self.configCursorOwned = false
    self.configCursorWasVisible = false
    self.configPanelGate = nil
    self.hornHookInstalled = false
    if createImageOverlay ~= nil then
        self.markerOverlay = createImageOverlay(MOD_DIR .. "config_marker.dds")
    end
    if not self:installHornHook() then
        print("[SmartGate][CONFIG] horn hook not available yet; update loop will retry")
    end
end

function SmartGate:deleteMap()
    self:setConfigCursorEnabled(false)
    self.configPanelGate = nil
    if g_currentMission ~= nil and g_currentMission.agricultureScienceSmartGateAPI == SmartGateAPI then
        g_currentMission.agricultureScienceSmartGateAPI = nil
        print("[SmartGate][API] shared API unregistered from mission")
    end
    if self.markerOverlay ~= nil then delete(self.markerOverlay); self.markerOverlay = nil end
end

function SmartGate:saveSavegame()
    self:saveConfig()
end

-- Dedicated-server-safe AutoDrive pre-open notification. The server broadcasts
-- the causing vehicle; each client only displays the message when that vehicle
-- is the one locally controlled by the player.
SmartGatePreOpenNotifyEvent = {}
local SmartGatePreOpenNotifyEvent_mt = Class(SmartGatePreOpenNotifyEvent, Event)
InitEventClass(SmartGatePreOpenNotifyEvent, "SmartGatePreOpenNotifyEvent")
function SmartGatePreOpenNotifyEvent.emptyNew() return Event.new(SmartGatePreOpenNotifyEvent_mt) end
function SmartGatePreOpenNotifyEvent.new(vehicle, gateName, distance)
    local self = SmartGatePreOpenNotifyEvent.emptyNew()
    self.vehicle = getRootVehicle(vehicle) or vehicle
    self.gateName = tostring(gateName or "Tor")
    self.distance = tonumber(distance) or -1
    return self
end
function SmartGatePreOpenNotifyEvent:writeStream(streamId, connection)
    NetworkUtil.writeNodeObject(streamId, self.vehicle)
    streamWriteString(streamId, self.gateName or "Tor")
    streamWriteFloat32(streamId, self.distance or -1)
end
function SmartGatePreOpenNotifyEvent:readStream(streamId, connection)
    self.vehicle = NetworkUtil.readNodeObject(streamId)
    self.gateName = streamReadString(streamId)
    self.distance = streamReadFloat32(streamId)
    self:run(connection)
end
function SmartGatePreOpenNotifyEvent:run(connection)
    if g_client == nil then return end
    local localRoot = getRootVehicle(getLocalVehicle())
    local eventRoot = getRootVehicle(self.vehicle)
    if localRoot ~= nil and eventRoot ~= nil and localRoot == eventRoot then
        local distanceText = self.distance ~= nil and self.distance >= 0 and string.format(" (%.0f m)", self.distance) or ""
        showNotification("SmartGate: Tor voraus vorgeöffnet" .. distanceText, 3000, FSBaseMission.INGAME_NOTIFICATION_OK)
    end
end
function SmartGatePreOpenNotifyEvent.send(vehicle, gateName, distance)
    if vehicle == nil then return end
    local event = SmartGatePreOpenNotifyEvent.new(vehicle, gateName, distance)
    if g_server ~= nil then
        g_server:broadcastEvent(event, false)
        -- Listen server / singleplayer does not receive its own broadcast.
        if g_client ~= nil then event:run(nil) end
    end
end

-- Config request: client -> server. The descriptor fallback is important for
-- modded placeables whose runtime AnimatedObject/node identity can differ between
-- dedicated server and client even though they represent the same visible gate.
SmartGateConfigEvent = {}
local SmartGateConfigEvent_mt = Class(SmartGateConfigEvent, Event)
InitEventClass(SmartGateConfigEvent, "SmartGateConfigEvent")
function SmartGateConfigEvent.emptyNew() return Event.new(SmartGateConfigEvent_mt) end
function SmartGateConfigEvent.new(id, ownerKey, nodeKey, x, z)
    local self=SmartGateConfigEvent.emptyNew(); self.id=id; self.ownerKey=ownerKey; self.nodeKey=nodeKey; self.x=x; self.z=z; return self
end
function SmartGateConfigEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or ""); streamWriteString(streamId, self.ownerKey or ""); streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0); streamWriteFloat32(streamId, self.z or 0)
end
function SmartGateConfigEvent:readStream(streamId, connection)
    self.id=streamReadString(streamId); self.ownerKey=streamReadString(streamId); self.nodeKey=streamReadString(streamId)
    self.x=streamReadFloat32(streamId); self.z=streamReadFloat32(streamId); self:run(connection)
end
function SmartGateConfigEvent:run(connection)
    if connection ~= nil and not connection:getIsServer() and g_smartGate ~= nil then
        g_smartGate:cycleGate(self.id, self.ownerKey, self.nodeKey, self.x, self.z)
    end
end
function SmartGateConfigEvent.send(gate)
    if gate == nil then return end
    local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
    if g_server ~= nil then g_smartGate:cycleGate(id, ownerKey, nodeKey, x, z)
    elseif g_client ~= nil then g_client:getServerConnection():sendEvent(SmartGateConfigEvent.new(id, ownerKey, nodeKey, x, z)) end
end

-- Mode update: server -> all clients. Clients resolve by exact id first and then
-- by the stable descriptor so mod-placeable runtime ids no longer have to match.
SmartGateModeEvent = {}
local SmartGateModeEvent_mt = Class(SmartGateModeEvent, Event)
InitEventClass(SmartGateModeEvent, "SmartGateModeEvent")
function SmartGateModeEvent.emptyNew() return Event.new(SmartGateModeEvent_mt) end
function SmartGateModeEvent.new(id, ownerKey, nodeKey, x, z, mode)
    local self=SmartGateModeEvent.emptyNew(); self.id=id; self.ownerKey=ownerKey; self.nodeKey=nodeKey; self.x=x; self.z=z; self.mode=mode; return self
end
function SmartGateModeEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or ""); streamWriteString(streamId, self.ownerKey or ""); streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0); streamWriteFloat32(streamId, self.z or 0); streamWriteUIntN(streamId, self.mode or 0, 2)
end
function SmartGateModeEvent:readStream(streamId, connection)
    self.id=streamReadString(streamId); self.ownerKey=streamReadString(streamId); self.nodeKey=streamReadString(streamId)
    self.x=streamReadFloat32(streamId); self.z=streamReadFloat32(streamId); self.mode=streamReadUIntN(streamId,2); self:run(connection)
end
function SmartGateModeEvent:run(connection)
    if connection ~= nil and connection:getIsServer() and g_smartGate ~= nil then
        local gate = g_smartGate:resolveGate(self.id, self.ownerKey, self.nodeKey, self.x, self.z)
        if gate ~= nil then gate.mode=self.mode; g_smartGate.savedModes[gate.id]=self.mode; g_smartGate:notifyMode(gate,self.mode) end
    end
end
function SmartGateModeEvent.sendToClients(gate, mode)
    if g_server ~= nil and gate ~= nil then
        local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
        g_server:broadcastEvent(SmartGateModeEvent.new(id, ownerKey, nodeKey, x, z, mode), false)
        if g_smartGate ~= nil then g_smartGate:notifyMode(gate, mode) end
    end
end

-- Blacklist request: client -> server.
SmartGateBlacklistRequestEvent = {}
local SmartGateBlacklistRequestEvent_mt = Class(SmartGateBlacklistRequestEvent, Event)
InitEventClass(SmartGateBlacklistRequestEvent, "SmartGateBlacklistRequestEvent")
function SmartGateBlacklistRequestEvent.emptyNew() return Event.new(SmartGateBlacklistRequestEvent_mt) end
function SmartGateBlacklistRequestEvent.new(id, ownerKey, nodeKey, x, z)
    local self=SmartGateBlacklistRequestEvent.emptyNew(); self.id=id; self.ownerKey=ownerKey; self.nodeKey=nodeKey; self.x=x; self.z=z; return self
end
function SmartGateBlacklistRequestEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or ""); streamWriteString(streamId, self.ownerKey or ""); streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0); streamWriteFloat32(streamId, self.z or 0)
end
function SmartGateBlacklistRequestEvent:readStream(streamId, connection)
    self.id=streamReadString(streamId); self.ownerKey=streamReadString(streamId); self.nodeKey=streamReadString(streamId)
    self.x=streamReadFloat32(streamId); self.z=streamReadFloat32(streamId); self:run(connection)
end
function SmartGateBlacklistRequestEvent:run(connection)
    if connection ~= nil and not connection:getIsServer() and g_smartGate ~= nil then
        g_smartGate:toggleBlacklist(self.id, self.ownerKey, self.nodeKey, self.x, self.z)
    end
end
function SmartGateBlacklistRequestEvent.send(gate)
    if gate == nil then return end
    local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
    if g_server ~= nil then g_smartGate:toggleBlacklist(id, ownerKey, nodeKey, x, z)
    elseif g_client ~= nil then g_client:getServerConnection():sendEvent(SmartGateBlacklistRequestEvent.new(id, ownerKey, nodeKey, x, z)) end
end

-- Blacklist update: server -> all clients.
SmartGateBlacklistEvent = {}
local SmartGateBlacklistEvent_mt = Class(SmartGateBlacklistEvent, Event)
InitEventClass(SmartGateBlacklistEvent, "SmartGateBlacklistEvent")
function SmartGateBlacklistEvent.emptyNew() return Event.new(SmartGateBlacklistEvent_mt) end
function SmartGateBlacklistEvent.new(id, ownerKey, nodeKey, x, z, blacklisted)
    local self=SmartGateBlacklistEvent.emptyNew(); self.id=id; self.ownerKey=ownerKey; self.nodeKey=nodeKey; self.x=x; self.z=z; self.blacklisted=blacklisted == true; return self
end
function SmartGateBlacklistEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or ""); streamWriteString(streamId, self.ownerKey or ""); streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0); streamWriteFloat32(streamId, self.z or 0); streamWriteBool(streamId, self.blacklisted)
end
function SmartGateBlacklistEvent:readStream(streamId, connection)
    self.id=streamReadString(streamId); self.ownerKey=streamReadString(streamId); self.nodeKey=streamReadString(streamId)
    self.x=streamReadFloat32(streamId); self.z=streamReadFloat32(streamId); self.blacklisted=streamReadBool(streamId); self:run(connection)
end
function SmartGateBlacklistEvent:run(connection)
    if connection ~= nil and connection:getIsServer() and g_smartGate ~= nil then
        local gate = g_smartGate:resolveGate(self.id, self.ownerKey, self.nodeKey, self.x, self.z)
        if gate ~= nil then
            gate.blacklisted = self.blacklisted
            if self.blacklisted then g_smartGate.savedBlacklist[gate.id]=true else g_smartGate.savedBlacklist[gate.id]=nil end
            g_smartGate:notifyBlacklist(gate, self.blacklisted)
        end
    end
end
function SmartGateBlacklistEvent.sendToClients(gate, blacklisted)
    if g_server ~= nil and gate ~= nil then
        local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
        g_server:broadcastEvent(SmartGateBlacklistEvent.new(id, ownerKey, nodeKey, x, z, blacklisted), false)
        if g_smartGate ~= nil then g_smartGate:notifyBlacklist(gate, blacklisted) end
    end
end

-- Periodic full-state sync. This deliberately avoids depending on a specific
-- join callback: a late-joining MP client receives modes and blacklist state
-- within STATE_SYNC_INTERVAL_MS even if it missed earlier per-gate events.

function SmartGate:applyGateGeometryOnServer(id, ownerKey, nodeKey, x, z, resetToDefaults, values)
    if g_server == nil then return end
    local gate = self:resolveGate(id, ownerKey, nodeKey, x, z)
    if gate == nil then return end

    if resetToDefaults then
        local defaults = self.settings ~= nil and self.settings.values or nil
        gate.customGeometry = false
        local defaultWidth = tonumber(defaults and defaults.triggerSideDistance) or DEFAULT_TRIGGER_SIDE_DISTANCE
        gate.triggerOpenDistance = tonumber(defaults and defaults.triggerOpenDistance) or AUTO_OPEN_DISTANCE
        gate.triggerOpenHalfWidth = defaultWidth
        gate.triggerCloseDistance = tonumber(defaults and defaults.triggerCloseDistance) or AUTO_CLOSE_DISTANCE
        gate.triggerCloseHalfWidth = defaultWidth
        gate.triggerSideDistance = defaultWidth
        gate.safetyDepth = tonumber(defaults and defaults.safetyDepth) or DEFAULT_SAFETY_DEPTH
        gate.safetyHalfWidth = tonumber(defaults and defaults.safetyHalfWidth) or DEFAULT_SAFETY_HALF_WIDTH
        gate.configDepth = CONFIG_ZONE_LENGTH
        gate.configHalfWidth = CONFIG_ZONE_HALF_WIDTH
        gate.axisSwapped = false
        gate.objectType = OBJECT_GATE
        gate.washPoint = false
        gate.interactionLatched = false
        gate.safetyClearDelayMs = tonumber(defaults and defaults.safetyClearDelayMs) or DEFAULT_SAFETY_CLEAR_DELAY_MS
        self.savedCustomGeometry[gate.id] = nil
        print("[SmartGate][CONFIG] gate reset to global defaults: " .. tostring(gate.id))
    else
        gate.customGeometry = true
        gate.triggerOpenDistance = tonumber(values.triggerOpenDistance) or gate.triggerOpenDistance
        gate.triggerOpenHalfWidth = tonumber(values.triggerOpenHalfWidth) or gate.triggerOpenHalfWidth or gate.triggerSideDistance
        gate.triggerCloseDistance = tonumber(values.triggerCloseDistance) or gate.triggerCloseDistance
        gate.triggerCloseHalfWidth = tonumber(values.triggerCloseHalfWidth) or gate.triggerCloseHalfWidth or gate.triggerSideDistance
        gate.triggerSideDistance = gate.triggerOpenHalfWidth or gate.triggerSideDistance
        gate.safetyDepth = tonumber(values.safetyDepth) or gate.safetyDepth
        gate.safetyHalfWidth = tonumber(values.safetyHalfWidth) or gate.safetyHalfWidth
        gate.configDepth = tonumber(values.configDepth) or gate.configDepth or CONFIG_ZONE_LENGTH
        gate.configHalfWidth = tonumber(values.configHalfWidth) or gate.configHalfWidth or CONFIG_ZONE_HALF_WIDTH
        gate.axisSwapped = values.axisSwapped == true
        gate.objectType = tonumber(values.objectType) == OBJECT_INTERACTION and OBJECT_INTERACTION or OBJECT_GATE
        gate.washPoint = gate.objectType == OBJECT_INTERACTION and values.washPoint == true
        gate.interactionLatched = false
        gate.safetyClearDelayMs = tonumber(values.safetyClearDelayMs) or gate.safetyClearDelayMs
        self.savedCustomGeometry[gate.id] = true
        print("[SmartGate][CONFIG] custom geometry applied: " .. tostring(gate.id))
    end

    self.savedGateSettings[gate.id] = {
        triggerOpenDistance=gate.triggerOpenDistance,
        triggerOpenHalfWidth=gate.triggerOpenHalfWidth,
        triggerCloseDistance=gate.triggerCloseDistance,
        triggerCloseHalfWidth=gate.triggerCloseHalfWidth,
        triggerSideDistance=gate.triggerSideDistance,
        safetyDepth=gate.safetyDepth,
        safetyHalfWidth=gate.safetyHalfWidth,
        configDepth=gate.configDepth,
        configHalfWidth=gate.configHalfWidth,
        axisSwapped=gate.axisSwapped == true,
        objectType=gate.objectType or OBJECT_GATE,
        washPoint=gate.washPoint == true,
        safetyClearDelayMs=gate.safetyClearDelayMs
    }

    self:saveConfig()
    SmartGateStateSyncEvent.sendToClients(self.gates)
end

SmartGateGateSettingsEvent = {}
local SmartGateGateSettingsEvent_mt = Class(SmartGateGateSettingsEvent, Event)
InitEventClass(SmartGateGateSettingsEvent, "SmartGateGateSettingsEvent")
function SmartGateGateSettingsEvent.emptyNew() return Event.new(SmartGateGateSettingsEvent_mt) end
function SmartGateGateSettingsEvent.new(gate, resetToDefaults)
    local self = SmartGateGateSettingsEvent.emptyNew()
    self.id, self.ownerKey, self.nodeKey, self.x, self.z = g_smartGate:getGateDescriptor(gate)
    self.resetToDefaults = resetToDefaults == true
    self.values = {
        triggerOpenDistance=gate.triggerOpenDistance,
        triggerOpenHalfWidth=gate.triggerOpenHalfWidth,
        triggerCloseDistance=gate.triggerCloseDistance,
        triggerCloseHalfWidth=gate.triggerCloseHalfWidth,
        triggerSideDistance=gate.triggerSideDistance,
        safetyDepth=gate.safetyDepth,
        safetyHalfWidth=gate.safetyHalfWidth,
        configDepth=gate.configDepth,
        configHalfWidth=gate.configHalfWidth,
        axisSwapped=gate.axisSwapped == true,
        objectType=gate.objectType or OBJECT_GATE,
        washPoint=gate.washPoint == true,
        safetyClearDelayMs=gate.safetyClearDelayMs
    }
    return self
end
function SmartGateGateSettingsEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or "")
    streamWriteString(streamId, self.ownerKey or "")
    streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0)
    streamWriteFloat32(streamId, self.z or 0)
    streamWriteBool(streamId, self.resetToDefaults == true)
    streamWriteFloat32(streamId, self.values.triggerOpenDistance or AUTO_OPEN_DISTANCE)
    streamWriteFloat32(streamId, self.values.triggerOpenHalfWidth or self.values.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
    streamWriteFloat32(streamId, self.values.triggerCloseDistance or AUTO_CLOSE_DISTANCE)
    streamWriteFloat32(streamId, self.values.triggerCloseHalfWidth or self.values.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
    streamWriteFloat32(streamId, self.values.safetyDepth or DEFAULT_SAFETY_DEPTH)
    streamWriteFloat32(streamId, self.values.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH)
    streamWriteFloat32(streamId, self.values.configDepth or CONFIG_ZONE_LENGTH)
    streamWriteFloat32(streamId, self.values.configHalfWidth or CONFIG_ZONE_HALF_WIDTH)
    streamWriteBool(streamId, self.values.axisSwapped == true)
    streamWriteUIntN(streamId, self.values.objectType or OBJECT_GATE, 1)
    streamWriteBool(streamId, self.values.washPoint == true)
    streamWriteUInt16(streamId, self.values.safetyClearDelayMs or DEFAULT_SAFETY_CLEAR_DELAY_MS)
end
function SmartGateGateSettingsEvent:readStream(streamId, connection)
    self.id = streamReadString(streamId)
    self.ownerKey = streamReadString(streamId)
    self.nodeKey = streamReadString(streamId)
    self.x = streamReadFloat32(streamId)
    self.z = streamReadFloat32(streamId)
    self.resetToDefaults = streamReadBool(streamId)
    self.values = {
        triggerOpenDistance=streamReadFloat32(streamId),
        triggerOpenHalfWidth=streamReadFloat32(streamId),
        triggerCloseDistance=streamReadFloat32(streamId),
        triggerCloseHalfWidth=streamReadFloat32(streamId),
        safetyDepth=streamReadFloat32(streamId),
        safetyHalfWidth=streamReadFloat32(streamId),
        configDepth=streamReadFloat32(streamId),
        configHalfWidth=streamReadFloat32(streamId),
        axisSwapped=streamReadBool(streamId),
        objectType=streamReadUIntN(streamId,1),
        washPoint=streamReadBool(streamId),
        safetyClearDelayMs=streamReadUInt16(streamId)
    }
    self:run(connection)
end
function SmartGateGateSettingsEvent:run(connection)
    if g_server ~= nil and connection ~= nil and not connection:getIsServer() and g_smartGate ~= nil then
        g_smartGate:applyGateGeometryOnServer(self.id, self.ownerKey, self.nodeKey, self.x, self.z, self.resetToDefaults, self.values)
    end
end
function SmartGateGateSettingsEvent.send(gate, resetToDefaults)
    if gate == nil or g_smartGate == nil then return end
    if g_server ~= nil then
        local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
        g_smartGate:applyGateGeometryOnServer(id, ownerKey, nodeKey, x, z, resetToDefaults == true, {
            triggerOpenDistance=gate.triggerOpenDistance,
            triggerOpenHalfWidth=gate.triggerOpenHalfWidth,
            triggerCloseDistance=gate.triggerCloseDistance,
            triggerCloseHalfWidth=gate.triggerCloseHalfWidth,
            triggerSideDistance=gate.triggerSideDistance,
            safetyDepth=gate.safetyDepth,
            safetyHalfWidth=gate.safetyHalfWidth,
            configDepth=gate.configDepth,
            configHalfWidth=gate.configHalfWidth,
            axisSwapped=gate.axisSwapped == true,
            objectType=gate.objectType or OBJECT_GATE,
            washPoint=gate.washPoint == true,
            safetyClearDelayMs=gate.safetyClearDelayMs
        })
    elseif g_client ~= nil and g_client.getServerConnection ~= nil then
        g_client:getServerConnection():sendEvent(SmartGateGateSettingsEvent.new(gate, resetToDefaults))
    end
end

SmartGateStateSyncEvent = {}
local SmartGateStateSyncEvent_mt = Class(SmartGateStateSyncEvent, Event)
InitEventClass(SmartGateStateSyncEvent, "SmartGateStateSyncEvent")
function SmartGateStateSyncEvent.emptyNew() return Event.new(SmartGateStateSyncEvent_mt) end
function SmartGateStateSyncEvent.new(gates)
    local self = SmartGateStateSyncEvent.emptyNew()
    self.entries = {}
    for _, gate in ipairs(gates or {}) do
        table.insert(self.entries, {
            id=gate.id, ownerKey=gate.ownerKey or "", nodeKey=gate.nodeKey or "", x=gate.x or 0, z=gate.z or 0,
            mode=gate.mode or MODE_ALL, blacklisted=gate.blacklisted == true,
            customGeometry=gate.customGeometry == true,
            triggerOpenDistance=gate.triggerOpenDistance or AUTO_OPEN_DISTANCE,
            triggerOpenHalfWidth=gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE,
            triggerCloseDistance=gate.triggerCloseDistance or AUTO_CLOSE_DISTANCE,
            triggerCloseHalfWidth=gate.triggerCloseHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE,
            safetyDepth=gate.safetyDepth or DEFAULT_SAFETY_DEPTH,
            safetyHalfWidth=gate.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH,
            configDepth=gate.configDepth or CONFIG_ZONE_LENGTH,
            configHalfWidth=gate.configHalfWidth or CONFIG_ZONE_HALF_WIDTH,
            axisSwapped=gate.axisSwapped == true,
            objectType=gate.objectType or OBJECT_GATE,
            washPoint=gate.washPoint == true,
            safetyClearDelayMs=gate.safetyClearDelayMs or DEFAULT_SAFETY_CLEAR_DELAY_MS
        })
    end
    return self
end
function SmartGateStateSyncEvent:writeStream(streamId, connection)
    streamWriteUInt16(streamId, #self.entries)
    for _, entry in ipairs(self.entries) do
        streamWriteString(streamId, entry.id or "")
        streamWriteString(streamId, entry.ownerKey or "")
        streamWriteString(streamId, entry.nodeKey or "")
        streamWriteFloat32(streamId, entry.x or 0)
        streamWriteFloat32(streamId, entry.z or 0)
        streamWriteUIntN(streamId, entry.mode or MODE_ALL, 2)
        streamWriteBool(streamId, entry.blacklisted == true)
        streamWriteBool(streamId, entry.customGeometry == true)
        streamWriteFloat32(streamId, entry.triggerOpenDistance or AUTO_OPEN_DISTANCE)
        streamWriteFloat32(streamId, entry.triggerOpenHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE)
        streamWriteFloat32(streamId, entry.triggerCloseDistance or AUTO_CLOSE_DISTANCE)
        streamWriteFloat32(streamId, entry.triggerCloseHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE)
        streamWriteFloat32(streamId, entry.safetyDepth or DEFAULT_SAFETY_DEPTH)
        streamWriteFloat32(streamId, entry.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH)
        streamWriteFloat32(streamId, entry.configDepth or CONFIG_ZONE_LENGTH)
        streamWriteFloat32(streamId, entry.configHalfWidth or CONFIG_ZONE_HALF_WIDTH)
        streamWriteBool(streamId, entry.axisSwapped == true)
        streamWriteUIntN(streamId, entry.objectType or OBJECT_GATE, 1)
        streamWriteBool(streamId, entry.washPoint == true)
        streamWriteUInt16(streamId, entry.safetyClearDelayMs or DEFAULT_SAFETY_CLEAR_DELAY_MS)
    end
end
function SmartGateStateSyncEvent:readStream(streamId, connection)
    self.entries = {}
    local count = streamReadUInt16(streamId)
    for i=1,count do
        self.entries[i] = {
            id=streamReadString(streamId),
            ownerKey=streamReadString(streamId),
            nodeKey=streamReadString(streamId),
            x=streamReadFloat32(streamId),
            z=streamReadFloat32(streamId),
            mode=streamReadUIntN(streamId,2),
            blacklisted=streamReadBool(streamId),
            customGeometry=streamReadBool(streamId),
            triggerOpenDistance=streamReadFloat32(streamId),
            triggerOpenHalfWidth=streamReadFloat32(streamId),
            triggerCloseDistance=streamReadFloat32(streamId),
            triggerCloseHalfWidth=streamReadFloat32(streamId),
            safetyDepth=streamReadFloat32(streamId),
            safetyHalfWidth=streamReadFloat32(streamId),
            configDepth=streamReadFloat32(streamId),
            configHalfWidth=streamReadFloat32(streamId),
            axisSwapped=streamReadBool(streamId),
            objectType=streamReadUIntN(streamId,1),
            washPoint=streamReadBool(streamId),
            safetyClearDelayMs=streamReadUInt16(streamId)
        }
    end
    self:run(connection)
end
function SmartGateStateSyncEvent:run(connection)
    if connection ~= nil and connection:getIsServer() and g_smartGate ~= nil then
        local blacklistCount = 0
        local resolvedCount = 0
        for _, entry in ipairs(self.entries or {}) do
            local gate = g_smartGate:resolveGate(entry.id, entry.ownerKey, entry.nodeKey, entry.x, entry.z)
            if gate ~= nil then
                resolvedCount = resolvedCount + 1
                gate.mode = entry.mode
                gate.blacklisted = entry.blacklisted == true
                gate.customGeometry = entry.customGeometry == true
                gate.triggerOpenDistance = entry.triggerOpenDistance or AUTO_OPEN_DISTANCE
                gate.triggerOpenHalfWidth = entry.triggerOpenHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE
                gate.triggerCloseDistance = entry.triggerCloseDistance or AUTO_CLOSE_DISTANCE
                gate.triggerCloseHalfWidth = entry.triggerCloseHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE
                gate.triggerSideDistance = gate.triggerOpenHalfWidth
                gate.safetyDepth = entry.safetyDepth or DEFAULT_SAFETY_DEPTH
                gate.safetyHalfWidth = entry.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH
                gate.configDepth = entry.configDepth or CONFIG_ZONE_LENGTH
                gate.configHalfWidth = entry.configHalfWidth or CONFIG_ZONE_HALF_WIDTH
                gate.axisSwapped = entry.axisSwapped == true
                gate.objectType = entry.objectType == OBJECT_INTERACTION and OBJECT_INTERACTION or OBJECT_GATE
                gate.washPoint = gate.objectType == OBJECT_INTERACTION and entry.washPoint == true
                gate.interactionLatched = false
                gate.safetyClearDelayMs = entry.safetyClearDelayMs or DEFAULT_SAFETY_CLEAR_DELAY_MS
                g_smartGate.savedModes[gate.id] = entry.mode
                if gate.customGeometry then
                    g_smartGate.savedCustomGeometry[gate.id] = true
                else
                    g_smartGate.savedCustomGeometry[gate.id] = nil
                end
                g_smartGate.savedGateSettings[gate.id] = {
                    triggerOpenDistance=gate.triggerOpenDistance, triggerOpenHalfWidth=gate.triggerOpenHalfWidth,
                    triggerCloseDistance=gate.triggerCloseDistance, triggerCloseHalfWidth=gate.triggerCloseHalfWidth,
                    triggerSideDistance=gate.triggerSideDistance, safetyDepth=gate.safetyDepth,
                    safetyHalfWidth=gate.safetyHalfWidth, configDepth=gate.configDepth, configHalfWidth=gate.configHalfWidth,
                    axisSwapped=gate.axisSwapped == true, objectType=gate.objectType or OBJECT_GATE, washPoint=gate.washPoint == true, safetyClearDelayMs=gate.safetyClearDelayMs
                }
                if entry.blacklisted then
                    g_smartGate.savedBlacklist[gate.id] = true
                    blacklistCount = blacklistCount + 1
                else
                    g_smartGate.savedBlacklist[gate.id] = nil
                end
            end
        end
        debugLog("state sync received: %d/%d resolved, %d blacklisted", resolvedCount, #(self.entries or {}), blacklistCount)
    end
end
function SmartGateStateSyncEvent.sendToClients(gates)
    if g_server ~= nil then
        g_server:broadcastEvent(SmartGateStateSyncEvent.new(gates), false)
    end
end

-- Public, optional integration API (e.g. APS). Keep this surface small and
-- independent from SmartGate internals so external mods do not need hard links.
SmartGateAPI = SmartGateAPI or {}
SmartGateAPI.VERSION = "1.3"

function SmartGateAPI.isAvailable()
    return g_smartGate ~= nil and type(g_smartGate.findGateById) == "function"
end


function SmartGateAPI.findNearestInteraction(x, z, maxDistance)
    if g_smartGate == nil then return nil end
    x = tonumber(x)
    z = tonumber(z)
    maxDistance = tonumber(maxDistance) or 25
    if x == nil or z == nil or maxDistance <= 0 then return nil end

    local best = nil
    local bestDistance = maxDistance

    for _, gate in ipairs(g_smartGate.gates or {}) do
        if gate.objectType == OBJECT_INTERACTION and gate.x ~= nil and gate.z ~= nil then
            local dx = x - gate.x
            local dz = z - gate.z
            local distance = math.sqrt(dx * dx + dz * dz)
            if distance <= bestDistance then
                best = gate
                bestDistance = distance
            end
        end
    end

    if best == nil then return nil end
    return {
        id = best.id,
        name = tostring(best.displayName or best.id),
        distance = bestDistance,
        washPoint = best.washPoint == true,
        running = best.animatedObject ~= nil
            and best.animatedObject.animation ~= nil
            and (tonumber(best.animatedObject.animation.direction) or 0) ~= 0
    }
end

function SmartGateAPI.findNearestWashPoint(x, z, maxDistance)
    if g_smartGate == nil then return nil end
    x = tonumber(x)
    z = tonumber(z)
    maxDistance = tonumber(maxDistance) or 25
    if x == nil or z == nil or maxDistance <= 0 then return nil end

    local best = nil
    local bestDistance = maxDistance
    for _, gate in ipairs(g_smartGate.gates or {}) do
        if gate.objectType == OBJECT_INTERACTION and gate.washPoint == true and gate.x ~= nil and gate.z ~= nil then
            local dx = x - gate.x
            local dz = z - gate.z
            local distance = math.sqrt(dx * dx + dz * dz)
            if distance <= bestDistance then
                best = gate
                bestDistance = distance
            end
        end
    end

    if best == nil then return nil end
    local halfLength = math.max(tonumber(best.triggerOpenDistance) or 0, tonumber(best.triggerCloseDistance) or 0, tonumber(best.configDepth) or 0)
    local halfWidth = math.max(tonumber(best.triggerOpenHalfWidth) or tonumber(best.triggerSideDistance) or 0, tonumber(best.triggerCloseHalfWidth) or tonumber(best.triggerSideDistance) or 0, tonumber(best.configHalfWidth) or 0)
    return {
        id = best.id,
        name = tostring(best.displayName or best.id),
        distance = bestDistance,
        washPoint = true,
        halfLength = halfLength,
        halfWidth = halfWidth,
        usableLength = halfLength * 2,
        usableWidth = halfWidth * 2,
        running = best.animatedObject ~= nil
            and best.animatedObject.animation ~= nil
            and (tonumber(best.animatedObject.animation.direction) or 0) ~= 0
    }
end

function SmartGateAPI.requestNearestInteraction(x, z, maxDistance)
    local found = SmartGateAPI.findNearestInteraction(x, z, maxDistance)
    if found == nil then
        return false, "no interaction in range", nil
    end

    local ok, detail = SmartGateAPI.requestInteraction(found.id)
    return ok, detail, found
end

function SmartGateAPI.requestInteraction(gateId)
    if g_server == nil then
        return false, "server only"
    end
    if g_smartGate == nil then
        return false, "SmartGate unavailable"
    end

    local gate = g_smartGate:findGateById(tostring(gateId or ""))
    if gate == nil then
        return false, "interaction not found"
    end
    if gate.objectType ~= OBJECT_INTERACTION then
        return false, "target is not INTERAKTIV"
    end

    local triggered, method = triggerInteractiveObject(gate)
    if triggered then
        gate.interactionLatched = true
        gate.interactionClearSince = nil
        print(string.format("[SmartGate][INTERACTION] external request triggered '%s' via %s", tostring(gate.displayName or gate.id), tostring(method)))
    end
    return triggered, method
end

function SmartGateAPI.isInteractionRunning(gateId)
    if g_smartGate == nil then return false end
    local gate = g_smartGate:findGateById(tostring(gateId or ""))
    local ao = gate ~= nil and gate.animatedObject or nil
    return ao ~= nil and ao.animation ~= nil and (tonumber(ao.animation.direction) or 0) ~= 0
end

function SmartGateAPI.getInteractionState(gateId)
    if g_smartGate == nil then return nil end
    local gate = g_smartGate:findGateById(tostring(gateId or ""))
    if gate == nil or gate.objectType ~= OBJECT_INTERACTION then return nil end
    local ao = gate.animatedObject
    return {
        id = gate.id,
        running = ao ~= nil and ao.animation ~= nil and (tonumber(ao.animation.direction) or 0) ~= 0,
        animationTime = ao ~= nil and ao.animation ~= nil and (tonumber(ao.animation.time) or 0) or 0,
        latched = gate.interactionLatched == true
    }
end

g_smartGate = SmartGate.new()
installConfigInputHook()
addModEventListener(g_smartGate)
