-- FS25_SmartGate_AgricultureScience
-- Agriculture Science test build 0.1.0.9
-- Gate discovery portions are independently adapted from FS25_OpenTheGate
-- (c) 2026 bisdat, MPL-2.0. See LICENSE-MPL-2.0.txt and NOTICE.txt.

SmartGate = {}
SmartGate_mt = Class(SmartGate)

local MOD_DIR = g_currentModDirectory
local MODE_DISABLED = 0
local MODE_ALL = 1
local MODE_VEHICLES = 2
local MODE_PLAYERS = 3

local AUTO_OPEN_DISTANCE = 11.0
local AUTO_CLOSE_DISTANCE = 14.0
local CONFIG_ZONE_LENGTH = 4.0
local CONFIG_ZONE_HALF_WIDTH = 3.5
local CONFIG_FALLBACK_RADIUS = 12.0
local STATE_SYNC_INTERVAL_MS = 15000
local DOUBLE_HONK_MS = 900
local SHORT_HONK_MAX_MS = 650
local SCAN_INTERVAL_MS = 350
local GATE_RESCAN_MS = 10000
local MARKER_TIME_MS = 5000
local BLACKLIST_TEXT = "BLACKLIST"
local DEBUG_LOG = false
local CONFIG_RESOLVE_MAX_DISTANCE = 8.0

local MODE_TEXT_DE = {
    [MODE_DISABLED] = "DEAKTIVIERT",
    [MODE_ALL] = "FAHRZEUGE + PERSONEN",
    [MODE_VEHICLES] = "NUR FAHRZEUGE",
    [MODE_PLAYERS] = "NUR PERSONEN"
}

local function debugLog(fmt, ...)
    if not DEBUG_LOG then return end
    if select("#", ...) > 0 then
        print(string.format("[SmartGate][DEBUG] " .. fmt, ...))
    else
        print("[SmartGate][DEBUG] " .. tostring(fmt))
    end
end

local function showNotification(text, duration, notificationType)
    local mission = g_currentMission
    if mission ~= nil and mission.hud ~= nil and mission.hud.addSideNotification ~= nil then
        mission.hud:addSideNotification(notificationType or FSBaseMission.INGAME_NOTIFICATION_OK, text, duration or 4000)
    end
end

local function nowMs()
    if g_time ~= nil then return g_time end
    return math.floor(os.clock() * 1000)
end

local function validNode(node)
    return node ~= nil and node ~= 0 and entityExists(node)
end

local function sqrDistance2D(ax, az, bx, bz)
    local dx, dz = ax - bx, az - bz
    return dx * dx + dz * dz
end

local function firstValidNode(...)
    for i = 1, select("#", ...) do
        local node = select(i, ...)
        if validNode(node) then return node end
    end
    return nil
end

local function getAnimatedObjectNode(animatedObject, owner)
    local controls = animatedObject ~= nil and animatedObject.controls or nil
    local node = firstValidNode(
        animatedObject ~= nil and animatedObject.triggerNode or nil,
        controls ~= nil and controls.triggerNode or nil,
        animatedObject ~= nil and animatedObject.node or nil,
        animatedObject ~= nil and animatedObject.rootNode or nil,
        animatedObject ~= nil and animatedObject.saveIdNode or nil,
        owner ~= nil and owner.rootNode or nil
    )
    if node ~= nil then return node end
    local animation = animatedObject ~= nil and animatedObject.animation or nil
    if animation ~= nil and animation.parts ~= nil then
        for _, part in pairs(animation.parts) do
            if part ~= nil and validNode(part.node) then return part.node end
        end
    end
    return nil
end

local function isOperable(animatedObject, extraName)
    if animatedObject == nil or animatedObject.animation == nil then return false end
    if type(animatedObject.setDirection) ~= "function" then return false end
    local triggerNode = animatedObject.triggerNode
    if not validNode(triggerNode) and animatedObject.controls ~= nil then
        triggerNode = animatedObject.controls.triggerNode
    end
    if not validNode(triggerNode) then return false end

    local animation = animatedObject.animation
    local duration = tonumber(animation.duration)
    local hasDuration = duration ~= nil and duration > 0
    local hasStateAndParts = animation.time ~= nil and animation.direction ~= nil and animation.parts ~= nil and next(animation.parts) ~= nil
    if not hasDuration and not hasStateAndParts then return false end
    if extraName == "fenceGate" then return true end

    local a = animatedObject.activatable
    local hasActivatable = a ~= nil and (type(a.onAnimationInputToggle) == "function" or type(a.run) == "function" or type(a.getIsActivatable) == "function")
    local c = animatedObject.controls
    local hasControls = c ~= nil and (c.posAction ~= nil or c.negAction ~= nil or c.posActionEventId ~= nil or c.negActionEventId ~= nil)
    local hasContract = type(animatedObject.getCanBeTriggered) == "function" or type(animatedObject.onActivateObject) == "function" or type(animatedObject.registerInteraction) == "function"
    return hasActivatable or hasControls or hasContract
end

local function makeGateId(node, owner, x, y, z)
    local ownerName = "map"
    if owner ~= nil then
        ownerName = tostring(owner.configFileName or owner.configFileNameClean or owner.typeName or owner.className or "placeable")
    end
    local nodeName = validNode(node) and tostring(getName(node) or "node") or "node"
    return string.format("%s|%s|%.2f|%.2f|%.2f", ownerName, nodeName, x or 0, y or 0, z or 0)
end

local function getOwnerKey(owner)
    if owner == nil then return "map" end
    local value = owner.configFileNameClean or owner.configFileName or owner.typeName or owner.className or "placeable"
    return tostring(value):lower():gsub("\\", "/")
end

local function getNodeKey(node)
    if not validNode(node) then return "node" end
    return tostring(getName(node) or "node"):lower()
end

local function getGateDisplayName(animatedObject, owner, node)
    if owner ~= nil then
        if type(owner.getName) == "function" then
            local ok, name = pcall(owner.getName, owner)
            if ok and name ~= nil and tostring(name) ~= "" then return tostring(name) end
        end
        local candidates = {owner.name, owner.customName, owner.typeName, owner.className}
        for _, name in ipairs(candidates) do
            if name ~= nil and tostring(name) ~= "" then return tostring(name) end
        end
        local cfg = owner.configFileNameClean or owner.configFileName
        if cfg ~= nil and tostring(cfg) ~= "" then
            local clean = tostring(cfg):gsub("\\", "/")
            clean = clean:match("([^/]+)$") or clean
            clean = clean:gsub("%.xml$", "")
            if clean ~= "" then return clean end
        end
    end
    if animatedObject ~= nil then
        local candidates = {animatedObject.name, animatedObject.id, animatedObject.typeName}
        for _, name in ipairs(candidates) do
            if name ~= nil and tostring(name) ~= "" then return tostring(name) end
        end
    end
    if validNode(node) then
        local name = getName(node)
        if name ~= nil and tostring(name) ~= "" then return tostring(name) end
    end
    return "Unbekannter Trigger"
end

local function isDefaultExcludedOwner(owner)
    if owner == nil then return false end
    local values = {
        owner.configFileName, owner.configFileNameClean, owner.typeName, owner.className, owner.name, owner.customName
    }
    for _, value in ipairs(values) do
        if value ~= nil then
            local text = tostring(value):lower():gsub("\\", "/")
            if text:find("fs25_schneidwerklager_wobbytec", 1, true) ~= nil
                or text:find("schneidwerklager", 1, true) ~= nil
                or text:find("schneidewerklager", 1, true) ~= nil
                or text:find("cuttingstoragexp", 1, true) ~= nil then
                return true
            end
        end
    end
    return false
end

local function addGate(result, seen, animatedObject, owner, extraName, segment)
    if animatedObject == nil or seen[animatedObject] or not isOperable(animatedObject, extraName) then return end
    -- WobbyTec Schneidwerklager contains several animated storage controls which
    -- look like gates to generic AnimatedObject discovery. They are explicitly
    -- excluded: SmartGate must never operate or configure them.
    if isDefaultExcludedOwner(owner) then return end
    local node = getAnimatedObjectNode(animatedObject, owner)
    if not validNode(node) then return end
    local x, y, z = getWorldTranslation(node)
    if segment ~= nil and tonumber(segment.startPosX) ~= nil and tonumber(segment.endPosX) ~= nil then
        x = (segment.startPosX + segment.endPosX) * 0.5
        y = (segment.startPosY + segment.endPosY) * 0.5
        z = (segment.startPosZ + segment.endPosZ) * 0.5
    end
    local markerX, markerY, markerZ = x, y, z
    if owner ~= nil and validNode(owner.rootNode) then
        local ox, oy, oz = getWorldTranslation(owner.rootNode)
        -- A placeable's root is often a much better label position than a buried
        -- interaction trigger. Only use it when it still belongs to this object.
        if sqrDistance2D(x, z, ox, oz) <= (20.0 * 20.0) then
            markerX, markerY, markerZ = ox, oy, oz
        end
    end
    seen[animatedObject] = true
    table.insert(result, {
        animatedObject = animatedObject,
        owner = owner,
        node = node,
        x = x, y = y, z = z,
        markerX = markerX, markerY = markerY, markerZ = markerZ,
        id = makeGateId(node, owner, x, y, z),
        ownerKey = getOwnerKey(owner),
        nodeKey = getNodeKey(node),
        displayName = getGateDisplayName(animatedObject, owner, node),
        mode = MODE_ALL,
        blacklisted = false,
        occupied = false
    })
end

local function collectGates()
    local result = {}
    local seen = setmetatable({}, {__mode="k"})
    local mission = g_currentMission
    if mission == nil then return result end

    local placeables = mission.placeableSystem ~= nil and (mission.placeableSystem.placeables or mission.placeableSystem.placeablesById) or mission.placeables
    if placeables ~= nil then
        for _, p in pairs(placeables) do
            if p ~= nil and p.spec_animatedObjects ~= nil then
                for _, ao in pairs(p.spec_animatedObjects.animatedObjects or {}) do addGate(result, seen, ao, p, nil, nil) end
            end
            local fenceSpecs = { p ~= nil and p.spec_newFence or nil, p ~= nil and p.spec_fence or nil }
            for _, fenceSpec in pairs(fenceSpecs) do
                local segments = fenceSpec ~= nil and ((fenceSpec.fence ~= nil and fenceSpec.fence.segments) or fenceSpec.segments) or nil
                for _, segment in pairs(segments or {}) do
                    local containers = {segment, segment.gate, segment.fenceGate, segment.gateData, segment.object}
                    for _, c in pairs(containers) do
                        if c ~= nil then
                            if c.animatedObjects ~= nil then
                                for _, ao in pairs(c.animatedObjects) do addGate(result, seen, ao, p, "fenceGate", segment) end
                            end
                            if c.animatedObject ~= nil then addGate(result, seen, c.animatedObject, p, "fenceGate", segment) end
                        end
                    end
                end
            end
            if p ~= nil and p.animatedObjects ~= nil then
                for _, ao in pairs(p.animatedObjects) do addGate(result, seen, ao, p, nil, nil) end
            end
        end
    end

    local containers = {}
    if mission.animatedMapObjects ~= nil then table.insert(containers, mission.animatedMapObjects) end
    if mission.animatedObjects ~= nil then table.insert(containers, mission.animatedObjects) end
    if mission.onCreateObjectSystem ~= nil then
        if mission.onCreateObjectSystem.animatedObjects ~= nil then table.insert(containers, mission.onCreateObjectSystem.animatedObjects) end
        if mission.onCreateObjectSystem.objects ~= nil then table.insert(containers, mission.onCreateObjectSystem.objects) end
    end
    for _, container in ipairs(containers) do
        for _, object in pairs(container or {}) do
            addGate(result, seen, object.animatedObject or object, object, nil, nil)
        end
    end
    return result
end

local function getLocalVehicle()
    if g_localPlayer ~= nil and g_localPlayer.getCurrentVehicle ~= nil then
        local ok, v = pcall(g_localPlayer.getCurrentVehicle, g_localPlayer)
        if ok and v ~= nil then return v end
    end
    if g_currentMission ~= nil and g_currentMission.player ~= nil and g_currentMission.player.getCurrentVehicle ~= nil then
        local ok, v = pcall(g_currentMission.player.getCurrentVehicle, g_currentMission.player)
        if ok and v ~= nil then return v end
    end
    if g_currentMission ~= nil and g_currentMission.playerSystem ~= nil and g_currentMission.playerSystem.getLocalPlayer ~= nil then
        local okP, p = pcall(g_currentMission.playerSystem.getLocalPlayer, g_currentMission.playerSystem)
        if okP and p ~= nil and p.getCurrentVehicle ~= nil then
            local ok, v = pcall(p.getCurrentVehicle, p)
            if ok and v ~= nil then return v end
        end
    end
    return g_currentMission ~= nil and g_currentMission.controlledVehicle or nil
end

local function resolveAutoDriveApi()
    -- FS25 gives every script mod its own Lua environment. AutoDrive therefore
    -- is not necessarily available as a direct global inside SmartGate.
    if AutoDrive ~= nil then return AutoDrive, "DIRECT" end

    local okEnv, env = pcall(getfenv, 0)
    if okEnv and env ~= nil then
        local adEnv = rawget(env, "FS25_AutoDrive")
        if type(adEnv) == "table" and adEnv.AutoDrive ~= nil then
            return adEnv.AutoDrive, "MOD_ENV"
        end

        local root = rawget(env, "_G")
        if type(root) == "table" then
            adEnv = rawget(root, "FS25_AutoDrive")
            if type(adEnv) == "table" and adEnv.AutoDrive ~= nil then
                return adEnv.AutoDrive, "ROOT_MOD_ENV"
            end
        end
    end

    return nil, "NO_AUTODRIVE_ENV"
end

local function getAutoDriveEditorState()
    local ad, envSource = resolveAutoDriveApi()
    if ad == nil then return nil, envSource end

    -- Prefer AutoDrive's public getter. The setting is user-specific and can be
    -- OFF(1), ON(2), EXTENDED(3) or SHOW(4).
    if ad.getEditorMode ~= nil then
        local ok, mode = pcall(ad.getEditorMode)
        mode = ok and tonumber(mode) or nil
        if mode ~= nil then return mode, envSource .. ":getEditorMode" end
    end

    if ad.getSetting ~= nil then
        local ok, mode = pcall(ad.getSetting, "EditorMode")
        mode = ok and tonumber(mode) or nil
        if mode ~= nil then return mode, envSource .. ":getSetting" end
    end

    local settings = ad.settings
    local setting = settings ~= nil and settings.EditorMode or nil
    if setting ~= nil then
        local current = tonumber(setting.current)
        if current ~= nil and setting.values ~= nil and setting.values[current] ~= nil then
            return tonumber(setting.values[current]) or current, envSource .. ":settings.current"
        end
        if current ~= nil then return current, envSource .. ":settings.currentRaw" end
    end

    return nil, envSource .. ":UNKNOWN"
end

local function editorModeName(mode)
    local ad = resolveAutoDriveApi()
    if ad ~= nil then
        if mode == ad.EDITOR_OFF then return "OFF" end
        if mode == ad.EDITOR_ON then return "ON" end
        if mode == ad.EDITOR_EXTENDED then return "EXTENDED" end
        if mode == ad.EDITOR_SHOW then return "SHOW" end
    end
    if mode == 1 then return "OFF" end
    if mode == 2 then return "ON" end
    if mode == 3 then return "EXTENDED" end
    if mode == 4 then return "SHOW" end
    return tostring(mode or "UNKNOWN")
end

local function isEditorMode()
    local mode = getAutoDriveEditorState()
    if mode == nil then return false end
    local ad = resolveAutoDriveApi()
    local off = ad ~= nil and ad.EDITOR_OFF or 1
    return mode ~= off and mode >= 2 and mode <= 4
end

local function getRootVehicle(v)
    if v ~= nil and v.getRootVehicle ~= nil then
        local ok, root = pcall(v.getRootVehicle, v)
        if ok and root ~= nil then return root end
    end
    return v
end

local function getVehiclePoints(vehicle)
    vehicle = getRootVehicle(vehicle)
    if vehicle == nil or not validNode(vehicle.rootNode) then return {} end
    local points = {}
    local seen = setmetatable({}, {__mode="k"})
    local function walk(obj)
        if obj == nil or seen[obj] then return end
        seen[obj] = true
        if validNode(obj.rootNode) then
            local x, y, z = getWorldTranslation(obj.rootNode)
            table.insert(points, {x=x, y=y, z=z})
            local fx, _, fz = localDirectionToWorld(obj.rootNode, 0, 0, 1)
            local len = math.sqrt(fx*fx + fz*fz)
            if len > 0.001 then fx, fz = fx/len, fz/len end
            local size = obj.size or {}
            local half = (tonumber(size.length) or 8) * 0.5
            local off = tonumber(size.lengthOffset) or 0
            table.insert(points, {x=x + fx*(half+off), y=y, z=z + fz*(half+off)})
            table.insert(points, {x=x - fx*(half-off), y=y, z=z - fz*(half-off)})
        end
        if obj.getAttachedImplements ~= nil then
            local ok, impls = pcall(obj.getAttachedImplements, obj)
            if ok and impls ~= nil then for _, impl in ipairs(impls) do walk(impl.object) end end
        end
    end
    walk(vehicle)
    return points
end

local function isVehicleOperational(vehicle)
    local root = getRootVehicle(vehicle)
    if root == nil then return false end

    -- A parked, empty vehicle must not hold a gate open. Count only vehicles
    -- that are currently controlled by a player or driven by AI/AutoDrive.
    if root.getIsEntered ~= nil then
        local ok, entered = pcall(root.getIsEntered, root)
        if ok and entered == true then return true end
    end
    if root.getIsControlled ~= nil then
        local ok, controlled = pcall(root.getIsControlled, root)
        if ok and controlled == true then return true end
    end
    local ad = resolveAutoDriveApi()
    if ad ~= nil and ad.getIsEntered ~= nil then
        local ok, entered = pcall(ad.getIsEntered, ad, root)
        if ok and entered == true then return true end
    end
    if root.getIsAIActive ~= nil then
        local ok, aiActive = pcall(root.getIsAIActive, root)
        if ok and aiActive == true then return true end
    end
    if root.ad ~= nil and root.ad.stateModule ~= nil and root.ad.stateModule.isActive ~= nil then
        local ok, adActive = pcall(root.ad.stateModule.isActive, root.ad.stateModule)
        if ok and adActive == true then return true end
    end

    -- Multiplayer fallback when the server knows a controller user id but the
    -- convenience methods above are unavailable for a specific vehicle type.
    local enterable = root.spec_enterable
    if enterable ~= nil and enterable.controllerUserId ~= nil and enterable.controllerUserId ~= 0 then
        return true
    end

    return getRootVehicle(getLocalVehicle()) == root
end

local function vehicleNearGate(gate, radius)
    local mission = g_currentMission
    if mission == nil then return false end

    -- FS25 keeps the authoritative vehicle list in vehicleSystem.vehicles.
    -- mission.vehicles exists in some contexts/mods, but is not reliable.
    local lists = {}
    if mission.vehicleSystem ~= nil and mission.vehicleSystem.vehicles ~= nil then
        table.insert(lists, mission.vehicleSystem.vehicles)
    end
    if mission.vehicles ~= nil then
        table.insert(lists, mission.vehicles)
    end
    if #lists == 0 then return false end

    local r2 = radius * radius
    local roots = setmetatable({}, {__mode="k"})
    for _, list in ipairs(lists) do
        for _, vehicle in pairs(list) do
            local root = getRootVehicle(vehicle)
            if root ~= nil and not roots[root] then
                roots[root] = true
                if isVehicleOperational(root) then
                    for _, p in ipairs(getVehiclePoints(root)) do
                        if sqrDistance2D(gate.x, gate.z, p.x, p.z) <= r2 then return true end
                    end
                end
            end
        end
    end
    return false
end

local function eachPlayer(callback)
    local mission = g_currentMission
    if mission == nil then return end
    local used = setmetatable({}, {__mode="k"})
    local function add(p)
        if p ~= nil and not used[p] then used[p] = true; callback(p) end
    end
    if mission.playerSystem ~= nil and mission.playerSystem.players ~= nil then
        for _, p in pairs(mission.playerSystem.players) do add(p) end
    end
    if mission.players ~= nil then for _, p in pairs(mission.players) do add(p) end end
    add(mission.player)
    add(g_localPlayer)
end

local function playerNearGate(gate, radius)
    local found = false
    local r2 = radius * radius
    eachPlayer(function(p)
        if found then return end
        local node = p.rootNode or p.node
        if validNode(node) then
            local x, _, z = getWorldTranslation(node)
            if sqrDistance2D(gate.x, gate.z, x, z) <= r2 then found = true end
        end
    end)
    return found
end

local function setGateOpen(gate, shouldOpen)
    local ao = gate.animatedObject
    if ao == nil or ao.animation == nil then return end

    -- AnimatedObjectExtender proves that automatic open/close is driven by the
    -- animation direction directly. AnimatedObject:setDirection(0) is a toggle
    -- command in FS25 and +/-1 is not a reliable open/close API.
    local time = tonumber(ao.animation.time) or 0
    local desired = shouldOpen and 1 or -1
    local needsMove = (shouldOpen and time < 0.999) or ((not shouldOpen) and time > 0.001)
    if needsMove and ao.animation.direction ~= desired then
        ao.animation.direction = desired
        if ao.raiseActive ~= nil then
            pcall(ao.raiseActive, ao)
        end
        debugLog("%s gate '%s' (time=%.3f)", shouldOpen and "OPEN" or "CLOSE", tostring(gate.id), time)
    end
end

local function getSavePath()
    local mi = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    local dir = mi ~= nil and mi.savegameDirectory or nil
    if dir == nil or dir == "" then return nil end
    return dir .. "/smartGate.xml"
end

function SmartGate.new()
    local self = setmetatable({}, SmartGate_mt)
    self.gates = {}
    self.savedModes = {}
    self.savedBlacklist = {}
    self.scanTimer = 0
    self.rescanTimer = 0
    self.stateSyncTimer = 0
    self.hornStates = setmetatable({}, {__mode="k"})
    self.lastPolledVehicle = nil
    self.lastPolledHorn = nil
    self.markerGate = nil
    self.markerUntil = 0
    self.markerMode = MODE_DISABLED
    self.markerBlacklisted = false
    self.markerOverlay = nil
    self.lastEditorRawMode = nil
    self.lastEditorSource = nil
    self.configModeEnabled = false
    self.configInputHookInstalled = false
    self.lastGateCount = nil
    return self
end

function SmartGate:loadConfig()
    self.savedModes = {}
    self.savedBlacklist = {}
    local path = getSavePath()
    if path == nil or not fileExists(path) then return end
    local xml = loadXMLFile("smartGate", path)
    if xml == 0 then return end
    local i = 0
    while hasXMLProperty(xml, string.format("smartGate.gates.gate(%d)", i)) do
        local key = string.format("smartGate.gates.gate(%d)", i)
        local id = getXMLString(xml, key .. "#id")
        local mode = getXMLInt(xml, key .. "#mode")
        local blacklisted = getXMLBool(xml, key .. "#blacklisted")
        if id ~= nil then
            if mode ~= nil then self.savedModes[id] = math.max(0, math.min(3, mode)) end
            if blacklisted == true then self.savedBlacklist[id] = true end
        end
        i = i + 1
    end
    delete(xml)
end

function SmartGate:saveConfig()
    if g_server == nil then return end
    local path = getSavePath()
    if path == nil then return end
    local xml = createXMLFile("smartGate", path, "smartGate")
    local i = 0
    for _, gate in ipairs(self.gates) do
        local key = string.format("smartGate.gates.gate(%d)", i)
        setXMLString(xml, key .. "#id", gate.id)
        setXMLInt(xml, key .. "#mode", gate.mode or MODE_ALL)
        setXMLBool(xml, key .. "#blacklisted", gate.blacklisted == true)
        i = i + 1
    end
    saveXMLFile(xml)
    delete(xml)
end

function SmartGate:rescan()
    local oldModes = {}
    local oldBlacklist = {}
    for _, g in ipairs(self.gates) do
        oldModes[g.id] = g.mode
        oldBlacklist[g.id] = g.blacklisted == true
    end
    self.gates = collectGates()
    for _, gate in ipairs(self.gates) do
        gate.mode = self.savedModes[gate.id] or oldModes[gate.id] or MODE_ALL
        gate.blacklisted = self.savedBlacklist[gate.id] == true or oldBlacklist[gate.id] == true
    end
    if self.lastGateCount == nil or self.lastGateCount ~= #self.gates then
        print(string.format("[SmartGate] gate inventory: %d gate(s) found", #self.gates))
        self.lastGateCount = #self.gates
    else
        debugLog("periodic gate rescan complete: %d gate(s)", #self.gates)
    end
end

function SmartGate:findGateById(id)
    for _, gate in ipairs(self.gates) do if gate.id == id then return gate end end
    return nil
end

function SmartGate:resolveGate(id, ownerKey, nodeKey, x, z)
    local exact = self:findGateById(id)
    if exact ~= nil then return exact, "exact" end

    ownerKey = tostring(ownerKey or ""):lower():gsub("\\", "/")
    nodeKey = tostring(nodeKey or ""):lower()
    x = tonumber(x)
    z = tonumber(z)

    local best, bestScore, bestDistance = nil, -math.huge, math.huge
    for _, gate in ipairs(self.gates) do
        local score = 0
        if ownerKey ~= "" and gate.ownerKey == ownerKey then score = score + 100 end
        if nodeKey ~= "" and gate.nodeKey == nodeKey then score = score + 30 end
        local distance = math.huge
        if x ~= nil and z ~= nil then
            distance = math.sqrt(sqrDistance2D(gate.x, gate.z, x, z))
            if distance <= CONFIG_RESOLVE_MAX_DISTANCE then
                score = score + math.max(0, 25 - distance * 3)
            elseif score < 100 then
                score = score - 50
            end
        end
        if score > bestScore or (score == bestScore and distance < bestDistance) then
            best, bestScore, bestDistance = gate, score, distance
        end
    end

    if best ~= nil and (bestScore >= 100 or (bestScore >= 30 and bestDistance <= CONFIG_RESOLVE_MAX_DISTANCE) or bestDistance <= 2.5) then
        debugLog("resolved remote gate '%s' -> '%s' score=%.1f distance=%.2f", tostring(id), tostring(best.id), bestScore, bestDistance)
        return best, "descriptor"
    end
    print(string.format("[SmartGate][WARN] unable to resolve remote gate: id=%s owner=%s node=%s", tostring(id), tostring(ownerKey), tostring(nodeKey)))
    return nil, "missing"
end

function SmartGate:getGateDescriptor(gate)
    if gate == nil then return "", "", "", 0, 0 end
    return gate.id or "", gate.ownerKey or "", gate.nodeKey or "", gate.x or 0, gate.z or 0
end

function SmartGate:getGateName(gate)
    if gate == nil then return "Unbekannter Trigger" end
    return gate.displayName or "Unbekannter Trigger"
end

function SmartGate:showMarker(gate, mode, blacklisted)
    self.markerGate = gate
    self.markerMode = mode or MODE_DISABLED
    self.markerBlacklisted = blacklisted == true
    self.markerUntil = nowMs() + MARKER_TIME_MS
end

function SmartGate:notifyMode(gate, mode)
    self:showMarker(gate, mode, gate.blacklisted)
    local txt = string.format("SmartGate: %s -> %s", self:getGateName(gate), MODE_TEXT_DE[mode] or tostring(mode))
    showNotification(txt, 4500, FSBaseMission.INGAME_NOTIFICATION_OK)
end

function SmartGate:notifyBlacklist(gate, blacklisted)
    self:showMarker(gate, gate.mode, blacklisted)
    local state = blacklisted and "BLACKLIST" or "BLACKLIST ENTFERNT"
    local txt = string.format("SmartGate: %s -> %s", self:getGateName(gate), state)
    showNotification(txt, 5000, FSBaseMission.INGAME_NOTIFICATION_OK)
end

function SmartGate:cycleGate(id, ownerKey, nodeKey, x, z)
    if g_server == nil then return end
    local gate = self:resolveGate(id, ownerKey, nodeKey, x, z)
    if gate == nil then return end
    if gate.blacklisted then
        print(string.format("[SmartGate][CONFIG] mode change ignored; blacklisted: %s (%s)", self:getGateName(gate), tostring(id)))
        SmartGateBlacklistEvent.sendToClients(gate, true)
        return
    end
    gate.mode = ((gate.mode or MODE_ALL) + 1) % 4
    print(string.format("[SmartGate][CONFIG] mode changed: %s (%s) -> %s", self:getGateName(gate), tostring(id), MODE_TEXT_DE[gate.mode] or tostring(gate.mode)))
    self.savedModes[gate.id] = gate.mode
    self:saveConfig()
    SmartGateModeEvent.sendToClients(gate, gate.mode)
end

function SmartGate:toggleBlacklist(id, ownerKey, nodeKey, x, z)
    if g_server == nil then return end
    local gate = self:resolveGate(id, ownerKey, nodeKey, x, z)
    if gate == nil then return end
    gate.blacklisted = not gate.blacklisted
    gate.occupied = false
    if gate.blacklisted then self.savedBlacklist[gate.id] = true else self.savedBlacklist[gate.id] = nil end
    print(string.format("[SmartGate][CONFIG] blacklist changed: %s (%s) -> %s", self:getGateName(gate), tostring(id), tostring(gate.blacklisted)))
    self:saveConfig()
    SmartGateBlacklistEvent.sendToClients(gate, gate.blacklisted)
end

function SmartGate:findConfigGate(vehicle)
    vehicle = getRootVehicle(vehicle)
    if vehicle == nil or not validNode(vehicle.rootNode) then return nil end
    local x, _, z = getWorldTranslation(vehicle.rootNode)
    local fx, _, fz = localDirectionToWorld(vehicle.rootNode, 0, 0, 1)
    local fl = math.sqrt(fx*fx + fz*fz)
    if fl < 0.001 then return nil end
    fx, fz = fx/fl, fz/fl
    local rx, rz = fz, -fx

    -- Find the actual front/rear of the whole vehicle combination. The config
    -- zones sit just outside those endpoints, not around the tractor centre.
    local minProj, maxProj = 0, 0
    for _, point in ipairs(getVehiclePoints(vehicle)) do
        local projection = (point.x - x) * fx + (point.z - z) * fz
        minProj = math.min(minProj, projection)
        maxProj = math.max(maxProj, projection)
    end
    local frontX, frontZ = x + fx * maxProj, z + fz * maxProj
    local rearX, rearZ = x + fx * minProj, z + fz * minProj

    local best, bestD = nil, math.huge
    for _, gate in ipairs(self.gates) do
        local function testZone(originX, originZ, outwardSign)
            local dx, dz = gate.x - originX, gate.z - originZ
            local outward = (dx*fx + dz*fz) * outwardSign
            local lateral = math.abs(dx*rx + dz*rz)
            if outward >= -0.5 and outward <= CONFIG_ZONE_LENGTH and lateral <= CONFIG_ZONE_HALF_WIDTH then
                local d = dx*dx + dz*dz
                if d < bestD then best, bestD = gate, d end
            end
        end
        testZone(frontX, frontZ, 1)
        testZone(rearX, rearZ, -1)
    end
    if best ~= nil then return best end

    -- Fallback for animated objects whose interaction trigger is offset from the
    -- visible object: select the nearest known SmartGate object around the whole
    -- vehicle combination, but only while the user explicitly configures it.
    local fallbackR2 = CONFIG_FALLBACK_RADIUS * CONFIG_FALLBACK_RADIUS
    for _, gate in ipairs(self.gates) do
        for _, point in ipairs(getVehiclePoints(vehicle)) do
            local d = sqrDistance2D(gate.x, gate.z, point.x, point.z)
            if d <= fallbackR2 and d < bestD then
                best, bestD = gate, d
            end
        end
    end
    if best ~= nil then
        debugLog("fallback target selected: %s (%s)", self:getGateName(best), tostring(best.id))
    end
    return best
end

function SmartGate:isLocalVehicle(vehicle)
    if vehicle == nil then return false end
    if vehicle.getIsActiveForInputIgnoreSelection ~= nil then
        local ok, active = pcall(vehicle.getIsActiveForInputIgnoreSelection, vehicle)
        if ok and active == true then return true end
    end
    if vehicle.getIsActiveForInput ~= nil then
        local ok, active = pcall(vehicle.getIsActiveForInput, vehicle)
        if ok and active == true then return true end
    end
    return getRootVehicle(vehicle) == getRootVehicle(getLocalVehicle())
end

function SmartGate:installHornHook()
    if self.hornHookInstalled then return true end
    if Honk == nil or Honk.playHonk == nil then return false end
    Honk.playHonk = Utils.appendedFunction(Honk.playHonk, function(vehicle, isPlaying, noEventSend)
        if g_smartGate ~= nil then g_smartGate:onHonk(vehicle, isPlaying) end
    end)
    self.hornHookInstalled = true
    print("[SmartGate][CONFIG] horn hook installed")
    return true
end

function SmartGate:onHonk(vehicle, isPlaying)
    if not self.configModeEnabled then return end
    if not self:isLocalVehicle(vehicle) then return end
    local root = getRootVehicle(vehicle)
    local state = self.hornStates[root]
    if state == nil then state = {pressed=false, started=0, previousRelease=nil}; self.hornStates[root] = state end
    local t = nowMs()
    if isPlaying and not state.pressed then
        state.pressed = true
        state.started = t
    elseif not isPlaying and state.pressed then
        state.pressed = false
        local duration = t - state.started
        if duration <= SHORT_HONK_MAX_MS then
            if state.previousRelease ~= nil and t - state.previousRelease <= DOUBLE_HONK_MS then
                local gap = t - state.previousRelease
                state.previousRelease = nil
                print(string.format("[SmartGate][CONFIG] double honk detected (gap=%dms)", gap))
                local gate = self:findConfigGate(root)
                if gate ~= nil then
                    print(string.format("[SmartGate][CONFIG] gate selected: %s", tostring(gate.id)))
                    showNotification("SmartGate: Tor erkannt - Konfiguration wird geaendert", 2500, FSBaseMission.INGAME_NOTIFICATION_OK)
                    SmartGateConfigEvent.send(gate)
                else
                    print("[SmartGate][CONFIG] no gate in front/rear config zone")
                    showNotification("SmartGate: Kein Tor im Config-Bereich", 3000, FSBaseMission.INGAME_NOTIFICATION_WARNING)
                end
            else
                state.previousRelease = t
            end
        else
            state.previousRelease = nil
        end
    end
end

function SmartGate:onToggleConfigAction(actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory)
    if inputValue ~= nil and inputValue <= 0 then return end
    self.configModeEnabled = not self.configModeEnabled
    self.hornStates = setmetatable({}, {__mode="k"})
    if self.configModeEnabled then
        print("[SmartGate][CONFIG] SmartGate config mode: true")
        showNotification("SmartGate Config: AKTIV - Doppelhupe vor/hinter einem Tor", 5000, FSBaseMission.INGAME_NOTIFICATION_OK)
    else
        print("[SmartGate][CONFIG] SmartGate config mode: false")
        showNotification("SmartGate Config: AUS", 2500, FSBaseMission.INGAME_NOTIFICATION_OK)
        self.markerGate = nil
        self.markerUntil = 0
    end
end

function SmartGate:onToggleBlacklistAction(actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory)
    if inputValue ~= nil and inputValue <= 0 then return end
    if not self.configModeEnabled then
        showNotification("SmartGate: Erst Config-Modus aktivieren", 3000, FSBaseMission.INGAME_NOTIFICATION_WARNING)
        return
    end
    local vehicle = getLocalVehicle()
    local gate = self:findConfigGate(vehicle)
    if gate == nil then
        showNotification("SmartGate: Kein Trigger im Config-Bereich", 3000, FSBaseMission.INGAME_NOTIFICATION_WARNING)
        return
    end
    print(string.format("[SmartGate][CONFIG] blacklist target: %s (%s)", self:getGateName(gate), tostring(gate.id)))
    SmartGateBlacklistRequestEvent.send(gate)
end

local function installConfigInputHook()
    if PlayerInputComponent == nil or PlayerInputComponent.registerGlobalPlayerActionEvents == nil then
        print("[SmartGate][CONFIG] PlayerInputComponent unavailable; config input hook not installed")
        return false
    end
    PlayerInputComponent.registerGlobalPlayerActionEvents = Utils.appendedFunction(
        PlayerInputComponent.registerGlobalPlayerActionEvents,
        function(playerInputComponent, controlling)
            if g_smartGate == nil or g_inputBinding == nil or InputAction == nil or InputAction.SMARTGATE_CONFIG_TOGGLE == nil then return end
            local _, eventId = g_inputBinding:registerActionEvent(
                InputAction.SMARTGATE_CONFIG_TOGGLE,
                g_smartGate,
                SmartGate.onToggleConfigAction,
                false,
                true,
                false,
                true
            )
            if eventId ~= nil then
                g_inputBinding:setActionEventTextVisibility(eventId, false)
            end
            if InputAction.SMARTGATE_BLACKLIST_TOGGLE ~= nil then
                local _, blacklistEventId = g_inputBinding:registerActionEvent(
                    InputAction.SMARTGATE_BLACKLIST_TOGGLE,
                    g_smartGate,
                    SmartGate.onToggleBlacklistAction,
                    false,
                    true,
                    false,
                    true
                )
                if blacklistEventId ~= nil then
                    g_inputBinding:setActionEventTextVisibility(blacklistEventId, false)
                end
            end
        end
    )
    print("[SmartGate][CONFIG] global config input hook installed")
    return true
end

function SmartGate:update(dt)
    self.scanTimer = self.scanTimer + dt
    self.rescanTimer = self.rescanTimer + dt
    self.stateSyncTimer = self.stateSyncTimer + dt
    if self.rescanTimer >= GATE_RESCAN_MS then self.rescanTimer = 0; self:rescan() end
    if g_server ~= nil and self.stateSyncTimer >= STATE_SYNC_INTERVAL_MS then
        self.stateSyncTimer = 0
        SmartGateStateSyncEvent.sendToClients(self.gates)
    end

    if not self.hornHookInstalled then self:installHornHook() end

    -- Config mode is deliberately SmartGate-owned. No cross-mod editor-state
    -- dependency is required; AutoDrive can remain installed or absent.

    local localVehicle = getLocalVehicle()
    if localVehicle ~= self.lastPolledVehicle then
        self.lastPolledVehicle = localVehicle
        self.lastPolledHorn = nil
    end
    if localVehicle ~= nil and localVehicle.spec_honk ~= nil then
        local horn = localVehicle.spec_honk.isPlaying == true
        if self.lastPolledHorn == nil or horn ~= self.lastPolledHorn then
            self.lastPolledHorn = horn
            self:onHonk(localVehicle, horn)
        end
    end

    if g_server ~= nil and self.scanTimer >= SCAN_INTERVAL_MS then
        self.scanTimer = 0
        for _, gate in ipairs(self.gates) do
            local mode = gate.mode or MODE_ALL
            if gate.blacklisted then
                gate.occupied = false
            elseif mode == MODE_DISABLED then
                gate.occupied = false
            else
                local vehicleHit = (mode == MODE_ALL or mode == MODE_VEHICLES) and vehicleNearGate(gate, gate.occupied and AUTO_CLOSE_DISTANCE or AUTO_OPEN_DISTANCE)
                local playerHit = (mode == MODE_ALL or mode == MODE_PLAYERS) and playerNearGate(gate, gate.occupied and AUTO_CLOSE_DISTANCE or AUTO_OPEN_DISTANCE)
                local occupied = vehicleHit or playerHit
                if occupied ~= gate.occupied then
                    gate.occupied = occupied
                    setGateOpen(gate, occupied)
                end
            end
        end
    end
end

function SmartGate:draw()
    if not self.configModeEnabled then return end
    if self.markerGate == nil or nowMs() > self.markerUntil then return end
    local gate = self.markerGate
    local mx = gate.markerX or gate.x
    local my = gate.markerY or gate.y
    local mz = gate.markerZ or gate.z
    local sx, sy, depth = project(mx, my + 2.5, mz)
    if depth == nil or depth <= 0 or depth >= 1 then return end
    local w, h = 0.035, 0.035 * g_screenAspectRatio
    if self.markerOverlay ~= nil then renderOverlay(self.markerOverlay, sx - w/2, sy, w, h) end
    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextBold(true)
    local stateText = self.markerBlacklisted and BLACKLIST_TEXT or (MODE_TEXT_DE[self.markerMode] or "SMARTGATE")
    renderText(sx, sy - 0.018, 0.013, stateText)
    renderText(sx, sy - 0.034, 0.010, self:getGateName(gate))
    setTextBold(false)
    setTextAlignment(RenderText.ALIGN_LEFT)
end

function SmartGate:loadMap()
    print("[SmartGate] Agriculture Science SmartGate v0.1.0.9 loaded")
    self:loadConfig()
    self:rescan()
    self.configModeEnabled = false
    self.hornHookInstalled = false
    if createImageOverlay ~= nil then
        self.markerOverlay = createImageOverlay(MOD_DIR .. "config_marker.dds")
    end
    if not self:installHornHook() then
        print("[SmartGate][CONFIG] horn hook not available yet; update loop will retry")
    end
end

function SmartGate:deleteMap()
    if self.markerOverlay ~= nil then delete(self.markerOverlay); self.markerOverlay = nil end
end

function SmartGate:saveSavegame()
    self:saveConfig()
end

-- Config request: client -> server. The descriptor fallback is important for
-- modded placeables whose runtime AnimatedObject/node identity can differ between
-- dedicated server and client even though they represent the same visible gate.
SmartGateConfigEvent = {}
local SmartGateConfigEvent_mt = Class(SmartGateConfigEvent, Event)
InitEventClass(SmartGateConfigEvent, "SmartGateConfigEvent")
function SmartGateConfigEvent.emptyNew() return Event.new(SmartGateConfigEvent_mt) end
function SmartGateConfigEvent.new(id, ownerKey, nodeKey, x, z)
    local self=SmartGateConfigEvent.emptyNew(); self.id=id; self.ownerKey=ownerKey; self.nodeKey=nodeKey; self.x=x; self.z=z; return self
end
function SmartGateConfigEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or ""); streamWriteString(streamId, self.ownerKey or ""); streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0); streamWriteFloat32(streamId, self.z or 0)
end
function SmartGateConfigEvent:readStream(streamId, connection)
    self.id=streamReadString(streamId); self.ownerKey=streamReadString(streamId); self.nodeKey=streamReadString(streamId)
    self.x=streamReadFloat32(streamId); self.z=streamReadFloat32(streamId); self:run(connection)
end
function SmartGateConfigEvent:run(connection)
    if connection ~= nil and not connection:getIsServer() and g_smartGate ~= nil then
        g_smartGate:cycleGate(self.id, self.ownerKey, self.nodeKey, self.x, self.z)
    end
end
function SmartGateConfigEvent.send(gate)
    if gate == nil then return end
    local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
    if g_server ~= nil then g_smartGate:cycleGate(id, ownerKey, nodeKey, x, z)
    elseif g_client ~= nil then g_client:getServerConnection():sendEvent(SmartGateConfigEvent.new(id, ownerKey, nodeKey, x, z)) end
end

-- Mode update: server -> all clients. Clients resolve by exact id first and then
-- by the stable descriptor so mod-placeable runtime ids no longer have to match.
SmartGateModeEvent = {}
local SmartGateModeEvent_mt = Class(SmartGateModeEvent, Event)
InitEventClass(SmartGateModeEvent, "SmartGateModeEvent")
function SmartGateModeEvent.emptyNew() return Event.new(SmartGateModeEvent_mt) end
function SmartGateModeEvent.new(id, ownerKey, nodeKey, x, z, mode)
    local self=SmartGateModeEvent.emptyNew(); self.id=id; self.ownerKey=ownerKey; self.nodeKey=nodeKey; self.x=x; self.z=z; self.mode=mode; return self
end
function SmartGateModeEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or ""); streamWriteString(streamId, self.ownerKey or ""); streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0); streamWriteFloat32(streamId, self.z or 0); streamWriteUIntN(streamId, self.mode or 0, 2)
end
function SmartGateModeEvent:readStream(streamId, connection)
    self.id=streamReadString(streamId); self.ownerKey=streamReadString(streamId); self.nodeKey=streamReadString(streamId)
    self.x=streamReadFloat32(streamId); self.z=streamReadFloat32(streamId); self.mode=streamReadUIntN(streamId,2); self:run(connection)
end
function SmartGateModeEvent:run(connection)
    if connection ~= nil and connection:getIsServer() and g_smartGate ~= nil then
        local gate = g_smartGate:resolveGate(self.id, self.ownerKey, self.nodeKey, self.x, self.z)
        if gate ~= nil then gate.mode=self.mode; g_smartGate.savedModes[gate.id]=self.mode; g_smartGate:notifyMode(gate,self.mode) end
    end
end
function SmartGateModeEvent.sendToClients(gate, mode)
    if g_server ~= nil and gate ~= nil then
        local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
        g_server:broadcastEvent(SmartGateModeEvent.new(id, ownerKey, nodeKey, x, z, mode), false)
        if g_smartGate ~= nil then g_smartGate:notifyMode(gate, mode) end
    end
end

-- Blacklist request: client -> server.
SmartGateBlacklistRequestEvent = {}
local SmartGateBlacklistRequestEvent_mt = Class(SmartGateBlacklistRequestEvent, Event)
InitEventClass(SmartGateBlacklistRequestEvent, "SmartGateBlacklistRequestEvent")
function SmartGateBlacklistRequestEvent.emptyNew() return Event.new(SmartGateBlacklistRequestEvent_mt) end
function SmartGateBlacklistRequestEvent.new(id, ownerKey, nodeKey, x, z)
    local self=SmartGateBlacklistRequestEvent.emptyNew(); self.id=id; self.ownerKey=ownerKey; self.nodeKey=nodeKey; self.x=x; self.z=z; return self
end
function SmartGateBlacklistRequestEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or ""); streamWriteString(streamId, self.ownerKey or ""); streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0); streamWriteFloat32(streamId, self.z or 0)
end
function SmartGateBlacklistRequestEvent:readStream(streamId, connection)
    self.id=streamReadString(streamId); self.ownerKey=streamReadString(streamId); self.nodeKey=streamReadString(streamId)
    self.x=streamReadFloat32(streamId); self.z=streamReadFloat32(streamId); self:run(connection)
end
function SmartGateBlacklistRequestEvent:run(connection)
    if connection ~= nil and not connection:getIsServer() and g_smartGate ~= nil then
        g_smartGate:toggleBlacklist(self.id, self.ownerKey, self.nodeKey, self.x, self.z)
    end
end
function SmartGateBlacklistRequestEvent.send(gate)
    if gate == nil then return end
    local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
    if g_server ~= nil then g_smartGate:toggleBlacklist(id, ownerKey, nodeKey, x, z)
    elseif g_client ~= nil then g_client:getServerConnection():sendEvent(SmartGateBlacklistRequestEvent.new(id, ownerKey, nodeKey, x, z)) end
end

-- Blacklist update: server -> all clients.
SmartGateBlacklistEvent = {}
local SmartGateBlacklistEvent_mt = Class(SmartGateBlacklistEvent, Event)
InitEventClass(SmartGateBlacklistEvent, "SmartGateBlacklistEvent")
function SmartGateBlacklistEvent.emptyNew() return Event.new(SmartGateBlacklistEvent_mt) end
function SmartGateBlacklistEvent.new(id, ownerKey, nodeKey, x, z, blacklisted)
    local self=SmartGateBlacklistEvent.emptyNew(); self.id=id; self.ownerKey=ownerKey; self.nodeKey=nodeKey; self.x=x; self.z=z; self.blacklisted=blacklisted == true; return self
end
function SmartGateBlacklistEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or ""); streamWriteString(streamId, self.ownerKey or ""); streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0); streamWriteFloat32(streamId, self.z or 0); streamWriteBool(streamId, self.blacklisted)
end
function SmartGateBlacklistEvent:readStream(streamId, connection)
    self.id=streamReadString(streamId); self.ownerKey=streamReadString(streamId); self.nodeKey=streamReadString(streamId)
    self.x=streamReadFloat32(streamId); self.z=streamReadFloat32(streamId); self.blacklisted=streamReadBool(streamId); self:run(connection)
end
function SmartGateBlacklistEvent:run(connection)
    if connection ~= nil and connection:getIsServer() and g_smartGate ~= nil then
        local gate = g_smartGate:resolveGate(self.id, self.ownerKey, self.nodeKey, self.x, self.z)
        if gate ~= nil then
            gate.blacklisted = self.blacklisted
            if self.blacklisted then g_smartGate.savedBlacklist[gate.id]=true else g_smartGate.savedBlacklist[gate.id]=nil end
            g_smartGate:notifyBlacklist(gate, self.blacklisted)
        end
    end
end
function SmartGateBlacklistEvent.sendToClients(gate, blacklisted)
    if g_server ~= nil and gate ~= nil then
        local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
        g_server:broadcastEvent(SmartGateBlacklistEvent.new(id, ownerKey, nodeKey, x, z, blacklisted), false)
        if g_smartGate ~= nil then g_smartGate:notifyBlacklist(gate, blacklisted) end
    end
end

-- Periodic full-state sync. This deliberately avoids depending on a specific
-- join callback: a late-joining MP client receives modes and blacklist state
-- within STATE_SYNC_INTERVAL_MS even if it missed earlier per-gate events.
SmartGateStateSyncEvent = {}
local SmartGateStateSyncEvent_mt = Class(SmartGateStateSyncEvent, Event)
InitEventClass(SmartGateStateSyncEvent, "SmartGateStateSyncEvent")
function SmartGateStateSyncEvent.emptyNew() return Event.new(SmartGateStateSyncEvent_mt) end
function SmartGateStateSyncEvent.new(gates)
    local self = SmartGateStateSyncEvent.emptyNew()
    self.entries = {}
    for _, gate in ipairs(gates or {}) do
        table.insert(self.entries, {id=gate.id, ownerKey=gate.ownerKey or "", nodeKey=gate.nodeKey or "", x=gate.x or 0, z=gate.z or 0, mode=gate.mode or MODE_ALL, blacklisted=gate.blacklisted == true})
    end
    return self
end
function SmartGateStateSyncEvent:writeStream(streamId, connection)
    streamWriteUInt16(streamId, #self.entries)
    for _, entry in ipairs(self.entries) do
        streamWriteString(streamId, entry.id or "")
        streamWriteString(streamId, entry.ownerKey or "")
        streamWriteString(streamId, entry.nodeKey or "")
        streamWriteFloat32(streamId, entry.x or 0)
        streamWriteFloat32(streamId, entry.z or 0)
        streamWriteUIntN(streamId, entry.mode or MODE_ALL, 2)
        streamWriteBool(streamId, entry.blacklisted == true)
    end
end
function SmartGateStateSyncEvent:readStream(streamId, connection)
    self.entries = {}
    local count = streamReadUInt16(streamId)
    for i=1,count do
        self.entries[i] = {
            id=streamReadString(streamId),
            ownerKey=streamReadString(streamId),
            nodeKey=streamReadString(streamId),
            x=streamReadFloat32(streamId),
            z=streamReadFloat32(streamId),
            mode=streamReadUIntN(streamId,2),
            blacklisted=streamReadBool(streamId)
        }
    end
    self:run(connection)
end
function SmartGateStateSyncEvent:run(connection)
    if connection ~= nil and connection:getIsServer() and g_smartGate ~= nil then
        local blacklistCount = 0
        local resolvedCount = 0
        for _, entry in ipairs(self.entries or {}) do
            local gate = g_smartGate:resolveGate(entry.id, entry.ownerKey, entry.nodeKey, entry.x, entry.z)
            if gate ~= nil then
                resolvedCount = resolvedCount + 1
                gate.mode = entry.mode
                gate.blacklisted = entry.blacklisted == true
                g_smartGate.savedModes[gate.id] = entry.mode
                if entry.blacklisted then
                    g_smartGate.savedBlacklist[gate.id] = true
                    blacklistCount = blacklistCount + 1
                else
                    g_smartGate.savedBlacklist[gate.id] = nil
                end
            end
        end
        debugLog("state sync received: %d/%d resolved, %d blacklisted", resolvedCount, #(self.entries or {}), blacklistCount)
    end
end
function SmartGateStateSyncEvent.sendToClients(gates)
    if g_server ~= nil then
        g_server:broadcastEvent(SmartGateStateSyncEvent.new(gates), false)
    end
end

g_smartGate = SmartGate.new()
installConfigInputHook()
addModEventListener(g_smartGate)
