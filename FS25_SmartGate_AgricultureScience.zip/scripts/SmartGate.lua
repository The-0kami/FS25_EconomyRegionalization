-- FS25_SmartGate_AgricultureScience
-- Agriculture Science release 0.1.3.8 RC
-- Gate discovery portions are independently adapted from FS25_OpenTheGate
-- (c) 2026 bisdat, MPL-2.0. See LICENSE-MPL-2.0.txt and NOTICE.txt.

SmartGate = {}
SmartGate_mt = Class(SmartGate)

local MOD_DIR = g_currentModDirectory
local MODE_DISABLED = 0
local MODE_ALL = 1
local MODE_VEHICLES = 2
local MODE_PLAYERS = 3
local OBJECT_GATE = 0
local OBJECT_INTERACTION = 1

local AUTO_OPEN_DISTANCE = 11.0
local AUTO_CLOSE_DISTANCE = 14.0
-- Legacy-only defaults retained so old smartGate.xml files and network payloads
-- remain readable. The Config Trigger itself is retired as of v0.1.3.8.
local CONFIG_ZONE_LENGTH = 4.0
local CONFIG_ZONE_HALF_WIDTH = 3.5
local CONFIG_FALLBACK_RADIUS = 12.0
local DEFAULT_TRIGGER_SIDE_DISTANCE = 5.0
local DEFAULT_SAFETY_DEPTH = 4.5
local DEFAULT_SAFETY_HALF_WIDTH = 4.5
local DEFAULT_SAFETY_CLEAR_DELAY_MS = 1800
local VISUAL_TRIGGER_R, VISUAL_TRIGGER_G, VISUAL_TRIGGER_B = 0.15, 0.85, 1.00
local VISUAL_CLOSE_R, VISUAL_CLOSE_G, VISUAL_CLOSE_B = 0.72, 0.35, 1.00
local VISUAL_WASHBOX_R, VISUAL_WASHBOX_G, VISUAL_WASHBOX_B = 1.00, 0.75, 0.15
local VISUAL_SAFETY_R, VISUAL_SAFETY_G, VISUAL_SAFETY_B = 1.00, 0.20, 0.20
local STATE_SYNC_INTERVAL_MS = 15000
local DOUBLE_HONK_MS = 900
local SHORT_HONK_MAX_MS = 650
local SCAN_INTERVAL_MS = 350
local GATE_RESCAN_MS = 10000
local AD_PREOPEN_DISTANCE = 55.0
local AD_PREOPEN_GATE_DEPTH = 3.5
local AD_PREOPEN_MIN_HALF_WIDTH = 5.5
local AD_PREOPEN_MAX_POINTS = 120
local MARKER_TIME_MS = 5000
local BLACKLIST_TEXT = "BLACKLIST"
local DEBUG_LOG = false
local CONFIG_RESOLVE_MAX_DISTANCE = 8.0
local DESCRIPTOR_MATCH_MAX_DISTANCE = 2.0

local INTERACTION_TRIGGER_ENTER = 1
local INTERACTION_TRIGGER_EXIT = 2
local INTERACTION_TRIGGER_ENTER_EXIT = 3
local INTERACTION_TRIGGER_OCCUPIED = 4
local DEFAULT_INTERACTION_REPEAT_COUNT = 1
local DEFAULT_INTERACTION_REPEAT_DELAY_MS = 1000
local DEFAULT_INTERACTION_REARM_MS = 750

local WASH_SOURCE_TRIGGER = 0
local WASH_SOURCE_PROFILE = 1
local WASH_SOURCE_GEOMETRY = 2
local WASH_SOURCE_MANUAL = 3
local DEFAULT_WASH_WIDTH = 5.0
local DEFAULT_WASH_HEIGHT = 5.0
local DEFAULT_WASH_LENGTH = 16.0
local AUTO_WASH_PROFILE_WIDTH = 5.8
local AUTO_WASH_PROFILE_HEIGHT = 6.2
local AUTO_WASH_PROFILE_LENGTH = 24.5
local AUTO_WASH_PROFILE_OFFSET_X = 0.0
local AUTO_WASH_PROFILE_OFFSET_Y = 3.0
local AUTO_WASH_PROFILE_OFFSET_Z = 0.0

local PANEL_LENGTH_CHOICES = {0.5, 0.75, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 8, 10, 11, 12, 14, 16, 18, 20, 22, 24}
local PANEL_WIDTH_CHOICES  = {0.5, 0.75, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 8, 10, 12}
local PANEL_DELAY_CHOICES = {250, 500, 750, 1000, 1500, 1800, 2000, 2500, 3000, 4000, 5000, 7500, 10000}
local PANEL_REPEAT_CHOICES = {1, 2, 3, 4, 5, 6, 8, 10}
local PANEL_INTERACTION_TRIGGER_CHOICES = {INTERACTION_TRIGGER_ENTER, INTERACTION_TRIGGER_EXIT, INTERACTION_TRIGGER_ENTER_EXIT, INTERACTION_TRIGGER_OCCUPIED}
local WASH_YES_SIZE = 250
local PANEL_WASH_LENGTH_CHOICES = {1, 2, 3, 4, 5, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 24.5, 26, 28, 30, 35, 40, WASH_YES_SIZE}
local PANEL_WASH_WIDTH_CHOICES = {1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 5.8, 6, 6.5, 7, 8, 10, 12, WASH_YES_SIZE}
local PANEL_WASH_HEIGHT_CHOICES = {1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.2, 6.5, 7, 8, 10, WASH_YES_SIZE}
local PANEL_OFFSET_CHOICES = {-10, -8, -6, -5, -4, -3, -2.5, -2, -1.5, -1, -0.75, -0.5, -0.25, 0, 0.25, 0.5, 0.75, 1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10}

local CONFIG_PANEL_X = 0.735
local CONFIG_PANEL_Y = 0.835
local CONFIG_PANEL_W = 0.245
local CONFIG_PANEL_ROW_H = 0.030

local MODE_TEXT_DE = {
    [MODE_DISABLED] = "DEAKTIVIERT",
    [MODE_ALL] = "FAHRZEUGE + PERSONEN",
    [MODE_VEHICLES] = "NUR FAHRZEUGE",
    [MODE_PLAYERS] = "NUR PERSONEN"
}

local function debugLog(fmt, ...)
    if not DEBUG_LOG then return end
    if select("#", ...) > 0 then
        print(string.format("[SmartGate][DEBUG] " .. fmt, ...))
    else
        print("[SmartGate][DEBUG] " .. tostring(fmt))
    end
end

local function showNotification(text, duration, notificationType)
    local mission = g_currentMission
    if mission ~= nil and mission.hud ~= nil and mission.hud.addSideNotification ~= nil then
        mission.hud:addSideNotification(notificationType or FSBaseMission.INGAME_NOTIFICATION_OK, text, duration or 4000)
    end
end

local updateTimeMs = 0
local function isFiniteNumber(value)
    return type(value) == "number" and value == value and math.abs(value) < math.huge
end

local function nowMs()
    if isFiniteNumber(g_time) then return g_time end
    local missionTime = g_currentMission ~= nil and g_currentMission.time or nil
    if isFiniteNumber(missionTime) then return missionTime end
    -- Gameplay timers must not depend on optional Lua standard libraries.
    return updateTimeMs
end

local function logicalAnimationTime(gate)
    local animation = gate.animatedObject ~= nil and gate.animatedObject.animation or nil
    local time = animation ~= nil and (tonumber(animation.time) or 0) or 0
    return gate.animationInverted == true and (1 - time) or time
end

local function animationDirection(gate, shouldOpen)
    local openDirection = gate.animationInverted == true and -1 or 1
    return shouldOpen and openDirection or -openDirection
end

local function validNode(node)
    return node ~= nil and node ~= 0 and entityExists(node)
end

local function sqrDistance2D(ax, az, bx, bz)
    local dx, dz = ax - bx, az - bz
    return dx * dx + dz * dz
end

local function firstValidNode(...)
    for i = 1, select("#", ...) do
        local node = select(i, ...)
        if validNode(node) then return node end
    end
    return nil
end

local function getAnimatedObjectNode(animatedObject, owner)
    local controls = animatedObject ~= nil and animatedObject.controls or nil
    local node = firstValidNode(
        animatedObject ~= nil and animatedObject.triggerNode or nil,
        controls ~= nil and controls.triggerNode or nil,
        animatedObject ~= nil and animatedObject.node or nil,
        animatedObject ~= nil and animatedObject.rootNode or nil,
        animatedObject ~= nil and animatedObject.saveIdNode or nil,
        owner ~= nil and owner.rootNode or nil
    )
    if node ~= nil then return node end
    local animation = animatedObject ~= nil and animatedObject.animation or nil
    if animation ~= nil and animation.parts ~= nil then
        for _, part in pairs(animation.parts) do
            if part ~= nil and validNode(part.node) then return part.node end
        end
    end
    return nil
end

local function isOperable(animatedObject, extraName)
    if animatedObject == nil or animatedObject.animation == nil then return false end
    if type(animatedObject.setDirection) ~= "function" then return false end
    local triggerNode = animatedObject.triggerNode
    if not validNode(triggerNode) and animatedObject.controls ~= nil then
        triggerNode = animatedObject.controls.triggerNode
    end
    if not validNode(triggerNode) then return false end

    local animation = animatedObject.animation
    local duration = tonumber(animation.duration)
    local hasDuration = duration ~= nil and duration > 0
    local hasStateAndParts = animation.time ~= nil and animation.direction ~= nil and animation.parts ~= nil and next(animation.parts) ~= nil
    if not hasDuration and not hasStateAndParts then return false end
    if extraName == "fenceGate" then return true end

    local a = animatedObject.activatable
    local hasActivatable = a ~= nil and (type(a.onAnimationInputToggle) == "function" or type(a.run) == "function" or type(a.getIsActivatable) == "function")
    local c = animatedObject.controls
    local hasControls = c ~= nil and (c.posAction ~= nil or c.negAction ~= nil or c.posActionEventId ~= nil or c.negActionEventId ~= nil)
    local hasContract = type(animatedObject.getCanBeTriggered) == "function" or type(animatedObject.onActivateObject) == "function" or type(animatedObject.registerInteraction) == "function"
    return hasActivatable or hasControls or hasContract
end

local function makeLegacyGateId(node, owner, x, y, z)
    local ownerName = "map"
    if owner ~= nil then
        ownerName = tostring(owner.configFileName or owner.configFileNameClean or owner.typeName or owner.className or "placeable")
    end
    local nodeName = validNode(node) and tostring(getName(node) or "node") or "node"
    return string.format("%s|%s|%.2f|%.2f|%.2f", ownerName, nodeName, x or 0, y or 0, z or 0)
end

local function makeGateId(animatedObject, node, owner, x, y, z)
    local ownerName = "map"
    if owner ~= nil then
        ownerName = tostring(owner.configFileNameClean or owner.configFileName or owner.typeName or owner.className or "placeable")
    end
    local nodeName = validNode(node) and tostring(getName(node) or "node") or "node"
    local objectKey = animatedObject ~= nil and (animatedObject.saveId or animatedObject.id or animatedObject.name) or nil
    if objectKey ~= nil and tostring(objectKey) ~= "" then
        return string.format("%s|%s|%s", ownerName, tostring(objectKey), nodeName)
    end
    return makeLegacyGateId(node, owner, x, y, z)
end

local function getOwnerKey(owner)
    if owner == nil then return "map" end
    local value = owner.configFileNameClean or owner.configFileName or owner.typeName or owner.className or "placeable"
    return tostring(value):lower():gsub("\\", "/")
end

local function getNodeKey(node)
    if not validNode(node) then return "node" end
    return tostring(getName(node) or "node"):lower()
end

local function getGateDisplayName(animatedObject, owner, node)
    if owner ~= nil then
        if type(owner.getName) == "function" then
            local ok, name = pcall(owner.getName, owner)
            if ok and name ~= nil and tostring(name) ~= "" then return tostring(name) end
        end
        local candidates = {owner.name, owner.customName, owner.typeName, owner.className}
        for _, name in ipairs(candidates) do
            if name ~= nil and tostring(name) ~= "" then return tostring(name) end
        end
        local cfg = owner.configFileNameClean or owner.configFileName
        if cfg ~= nil and tostring(cfg) ~= "" then
            local clean = tostring(cfg):gsub("\\", "/")
            clean = clean:match("([^/]+)$") or clean
            clean = clean:gsub("%.xml$", "")
            if clean ~= "" then return clean end
        end
    end
    if animatedObject ~= nil then
        local candidates = {animatedObject.name, animatedObject.id, animatedObject.typeName}
        for _, name in ipairs(candidates) do
            if name ~= nil and tostring(name) ~= "" then return tostring(name) end
        end
    end
    if validNode(node) then
        local name = getName(node)
        if name ~= nil and tostring(name) ~= "" then return tostring(name) end
    end
    return "Unbekannter Trigger"
end

local function isDefaultExcludedOwner(owner)
    if owner == nil then return false end
    local values = {
        owner.configFileName, owner.configFileNameClean, owner.typeName, owner.className, owner.name, owner.customName
    }
    for _, value in ipairs(values) do
        if value ~= nil then
            local text = tostring(value):lower():gsub("\\", "/")
            if text:find("fs25_schneidwerklager_wobbytec", 1, true) ~= nil
                or text:find("schneidwerklager", 1, true) ~= nil
                or text:find("schneidewerklager", 1, true) ~= nil
                or text:find("cuttingstoragexp", 1, true) ~= nil then
                return true
            end
        end
    end
    return false
end

local function addGate(result, seen, animatedObject, owner, extraName, segment)
    if animatedObject == nil or seen[animatedObject] or not isOperable(animatedObject, extraName) then return end
    -- WobbyTec Schneidwerklager contains several animated storage controls which
    -- look like gates to generic AnimatedObject discovery. They are explicitly
    -- excluded: SmartGate must never operate or configure them.
    if isDefaultExcludedOwner(owner) then return end
    local node = getAnimatedObjectNode(animatedObject, owner)
    if not validNode(node) then return end
    local x, y, z = getWorldTranslation(node)
    if segment ~= nil and tonumber(segment.startPosX) ~= nil and tonumber(segment.endPosX) ~= nil then
        x = (segment.startPosX + segment.endPosX) * 0.5
        y = (segment.startPosY + segment.endPosY) * 0.5
        z = (segment.startPosZ + segment.endPosZ) * 0.5
    end
    -- Keep the marker anchored to the concrete gate trigger. Using a placeable
    -- root works for many vanilla buildings, but becomes ambiguous on modded
    -- halls with several gates because every gate then points to the building centre.
    local markerX, markerY, markerZ = x, y, z

    local forwardX, forwardZ = 0, 1
    local rightX, rightZ = 1, 0
    if validNode(node) then
        local fx, _, fz = localDirectionToWorld(node, 0, 0, 1)
        local fl = math.sqrt(fx*fx + fz*fz)
        if fl > 0.001 then
            forwardX, forwardZ = fx/fl, fz/fl
            rightX, rightZ = forwardZ, -forwardX
        end
    end
    seen[animatedObject] = true
    table.insert(result, {
        animatedObject = animatedObject,
        owner = owner,
        node = node,
        x = x, y = y, z = z,
        markerX = markerX, markerY = markerY, markerZ = markerZ,
        forwardX = forwardX, forwardZ = forwardZ,
        rightX = rightX, rightZ = rightZ,
        triggerOpenDistance = AUTO_OPEN_DISTANCE,
        triggerOpenHalfWidth = DEFAULT_TRIGGER_SIDE_DISTANCE,
        triggerCloseDistance = AUTO_CLOSE_DISTANCE,
        triggerCloseHalfWidth = DEFAULT_TRIGGER_SIDE_DISTANCE,
        triggerSideDistance = DEFAULT_TRIGGER_SIDE_DISTANCE, -- legacy compatibility
        safetyDepth = DEFAULT_SAFETY_DEPTH,
        safetyHalfWidth = DEFAULT_SAFETY_HALF_WIDTH,
        configDepth = CONFIG_ZONE_LENGTH,
        configHalfWidth = CONFIG_ZONE_HALF_WIDTH,
        axisSwapped = false, animationInverted = false,
        interactionDepth=.75, interactionHalfWidth=DEFAULT_TRIGGER_SIDE_DISTANCE,
        interactionOffsetX=0, interactionOffsetZ=0, interactionYaw=0,
        objectType = OBJECT_GATE,
        safetyClearDelayMs = DEFAULT_SAFETY_CLEAR_DELAY_MS,
        clearSince = nil,
        id = makeGateId(animatedObject, node, owner, x, y, z),
        legacyId = makeLegacyGateId(node, owner, x, y, z),
        ownerKey = getOwnerKey(owner),
        nodeKey = getNodeKey(node),
        displayName = getGateDisplayName(animatedObject, owner, node),
        mode = MODE_ALL,
        blacklisted = false,
        occupied = false,
        preOpenReserved = false,
        preOpenMode = 1, preOpenDistance = 55,
        interactionLatched = false,
        interactionWasOccupied = false,
        interactionTriggerMode = INTERACTION_TRIGGER_ENTER,
        interactionRepeatCount = DEFAULT_INTERACTION_REPEAT_COUNT,
        interactionRepeatDelayMs = DEFAULT_INTERACTION_REPEAT_DELAY_MS,
        interactionRepeatRemaining = 0,
        interactionNextTriggerTime = nil,
        washWidth = DEFAULT_WASH_WIDTH,
        washHeight = DEFAULT_WASH_HEIGHT,
        washLength = DEFAULT_WASH_LENGTH,
        washOffsetX = 0,
        washOffsetY = 0,
        washOffsetZ = 0,
        washGeometryManual = false,
        washGeometrySource = WASH_SOURCE_TRIGGER
    })
end

local function collectGates()
    local result = {}
    local seen = setmetatable({}, {__mode="k"})
    local mission = g_currentMission
    if mission == nil then return result end

    local placeables = mission.placeableSystem ~= nil and (mission.placeableSystem.placeables or mission.placeableSystem.placeablesById) or mission.placeables
    if placeables ~= nil then
        for _, p in pairs(placeables) do
            if p ~= nil and p.spec_animatedObjects ~= nil then
                for _, ao in pairs(p.spec_animatedObjects.animatedObjects or {}) do addGate(result, seen, ao, p, nil, nil) end
            end
            local fenceSpecs = { p ~= nil and p.spec_newFence or nil, p ~= nil and p.spec_fence or nil }
            for _, fenceSpec in pairs(fenceSpecs) do
                local segments = fenceSpec ~= nil and ((fenceSpec.fence ~= nil and fenceSpec.fence.segments) or fenceSpec.segments) or nil
                for _, segment in pairs(segments or {}) do
                    local containers = {segment, segment.gate, segment.fenceGate, segment.gateData, segment.object}
                    for _, c in pairs(containers) do
                        if c ~= nil then
                            if c.animatedObjects ~= nil then
                                for _, ao in pairs(c.animatedObjects) do addGate(result, seen, ao, p, "fenceGate", segment) end
                            end
                            if c.animatedObject ~= nil then addGate(result, seen, c.animatedObject, p, "fenceGate", segment) end
                        end
                    end
                end
            end
            if p ~= nil and p.animatedObjects ~= nil then
                for _, ao in pairs(p.animatedObjects) do addGate(result, seen, ao, p, nil, nil) end
            end
        end
    end

    local containers = {}
    if mission.animatedMapObjects ~= nil then table.insert(containers, mission.animatedMapObjects) end
    if mission.animatedObjects ~= nil then table.insert(containers, mission.animatedObjects) end
    if mission.onCreateObjectSystem ~= nil then
        if mission.onCreateObjectSystem.animatedObjects ~= nil then table.insert(containers, mission.onCreateObjectSystem.animatedObjects) end
        if mission.onCreateObjectSystem.objects ~= nil then table.insert(containers, mission.onCreateObjectSystem.objects) end
    end
    for _, container in ipairs(containers) do
        for _, object in pairs(container or {}) do
            addGate(result, seen, object.animatedObject or object, object, nil, nil)
        end
    end
    return result
end

local function getLocalVehicle()
    if g_localPlayer ~= nil and g_localPlayer.getCurrentVehicle ~= nil then
        local ok, v = pcall(g_localPlayer.getCurrentVehicle, g_localPlayer)
        if ok and v ~= nil then return v end
    end
    if g_currentMission ~= nil and g_currentMission.player ~= nil and g_currentMission.player.getCurrentVehicle ~= nil then
        local ok, v = pcall(g_currentMission.player.getCurrentVehicle, g_currentMission.player)
        if ok and v ~= nil then return v end
    end
    if g_currentMission ~= nil and g_currentMission.playerSystem ~= nil and g_currentMission.playerSystem.getLocalPlayer ~= nil then
        local okP, p = pcall(g_currentMission.playerSystem.getLocalPlayer, g_currentMission.playerSystem)
        if okP and p ~= nil and p.getCurrentVehicle ~= nil then
            local ok, v = pcall(p.getCurrentVehicle, p)
            if ok and v ~= nil then return v end
        end
    end
    return g_currentMission ~= nil and g_currentMission.controlledVehicle or nil
end

local function getConfigPlayer()
    if g_localPlayer ~= nil then return g_localPlayer end
    local mission = g_currentMission
    if mission ~= nil and mission.playerSystem ~= nil and mission.playerSystem.getLocalPlayer ~= nil then
        local ok, player = pcall(mission.playerSystem.getLocalPlayer, mission.playerSystem)
        if ok and player ~= nil then return player end
    end
    return mission ~= nil and mission.player or nil
end

local function getConfigVehicle()
    local player = getConfigPlayer()
    if player ~= nil and type(player.getCurrentVehicle) == "function" then
        local ok, vehicle = pcall(player.getCurrentVehicle, player)
        if ok then return vehicle end
    end
    return getLocalVehicle()
end

local function resolveAutoDriveApi()
    -- FS25 gives every script mod its own Lua environment. AutoDrive therefore
    -- is not necessarily available as a direct global inside SmartGate.
    if AutoDrive ~= nil then return AutoDrive, "DIRECT" end

    local okEnv, env = pcall(getfenv, 0)
    if okEnv and env ~= nil then
        local adEnv = rawget(env, "FS25_AutoDrive")
        if type(adEnv) == "table" and adEnv.AutoDrive ~= nil then
            return adEnv.AutoDrive, "MOD_ENV"
        end

        local root = rawget(env, "_G")
        if type(root) == "table" then
            adEnv = rawget(root, "FS25_AutoDrive")
            if type(adEnv) == "table" and adEnv.AutoDrive ~= nil then
                return adEnv.AutoDrive, "ROOT_MOD_ENV"
            end
        end
    end

    return nil, "NO_AUTODRIVE_ENV"
end

local function resolveCourseplayApi()
    if g_Courseplay ~= nil then return g_Courseplay, "DIRECT_G_COURSEPLAY" end
    if Courseplay ~= nil then return Courseplay, "DIRECT_COURSEPLAY" end

    local okEnv, env = pcall(getfenv, 0)
    if okEnv and env ~= nil then
        local cpEnv = rawget(env, "FS25_Courseplay")
        if type(cpEnv) == "table" then
            if cpEnv.g_Courseplay ~= nil then return cpEnv.g_Courseplay, "MOD_ENV_G" end
            if cpEnv.Courseplay ~= nil then return cpEnv.Courseplay, "MOD_ENV" end
        end

        local root = rawget(env, "_G")
        if type(root) == "table" then
            cpEnv = rawget(root, "FS25_Courseplay")
            if type(cpEnv) == "table" then
                if cpEnv.g_Courseplay ~= nil then return cpEnv.g_Courseplay, "ROOT_MOD_ENV_G" end
                if cpEnv.Courseplay ~= nil then return cpEnv.Courseplay, "ROOT_MOD_ENV" end
            end
            local rootCp = rawget(root, "g_Courseplay")
            if rootCp ~= nil then return rootCp, "ROOT_G_COURSEPLAY" end
        end
    end

    if g_modManager ~= nil and g_modManager.CP_MOD_NAME ~= nil then
        return true, "MOD_MANAGER"
    end

    return nil, "NO_COURSEPLAY_ENV"
end

local function hasExternalCursorProvider()
    local ad = resolveAutoDriveApi()
    if ad ~= nil then return true, "AutoDrive" end
    local cp = resolveCourseplayApi()
    if cp ~= nil then return true, "Courseplay" end
    return false, "SmartGate"
end

local function getAutoDriveEditorState()
    local ad, envSource = resolveAutoDriveApi()
    if ad == nil then return nil, envSource end

    -- Prefer AutoDrive's public getter. The setting is user-specific and can be
    -- OFF(1), ON(2), EXTENDED(3) or SHOW(4).
    if ad.getEditorMode ~= nil then
        local ok, mode = pcall(ad.getEditorMode)
        mode = ok and tonumber(mode) or nil
        if mode ~= nil then return mode, envSource .. ":getEditorMode" end
    end

    if ad.getSetting ~= nil then
        local ok, mode = pcall(ad.getSetting, "EditorMode")
        mode = ok and tonumber(mode) or nil
        if mode ~= nil then return mode, envSource .. ":getSetting" end
    end

    local settings = ad.settings
    local setting = settings ~= nil and settings.EditorMode or nil
    if setting ~= nil then
        local current = tonumber(setting.current)
        if current ~= nil and setting.values ~= nil and setting.values[current] ~= nil then
            return tonumber(setting.values[current]) or current, envSource .. ":settings.current"
        end
        if current ~= nil then return current, envSource .. ":settings.currentRaw" end
    end

    return nil, envSource .. ":UNKNOWN"
end

local function editorModeName(mode)
    local ad = resolveAutoDriveApi()
    if ad ~= nil then
        if mode == ad.EDITOR_OFF then return "OFF" end
        if mode == ad.EDITOR_ON then return "ON" end
        if mode == ad.EDITOR_EXTENDED then return "EXTENDED" end
        if mode == ad.EDITOR_SHOW then return "SHOW" end
    end
    if mode == 1 then return "OFF" end
    if mode == 2 then return "ON" end
    if mode == 3 then return "EXTENDED" end
    if mode == 4 then return "SHOW" end
    return tostring(mode or "UNKNOWN")
end

local function isEditorMode()
    local mode = getAutoDriveEditorState()
    if mode == nil then return false end
    local ad = resolveAutoDriveApi()
    local off = ad ~= nil and ad.EDITOR_OFF or 1
    return mode ~= off and mode >= 2 and mode <= 4
end

local function getRootVehicle(v)
    if v ~= nil and v.getRootVehicle ~= nil then
        local ok, root = pcall(v.getRootVehicle, v)
        if ok and root ~= nil then return root end
    end
    return v
end

-- Scan-local diagnostics/cache only; never persisted or synchronized.
local scanContext = nil
local performanceTimingAvailable = true
local function cpuMs()
    -- GIANTS mod environments may omit os altogether. Profiling is optional;
    -- absent, throwing or invalid clocks must never abort gameplay updates.
    local clock = type(os) == "table" and rawget(os, "clock") or nil
    if type(clock) == "function" then
        local ok, seconds = pcall(clock)
        if ok and isFiniteNumber(seconds) and isFiniteNumber(seconds * 1000) then
            return seconds * 1000
        end
    end
    performanceTimingAvailable = false
    return 0
end

local function elapsedCpuMs(start)
    local finish = cpuMs()
    local elapsed = finish - start
    if not isFiniteNumber(elapsed) then performanceTimingAvailable = false end
    return performanceTimingAvailable and math.max(0, elapsed) or 0
end

local function gridInsert(grid, x, z, record)
    local cx, cz = math.floor(x / 25), math.floor(z / 25)
    local column = grid[cx]
    if column == nil then column = {}; grid[cx] = column end
    local cell = column[cz]
    if cell == nil then cell = {}; column[cz] = cell end
    cell[record] = true
end

local function gridQuery(grid, x, z, radius, all)
    local result, seen = {}, {}
    local loX, hiX = math.floor((x-radius)/25), math.floor((x+radius)/25)
    local loZ, hiZ = math.floor((z-radius)/25), math.floor((z+radius)/25)
    -- Preserve extreme custom geometry without enumerating millions of cells.
    if (hiX-loX+1)*(hiZ-loZ+1) > 256 then return all end
    for cx=loX,hiX do
        local column = grid[cx]
        if column ~= nil then
            for cz=loZ,hiZ do
                for record in pairs(column[cz] or {}) do
                    if not seen[record] then seen[record] = true; result[#result+1] = record end
                end
            end
        end
    end
    return result
end

local function getVehiclePoints(vehicle)
    vehicle = getRootVehicle(vehicle)
    if scanContext ~= nil and scanContext.optimized and scanContext.points[vehicle] ~= nil then
        return scanContext.points[vehicle]
    end
    if vehicle == nil or not validNode(vehicle.rootNode) then return {} end
    local points = {}
    local seen = setmetatable({}, {__mode="k"})
    local function walk(obj)
        if obj == nil or seen[obj] then return end
        seen[obj] = true
        if validNode(obj.rootNode) then
            local x, y, z = getWorldTranslation(obj.rootNode)
            table.insert(points, {x=x, y=y, z=z})
            local fx, _, fz = localDirectionToWorld(obj.rootNode, 0, 0, 1)
            local len = math.sqrt(fx*fx + fz*fz)
            if len > 0.001 then fx, fz = fx/len, fz/len end
            local size = obj.size or {}
            local half = (tonumber(size.length) or 8) * 0.5
            local halfWidth = (tonumber(size.width) or 3) * 0.5
            local off = tonumber(size.lengthOffset) or 0
            local rx, rz = fz, -fx
            local front = half + off
            local rear = half - off
            table.insert(points, {x=x + fx*front, y=y, z=z + fz*front})
            table.insert(points, {x=x - fx*rear, y=y, z=z - fz*rear})
            table.insert(points, {x=x + fx*front + rx*halfWidth, y=y, z=z + fz*front + rz*halfWidth})
            table.insert(points, {x=x + fx*front - rx*halfWidth, y=y, z=z + fz*front - rz*halfWidth})
            table.insert(points, {x=x - fx*rear + rx*halfWidth, y=y, z=z - fz*rear + rz*halfWidth})
            table.insert(points, {x=x - fx*rear - rx*halfWidth, y=y, z=z - fz*rear - rz*halfWidth})
        end
        if obj.getAttachedImplements ~= nil then
            local ok, impls = pcall(obj.getAttachedImplements, obj)
            if ok and impls ~= nil then for _, impl in ipairs(impls) do walk(impl.object) end end
        end
    end
    walk(vehicle)
    return points
end

local function getGateAxes(gate)
    local fx, fz = tonumber(gate.forwardX) or 0, tonumber(gate.forwardZ) or 1
    local fl = math.sqrt(fx*fx + fz*fz)
    if fl < 0.001 then fx, fz, fl = 0, 1, 1 end
    fx, fz = fx/fl, fz/fl
    local rx, rz = tonumber(gate.rightX) or fz, tonumber(gate.rightZ) or -fx
    local rl = math.sqrt(rx*rx + rz*rz)
    if rl < 0.001 then rx, rz, rl = fz, -fx, 1 end
    rx, rz = rx/rl, rz/rl
    if gate.axisSwapped == true then
        return rx, rz, -fx, -fz
    end
    return fx, fz, rx, rz
end

local function interactionProbe(gate)
    local angle=math.rad(tonumber(gate.interactionYaw) or 0)
    local fx,fz,rx,rz=getGateAxes({forwardX=gate.forwardX,forwardZ=gate.forwardZ,rightX=gate.rightX,rightZ=gate.rightZ})
    local sin,cos=math.sin(angle),math.cos(angle)
    return {x=(gate.x or 0)+(gate.interactionOffsetX or 0),y=gate.y,z=(gate.z or 0)+(gate.interactionOffsetZ or 0),
        forwardX=fx*cos+rx*sin,forwardZ=fz*cos+rz*sin,
        rightX=rx*cos-fx*sin,rightZ=rz*cos-fz*sin,axisSwapped=false}
end
function SmartGate:getInteractionProbe(gate) return interactionProbe(gate) end

-- Per-object AD lookahead. AnimatedObject.duration is milliseconds in GIANTS.
local function preOpenManualDistance(value)
    local n=tonumber(value)
    if n==nil or n~=n or n==math.huge or n==-math.huge then return AD_PREOPEN_DISTANCE end
    return math.max(10,math.min(500,n))
end
local function gatePreOpenDistance(gate)
    local mode=tonumber(gate~=nil and gate.preOpenMode) or 0
    if mode==2 then return preOpenManualDistance(gate.preOpenDistance) end
    if mode==1 then
        local animation=gate.animatedObject~=nil and gate.animatedObject.animation
        local duration=tonumber(animation~=nil and animation.duration)
        if duration~=nil and duration==duration and duration>0 and duration<math.huge then
            return preOpenManualDistance((duration/1000+2)*(50/3.6))
        end
    end
    return AD_PREOPEN_DISTANCE
end
function SmartGate:getADPreOpenDistance(gate) return gatePreOpenDistance(gate) end

local function isGermanUi()
    return tostring(g_languageShort or "en"):lower():sub(1,2) == "de"
end

local function uiText(de, en)
    if isGermanUi() then return de end
    return en
end

local function getWashSourceText(source)
    source = tonumber(source) or WASH_SOURCE_TRIGGER
    if source == WASH_SOURCE_PROFILE then return uiText("PROFIL", "PROFILE") end
    if source == WASH_SOURCE_GEOMETRY then return uiText("GEOMETRIE", "GEOMETRY") end
    if source == WASH_SOURCE_MANUAL then return uiText("MANUELL", "MANUAL") end
    return uiText("TRIGGER-FALLBACK", "TRIGGER FALLBACK")
end

local function getInteractionTriggerText(mode)
    mode = tonumber(mode) or INTERACTION_TRIGGER_ENTER
    if mode == INTERACTION_TRIGGER_EXIT then return uiText("BEIM VERLASSEN", "ON EXIT") end
    if mode == INTERACTION_TRIGGER_ENTER_EXIT then return uiText("EINFAHRT + VERLASSEN", "ENTER + EXIT") end
    if mode == INTERACTION_TRIGGER_OCCUPIED then return uiText("SOLANGE BELEGT", "WHILE OCCUPIED") end
    return uiText("BEI EINFAHRT", "ON ENTER")
end

local function isKnownAutoWashProfile(gate)
    local ownerKey = tostring(gate ~= nil and gate.ownerKey or ""):lower():gsub("\\", "/")
    return ownerKey:find("fs25_autowashingsystem", 1, true) ~= nil
        or ownerKey:find("/autowash.xml", 1, true) ~= nil
end

local function tryNodeBounds(node)
    if not validNode(node) then return nil end
    local candidates = {rawget(_G, "getWorldBoundingBox"), rawget(_G, "getBoundingBox")}
    for _, fn in pairs(candidates) do
        if type(fn) == "function" then
            local ok, minX, minY, minZ, maxX, maxY, maxZ = pcall(fn, node)
            if ok and type(minX) == "number" and type(minY) == "number" and type(minZ) == "number"
                and type(maxX) == "number" and type(maxY) == "number" and type(maxZ) == "number" then
                local width = math.abs(maxX - minX)
                local height = math.abs(maxY - minY)
                local length = math.abs(maxZ - minZ)
                if width > 0.2 and height > 0.2 and length > 0.2 then
                    return width, height, length
                end
            end
        end
    end
    return nil
end

local function detectWashGeometry(gate)
    if gate == nil then return nil end
    if isKnownAutoWashProfile(gate) then
        return {
            width=AUTO_WASH_PROFILE_WIDTH, height=AUTO_WASH_PROFILE_HEIGHT, length=AUTO_WASH_PROFILE_LENGTH,
            offsetX=AUTO_WASH_PROFILE_OFFSET_X, offsetY=AUTO_WASH_PROFILE_OFFSET_Y, offsetZ=AUTO_WASH_PROFILE_OFFSET_Z,
            source=WASH_SOURCE_PROFILE
        }
    end

    local nodes = {}
    local seen = {}
    local function addNode(node)
        if validNode(node) and not seen[node] then seen[node] = true; table.insert(nodes, node) end
    end
    addNode(gate.node)
    local ao = gate.animatedObject
    addNode(ao ~= nil and ao.triggerNode or nil)
    addNode(ao ~= nil and ao.controls ~= nil and ao.controls.triggerNode or nil)
    if ao ~= nil and ao.animation ~= nil and ao.animation.parts ~= nil then
        for _, part in pairs(ao.animation.parts) do
            local node = part ~= nil and part.node or nil
            local name = validNode(node) and tostring(getName(node) or ""):lower() or ""
            if name:find("vehicle", 1, true) ~= nil or name:find("trigger", 1, true) ~= nil then addNode(node) end
        end
    end
    for _, node in ipairs(nodes) do
        local width, height, length = tryNodeBounds(node)
        if width ~= nil then
            -- Bounding boxes are world-aligned. Use the longer ground dimension as length.
            local washLength = math.max(width, length)
            local washWidth = math.min(width, length)
            if washLength >= 2 and washWidth >= 1 then
                return {width=washWidth, height=height, length=washLength, offsetX=0, offsetY=height*0.5, offsetZ=0, source=WASH_SOURCE_GEOMETRY}
            end
        end
    end

    -- Final fallback uses active SmartGate trigger geometry only. The retired
    -- Config Trigger must not influence WashBox dimensions anymore.
    local halfLength = math.max(tonumber(gate.triggerOpenDistance) or 0, tonumber(gate.triggerCloseDistance) or 0, tonumber(gate.safetyDepth) or 0)
    local halfWidth = math.max(tonumber(gate.triggerOpenHalfWidth) or tonumber(gate.triggerSideDistance) or 0,
        tonumber(gate.triggerCloseHalfWidth) or tonumber(gate.triggerSideDistance) or 0, tonumber(gate.safetyHalfWidth) or 0)
    return {
        width=math.max(1, halfWidth * 2), height=DEFAULT_WASH_HEIGHT, length=math.max(1, halfLength * 2),
        offsetX=0, offsetY=DEFAULT_WASH_HEIGHT*0.5, offsetZ=0, source=WASH_SOURCE_TRIGGER
    }
end

local function applyAutoWashGeometry(gate)
    local geo = detectWashGeometry(gate)
    if gate == nil or geo == nil then return false end
    gate.washWidth = tonumber(geo.width) or DEFAULT_WASH_WIDTH
    gate.washHeight = tonumber(geo.height) or DEFAULT_WASH_HEIGHT
    gate.washLength = tonumber(geo.length) or DEFAULT_WASH_LENGTH
    gate.washOffsetX = tonumber(geo.offsetX) or 0
    gate.washOffsetY = tonumber(geo.offsetY) or 0
    gate.washOffsetZ = tonumber(geo.offsetZ) or 0
    gate.washGeometrySource = tonumber(geo.source) or WASH_SOURCE_TRIGGER
    gate.washGeometryManual = false
    print(string.format("[SmartGate][WASH] auto geometry '%s': source=%s width=%.2f height=%.2f length=%.2f offset=(%.2f,%.2f,%.2f)",
        tostring(gate.displayName or gate.id), getWashSourceText(gate.washGeometrySource), gate.washWidth, gate.washHeight, gate.washLength,
        gate.washOffsetX, gate.washOffsetY, gate.washOffsetZ))
    return true
end

local function legacyWashBay(gate)
    local infra=g_smartGate~=nil and g_smartGate.serviceInfrastructure
    local id=type(g_smartGate~=nil and g_smartGate.getServiceSourceId)=="function" and g_smartGate:getServiceSourceId(gate) or gate.id
    if infra==nil or type(infra.getLegacyWashBay)~="function" then return nil end
    local bay=infra:getLegacyWashBay(id)
    if bay==nil and not g_smartGate:hasGateIdCollision(gate.id) then bay=infra:getLegacyWashBay(gate.id) end
    return bay
end
local function getWashBoxCenter(gate)
    local bay=legacyWashBay(gate)
    if bay~=nil then return bay.x,bay.y+bay.height*.5,bay.z end
    local fx, fz, rx, rz = getGateAxes(gate)
    local ox = tonumber(gate.washOffsetX) or 0
    local oy = tonumber(gate.washOffsetY) or 0
    local oz = tonumber(gate.washOffsetZ) or 0
    return (gate.x or 0) + rx*ox + fx*oz, (gate.y or 0) + oy, (gate.z or 0) + rz*ox + fz*oz
end

function SmartGate:getWashPointTemplate(id)
    local gate=self:findGateById(id)
    if gate==nil or gate.objectType~=OBJECT_INTERACTION then return nil end
    -- Old saved washPoint flags remain valid. New explicit service bindings
    -- may use a verified native wash source without this retired UI flag.
    if not gate.washPoint and not (type(self.isServiceWashSource)=="function" and self:isServiceWashSource(gate)) then return nil end
    local x,y,z=getWashBoxCenter(gate)
    -- New native-source imports can still have the untouched zero centre
    -- offset. That default is not a manually configured half-buried wash box.
    local uninitializedBase=not gate.washPoint and not gate.washGeometryManual
        and (tonumber(gate.washOffsetY) or 0)==0 and legacyWashBay(gate)==nil
    if not uninitializedBase then y=y-(gate.washHeight or DEFAULT_WASH_HEIGHT)*.5 end
    local fx,fz=getGateAxes(gate)
    local farm
    if gate.owner~=nil and type(gate.owner.getOwnerFarmId)=="function" then local ok,value=pcall(gate.owner.getOwnerFarmId,gate.owner); if ok then farm=value end end
    return {id=id,name=self:getGateName(gate),x=x,y=y,z=z,yaw=math.atan2(fx,fz),
        width=gate.washWidth or DEFAULT_WASH_WIDTH,height=gate.washHeight or DEFAULT_WASH_HEIGHT,length=gate.washLength or DEFAULT_WASH_LENGTH,farmId=farm}
end

local function pointInGateBox(gate, x, z, halfDepth, halfWidth)
    local fx, fz, rx, rz = getGateAxes(gate)
    local dx, dz = x - gate.x, z - gate.z
    local forward = dx*fx + dz*fz
    local lateral = dx*rx + dz*rz
    return math.abs(forward) <= halfDepth and math.abs(lateral) <= halfWidth
end

local function getGateVehicleLists()
    if scanContext ~= nil and scanContext.optimized and scanContext.currentRoots ~= nil then
        return {scanContext.currentRoots}
    end
    local mission = g_currentMission
    local lists = {}
    if mission ~= nil and mission.vehicleSystem ~= nil and mission.vehicleSystem.vehicles ~= nil then
        table.insert(lists, mission.vehicleSystem.vehicles)
    end
    if mission ~= nil and mission.vehicles ~= nil then table.insert(lists, mission.vehicles) end
    return lists
end

local function isVehicleOperational(vehicle)
    local root = getRootVehicle(vehicle)
    if root == nil then return false end
    if scanContext ~= nil and scanContext.optimized and scanContext.operational[root] ~= nil then
        return scanContext.operational[root]
    end

    -- A parked, empty vehicle must not hold a gate open. Count only vehicles
    -- that are currently controlled by a player or driven by AI/AutoDrive.
    if root.getIsEntered ~= nil then
        local ok, entered = pcall(root.getIsEntered, root)
        if ok and entered == true then return true end
    end
    if root.getIsControlled ~= nil then
        local ok, controlled = pcall(root.getIsControlled, root)
        if ok and controlled == true then return true end
    end
    local ad = resolveAutoDriveApi()
    if ad ~= nil and ad.getIsEntered ~= nil then
        local ok, entered = pcall(ad.getIsEntered, ad, root)
        if ok and entered == true then return true end
    end
    if root.getIsAIActive ~= nil then
        local ok, aiActive = pcall(root.getIsAIActive, root)
        if ok and aiActive == true then return true end
    end
    -- Courseplay exposes this vehicle API; no local-player dependency.
    if root.getIsCpActive ~= nil then
        local ok, cpActive = pcall(root.getIsCpActive, root)
        if ok and cpActive == true then return true end
    end
    if root.ad ~= nil and root.ad.stateModule ~= nil and root.ad.stateModule.isActive ~= nil then
        local ok, adActive = pcall(root.ad.stateModule.isActive, root.ad.stateModule)
        if ok and adActive == true then return true end
    end

    -- Multiplayer fallback when the server knows a controller user id but the
    -- convenience methods above are unavailable for a specific vehicle type.
    local enterable = root.spec_enterable
    if enterable ~= nil and enterable.controllerUserId ~= nil and enterable.controllerUserId ~= 0 then
        return true
    end

    return getRootVehicle(getLocalVehicle()) == root
end

local function vehicleNearGate(gate, depth, sideDistance, operationalOnly)
    local lists = getGateVehicleLists()
    if #lists == 0 then return false end

    local roots = setmetatable({}, {__mode="k"})
    for _, list in ipairs(lists) do
        for _, vehicle in pairs(list) do
            local root = getRootVehicle(vehicle)
            if root ~= nil and not roots[root] then
                roots[root] = true
                if scanContext ~= nil then scanContext.vehicleGateComparisons = scanContext.vehicleGateComparisons + 1 end
                if (not operationalOnly) or isVehicleOperational(root) then
                    for _, p in ipairs(getVehiclePoints(root)) do
                        if pointInGateBox(gate, p.x, p.z, depth, sideDistance) then return true end
                    end
                end
            end
        end
    end
    return false
end

local function getVehicleWorldXZ(vehicle)
    local root = getRootVehicle(vehicle)
    if root == nil then return nil, nil end

    local node = nil
    if root.components ~= nil and root.components[1] ~= nil then
        node = root.components[1].node
    end
    node = node or root.rootNode
    if not validNode(node) then return nil, nil end

    local x, _, z = getWorldTranslation(node)
    return x, z
end

-- Clips a route segment against the gate's oriented rectangle.
-- Returns true plus the entry position [0..1] on the segment.
local function segmentIntersectsGateBox(gate, ax, az, bx, bz, halfDepth, halfWidth)
    local fx, fz, rx, rz = getGateAxes(gate)

    local adx, adz = ax - gate.x, az - gate.z
    local bdx, bdz = bx - gate.x, bz - gate.z

    local aForward = adx * fx + adz * fz
    local aSide = adx * rx + adz * rz
    local bForward = bdx * fx + bdz * fz
    local bSide = bdx * rx + bdz * rz

    local dForward = bForward - aForward
    local dSide = bSide - aSide
    local tMin, tMax = 0.0, 1.0

    local function clipAxis(startValue, delta, minValue, maxValue)
        if math.abs(delta) < 0.000001 then
            return startValue >= minValue and startValue <= maxValue
        end

        local t1 = (minValue - startValue) / delta
        local t2 = (maxValue - startValue) / delta
        if t1 > t2 then t1, t2 = t2, t1 end

        if t1 > tMin then tMin = t1 end
        if t2 < tMax then tMax = t2 end
        return tMin <= tMax
    end

    if not clipAxis(aForward, dForward, -halfDepth, halfDepth) then return false, nil end
    if not clipAxis(aSide, dSide, -halfWidth, halfWidth) then return false, nil end

    return true, math.max(0.0, math.min(1.0, tMin))
end

local function isAutoDriveActive(root)
    return root ~= nil
        and root.ad ~= nil
        and root.ad.stateModule ~= nil
        and root.ad.drivePathModule ~= nil
        and root.ad.stateModule.isActive ~= nil
        and root.ad.drivePathModule.getWayPoints ~= nil
        and select(1, pcall(root.ad.stateModule.isActive, root.ad.stateModule)) == true
        and select(2, pcall(root.ad.stateModule.isActive, root.ad.stateModule)) == true
end

-- Safety also needs the body between sampled endpoints/corners. A long trailer
-- can bridge the opening with none of its seven sample points inside the box.
local function bodyIntersectsGateBox(gate, points, depth, width)
    for first=1,#points,7 do
        local corners = {points[first+3], points[first+4], points[first+6], points[first+5]}
        if corners[4] ~= nil then
            local positive, negative = false, false
            for i=1,4 do
                local a, b = corners[i], corners[i%4+1]
                if segmentIntersectsGateBox(gate, a.x, a.z, b.x, b.z, depth, width) then return true end
                local cross = (b.x-a.x)*(gate.z-a.z) - (b.z-a.z)*(gate.x-a.x)
                positive = positive or cross > 0.00001
                negative = negative or cross < -0.00001
            end
            -- Gate center inside the unit rectangle (including containment).
            local a, b, d = corners[1], corners[2], corners[4]
            local area = math.abs((b.x-a.x)*(d.z-a.z) - (b.z-a.z)*(d.x-a.x))
            if area > 0.00001 and not (positive and negative) then return true end
        end
    end
    return false
end

-- Returns true when an active AutoDrive route will cross this gate within the
-- look-ahead distance. This follows AutoDrive's current drivePathModule path
-- rather than using a giant proximity box, so traffic merely passing nearby
-- should not pre-open the gate.
local function autoDriveRouteWillCrossGate(gate, maxDistance)
    local lists = getGateVehicleLists()
    if #lists == 0 then return false, nil, nil end

    local roots = setmetatable({}, {__mode="k"})
    local halfWidth = math.max(gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE, AD_PREOPEN_MIN_HALF_WIDTH)

    for _, list in ipairs(lists) do
        for _, vehicle in pairs(list) do
            local root = getRootVehicle(vehicle)
            if root ~= nil and not roots[root] then
                roots[root] = true
                if scanContext ~= nil then scanContext.vehicleGateComparisons = scanContext.vehicleGateComparisons + 1 end

                local stateModule = root.ad ~= nil and root.ad.stateModule or nil
                local drivePathModule = root.ad ~= nil and root.ad.drivePathModule or nil
                local adActive = false

                if stateModule ~= nil and stateModule.isActive ~= nil then
                    local ok, active = pcall(stateModule.isActive, stateModule)
                    adActive = ok and active == true
                end

                if adActive and drivePathModule ~= nil and drivePathModule.getWayPoints ~= nil then
                    local okPath, wayPoints, currentIndex = pcall(drivePathModule.getWayPoints, drivePathModule)
                    currentIndex = tonumber(currentIndex)

                    if okPath and type(wayPoints) == "table" and currentIndex ~= nil then
                        local prevX, prevZ = getVehicleWorldXZ(root)
                        local travelled = 0.0
                        local checked = 0

                        if prevX ~= nil then
                            for i = math.max(1, math.floor(currentIndex)), #wayPoints do
                                local wp = wayPoints[i]
                                if wp ~= nil and tonumber(wp.x) ~= nil and tonumber(wp.z) ~= nil then
                                    local wx, wz = tonumber(wp.x), tonumber(wp.z)
                                    local dx, dz = wx - prevX, wz - prevZ
                                    local segmentLength = math.sqrt(dx * dx + dz * dz)

                                    if segmentLength > 0.001 then
                                        local hit, tEnter = segmentIntersectsGateBox(
                                            gate,
                                            prevX, prevZ,
                                            wx, wz,
                                            AD_PREOPEN_GATE_DEPTH,
                                            halfWidth
                                        )

                                        if hit then
                                            local distanceToGate = travelled + segmentLength * (tEnter or 0)
                                            if distanceToGate <= maxDistance then
                                                return true, root, distanceToGate
                                            end
                                        end

                                        travelled = travelled + segmentLength
                                        if travelled > maxDistance + 20.0 then break end
                                    end

                                    prevX, prevZ = wx, wz
                                    checked = checked + 1
                                    if checked >= AD_PREOPEN_MAX_POINTS then break end
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    return false, nil, nil
end

local function vehicleInSafetyZone(gate, includeBodies)
    -- Deliberately ignores player/helper/AutoDrive control state. A parked or
    -- completely unattended vehicle/implement is still a physical obstacle.
    local depth, width = gate.safetyDepth or DEFAULT_SAFETY_DEPTH, gate.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH
    if vehicleNearGate(gate, depth, width, false) then return true end
    if (scanContext ~= nil and scanContext.optimized) or includeBodies then
        local lists = scanContext ~= nil and {scanContext.currentRoots or {}} or getGateVehicleLists()
        local seen = {}
        for _, list in ipairs(lists) do for _, vehicle in pairs(list) do
            local root = getRootVehicle(vehicle)
            if root ~= nil and not seen[root] then
                seen[root] = true
                if scanContext ~= nil then scanContext.vehicleGateComparisons = scanContext.vehicleGateComparisons + 1 end
                if bodyIntersectsGateBox(gate, getVehiclePoints(root), depth, width) then return true end
            end
        end
        end
    end
    return false
end

local function eachPlayer(callback)
    local mission = g_currentMission
    if mission == nil then return end
    local used = setmetatable({}, {__mode="k"})
    local function add(p)
        if p ~= nil and not used[p] then used[p] = true; callback(p) end
    end
    if mission.playerSystem ~= nil and mission.playerSystem.players ~= nil then
        for _, p in pairs(mission.playerSystem.players) do add(p) end
    end
    if mission.players ~= nil then for _, p in pairs(mission.players) do add(p) end end
    add(mission.player)
    add(g_localPlayer)
end

local function playerNearGate(gate, depth, sideDistance)
    if scanContext ~= nil and scanContext.optimized then
        for _, p in ipairs(scanContext.players) do
            if pointInGateBox(gate, p.x, p.z, depth, sideDistance) then return true end
        end
        return false
    end
    local found = false
    eachPlayer(function(p)
        if found then return end
        local node = p.rootNode or p.node
        if validNode(node) then
            local x, _, z = getWorldTranslation(node)
            if pointInGateBox(gate, x, z, depth, sideDistance) then found = true end
        end
    end)
    return found
end

local function triggerInteractiveObject(gate)
    local ao = gate ~= nil and gate.animatedObject or nil
    if ao == nil or ao.animation == nil or type(ao.setDirection) ~= "function" then
        return false, "missing AnimatedObject API"
    end

    -- Start exactly one complete cycle toward the opposite animation endpoint.
    -- A resting AnimatedObject reports direction=0; blindly negating that gives
    -- -0, which is not a useful server-side start command. Use animation time to
    -- select the next endpoint instead, while leaving foreign work/wash logic alone.
    local currentDirection = tonumber(ao.animation.direction) or 0
    if currentDirection ~= 0 then
        return false, "animation already running"
    end

    local time = logicalAnimationTime(gate)
    local direction = animationDirection(gate, time < 0.5)
    local commandStart = scanContext ~= nil and cpuMs() or nil
    local ok, err = pcall(ao.setDirection, ao, direction)
    if commandStart ~= nil then scanContext.animationDurationMs = scanContext.animationDurationMs + elapsedCpuMs(commandStart) end
    if not ok then
        return false, "setDirection failed: " .. tostring(err)
    end

    if scanContext ~= nil then
        local key = direction == 1 and "gateOpenCommands" or "gateCloseCommands"
        scanContext[key] = scanContext[key] + 1
        if ao.animation.direction ~= currentDirection then
            scanContext.animationStateChanges = scanContext.animationStateChanges + 1
        end
    end

    return true, string.format("AnimatedObject:setDirection(%s)", tostring(direction))
end

local function setGateOpen(gate, shouldOpen)
    local ao = gate.animatedObject
    if ao == nil or ao.animation == nil then return end

    -- AnimatedObjectExtender proves that automatic open/close is driven by the
    -- animation direction directly. AnimatedObject:setDirection(0) is a toggle
    -- command in FS25 and +/-1 is not a reliable open/close API.
    local time = logicalAnimationTime(gate)
    local desired = animationDirection(gate, shouldOpen)
    local needsMove = (shouldOpen and time < 0.999) or ((not shouldOpen) and time > 0.001)
        or (tonumber(ao.animation.direction) or 0) == -desired
    if needsMove and ao.animation.direction ~= desired then
        local commandStart = scanContext ~= nil and cpuMs() or nil
        if scanContext ~= nil then
            local key = shouldOpen and "gateOpenCommands" or "gateCloseCommands"
            scanContext[key] = scanContext[key] + 1
            scanContext.animationStateChanges = scanContext.animationStateChanges + 1
        end
        ao.animation.direction = desired
        if ao.raiseActive ~= nil then
            pcall(ao.raiseActive, ao)
        end
        debugLog("%s gate '%s' (time=%.3f)", shouldOpen and "OPEN" or "CLOSE", tostring(gate.id), time)
        if commandStart ~= nil then scanContext.animationDurationMs = scanContext.animationDurationMs + elapsedCpuMs(commandStart) end
    end
end

local function getSavePath(directory)
    local mi = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    local dir = directory or (mi ~= nil and mi.savegameDirectory or nil)
    if dir == nil or dir == "" then return nil end
    return dir:gsub("[/\\]+$", "") .. "/smartGate.xml"
end

local function readPersistentXML(path)
    if path == nil or not fileExists(path) then return nil end
    local xml = loadXMLFile("smartGateVerify", path)
    if xml == nil or xml == 0 then return nil end
    local ok, content = pcall(function()
        if not hasXMLProperty(xml, "smartGate") then return nil end
        return saveXMLFileToMemory(xml)
    end)
    delete(xml)
    if ok and type(content) == "string" and content ~= "" then return content end
    return nil
end

local function nextPersistenceSlot(previous)
    -- The committed file carries the pointer, including after a GIANTS
    -- tempsavegame promotion or process restart. Legacy numbered files are
    -- never reused or deleted by this bounded scheme.
    local slot=0
    if previous~=nil and fileExists(previous) then
        local xml=loadXMLFile("smartGateSlot",previous)
        if xml~=nil and xml~=0 then
            local value=getXMLInt(xml,"smartGate#backupSlot")
            if type(value)=="number" and value>=1 and value<=3 and value==math.floor(value) then slot=value end
            delete(xml)
        end
    end
    return slot%3+1
end

local function copyPersistentXML(source, target, overwrite)
    local function failed(cause, detail)
        print(string.format("[SmartGate][PERSIST][COPY][ERROR] cause=%s source=%s target=%s overwrite=%s detail=%s",
            cause, tostring(source), tostring(target), tostring(overwrite), tostring(detail or "nil")))
        return false
    end
    local expected = readPersistentXML(source)
    if expected == nil then return failed("SOURCE_UNREADABLE") end
    if not overwrite and fileExists(target) then return failed("TARGET_EXISTS") end
    if type(copyFile) ~= "function" then return failed("COPY_API_UNAVAILABLE") end
    local ok, result = pcall(copyFile, source, target, overwrite)
    if not ok then return failed("COPY_EXCEPTION", result) end
    if result == false then return failed("COPY_RETURNED_FALSE") end
    -- GIANTS copyFile(source, target, overwrite) can return no Lua value.
    -- A successful pcall alone proves nothing: require a complete disk readback.
    if result ~= nil and result ~= true then return failed("UNEXPECTED_COPY_RETURN", result) end
    local actual = readPersistentXML(target)
    if actual == nil then return failed("TARGET_UNREADABLE", "return=" .. tostring(result)) end
    if actual ~= expected then return failed("CONTENT_MISMATCH", "return=" .. tostring(result)) end
    print(string.format("[SmartGate][PERSIST][COPY] verified source=%s target=%s overwrite=%s return=%s",
        source, target, tostring(overwrite), tostring(result)))
    return true
end

function SmartGate.new()
    local self = setmetatable({}, SmartGate_mt)
    self.gates = {}
    self.savedModes = {}
    self.savedBlacklist = {}
    self.savedGateSettings = {}
    self.savedCustomGeometry = {}
    self.savedGateRecords = {}
    self.persistenceRestorePass = false
    self.scanTimer = 0
    self.rescanTimer = 0
    self.stateSyncTimer = 0
    self.hornStates = setmetatable({}, {__mode="k"})
    self.lastPolledVehicle = nil
    self.lastPolledHorn = nil
    self.markerGate = nil
    self.markerUntil = 0
    self.markerMode = MODE_DISABLED
    self.markerBlacklisted = false
    self.markerOverlay = nil
    self.lastEditorRawMode = nil
    self.lastEditorSource = nil
    self.configModeEnabled = false
    self.configCursorOwned = false
    self.configCursorWasVisible = false
    self.configPanelGate = nil
    self.configProfileGateId,self.configGeometryProfile=nil,nil
    self.serviceAdXmlCache=nil
    self.configPanelRefreshTimer = 0
    self.showZonesAlways = false
    self.configInputHookInstalled = false
    self.lastGateCount = nil
    self.persistenceConfigLoaded = false
    self.persistenceConfigMissing = false
    return self
end

function SmartGate:loadConfig()
    if g_server == nil then return false end
    local path = getSavePath()
    if path == nil then
        print("[SmartGate][PERSIST] load deferred: savegame directory unavailable")
        return false
    end
    if not fileExists(path) then
        self.persistenceConfigLoaded = false
        self.persistenceConfigMissing = true
        print("[SmartGate][PERSIST] no config file at " .. tostring(path))
        return false
    end
    local xml = loadXMLFile("smartGate", path)
    if xml == nil or xml == 0 then
        print("[SmartGate][PERSIST] failed to open " .. tostring(path))
        return false
    end
    if not hasXMLProperty(xml, "smartGate") then
        delete(xml)
        print("[SmartGate][PERSIST][ERROR] invalid config root; preserving memory path=" .. tostring(path))
        return false
    end
    -- Only replace restored state after a readable authoritative file exists.
    local enabled=getXMLBool(xml,"smartGate#newGatesEnabled")
    self.newGatesEnabled=enabled~=false
    self.savedModes = {}
    self.savedBlacklist = {}
    self.savedGateSettings = {}
    self.savedCustomGeometry = {}
    self.savedGateRecords = {}
    local i = 0
    while hasXMLProperty(xml, string.format("smartGate.gates.gate(%d)", i)) do
        local key = string.format("smartGate.gates.gate(%d)", i)
        local id = getXMLString(xml, key .. "#id")
        local mode = getXMLInt(xml, key .. "#mode")
        local blacklisted = getXMLBool(xml, key .. "#blacklisted")
        if id ~= nil then
            self.savedModes[id] = mode ~= nil and math.max(0, math.min(3, mode)) or MODE_ALL
            if blacklisted == true then self.savedBlacklist[id] = true end
            local customGeometry = getXMLBool(xml, key .. "#customGeometry") == true
            self.savedCustomGeometry[id] = customGeometry
            local settings = {
                preOpenMode=getXMLInt(xml,key.."#preOpenMode"),preOpenDistance=getXMLFloat(xml,key.."#preOpenDistance"),
                interactionDepth = getXMLFloat(xml, key .. "#interactionDepth"),
                interactionHalfWidth = getXMLFloat(xml, key .. "#interactionHalfWidth"),
                interactionOffsetX = getXMLFloat(xml, key .. "#interactionOffsetX"),
                interactionOffsetZ = getXMLFloat(xml, key .. "#interactionOffsetZ"),
                interactionYaw = getXMLFloat(xml, key .. "#interactionYaw"),
                gateOpenDistance = getXMLFloat(xml, key .. "#gateOpenDistance"),
                gateOpenHalfWidth = getXMLFloat(xml, key .. "#gateOpenHalfWidth"),
                triggerOpenDistance = getXMLFloat(xml, key .. "#triggerOpenDistance"),
                triggerOpenHalfWidth = getXMLFloat(xml, key .. "#triggerOpenHalfWidth"),
                triggerCloseDistance = getXMLFloat(xml, key .. "#triggerCloseDistance"),
                triggerCloseHalfWidth = getXMLFloat(xml, key .. "#triggerCloseHalfWidth"),
                triggerSideDistance = getXMLFloat(xml, key .. "#triggerSideDistance"),
                safetyDepth = getXMLFloat(xml, key .. "#safetyDepth"),
                safetyHalfWidth = getXMLFloat(xml, key .. "#safetyHalfWidth"),
                configDepth = getXMLFloat(xml, key .. "#configDepth"),
                configHalfWidth = getXMLFloat(xml, key .. "#configHalfWidth"),
                axisSwapped = getXMLBool(xml, key .. "#axisSwapped") == true, animationInverted = getXMLBool(xml, key .. "#animationInverted") == true,
                objectType = getXMLInt(xml, key .. "#objectType"),
                washPoint = getXMLBool(xml, key .. "#washPoint") == true,
                safetyClearDelayMs = getXMLInt(xml, key .. "#safetyClearDelayMs"),
                interactionTriggerMode = getXMLInt(xml, key .. "#interactionTriggerMode"),
                interactionRepeatCount = getXMLInt(xml, key .. "#interactionRepeatCount"),
                interactionRepeatDelayMs = getXMLInt(xml, key .. "#interactionRepeatDelayMs"),
                washWidth = getXMLFloat(xml, key .. "#washWidth"),
                washHeight = getXMLFloat(xml, key .. "#washHeight"),
                washLength = getXMLFloat(xml, key .. "#washLength"),
                washOffsetX = getXMLFloat(xml, key .. "#washOffsetX"),
                washOffsetY = getXMLFloat(xml, key .. "#washOffsetY"),
                washOffsetZ = getXMLFloat(xml, key .. "#washOffsetZ"),
                washGeometryManual = getXMLBool(xml, key .. "#washGeometryManual") == true,
                washGeometrySource = getXMLInt(xml, key .. "#washGeometrySource")
            }
            self.savedGateSettings[id] = settings

            local ownerKey = getXMLString(xml, key .. "#ownerKey")
            local nodeKey = getXMLString(xml, key .. "#nodeKey")
            local savedX = getXMLFloat(xml, key .. "#x")
            local savedZ = getXMLFloat(xml, key .. "#z")

            -- Backward compatibility for configs written before descriptor
            -- persistence existed. Stable IDs are owner|objectKey|node; legacy
            -- IDs are owner|node|x|y|z.
            if ownerKey == nil or ownerKey == "" then
                ownerKey = tostring(id):match("^([^|]+)")
            end
            if nodeKey == nil or nodeKey == "" then
                local parts = {}
                for part in tostring(id):gmatch("([^|]+)") do table.insert(parts, part) end
                if #parts >= 3 then nodeKey = parts[#parts] end
                if #parts >= 5 then
                    savedX = savedX or tonumber(parts[#parts-2])
                    savedZ = savedZ or tonumber(parts[#parts])
                end
            end

            table.insert(self.savedGateRecords, {
                id=id,
                ownerKey=tostring(ownerKey or ""):lower():gsub("\\", "/"),
                nodeKey=tostring(nodeKey or ""):lower(),
                x=savedX,
                z=savedZ,
                mode=mode,
                blacklisted=blacklisted == true,
                customGeometry=customGeometry,
                settings=settings
            })
        end
        i = i + 1
    end
    if self.serviceInfrastructure ~= nil then self.serviceInfrastructure:readXML(xml) end
    if self.interactionDiscovery ~= nil then self.interactionDiscovery:readXML(xml) end
    delete(xml)
    self.persistenceConfigLoaded = true
    self.persistenceConfigMissing = false
    self.persistenceConfigPath = path
    print(string.format("[SmartGate][PERSIST] loaded %d gate config(s) from %s", i, tostring(path)))
    return true
end

function SmartGate:saveConfig(directory, source)
    if g_server == nil then return false end
    if self.serviceInfrastructure ~= nil and not self.serviceInfrastructure.persistenceSafe then return false end
    if self.interactionDiscovery ~= nil and not self.interactionDiscovery.safe then return false end
    local path = getSavePath(directory)
    if path == nil then
        print("[SmartGate][PERSIST] save skipped: savegame directory unavailable")
        return false
    end
    print(string.format("[SmartGate][PERSIST][WRITE] begin source=%s path=%s loaded=%s gates=%d records=%d",
        tostring(source or "CONFIG_CHANGE"), path, tostring(self.persistenceConfigLoaded), #(self.gates or {}), #(self.savedGateRecords or {})))
    local originalPath = self.persistenceConfigPath or getSavePath()
    if self.persistenceConfigLoaded ~= true and originalPath ~= nil and fileExists(originalPath) then
        print("[SmartGate][PERSIST][ERROR] write refused: existing config not restored path=" .. originalPath)
        return false
    end
    local gates, represented = {}, {}
    for _, gate in ipairs(self.gates or {}) do
        table.insert(gates, gate)
        local record = self:findSavedGateRecord(gate, true)
        if record ~= nil then represented[record] = true end
    end
    -- Preserve records for objects that have not yet been discovered on Dedi.
    for _, record in ipairs(self.savedGateRecords or {}) do
        if not represented[record] then
            local gate = {}
            local collision=self:hasGateIdCollision(record.id)
            local stored=collision and (record.settings or {}) or (self.savedGateSettings[record.id] or record.settings or {})
            for key, value in pairs(stored) do gate[key] = value end
            for _, key in ipairs({"id", "ownerKey", "nodeKey", "x", "z", "mode", "blacklisted", "customGeometry"}) do gate[key] = record[key] end
            if not collision then
                gate.mode = self.savedModes[record.id] or record.mode
                gate.blacklisted = self.savedBlacklist[record.id] == true
                gate.customGeometry = self.savedCustomGeometry[record.id] == true
            end
            table.insert(gates, gate)
        end
    end
    if source~="NEW_GATE_DEFAULT" and #gates == 0 and not (self.serviceInfrastructure ~= nil and self.serviceInfrastructure:hasData()) and not (self.interactionDiscovery ~= nil and self.interactionDiscovery:hasData()) then
        print("[SmartGate][PERSIST] save skipped: gate inventory and restored records are empty/not ready path=" .. path)
        return false
    end
    local previous = fileExists(path) and path or originalPath
    local slot = nextPersistenceSlot(previous)
    local pending = path .. ".pending-slot-" .. tostring((slot-1)%2+1)
    local xml = createXMLFile("smartGate", pending, "smartGate")
    if xml == nil or xml == 0 then
        print("[SmartGate][PERSIST][ERROR] failed to create staging XML path=" .. pending)
        return false
    end
    local expected
    local ok, failure = pcall(function()
    setXMLBool(xml,"smartGate#newGatesEnabled",self.newGatesEnabled~=false)
    setXMLInt(xml, "smartGate#configVersion", 4)
    setXMLInt(xml, "smartGate#backupSlot", slot)
    local i = 0
    for _, gate in ipairs(gates) do
        local key = string.format("smartGate.gates.gate(%d)", i)
        setXMLString(xml, key .. "#id", gate.id)
        setXMLString(xml, key .. "#ownerKey", gate.ownerKey or "")
        setXMLString(xml, key .. "#nodeKey", gate.nodeKey or "")
        setXMLFloat(xml, key .. "#x", gate.x or 0)
        setXMLFloat(xml, key .. "#z", gate.z or 0)
        setXMLInt(xml, key .. "#mode", gate.mode or MODE_ALL)
        setXMLBool(xml, key .. "#blacklisted", gate.blacklisted == true)
        setXMLBool(xml, key .. "#customGeometry", gate.customGeometry == true)
        setXMLFloat(xml, key .. "#interactionDepth", gate.interactionDepth or .75)
        setXMLFloat(xml, key .. "#interactionHalfWidth", gate.interactionHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE)
        setXMLFloat(xml, key .. "#interactionOffsetX", gate.interactionOffsetX or 0)
        setXMLFloat(xml, key .. "#interactionOffsetZ", gate.interactionOffsetZ or 0)
        setXMLFloat(xml, key .. "#interactionYaw", gate.interactionYaw or 0)
        if gate.gateOpenDistance ~= nil then setXMLFloat(xml, key .. "#gateOpenDistance", gate.gateOpenDistance) end
        if gate.gateOpenHalfWidth ~= nil then setXMLFloat(xml, key .. "#gateOpenHalfWidth", gate.gateOpenHalfWidth) end
        setXMLFloat(xml, key .. "#triggerOpenDistance", gate.triggerOpenDistance or AUTO_OPEN_DISTANCE)
        setXMLFloat(xml, key .. "#triggerOpenHalfWidth", gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
        setXMLFloat(xml, key .. "#triggerCloseDistance", gate.triggerCloseDistance or AUTO_CLOSE_DISTANCE)
        setXMLFloat(xml, key .. "#triggerCloseHalfWidth", gate.triggerCloseHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
        setXMLFloat(xml, key .. "#triggerSideDistance", gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
        setXMLFloat(xml, key .. "#safetyDepth", gate.safetyDepth or DEFAULT_SAFETY_DEPTH)
        setXMLFloat(xml, key .. "#safetyHalfWidth", gate.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH)
        setXMLFloat(xml, key .. "#configDepth", gate.configDepth or CONFIG_ZONE_LENGTH)
        setXMLFloat(xml, key .. "#configHalfWidth", gate.configHalfWidth or CONFIG_ZONE_HALF_WIDTH)
        setXMLBool(xml, key .. "#axisSwapped", gate.axisSwapped == true)
        setXMLBool(xml, key .. "#animationInverted", gate.animationInverted == true)
        setXMLInt(xml,key.."#preOpenMode",gate.preOpenMode or 0)
        setXMLFloat(xml,key.."#preOpenDistance",preOpenManualDistance(gate.preOpenDistance))
        setXMLInt(xml, key .. "#objectType", gate.objectType or OBJECT_GATE)
        setXMLBool(xml, key .. "#washPoint", gate.objectType == OBJECT_INTERACTION and gate.washPoint == true)
        setXMLInt(xml, key .. "#safetyClearDelayMs", gate.safetyClearDelayMs or DEFAULT_SAFETY_CLEAR_DELAY_MS)
        setXMLInt(xml, key .. "#interactionTriggerMode", gate.interactionTriggerMode or INTERACTION_TRIGGER_ENTER)
        setXMLInt(xml, key .. "#interactionRepeatCount", gate.interactionRepeatCount or DEFAULT_INTERACTION_REPEAT_COUNT)
        setXMLInt(xml, key .. "#interactionRepeatDelayMs", gate.interactionRepeatDelayMs or DEFAULT_INTERACTION_REPEAT_DELAY_MS)
        setXMLFloat(xml, key .. "#washWidth", gate.washWidth or DEFAULT_WASH_WIDTH)
        setXMLFloat(xml, key .. "#washHeight", gate.washHeight or DEFAULT_WASH_HEIGHT)
        setXMLFloat(xml, key .. "#washLength", gate.washLength or DEFAULT_WASH_LENGTH)
        setXMLFloat(xml, key .. "#washOffsetX", gate.washOffsetX or 0)
        setXMLFloat(xml, key .. "#washOffsetY", gate.washOffsetY or 0)
        setXMLFloat(xml, key .. "#washOffsetZ", gate.washOffsetZ or 0)
        setXMLBool(xml, key .. "#washGeometryManual", gate.washGeometryManual == true)
        setXMLInt(xml, key .. "#washGeometrySource", gate.washGeometrySource or WASH_SOURCE_TRIGGER)
        i = i + 1
    end
    if self.serviceInfrastructure ~= nil then self.serviceInfrastructure:writeXML(xml) end
    if self.interactionDiscovery ~= nil then self.interactionDiscovery:writeXML(xml) end
    if saveXMLFile(xml) ~= true then error("saveXMLFile returned failure") end
    expected = saveXMLFileToMemory(xml)
    end)
    delete(xml)
    if not ok or expected == nil or readPersistentXML(pending) ~= expected then
        print(string.format("[SmartGate][PERSIST][ERROR] staging write/verification failed path=%s detail=%s; original untouched", pending, tostring(failure)))
        return false
    end
    -- Copy the previous configuration into the transaction too, so the backup
    -- survives GIANTS promoting its temporary directory to the real savegame.
    if previous~=nil and previous~=path then
        for historySlot=1,3 do if historySlot~=slot then
            local from=previous..".backup-slot-"..tostring(historySlot)
            local to=path..".backup-slot-"..tostring(historySlot)
            if fileExists(from) then
                if readPersistentXML(from)==nil then
                    print("[SmartGate][PERSIST][BACKUP] unreadable history skipped path="..from)
                elseif not copyPersistentXML(from,to,true) then
                    print("[SmartGate][PERSIST][ERROR] backup history transfer failed; current write aborted")
                    return false
                end
            end
        end end
    end
    local backup = nil
    if previous ~= nil and fileExists(previous) then
        backup = path .. ".backup-slot-" .. tostring(slot)
        if not copyPersistentXML(previous, backup, true) then
            print("[SmartGate][PERSIST][ERROR] backup failed; original untouched source=" .. previous .. " backup=" .. backup)
            return false
        end
        print("[SmartGate][PERSIST][BACKUP] verified source=" .. previous .. " path=" .. backup)
    end
    if not copyPersistentXML(pending, path, true) then
        print("[SmartGate][PERSIST][ERROR] commit failed path=" .. path .. " backup=" .. tostring(backup))
        if backup ~= nil then
            local restored = copyPersistentXML(backup, path, true)
            print("[SmartGate][PERSIST][RECOVERY] restored=" .. tostring(restored) .. " path=" .. path .. " backup=" .. backup)
        end
        return false
    end
    -- GIANTS restricts deletion in savegame folders. Reuse two staging paths
    -- and three backup paths instead of accumulating a new pair per save.
    print("[SmartGate][PERSIST][STAGING] retained=" .. pending .. " committed=" .. path)
    if directory == nil then
        self.persistenceConfigLoaded, self.persistenceConfigMissing = true, false
        self.persistenceConfigPath = path
    end
    print(string.format("[SmartGate][PERSIST][WRITE] verified %d gate config(s) path=%s source=%s", #gates, path, tostring(source or "CONFIG_CHANGE")))
    return true
end

function SmartGate:recalculateADPreOpen()
    if g_server==nil or not self.persistenceConfigLoaded then return false,"CONFIG_NOT_READY" end
    local plans,seen={},{}
    local function plan(id,gate,settings)
        if seen[id] then return end;seen[id]=true
        settings=self.savedGateSettings[id] or settings or {}
        if (gate~=nil and gate.objectType or settings.objectType or OBJECT_GATE)==OBJECT_INTERACTION
            or (gate~=nil and gate.preOpenMode or settings.preOpenMode)==2 then return end
        local nextSettings={};for k,v in pairs(settings) do nextSettings[k]=v end
        nextSettings.preOpenMode=1;nextSettings.preOpenDistance=preOpenManualDistance(settings.preOpenDistance)
        plans[#plans+1]={id=id,gate=gate,previous=self.savedGateSettings[id],mode=gate~=nil and gate.preOpenMode,
            distance=gate~=nil and gate.preOpenDistance,nextSettings=nextSettings}
    end
    for _,gate in ipairs(self.gates or {}) do plan(gate.id,gate) end
    for _,record in ipairs(self.savedGateRecords or {}) do plan(record.id,nil,record.settings) end
    for _,p in ipairs(plans) do
        self.savedGateSettings[p.id]=p.nextSettings
        if p.gate~=nil then p.gate.preOpenMode=1;p.gate.preOpenDistance=p.nextSettings.preOpenDistance end
    end
    if #plans>0 and not self:saveConfig(nil,"PREOPEN_AUTO_ALL") then
        for _,p in ipairs(plans) do
            self.savedGateSettings[p.id]=p.previous
            if p.gate~=nil then p.gate.preOpenMode=p.mode;p.gate.preOpenDistance=p.distance end
        end
        return false,"SAVE_FAILED"
    end
    print("[SmartGate][PREOPEN] automatic configured="..#plans.." manualOverrides=preserved")
    return true,#plans
end

function SmartGate:installPersistenceHook()
    if g_server == nil then return false end
    if self.persistenceHook ~= nil and self.persistenceHook.active then return true end
    if FSCareerMissionInfo == nil or type(FSCareerMissionInfo.saveToXMLFile) ~= "function" then
        if not self.persistenceHookWarning then
            print("[SmartGate][PERSIST][ERROR] save hook unavailable: FSCareerMissionInfo.saveToXMLFile")
            self.persistenceHookWarning = true
        end
        return false
    end
    local record = {target=FSCareerMissionInfo, original=FSCareerMissionInfo.saveToXMLFile, active=true, mission=g_currentMission}
    record.wrapper = function(missionInfo, ...)
        -- The passed missionInfo carries the actual transaction directory.
        -- Mod event listeners' saveSavegame is not a GIANTS save callback.
        if record.active and g_server ~= nil and g_currentMission == record.mission and missionInfo ~= nil and missionInfo.isValid then
            if missionInfo.savegameDirectory == nil or missionInfo.savegameDirectory == "" then
                print("[SmartGate][PERSIST][ERROR] save hook has no transaction directory")
            else
                local ok, result = pcall(self.saveConfig, self, missionInfo.savegameDirectory, "FSCareerMissionInfo.saveToXMLFile")
                if not ok or result ~= true then
                    print("[SmartGate][PERSIST][ERROR] transaction config write failed directory=" .. tostring(missionInfo.savegameDirectory) .. " detail=" .. tostring(result))
                    local target = getSavePath(missionInfo.savegameDirectory)
                    local previous = self.persistenceConfigPath
                    if not fileExists(target) and previous ~= nil and previous ~= target then
                        local preserved = copyPersistentXML(previous, target, false)
                        print("[SmartGate][PERSIST][RECOVERY] previous config preserved=" .. tostring(preserved) .. " source=" .. previous .. " path=" .. target .. "; current write remains failed")
                    end
                end
            end
        end
        return record.original(missionInfo, ...)
    end
    record.target.saveToXMLFile = record.wrapper
    self.persistenceHook, self.persistenceHookWarning = record, false
    print("[SmartGate][PERSIST][HOOK] installed FSCareerMissionInfo.saveToXMLFile server=true")
    return true
end

function SmartGate:removePersistenceHook()
    local record = self.persistenceHook
    if record ~= nil then
        record.active = false
        if record.target.saveToXMLFile == record.wrapper then record.target.saveToXMLFile = record.original end
    end
    self.persistenceHook = nil
end

function SmartGate:ensureGateIdentityCounts()
    if self.gateIdentitySource==self.gates and self.savedGateIdentitySource==self.savedGateRecords then return end
    self.gateIdentitySource,self.savedGateIdentitySource=self.gates,self.savedGateRecords
    self.gateIdCounts,self.savedGateIdCounts={},{}
    for _,gate in ipairs(self.gates or {}) do self.gateIdCounts[gate.id]=(self.gateIdCounts[gate.id] or 0)+1 end
    for _,record in ipairs(self.savedGateRecords or {}) do self.savedGateIdCounts[record.id]=(self.savedGateIdCounts[record.id] or 0)+1 end
end
function SmartGate:hasGateIdCollision(id)
    self:ensureGateIdentityCounts()
    return (self.gateIdCounts[id] or 0)>1 or (self.savedGateIdCounts[id] or 0)>1
end
function SmartGate:findSavedGateRecord(gate, allowDescriptorFallback)
    if gate == nil then return nil end
    local exactId = tostring(gate.id or "")
    local legacyId = tostring(gate.legacyId or "")

    -- Model-local animation IDs repeat across separate placed buildings. Keep
    -- the IDs, but require the existing spatial descriptor for these instances.
    if self:hasGateIdCollision(exactId) then
        local match
        for _,record in ipairs(self.savedGateRecords or {}) do
            if (record.id==exactId or legacyId~="" and record.id==legacyId)
                and record.ownerKey==gate.ownerKey and record.nodeKey==gate.nodeKey
                and type(record.x)=="number" and type(record.z)=="number" and type(gate.x)=="number" and type(gate.z)=="number"
                and sqrDistance2D(record.x,record.z,gate.x,gate.z)<=.25*.25 then
                if match~=nil then return nil,"ambiguous" end
                match=record
            end
        end
        return match,match~=nil and "id+position" or "missing"
    end
    -- A unique exact or legacy ID retains the original compatibility path.
    for _, record in ipairs(self.savedGateRecords or {}) do
        if record.id == exactId or (legacyId ~= "" and record.id == legacyId) then
            return record, "id"
        end
    end

    -- Descriptor migration is only allowed during the explicit persistence
    -- restore pass after loading smartGate.xml. Periodic runtime rescans must
    -- never reinterpret an unrelated saved record.
    if allowDescriptorFallback ~= true then
        return nil, "missing"
    end

    local ownerKey = tostring(gate.ownerKey or ""):lower():gsub("\\", "/")
    local nodeKey = tostring(gate.nodeKey or ""):lower()
    if ownerKey == "" or nodeKey == "" or gate.x == nil or gate.z == nil then
        return nil, "missing"
    end

    local best = nil
    local bestDistance = math.huge
    local secondDistance = math.huge

    for _, record in ipairs(self.savedGateRecords or {}) do
        if record.ownerKey == ownerKey and record.nodeKey == nodeKey
            and record.x ~= nil and record.z ~= nil then
            local distance = math.sqrt(sqrDistance2D(gate.x, gate.z, record.x, record.z))
            if distance < bestDistance then
                secondDistance = bestDistance
                best = record
                bestDistance = distance
            elseif distance < secondDistance then
                secondDistance = distance
            end
        end
    end

    if best ~= nil and bestDistance <= DESCRIPTOR_MATCH_MAX_DISTANCE then
        if secondDistance < math.huge and math.abs(secondDistance - bestDistance) < 0.25 then
            print(string.format("[SmartGate][PERSIST][WARN] ambiguous descriptor restore blocked newId=%s owner=%s node=%s best=%.2fm second=%.2fm",
                tostring(gate.id), ownerKey, nodeKey, bestDistance, secondDistance))
            return nil, "ambiguous"
        end

        print(string.format("[SmartGate][PERSIST] restored gate by strict descriptor oldId=%s newId=%s distance=%.2f",
            tostring(best.id), tostring(gate.id), bestDistance))
        return best, "descriptor"
    end

    return nil, "missing"
end

function SmartGate:rescan()
    local oldModes = {}
    local oldBlacklist = {}
    local oldSettings = {}
    local oldCustomGeometry = {}
    local oldRuntime = {}
    local oldInstances = {}
    for _, g in ipairs(self.gates) do
        oldModes[g.id] = g.mode
        oldBlacklist[g.id] = g.blacklisted == true
        oldCustomGeometry[g.id] = g.customGeometry == true
        oldSettings[g.id] = {
            gateOpenDistance=g.gateOpenDistance, gateOpenHalfWidth=g.gateOpenHalfWidth,
            interactionDepth=g.interactionDepth,
            interactionHalfWidth=g.interactionHalfWidth,
            interactionOffsetX=g.interactionOffsetX,
            interactionOffsetZ=g.interactionOffsetZ,
            interactionYaw=g.interactionYaw,
            triggerOpenDistance=g.triggerOpenDistance, triggerOpenHalfWidth=g.triggerOpenHalfWidth,
            triggerCloseDistance=g.triggerCloseDistance, triggerCloseHalfWidth=g.triggerCloseHalfWidth,
            triggerSideDistance=g.triggerSideDistance, safetyDepth=g.safetyDepth,
            safetyHalfWidth=g.safetyHalfWidth, configDepth=g.configDepth, configHalfWidth=g.configHalfWidth,
            axisSwapped=g.axisSwapped == true, animationInverted=g.animationInverted == true, objectType=g.objectType or OBJECT_GATE, washPoint=g.washPoint == true, safetyClearDelayMs=g.safetyClearDelayMs,
            preOpenMode=g.preOpenMode,preOpenDistance=g.preOpenDistance,
            interactionTriggerMode=g.interactionTriggerMode, interactionRepeatCount=g.interactionRepeatCount, interactionRepeatDelayMs=g.interactionRepeatDelayMs,
            washWidth=g.washWidth, washHeight=g.washHeight, washLength=g.washLength,
            washOffsetX=g.washOffsetX, washOffsetY=g.washOffsetY, washOffsetZ=g.washOffsetZ,
            washGeometryManual=g.washGeometryManual == true, washGeometrySource=g.washGeometrySource
        }
        oldRuntime[g.id] = {
            serviceControl = g.serviceControl,
            occupied = g.occupied == true,
            clearSince = g.clearSince,
            preOpenReserved = g.preOpenReserved == true,
            interactionLatched = g.interactionLatched == true,
            interactionWasOccupied = g.interactionWasOccupied == true,
            interactionRepeatRemaining = g.interactionRepeatRemaining or 0,
            interactionNextTriggerTime = g.interactionNextTriggerTime,
            configTestOpen = g.configTestOpen == true
        }
        if g.animatedObject~=nil then oldInstances[g.animatedObject]={mode=g.mode,blacklisted=g.blacklisted==true,
            custom=g.customGeometry==true,settings=oldSettings[g.id],runtime=oldRuntime[g.id]} end
    end
    self.gates = collectGates()

    -- Dedi maps can expose placeables/gates well after loadMap/onStartMission.
    -- If an existing smartGate.xml could not be restored during early startup,
    -- load it now before applying defaults to the newly discovered gates.
    local lateRestorePass = false
    if g_server ~= nil and #self.gates > 0 and self.persistenceConfigLoaded ~= true then
        local path = getSavePath()
        if path ~= nil and fileExists(path) then
            if self:loadConfig() then
                lateRestorePass = true
                print(string.format("[SmartGate][PERSIST] late authoritative restore armed for %d discovered gate(s)", #self.gates))
            end
        end
    end
    local authoritativeRestore = self.persistenceRestorePass == true or lateRestorePass

    for _, gate in ipairs(self.gates) do
        local legacyId = gate.legacyId
        local collision=self:hasGateIdCollision(gate.id)
        local instance=collision and oldInstances[gate.animatedObject] or nil
        local savedRecord = self:findSavedGateRecord(gate, authoritativeRestore)
        gate.mode = self.savedModes[gate.id] or (legacyId ~= nil and self.savedModes[legacyId]) or oldModes[gate.id] or (legacyId ~= nil and oldModes[legacyId]) or (self.newGatesEnabled~=false and MODE_ALL or MODE_DISABLED)
        gate.blacklisted = self.savedBlacklist[gate.id] == true or (legacyId ~= nil and self.savedBlacklist[legacyId] == true) or oldBlacklist[gate.id] == true or (legacyId ~= nil and oldBlacklist[legacyId] == true)
        local runtime = oldRuntime[gate.id] or (legacyId ~= nil and oldRuntime[legacyId])
        if collision then
            local own=not authoritativeRestore and instance or savedRecord
            gate.mode=own~=nil and own.mode or (self.newGatesEnabled~=false and MODE_ALL or MODE_DISABLED)
            gate.blacklisted=own~=nil and own.blacklisted==true
            runtime=instance~=nil and instance.runtime or nil
        end
        if runtime ~= nil then
            gate.serviceControl = runtime.serviceControl
            gate.occupied = runtime.occupied == true
            gate.clearSince = runtime.clearSince
            gate.preOpenReserved = runtime.preOpenReserved == true
            gate.interactionLatched = runtime.interactionLatched == true
            gate.interactionWasOccupied = runtime.interactionWasOccupied == true
            gate.interactionRepeatRemaining = runtime.interactionRepeatRemaining or 0
            gate.interactionNextTriggerTime = runtime.interactionNextTriggerTime
            gate.configTestOpen = runtime.configTestOpen == true
        else
            gate.preOpenReserved = false
            gate.interactionLatched = false
            gate.interactionWasOccupied = false
            gate.interactionRepeatRemaining = 0
            gate.interactionNextTriggerTime = nil
        end
        local recordCfg = savedRecord ~= nil and savedRecord.settings or nil

        -- Runtime state is authoritative after the initial load. A periodic
        -- rescan must preserve changes made during the current session instead
        -- of re-applying the startup snapshot every GATE_RESCAN_MS.
        local runtimeCfg = oldSettings[gate.id] or (legacyId ~= nil and oldSettings[legacyId]) or nil
        if collision then runtimeCfg=instance~=nil and instance.settings or nil end
        local runtimeCustom = nil
        if oldSettings[gate.id] ~= nil then
            runtimeCustom = oldCustomGeometry[gate.id] == true
        elseif legacyId ~= nil and oldSettings[legacyId] ~= nil then
            runtimeCustom = oldCustomGeometry[legacyId] == true
        end

        local cfg
        if collision then
            cfg=authoritativeRestore and (recordCfg or runtimeCfg or {}) or (runtimeCfg or recordCfg or {})
        elseif authoritativeRestore then
            cfg = self.savedGateSettings[gate.id]
                or (legacyId ~= nil and self.savedGateSettings[legacyId])
                or recordCfg
                or runtimeCfg
                or {}
        else
            cfg = runtimeCfg
                or self.savedGateSettings[gate.id]
                or (legacyId ~= nil and self.savedGateSettings[legacyId])
                or recordCfg
                or {}
        end

        if collision then
            if not authoritativeRestore and instance~=nil then gate.customGeometry=instance.custom
            else gate.customGeometry=savedRecord~=nil and savedRecord.customGeometry==true end
        elseif authoritativeRestore then
            if self.savedGateSettings[gate.id] ~= nil then
                gate.customGeometry = self.savedCustomGeometry[gate.id] == true
            elseif legacyId ~= nil and self.savedGateSettings[legacyId] ~= nil then
                gate.customGeometry = self.savedCustomGeometry[legacyId] == true
            elseif savedRecord ~= nil then
                gate.customGeometry = savedRecord.customGeometry == true
            elseif runtimeCustom ~= nil then
                gate.customGeometry = runtimeCustom
            end
        elseif runtimeCustom ~= nil then
            gate.customGeometry = runtimeCustom
        elseif self.savedGateSettings[gate.id] ~= nil then
            gate.customGeometry = self.savedCustomGeometry[gate.id] == true
        elseif legacyId ~= nil and self.savedGateSettings[legacyId] ~= nil then
            gate.customGeometry = self.savedCustomGeometry[legacyId] == true
        else
            gate.customGeometry = savedRecord ~= nil and savedRecord.customGeometry == true
        end

        if not collision and savedRecord ~= nil and runtimeCfg == nil and self.savedGateSettings[gate.id] == nil
            and (legacyId == nil or self.savedGateSettings[legacyId] == nil) then
            if savedRecord.mode ~= nil then gate.mode = math.max(0, math.min(3, savedRecord.mode)) end
            gate.blacklisted = savedRecord.blacklisted == true
        end

        self.savedModes[gate.id] = gate.mode
        if gate.blacklisted then self.savedBlacklist[gate.id] = true else self.savedBlacklist[gate.id] = nil end
        if gate.customGeometry then self.savedCustomGeometry[gate.id] = true else self.savedCustomGeometry[gate.id] = nil end
        self.savedGateSettings[gate.id] = cfg

        gate.animationInverted = cfg.animationInverted == true
        gate.preOpenMode=tonumber(cfg.preOpenMode) or (savedRecord~=nil and 0 or gate.preOpenMode or 1)
        if gate.preOpenMode~=0 and gate.preOpenMode~=1 and gate.preOpenMode~=2 then gate.preOpenMode=0 end
        gate.preOpenDistance=preOpenManualDistance(cfg.preOpenDistance or gate.preOpenDistance)
        cfg.preOpenMode=gate.preOpenMode;cfg.preOpenDistance=gate.preOpenDistance
        local defaults = self.settings ~= nil and self.settings.values or nil
        if gate.customGeometry then
            gate.interactionDepth = tonumber(cfg.interactionDepth) or .75
            gate.interactionHalfWidth = tonumber(cfg.interactionHalfWidth) or DEFAULT_TRIGGER_SIDE_DISTANCE
            gate.interactionOffsetX = tonumber(cfg.interactionOffsetX) or 0
            gate.interactionOffsetZ = tonumber(cfg.interactionOffsetZ) or 0
            gate.interactionYaw = tonumber(cfg.interactionYaw) or 0
            gate.gateOpenDistance = tonumber(cfg.gateOpenDistance)
            gate.gateOpenHalfWidth = tonumber(cfg.gateOpenHalfWidth)
            local legacyWidth = tonumber(cfg.triggerSideDistance) or DEFAULT_TRIGGER_SIDE_DISTANCE
            gate.triggerOpenDistance = tonumber(cfg.triggerOpenDistance) or AUTO_OPEN_DISTANCE
            gate.triggerOpenHalfWidth = tonumber(cfg.triggerOpenHalfWidth) or legacyWidth
            gate.triggerCloseDistance = tonumber(cfg.triggerCloseDistance) or AUTO_CLOSE_DISTANCE
            gate.triggerCloseHalfWidth = tonumber(cfg.triggerCloseHalfWidth) or legacyWidth
            gate.triggerSideDistance = gate.triggerOpenHalfWidth
            gate.safetyDepth = tonumber(cfg.safetyDepth) or DEFAULT_SAFETY_DEPTH
            gate.safetyHalfWidth = tonumber(cfg.safetyHalfWidth) or DEFAULT_SAFETY_HALF_WIDTH
            gate.configDepth = tonumber(cfg.configDepth) or CONFIG_ZONE_LENGTH
            gate.configHalfWidth = tonumber(cfg.configHalfWidth) or CONFIG_ZONE_HALF_WIDTH
            gate.axisSwapped = cfg.axisSwapped == true
            gate.objectType = tonumber(cfg.objectType) == OBJECT_INTERACTION and OBJECT_INTERACTION or OBJECT_GATE
            gate.washPoint = gate.objectType == OBJECT_INTERACTION and cfg.washPoint == true
            gate.safetyClearDelayMs = tonumber(cfg.safetyClearDelayMs) or DEFAULT_SAFETY_CLEAR_DELAY_MS
            gate.interactionTriggerMode = math.max(INTERACTION_TRIGGER_ENTER, math.min(INTERACTION_TRIGGER_OCCUPIED, tonumber(cfg.interactionTriggerMode) or INTERACTION_TRIGGER_ENTER))
            gate.interactionRepeatCount = math.max(1, tonumber(cfg.interactionRepeatCount) or DEFAULT_INTERACTION_REPEAT_COUNT)
            gate.interactionRepeatDelayMs = math.max(250, tonumber(cfg.interactionRepeatDelayMs) or DEFAULT_INTERACTION_REPEAT_DELAY_MS)
            gate.washWidth = tonumber(cfg.washWidth) or DEFAULT_WASH_WIDTH
            gate.washHeight = tonumber(cfg.washHeight) or DEFAULT_WASH_HEIGHT
            gate.washLength = tonumber(cfg.washLength) or DEFAULT_WASH_LENGTH
            gate.washOffsetX = tonumber(cfg.washOffsetX) or 0
            gate.washOffsetY = tonumber(cfg.washOffsetY) or 0
            gate.washOffsetZ = tonumber(cfg.washOffsetZ) or 0
            gate.washGeometryManual = cfg.washGeometryManual == true
            gate.washGeometrySource = tonumber(cfg.washGeometrySource) or WASH_SOURCE_TRIGGER
            if cfg.interactionDepth == nil and gate.objectType == OBJECT_INTERACTION then
                gate.interactionDepth = tonumber(cfg.triggerOpenDistance) or .75
                gate.interactionHalfWidth = tonumber(cfg.triggerOpenHalfWidth) or legacyWidth
                gate.triggerOpenDistance = tonumber(cfg.gateOpenDistance) or tonumber(defaults and defaults.triggerOpenDistance) or AUTO_OPEN_DISTANCE
                gate.triggerOpenHalfWidth = tonumber(cfg.gateOpenHalfWidth) or tonumber(defaults and defaults.triggerSideDistance) or DEFAULT_TRIGGER_SIDE_DISTANCE
                gate.triggerSideDistance = gate.triggerOpenHalfWidth
            end
            gate.gateOpenDistance,gate.gateOpenHalfWidth=nil,nil
            if gate.washPoint and not gate.washGeometryManual and cfg.washWidth == nil then applyAutoWashGeometry(gate) end
        else
            local defaultWidth = tonumber(defaults and defaults.triggerSideDistance) or DEFAULT_TRIGGER_SIDE_DISTANCE
            gate.triggerOpenDistance = tonumber(defaults and defaults.triggerOpenDistance) or AUTO_OPEN_DISTANCE
            gate.triggerOpenHalfWidth = defaultWidth
            gate.triggerCloseDistance = tonumber(defaults and defaults.triggerCloseDistance) or AUTO_CLOSE_DISTANCE
            gate.triggerCloseHalfWidth = defaultWidth
            gate.triggerSideDistance = defaultWidth
            gate.safetyDepth = tonumber(defaults and defaults.safetyDepth) or DEFAULT_SAFETY_DEPTH
            gate.safetyHalfWidth = tonumber(defaults and defaults.safetyHalfWidth) or DEFAULT_SAFETY_HALF_WIDTH
            gate.configDepth = CONFIG_ZONE_LENGTH
            gate.configHalfWidth = CONFIG_ZONE_HALF_WIDTH
            gate.axisSwapped = false
            gate.objectType = OBJECT_GATE
            gate.washPoint = false
            gate.safetyClearDelayMs = tonumber(defaults and defaults.safetyClearDelayMs) or DEFAULT_SAFETY_CLEAR_DELAY_MS
            gate.interactionTriggerMode = INTERACTION_TRIGGER_ENTER
            gate.interactionRepeatCount = DEFAULT_INTERACTION_REPEAT_COUNT
            gate.interactionRepeatDelayMs = DEFAULT_INTERACTION_REPEAT_DELAY_MS
            gate.washWidth = DEFAULT_WASH_WIDTH
            gate.washHeight = DEFAULT_WASH_HEIGHT
            gate.washLength = DEFAULT_WASH_LENGTH
            gate.washOffsetX, gate.washOffsetY, gate.washOffsetZ = 0, 0, 0
            gate.washGeometryManual = false
            gate.washGeometrySource = WASH_SOURCE_TRIGGER
        end
    end
    if self.lastGateCount == nil or self.lastGateCount ~= #self.gates then
        print(string.format("[SmartGate] gate inventory: %d gate(s) found", #self.gates))
        self.lastGateCount = #self.gates
    else
        debugLog("periodic gate rescan complete: %d gate(s)", #self.gates)
    end
end

function SmartGate:findGateById(id)
    for _, gate in ipairs(self.gates) do if gate.id == id then return gate end end
    return nil
end

function SmartGate:resolveGate(id, ownerKey, nodeKey, x, z)
    local collision=self:hasGateIdCollision(id)
    if not collision then
        local unique=self:findGateById(id)
        if unique~=nil then return unique,"exact" end
    end
    local count=0
    for _,gate in ipairs(self.gates) do if gate.id==id then count=count+1 end end

    ownerKey = tostring(ownerKey or ""):lower():gsub("\\", "/")
    nodeKey = tostring(nodeKey or ""):lower()
    x = tonumber(x)
    z = tonumber(z)

    -- Descriptor fallback is intentionally strict. Owner-only matching caused
    -- settings from one door to be applied to other objects of the same
    -- placeable. We now require owner AND node AND close world position.
    if ownerKey == "" or nodeKey == "" or x == nil or z == nil then
        print(string.format("[SmartGate][WARN] unable to resolve remote gate strictly: id=%s owner=%s node=%s",
            tostring(id), tostring(ownerKey), tostring(nodeKey)))
        return nil, "missing"
    end

    local best = nil
    local bestDistance = math.huge
    local secondDistance = math.huge

    for _, gate in ipairs(self.gates) do
        if (count==0 or gate.id==id) and gate.ownerKey == ownerKey and gate.nodeKey == nodeKey
            and gate.x ~= nil and gate.z ~= nil then
            local distance = math.sqrt(sqrDistance2D(gate.x, gate.z, x, z))
            if distance < bestDistance then
                secondDistance = bestDistance
                best = gate
                bestDistance = distance
            elseif distance < secondDistance then
                secondDistance = distance
            end
        end
    end

    if best ~= nil and bestDistance <= (collision and .25 or DESCRIPTOR_MATCH_MAX_DISTANCE) then
        -- If two candidates occupy almost exactly the same descriptor/position,
        -- refusing the fallback is safer than configuring the wrong object.
        if secondDistance < math.huge and math.abs(secondDistance - bestDistance) < 0.25 then
            print(string.format("[SmartGate][WARN] ambiguous remote gate descriptor: id=%s owner=%s node=%s best=%.2fm second=%.2fm",
                tostring(id), tostring(ownerKey), tostring(nodeKey), bestDistance, secondDistance))
            return nil, "ambiguous"
        end

        debugLog("strictly resolved remote gate '%s' -> '%s' distance=%.2f",
            tostring(id), tostring(best.id), bestDistance)
        return best, "descriptor"
    end

    print(string.format("[SmartGate][WARN] unable to resolve remote gate strictly: id=%s owner=%s node=%s nearest=%.2f",
        tostring(id), tostring(ownerKey), tostring(nodeKey), bestDistance))
    return nil, "missing"
end

function SmartGate:getGateDescriptor(gate)
    if gate == nil then return "", "", "", 0, 0 end
    return gate.id or "", gate.ownerKey or "", gate.nodeKey or "", gate.x or 0, gate.z or 0
end

function SmartGate:getGateName(gate)
    if gate == nil then return "Unbekannter Trigger" end
    return gate.displayName or "Unbekannter Trigger"
end

function SmartGate:getMarkerWorldPosition(gate)
    if gate == nil then return 0, 0, 0 end
    local fx, fz = getGateAxes(gate)
    local side = 1
    local vehicle = getLocalVehicle()
    if vehicle ~= nil and validNode(getRootVehicle(vehicle).rootNode) then
        local vx, _, vz = getWorldTranslation(getRootVehicle(vehicle).rootNode)
        local dot = (vx - gate.x) * fx + (vz - gate.z) * fz
        -- Put the icon on the opposite side of the gate from the local vehicle.
        side = dot >= 0 and -1 or 1
    end
    local offset = math.min(3.0, math.max(1.75, (gate.triggerOpenDistance or AUTO_OPEN_DISTANCE) * 0.25))
    return gate.x + fx * offset * side, (gate.y or 0), gate.z + fz * offset * side
end

function SmartGate:showMarker(gate, mode, blacklisted)
    self.markerGate = gate
    self.markerMode = mode or MODE_DISABLED
    self.markerBlacklisted = blacklisted == true
    self.markerUntil = nowMs() + MARKER_TIME_MS
end

function SmartGate:notifyMode(gate, mode)
    self:showMarker(gate, mode, gate.blacklisted)
    local txt = string.format("SmartGate: %s -> %s", self:getGateName(gate), MODE_TEXT_DE[mode] or tostring(mode))
    showNotification(txt, 4500, FSBaseMission.INGAME_NOTIFICATION_OK)
end

function SmartGate:notifyBlacklist(gate, blacklisted)
    self:showMarker(gate, gate.mode, blacklisted)
    local state = blacklisted and "BLACKLIST" or "BLACKLIST ENTFERNT"
    local txt = string.format("SmartGate: %s -> %s", self:getGateName(gate), state)
    showNotification(txt, 5000, FSBaseMission.INGAME_NOTIFICATION_OK)
end

function SmartGate:cycleGate(id, ownerKey, nodeKey, x, z)
    if g_server == nil then return end
    local gate = self:resolveGate(id, ownerKey, nodeKey, x, z)
    if gate == nil then return end
    if gate.blacklisted then
        print(string.format("[SmartGate][CONFIG] mode change ignored; blacklisted: %s (%s)", self:getGateName(gate), tostring(id)))
        SmartGateBlacklistEvent.sendToClients(gate, true)
        return
    end
    gate.mode = ((gate.mode or MODE_ALL) + 1) % 4
    print(string.format("[SmartGate][CONFIG] mode changed: %s (%s) -> %s", self:getGateName(gate), tostring(id), MODE_TEXT_DE[gate.mode] or tostring(gate.mode)))
    self.savedModes[gate.id] = gate.mode
    self:saveConfig()
    SmartGateModeEvent.sendToClients(gate, gate.mode)
end

function SmartGate:toggleBlacklist(id, ownerKey, nodeKey, x, z)
    if g_server == nil then return end
    local gate = self:resolveGate(id, ownerKey, nodeKey, x, z)
    if gate == nil then return end
    gate.blacklisted = not gate.blacklisted
    gate.occupied = false
    if gate.blacklisted then self.savedBlacklist[gate.id] = true else self.savedBlacklist[gate.id] = nil end
    print(string.format("[SmartGate][CONFIG] blacklist changed: %s (%s) -> %s", self:getGateName(gate), tostring(id), tostring(gate.blacklisted)))
    self:saveConfig()
    SmartGateBlacklistEvent.sendToClients(gate, gate.blacklisted)
end

function SmartGate:findConfigGate(vehicle)
    vehicle = getRootVehicle(vehicle)
    local player = getConfigPlayer()
    if player ~= nil and type(player.getCurrentVehicle) == "function" then
        local ok, current = pcall(player.getCurrentVehicle, player)
        if ok and current == nil then vehicle = nil end
    end
    local points
    if vehicle ~= nil and validNode(vehicle.rootNode) then points = getVehiclePoints(vehicle)
    else
        local player = getConfigPlayer()
        local node = player ~= nil and (player.rootNode or player.node) or nil
        if not validNode(node) then return nil end
        local x, y, z = getWorldTranslation(node)
        points = {{x=x,y=y,z=z}}
    end

    -- Config trigger retired in v0.1.3.8. Configuration now deliberately
    -- targets the nearest known SmartGate object around the full vehicle
    -- combination while config mode is active. This matches the effective
    -- fallback behaviour that already made the old config zone optional.
    local best, bestD = nil, math.huge
    local fallbackR2 = CONFIG_FALLBACK_RADIUS * CONFIG_FALLBACK_RADIUS
    for _, gate in ipairs(self.gates) do
        for _, point in ipairs(points) do
            local d = sqrDistance2D(gate.x, gate.z, point.x, point.z)
            if d <= fallbackR2 and d < bestD then
                best, bestD = gate, d
            end
        end
    end
    if best ~= nil then
        debugLog("config target selected by proximity: %s (%s)", self:getGateName(best), tostring(best.id))
    end
    return best
end

function SmartGate:isLocalVehicle(vehicle)
    if vehicle == nil then return false end
    if vehicle.getIsActiveForInputIgnoreSelection ~= nil then
        local ok, active = pcall(vehicle.getIsActiveForInputIgnoreSelection, vehicle)
        if ok and active == true then return true end
    end
    if vehicle.getIsActiveForInput ~= nil then
        local ok, active = pcall(vehicle.getIsActiveForInput, vehicle)
        if ok and active == true then return true end
    end
    return getRootVehicle(vehicle) == getRootVehicle(getLocalVehicle())
end

function SmartGate:installHornHook()
    if self.hornHookInstalled then return true end
    if Honk == nil or Honk.playHonk == nil then return false end
    Honk.playHonk = Utils.appendedFunction(Honk.playHonk, function(vehicle, isPlaying, noEventSend)
        if g_smartGate ~= nil then g_smartGate:onHonk(vehicle, isPlaying) end
    end)
    self.hornHookInstalled = true
    print("[SmartGate][CONFIG] horn hook installed")
    return true
end

function SmartGate:onHonk(vehicle, isPlaying)
    if not self.configModeEnabled then return end
    if not self:isLocalVehicle(vehicle) then return end
    local root = getRootVehicle(vehicle)
    local state = self.hornStates[root]
    if state == nil then state = {pressed=false, started=0, previousRelease=nil}; self.hornStates[root] = state end
    local t = nowMs()
    if isPlaying and not state.pressed then
        state.pressed = true
        state.started = t
    elseif not isPlaying and state.pressed then
        state.pressed = false
        local duration = t - state.started
        if duration <= SHORT_HONK_MAX_MS then
            if state.previousRelease ~= nil and t - state.previousRelease <= DOUBLE_HONK_MS then
                local gap = t - state.previousRelease
                state.previousRelease = nil
                print(string.format("[SmartGate][CONFIG] double honk detected (gap=%dms)", gap))
                local gate = self:findConfigGate(root)
                if gate ~= nil then
                    print(string.format("[SmartGate][CONFIG] gate selected: %s", tostring(gate.id)))
                    showNotification("SmartGate: Tor erkannt - Konfiguration wird geaendert", 2500, FSBaseMission.INGAME_NOTIFICATION_OK)
                    SmartGateConfigEvent.send(gate)
                else
                    print("[SmartGate][CONFIG] no gate in front/rear config zone")
                    showNotification(uiText("SmartGate: Kein SmartGate-Objekt in Reichweite", "SmartGate: No SmartGate object in range"), 3000, FSBaseMission.INGAME_NOTIFICATION_WARNING)
                end
            else
                state.previousRelease = t
            end
        else
            state.previousRelease = nil
        end
    end
end


local function configGuiVisible()
    if g_gui ~= nil and type(g_gui.getIsGuiVisible) == "function" then
        local ok, visible = pcall(g_gui.getIsGuiVisible, g_gui)
        return not ok or visible == true
    end
    return false
end
local function validConfigInputEvent(event)
    return type(event) == "table" and (InputEvent == nil or event ~= InputEvent.NO_EVENT)
        and event.id ~= nil and event.id ~= ""
end
local function configInputContext()
    if g_inputBinding ~= nil and type(g_inputBinding.getContextName) == "function" then
        local ok, name = pcall(g_inputBinding.getContextName, g_inputBinding)
        if ok then return tostring(name) end
    end
    return getConfigVehicle() ~= nil and "VEHICLE" or "PLAYER"
end
local function configInputLog(tag, detail)
    print("[SmartGate][CONFIG][" .. tag .. "] " .. tostring(detail))
end
local function setConfigEventActive(event, actionName, enabled)
    if not validConfigInputEvent(event) or g_inputBinding == nil then return false end
    -- GIANTS IDs can be identical in PLAYER and VEHICLE. Use the actual
    -- current-context InputEvent, exactly as setContextEventsActive does.
    if type(g_inputBinding.setEventActive) == "function" then
        return pcall(g_inputBinding.setEventActive, g_inputBinding, event, enabled)
    end
    if type(g_inputBinding.setContextEventsActive) == "function" then
        return pcall(g_inputBinding.setContextEventsActive, g_inputBinding, configInputContext(), actionName, enabled)
    end
    return false
end
function SmartGate:configUsesAutoDriveCursor()
    if g_inputBinding == nil or type(g_inputBinding.getFirstActiveEventForActionName) ~= "function" then return false end
    local ok, event = pcall(g_inputBinding.getFirstActiveEventForActionName, g_inputBinding, "ADToggleMouse")
    return ok and validConfigInputEvent(event)
end
function SmartGate:restoreConfigInputReservation(held)
    if held == nil or held.binding ~= g_inputBinding then return end
    local current
    if type(g_inputBinding.getEventsForActionName) == "function" then
        local ok, events = pcall(g_inputBinding.getEventsForActionName, g_inputBinding, "ADToggleMouse")
        if ok and type(events) == "table" then
            for _, event in pairs(events) do if event == held.event and event.id == held.id then current = event end end
        end
    end
    if current == nil then configInputLog("INPUT_ACTIVE", "AD restore skipped stale id=" .. tostring(held.id)); return end
    local ok = setConfigEventActive(current, "ADToggleMouse", true)
    configInputLog("INPUT_ACTIVE", "AD restore id=" .. tostring(held.id) .. " context=" .. held.context .. " ok=" .. tostring(ok))
end
function SmartGate:releaseConfigInputReservation()
    local held = self.configReservedADEvent
    self.configReservedADEvent = nil
    if held == nil then return end
    if held.context == configInputContext() then self:restoreConfigInputReservation(held)
    else
        -- Other contexts do not dispatch. Restore only when that context is
        -- current again and the original event object/ID still exists.
        self.configPendingADRestores = self.configPendingADRestores or {}
        self.configPendingADRestores[held.context] = held
    end
end
function SmartGate:registerConfigCursorEvent(context)
    if g_inputBinding == nil or InputAction == nil or InputAction.SMARTGATE_CURSOR_TOGGLE == nil then
        configInputLog("INPUT_REGISTERED", "success=false reason=ACTION_OR_BINDING_UNAVAILABLE")
        return
    end
    -- Register inactive: active registration rejects MMB collision with AD.
    local ok, registered, id, collision = pcall(g_inputBinding.registerActionEvent, g_inputBinding,
        InputAction.SMARTGATE_CURSOR_TOGGLE, self, SmartGate.onToggleConfigCursorAction, false, true, false, false)
    local valid = ok and registered == true and id ~= nil and id ~= ""
    configInputLog("INPUT_REGISTERED", "success=" .. tostring(valid) .. " id=" .. tostring(id)
        .. " context=" .. tostring(context) .. " collision=" .. tostring(collision))
    if not valid then return end
    self.configCursorEvents = self.configCursorEvents or {}
    self.configCursorEvents[id] = {id=id, context=tostring(context), active=false}
    g_inputBinding:setActionEventTextVisibility(id, false)
    self.configInputRefresh = true
end
function SmartGate:restoreConfigCameras()
    for camera, values in pairs(self.configCameraSnapshot or {}) do
        if camera.isRotatable == false then camera.isRotatable = values.isRotatable end
        if camera.allowTranslation == false then camera.allowTranslation = values.allowTranslation end
    end
    self.configCameraSnapshot = nil
end
function SmartGate:restoreConfigFootLook(context)
    local rows = (self.configFootLookPending or {})[context]
    if rows == nil or configGuiVisible() then return end
    self.configFootLookPending[context] = nil
    for _, held in ipairs(rows) do
        if held.binding == g_inputBinding and type(g_inputBinding.getEventsForActionName) == "function" then
            local ok, events = pcall(g_inputBinding.getEventsForActionName, g_inputBinding, held.action)
            if ok and type(events) == "table" then
                for _, event in pairs(events) do
                    if event == held.event then setConfigEventActive(event, held.action, true) end
                end
            end
        end
    end
end
function SmartGate:releaseConfigFootLook()
    self.configFootLookPending = self.configFootLookPending or {}
    for _, held in pairs(self.configFootLookHeld or {}) do
        local rows = self.configFootLookPending[held.context] or {}
        self.configFootLookPending[held.context] = rows
        rows[#rows+1] = held
    end
    self.configFootLookHeld = nil
    self:restoreConfigFootLook(configInputContext())
end
local CONFIG_FOOT_LOOK_ACTIONS = {"AXIS_LOOK_LEFTRIGHT_PLAYER", "AXIS_LOOK_UPDOWN_PLAYER"}
function SmartGate:pauseConfigFootLook()
    if not self.configCursorOwned or getConfigVehicle() ~= nil or configGuiVisible() then return end
    local context = configInputContext()
    local playerContext = PlayerInputComponent ~= nil and PlayerInputComponent.INPUT_CONTEXT_NAME or "PLAYER"
    if context ~= playerContext or g_inputBinding == nil or type(g_inputBinding.getFirstActiveEventForActionName) ~= "function" then return end
    self.configFootLookHeld = self.configFootLookHeld or {}
    -- Published FS25 PlayerInputComponent look actions only. No movement,
    -- zoom/wheel, controller bindings or other provider's cursor is changed.
    for _, action in ipairs(CONFIG_FOOT_LOOK_ACTIONS) do
        local ok, event = pcall(g_inputBinding.getFirstActiveEventForActionName, g_inputBinding, action)
        if ok and validConfigInputEvent(event) and setConfigEventActive(event, action, false) then
            self.configFootLookHeld[event] = {event=event, action=action, context=context, binding=g_inputBinding}
        end
    end
end
function SmartGate:updateConfigWheelZoom(active,context,generation,force)
    context=context or configInputContext()
    local playerContext=PlayerInputComponent~=nil and PlayerInputComponent.INPUT_CONTEXT_NAME or "PLAYER"
    local vehicleContext=Vehicle~=nil and Vehicle.INPUT_CONTEXT_NAME or "VEHICLE"
    active=active==true and self.configModeEnabled and not configGuiVisible() and g_dedicatedServer==nil
        and self.serviceConfigView and self.configOverlayDrag==nil and (context==playerContext or context==vehicleContext)
        and g_inputBinding~=nil and type(g_inputBinding.getShowMouseCursor)=="function" and g_inputBinding:getShowMouseCursor()==true
    local old=self.configWheelZoomRecord
    generation=generation or self.configInputGeneration
    if old and old.binding==g_inputBinding and old.context==context and old.active==active and old.generation==generation and not force then return end
    local pending=self.configWheelZoomPending or {};self.configWheelZoomPending=pending
    if old and #old.events>0 then
        pending[old.context]=pending[old.context] or {}
        for _,held in ipairs(old.events) do pending[old.context][#pending[old.context]+1]=held end
    end
    local restored=0
    if pending[context]~=nil and g_inputBinding~=nil and type(g_inputBinding.getEventsForActionName)=="function" then
        local ok,events=pcall(g_inputBinding.getEventsForActionName,g_inputBinding,"CAMERA_ZOOM_IN_OUT")
        if ok and type(events)=="table" then
            for _,held in ipairs(pending[context]) do
                if held.binding==g_inputBinding then for _,event in pairs(events) do
                    if event==held.event and event.id==held.id and setConfigEventActive(event,"CAMERA_ZOOM_IN_OUT",true) then restored=restored+1 end
                end end
            end
        end
        pending[context]=nil
    end
    local record={binding=g_inputBinding,context=context,active=active,generation=generation,events={}}
    self.configWheelZoomRecord=record
    if active and type(g_inputBinding.getEventsForActionName)=="function" and type(g_inputBinding.getFirstActiveEventForActionName)=="function" then
        -- Hold only currently active events in the current native context. Do not
        -- activate foreign-disabled events, register a new action, or edit bindings.
        local seen={}
        for _=1,8 do
            local ok,event=pcall(g_inputBinding.getFirstActiveEventForActionName,g_inputBinding,"CAMERA_ZOOM_IN_OUT")
            if not ok or not validConfigInputEvent(event) or seen[event] then break end
            seen[event]=true
            if not setConfigEventActive(event,"CAMERA_ZOOM_IN_OUT",false) then break end
            record.events[#record.events+1]={binding=g_inputBinding,event=event,id=event.id}
        end
    end
    if active or restored>0 then
        configInputLog("WHEEL_ZOOM","context="..context.." held="..#record.events.." restored="..restored)
    end
end
function SmartGate:setConfigCursorEnabled(enabled)
    if not enabled then
        self:finishConfigOverlayDrag()
        if self.serviceInfrastructure then self.serviceInfrastructure.panelGeometryHovered=false end
        self:updateConfigWheelZoom(false)
    end
    if g_inputBinding == nil or type(g_inputBinding.getShowMouseCursor) ~= "function"
        or type(g_inputBinding.setShowMouseCursor) ~= "function" then return end
    if enabled then
        if not self.configModeEnabled or configGuiVisible() then return end
        if self.configCursorOwned then return end
        self.configCursorWasVisible = g_inputBinding:getShowMouseCursor() == true
        -- A cursor opened by another provider is usable, but never ours to hide.
        if self.configCursorWasVisible then return end
        self.configCursorVehicle = getConfigVehicle()
        local vehicle = self.configCursorVehicle
        -- AD/CP manage their own cameras from shared cursor state. For a plain
        -- vehicle snapshot only the camera flags SG changes; do not force true.
        if vehicle ~= nil and vehicle.ad == nil and vehicle.spec_cpHud == nil then
            self.configCameraSnapshot = {}
            for _, camera in pairs(vehicle.spec_enterable ~= nil and vehicle.spec_enterable.cameras or {}) do
                self.configCameraSnapshot[camera] = {isRotatable=camera.isRotatable, allowTranslation=camera.allowTranslation}
                camera.isRotatable, camera.allowTranslation = false, false
            end
        end
        g_inputBinding:setShowMouseCursor(true)
        self.configCursorOwned = true
        self:pauseConfigFootLook()
    else
        self:releaseConfigFootLook()
        if self.configCursorOwned and not configGuiVisible() then
            if g_inputBinding:getShowMouseCursor() == true then g_inputBinding:setShowMouseCursor(self.configCursorWasVisible == true) end
        end
        self:restoreConfigCameras()
        self.configCursorOwned, self.configCursorWasVisible, self.configCursorVehicle = false, false, nil
    end
end
function SmartGate:onToggleConfigCursorAction(actionName, inputValue)
    configInputLog("INPUT_PRESSED", "action=" .. tostring(actionName) .. " value=" .. tostring(inputValue) .. " context=" .. configInputContext())
    if inputValue ~= nil and inputValue <= 0 then return end
    if not self.configModeEnabled then configInputLog("CURSOR_BLOCKED", "reason=CONFIG_OFF"); return end
    if configGuiVisible() then configInputLog("CURSOR_BLOCKED", "reason=GUI_VISIBLE"); return end
    if g_inputBinding == nil or type(g_inputBinding.getShowMouseCursor) ~= "function" or type(g_inputBinding.setShowMouseCursor) ~= "function" then
        configInputLog("CURSOR_BLOCKED", "reason=CURSOR_API_UNAVAILABLE"); return
    end
    if not self.configCursorOwned and g_inputBinding:getShowMouseCursor() then
        configInputLog("CURSOR_BLOCKED", "reason=FOREIGN_VISIBLE_CURSOR"); return
    end
    self:setConfigCursorEnabled(not self.configCursorOwned)
    configInputLog("CURSOR_TOGGLE", "visible=" .. tostring(g_inputBinding:getShowMouseCursor()) .. " owned=" .. tostring(self.configCursorOwned))
end
function SmartGate:updateConfigCursorInput()
    if self.configCursorOwned and (not self.configModeEnabled or configGuiVisible()
        or getConfigVehicle() ~= self.configCursorVehicle
        or g_inputBinding == nil or g_inputBinding:getShowMouseCursor() ~= true) then self:setConfigCursorEnabled(false) end
    local context = configInputContext()
    self:restoreConfigFootLook(context)
    self:pauseConfigFootLook()
    local pending = (self.configPendingADRestores or {})[context]
    if pending ~= nil then self.configPendingADRestores[context] = nil; self:restoreConfigInputReservation(pending) end
    local active = self.configModeEnabled and not configGuiVisible()
    -- Reuse cursor lifecycle maintenance, including a cursor owned by AD/CP.
    -- No drag polling or additional input registration outside an active drag.
    local drag = self.configOverlayDrag
    if drag ~= nil and (not active or getConfigVehicle() ~= drag.vehicle
        or g_inputBinding == nil or g_inputBinding:getShowMouseCursor() ~= true) then self:finishConfigOverlayDrag() end
    local current = {}
    if g_inputBinding ~= nil and type(g_inputBinding.getEventsForActionName) == "function" then
        local ok, events = pcall(g_inputBinding.getEventsForActionName, g_inputBinding, "SMARTGATE_CURSOR_TOGGLE")
        if ok and type(events) == "table" then
            for _, event in pairs(events) do
                if validConfigInputEvent(event) and (self.configCursorEvents or {})[event.id] ~= nil then current[event.id] = event end
            end
        end
    else
        for id, record in pairs(self.configCursorEvents or {}) do if record.context == context then current[id] = record end end
    end
    local ids = {}
    for id in pairs(current) do ids[#ids+1] = tostring(id) end
    table.sort(ids)
    local generation = context .. ":" .. table.concat(ids, ",")
    local objectsChanged = false
    for id, event in pairs(current) do
        if (self.configInputEventObjects or {})[id] ~= event then objectsChanged = true end
    end
    self:updateConfigWheelZoom(self.serviceInfrastructure~=nil and self.serviceInfrastructure.panelGeometryHovered==true,context,generation,objectsChanged)
    if generation == self.configInputGeneration and active == self.configCursorActionActive and not objectsChanged and not self.configInputRefresh then return end
    self.configInputRefresh = nil
    -- Deactivate only SG's valid current-context events before collision check.
    for _, event in pairs(current) do setConfigEventActive(event, "SMARTGATE_CURSOR_TOGGLE", false) end
    self:releaseConfigInputReservation()
    local blocked
    if active and next(current) ~= nil and type(g_inputBinding.checkEventCollision) == "function" then
        local ok, collision, action = pcall(g_inputBinding.checkEventCollision, g_inputBinding, "SMARTGATE_CURSOR_TOGGLE")
        if not ok then blocked = "COLLISION_CHECK_FAILED"
        elseif collision then
            local adAction
            if type(g_inputBinding.getActionByName) == "function" then
                local found, value = pcall(g_inputBinding.getActionByName, g_inputBinding, "ADToggleMouse")
                if found then adAction = value end
            end
            if adAction ~= nil and action == adAction then
                local found, event = pcall(g_inputBinding.getFirstActiveEventForActionName, g_inputBinding, "ADToggleMouse")
                if found and validConfigInputEvent(event) then
                    local changed = setConfigEventActive(event, "ADToggleMouse", false)
                    if changed then self.configReservedADEvent = {id=event.id, event=event, binding=g_inputBinding, context=context} end
                    configInputLog("INPUT_ACTIVE", "AD reserve id=" .. tostring(event.id) .. " context=" .. context .. " ok=" .. tostring(changed))
                    local checked, remains = pcall(g_inputBinding.checkEventCollision, g_inputBinding, "SMARTGATE_CURSOR_TOGGLE")
                    if not checked or remains then blocked = "OTHER_BINDING_COLLISION" end
                else blocked = "AD_EVENT_NOT_VALID" end
            else blocked = "OTHER_BINDING_COLLISION" end
        end
    end
    if blocked ~= nil then self:releaseConfigInputReservation() end
    if active and next(current) == nil then blocked = "NO_VALID_EVENT_IN_CONTEXT" end
    for id, event in pairs(current) do
        local enabled = active and blocked == nil
        local ok = setConfigEventActive(event, "SMARTGATE_CURSOR_TOGGLE", enabled)
        local verified = false
        if type(g_inputBinding.getFirstActiveEventForActionName) == "function" then
            local read, activeEvent = pcall(g_inputBinding.getFirstActiveEventForActionName, g_inputBinding, "SMARTGATE_CURSOR_TOGGLE")
            if read then verified = enabled and activeEvent == event or not enabled and activeEvent ~= event end
        end
        configInputLog("INPUT_ACTIVE", "id=" .. tostring(id) .. " active=" .. tostring(enabled) .. " context=" .. context .. " object=" .. tostring(event) .. " ok=" .. tostring(ok) .. " verified=" .. tostring(verified))
    end
    if blocked ~= nil then configInputLog("CURSOR_BLOCKED", "reason=" .. blocked .. " context=" .. context) end
    self.configInputGeneration, self.configCursorActionActive, self.configInputEventObjects = generation, active, current
end
function SmartGate:getConfigCursorHelp()
    local visible = g_inputBinding ~= nil and type(g_inputBinding.getShowMouseCursor) == "function" and g_inputBinding:getShowMouseCursor() == true
    local help = uiText("MMB – Mauszeiger umschalten", "MMB – Toggle mouse cursor")
    if self.configReservedADEvent ~= nil then help = help .. uiText(" (SG hat Vorrang)", " (SG priority)") end
    return help .. " | " .. (visible and uiText("Panel", "Panel") or uiText("Kamera", "Camera"))
end

local function nearestChoiceIndex(choices, value)
    local best, bestDistance = 1, math.huge
    value = tonumber(value) or choices[1]
    for i, v in ipairs(choices) do
        local d = math.abs(v - value)
        if d < bestDistance then
            best, bestDistance = i, d
        end
    end
    return best
end

function SmartGate:requestGateObjectType(gate, interaction)
    if gate == nil then return end
    self.configGeometryProfile=interaction and OBJECT_INTERACTION or OBJECT_GATE
    local event = SmartGateGateSettingsEvent.new(gate, false)
    event.values.objectType = interaction and OBJECT_INTERACTION or OBJECT_GATE
    if g_server ~= nil then
        self:applyGateGeometryOnServer(event.id, event.ownerKey, event.nodeKey, event.x, event.z, false, event.values)
    elseif g_client ~= nil then
        g_client:getServerConnection():sendEvent(event)
    end
end

function SmartGate:applyLocalGateGeometry(gate, field, value)
    if gate == nil then return end
    gate[field] = value
    gate.customGeometry = true
    self.savedCustomGeometry[gate.id] = true
end

function SmartGate:requestGateGeometry(gate, resetToDefaults)
    if gate == nil then return end

    if resetToDefaults then
        local defaults = self.settings ~= nil and self.settings.values or nil
        gate.customGeometry = false
        local defaultWidth = tonumber(defaults and defaults.triggerSideDistance) or DEFAULT_TRIGGER_SIDE_DISTANCE
        gate.triggerOpenDistance = tonumber(defaults and defaults.triggerOpenDistance) or AUTO_OPEN_DISTANCE
        gate.triggerOpenHalfWidth = defaultWidth
        gate.triggerCloseDistance = tonumber(defaults and defaults.triggerCloseDistance) or AUTO_CLOSE_DISTANCE
        gate.triggerCloseHalfWidth = defaultWidth
        gate.triggerSideDistance = defaultWidth
        gate.safetyDepth = tonumber(defaults and defaults.safetyDepth) or DEFAULT_SAFETY_DEPTH
        gate.safetyHalfWidth = tonumber(defaults and defaults.safetyHalfWidth) or DEFAULT_SAFETY_HALF_WIDTH
        gate.configDepth = CONFIG_ZONE_LENGTH
        gate.configHalfWidth = CONFIG_ZONE_HALF_WIDTH
        gate.axisSwapped = false
        gate.safetyClearDelayMs = tonumber(defaults and defaults.safetyClearDelayMs) or DEFAULT_SAFETY_CLEAR_DELAY_MS
        gate.preOpenMode=0;gate.preOpenDistance=AD_PREOPEN_DISTANCE
        self.savedCustomGeometry[gate.id] = nil
    end

    SmartGateGateSettingsEvent.send(gate, resetToDefaults == true)
end

function SmartGate:stepGateSetting(gate, field, choices, delta)
    if gate == nil then return end
    if field=="preOpenDistance" and gate.preOpenMode~=2 then return end
    local index = nearestChoiceIndex(choices, gate[field])
    index = math.max(1, math.min(#choices, index + delta))
    if field=="preOpenMode" or field=="preOpenDistance" then
        gate[field]=choices[index]
        local event=SmartGateGateSettingsEvent.new(gate,false);event.values.preOpenOnly=true
        if g_server~=nil then self:applyGateGeometryOnServer(event.id,event.ownerKey,event.nodeKey,event.x,event.z,false,event.values)
        elseif g_client~=nil then g_client:getServerConnection():sendEvent(event) end
        return
    end
    self:applyLocalGateGeometry(gate, field, choices[index])
    if tostring(field):find("^wash") ~= nil then
        gate.washGeometryManual = true
        gate.washGeometrySource = WASH_SOURCE_MANUAL
    end
    self:requestGateGeometry(gate, false)
end

function SmartGate:notifyServiceGeometrySaveFailed()
    if g_dedicatedServer~=nil then return end
    showNotification(uiText("L.E.G.S.: Geometrie konnte nicht gespeichert werden. Änderungen bleiben im Speicher. Konfiguration erneut öffnen und schließen, um es nochmals zu versuchen.",
        "L.E.G.S.: Could not save geometry. Changes remain in memory. Reopen and close configuration to retry."),8000,FSBaseMission.INGAME_NOTIFICATION_WARNING)
end
function SmartGate:onToggleConfigAction(actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory)
    if inputValue ~= nil and inputValue <= 0 then return end
    self.configModeEnabled = not self.configModeEnabled
    self.hornStates = setmetatable({}, {__mode="k"})
    if self.configModeEnabled then
        print("[SmartGate][CONFIG] SmartGate config mode: true")
        self:setConfigCursorEnabled(false)
        showNotification(uiText("SmartGate Config: AKTIV - Tor anfahren und Panel benutzen", "SmartGate Config: ACTIVE - approach an object and use the panel"), 5000, FSBaseMission.INGAME_NOTIFICATION_OK)
    else
        print("[SmartGate][CONFIG] SmartGate config mode: false")
        self:setConfigCursorEnabled(false)
        self.configPanelGate = nil
        showNotification("SmartGate Config: AUS", 2500, FSBaseMission.INGAME_NOTIFICATION_OK)
        self.markerGate = nil
        self.markerUntil = 0
    end
    self:updateConfigCursorInput()
end

function SmartGate:onToggleVisualizationAction(actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory)
    if inputValue ~= nil and inputValue <= 0 then return end

    -- The selected gate visualization is intentionally forced while config mode
    -- is active. Do not change the user's normal visualization preference here,
    -- otherwise pressing the toggle in config mode would appear to do nothing
    -- and then unexpectedly change the state after leaving config mode.
    if self.configModeEnabled then
        showNotification("SmartGate: Visualisierung bleibt im Config-Modus aktiv", 3000, FSBaseMission.INGAME_NOTIFICATION_WARNING)
        return
    end

    self.showZonesAlways = not self.showZonesAlways
    showNotification(self.showZonesAlways and "SmartGate: Triggerbereiche sichtbar" or "SmartGate: Triggerbereiche ausgeblendet", 3000, FSBaseMission.INGAME_NOTIFICATION_OK)
end

function SmartGate:onToggleBlacklistAction(actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory)
    if inputValue ~= nil and inputValue <= 0 then return end
    if not self.configModeEnabled then
        showNotification("SmartGate: Erst Config-Modus aktivieren", 3000, FSBaseMission.INGAME_NOTIFICATION_WARNING)
        return
    end
    local vehicle = getLocalVehicle()
    local gate = self:findConfigGate(vehicle)
    if gate == nil then
        showNotification(uiText("SmartGate: Kein SmartGate-Objekt in Reichweite", "SmartGate: No SmartGate object in range"), 3000, FSBaseMission.INGAME_NOTIFICATION_WARNING)
        return
    end
    print(string.format("[SmartGate][CONFIG] blacklist target: %s (%s)", self:getGateName(gate), tostring(gate.id)))
    SmartGateBlacklistRequestEvent.send(gate)
end

function SmartGate:onCycleConfigAction(actionName, inputValue)
    if inputValue ~= nil and inputValue <= 0 then return end
    if not self.configModeEnabled then return end
    local gate = self:findConfigGate(getLocalVehicle())
    if gate ~= nil then SmartGateConfigEvent.send(gate) end
end

function SmartGate:canTestGate(gate, connection)
    local mission = g_currentMission
    local player
    if connection ~= nil then
        if connection:getIsServer() then return false end
        local players = mission ~= nil and mission.playerSystem or nil
        if players == nil or type(players.getPlayerByConnection) ~= "function" then return false end
        local ok, value = pcall(players.getPlayerByConnection, players, connection)
        if ok then player = value end
    else player = getConfigPlayer() end
    if player == nil then return false end
    local points = {}
    local vehicle
    if player.getCurrentVehicle ~= nil then
        local ok, value = pcall(player.getCurrentVehicle, player)
        if ok then vehicle = getRootVehicle(value) end
    end
    if vehicle ~= nil then points = getVehiclePoints(vehicle)
    else
        local node = player.rootNode or player.node
        if validNode(node) then
            local x, _, z = getWorldTranslation(node)
            points = {{x=x,z=z}}
        end
    end
    local near = false
    for _, point in ipairs(points) do
        if sqrDistance2D(gate.x,gate.z,point.x,point.z) <= CONFIG_FALLBACK_RADIUS^2 then near = true end
    end
    if not near then return false end
    local farmId = gate.owner ~= nil and gate.owner.ownerFarmId or nil
    if gate.owner ~= nil and gate.owner.getOwnerFarmId ~= nil then
        local ok, value = pcall(gate.owner.getOwnerFarmId, gate.owner)
        if ok then farmId = value end
    end
    if type(farmId) == "number" and farmId > 0 then
        local ok, actorFarm = false, nil
        if player.getFarmId ~= nil then ok, actorFarm = pcall(player.getFarmId, player)
        else actorFarm=player.farmId; ok=type(actorFarm)=="number" end
        if not ok or actorFarm ~= farmId then return false end
    end
    return true
end

function SmartGate:testGateAnimation(id, ownerKey, nodeKey, x, z, shouldOpen, connection)
    if g_server == nil then return false, "server only" end
    local gate = self:resolveGate(id, ownerKey, nodeKey, x, z)
    if gate == nil or not self:canTestGate(gate, connection) then return false, "access/range" end
    if gate.serviceControl~=nil then return false,"service controls platform" end
    if gate.blacklisted or (gate.mode or MODE_ALL) == MODE_DISABLED then return false, "disabled/blacklisted" end
    -- Generic interactive cycles may start washing/work or toggle a foreign
    -- process. Their setDirection API is not a verified absolute-endpoint API.
    if gate.objectType == OBJECT_INTERACTION then return false, "interactive cycle" end
    local ao = gate.animatedObject
    if ao == nil or ao.animation == nil then return false, "missing animation" end
    if ao.getCanBeTriggered ~= nil then
        local ok, allowed = pcall(ao.getCanBeTriggered, ao)
        if not ok or allowed ~= true then return false, "object dependency" end
    end
    if not shouldOpen then
        if vehicleInSafetyZone(gate, true) or gate.preOpenReserved == true
            or autoDriveRouteWillCrossGate(gate, gatePreOpenDistance(gate)) then return false, "safety/reservation" end
        local mode = gate.mode or MODE_ALL
        local depth = math.max(gate.triggerOpenDistance or AUTO_OPEN_DISTANCE, gate.triggerCloseDistance or AUTO_CLOSE_DISTANCE)
        local width = math.max(gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE,
            gate.triggerCloseHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
        if ((mode == MODE_ALL or mode == MODE_VEHICLES) and vehicleNearGate(gate, depth, width, true))
            or ((mode == MODE_ALL or mode == MODE_PLAYERS) and playerNearGate(gate, depth, width)) then return false, "normal activation" end
    end
    gate.configTestOpen = shouldOpen == true
    gate.occupied = shouldOpen == true
    gate.clearSince = nil
    setGateOpen(gate, shouldOpen == true)
    return true
end

function SmartGate:requestAnimationTest(gate, shouldOpen)
    SmartGateAnimationTestEvent.send(gate, shouldOpen)
end

local function installConfigInputHook()
    if PlayerInputComponent == nil or PlayerInputComponent.registerGlobalPlayerActionEvents == nil then
        print("[SmartGate][CONFIG] PlayerInputComponent unavailable; config input hook not installed")
        return false
    end
    PlayerInputComponent.registerGlobalPlayerActionEvents = Utils.appendedFunction(
        PlayerInputComponent.registerGlobalPlayerActionEvents,
        function(playerInputComponent, controlling)
            if g_smartGate == nil or g_inputBinding == nil or InputAction == nil or InputAction.SMARTGATE_CONFIG_TOGGLE == nil then return end
            local _, eventId = g_inputBinding:registerActionEvent(
                InputAction.SMARTGATE_CONFIG_TOGGLE,
                g_smartGate,
                SmartGate.onToggleConfigAction,
                false,
                true,
                false,
                true
            )
            if eventId ~= nil then
                g_inputBinding:setActionEventTextVisibility(eventId, false)
            end
            if InputAction.SMARTGATE_CURSOR_TOGGLE ~= nil then
                local context = controlling or (PlayerInputComponent.INPUT_CONTEXT_NAME or "PLAYER")
                g_smartGate:registerConfigCursorEvent(context)
                -- Activation waits for the finished GIANTS registration transaction.
            end
            if InputAction.SMARTGATE_BLACKLIST_TOGGLE ~= nil then
                local _, blacklistEventId = g_inputBinding:registerActionEvent(
                    InputAction.SMARTGATE_BLACKLIST_TOGGLE,
                    g_smartGate,
                    SmartGate.onToggleBlacklistAction,
                    false,
                    true,
                    false,
                    true
                )
                if blacklistEventId ~= nil then
                    g_inputBinding:setActionEventTextVisibility(blacklistEventId, false)
                end
            end
            if InputAction.SMARTGATE_VISUALIZATION_TOGGLE ~= nil then
                local _, visualEventId = g_inputBinding:registerActionEvent(
                    InputAction.SMARTGATE_VISUALIZATION_TOGGLE,
                    g_smartGate,
                    SmartGate.onToggleVisualizationAction,
                    false,
                    true,
                    false,
                    true
                )
                if visualEventId ~= nil then g_inputBinding:setActionEventTextVisibility(visualEventId, false) end
            end
            if InputAction.SMARTGATE_MODE_CYCLE ~= nil then
                local _, cycleId = g_inputBinding:registerActionEvent(InputAction.SMARTGATE_MODE_CYCLE,
                    g_smartGate, SmartGate.onCycleConfigAction, false, true, false, true)
                if cycleId ~= nil then g_inputBinding:setActionEventTextVisibility(cycleId, false) end
            end
        end
    )
    if InputBinding ~= nil and type(InputBinding.onActionBindingsChanged) == "function" then
        InputBinding.onActionBindingsChanged = Utils.appendedFunction(InputBinding.onActionBindingsChanged, function()
            if g_smartGate ~= nil then g_smartGate.configInputRefresh = true end
        end)
    end
    print("[SmartGate][CONFIG] global config input hook installed")
    return true
end

local function prepareScan(owner, interval)
    local c = {optimized=owner.spatialScanEnabled ~= false, points={}, operational={},
        grid={}, roots={}, players={}, adActive={}, awake={}, vehicleGateComparisons=0,
        gateOpenCommands=0, gateCloseCommands=0, animationStateChanges=0, animationDurationMs=0,
        gatesChecked=0, gatesActivated=0, scanIntervalMs=interval, gatesRegistered=#owner.gates}
    local now = nowMs()
    local safetyAwake = owner.spatialSafetyAwake or setmetatable({}, {__mode="k"})
    owner.spatialSafetyAwake = safetyAwake
    -- Cheap animation-state inspection, independent of vehicle activation.
    -- Even an externally/manually opened gate wakes safety immediately.
    for _, gate in ipairs(owner.gates) do
        local key = gate.animatedObject or gate
        local a = gate.animatedObject ~= nil and gate.animatedObject.animation or nil
        if gate.objectType ~= OBJECT_INTERACTION and not gate.blacklisted then
            if gate.occupied == true or (a ~= nil and (logicalAnimationTime(gate) > 0.001 or (tonumber(a.direction) or 0) ~= 0)) then
                safetyAwake[key] = now + 5000
            end
            if (safetyAwake[key] or 0) > now then c.safetyAwake = true end
        else
            safetyAwake[key] = nil
        end
    end
    local seen = {}
    -- scanContext is unset here: these calls read the real mission once.
    for _, list in ipairs(getGateVehicleLists()) do
        for _, vehicle in pairs(list) do
            local root = getRootVehicle(vehicle)
            if root ~= nil and not seen[root] then
                seen[root] = true; c.roots[#c.roots+1] = root
                if c.optimized then
                    c.operational[root] = isVehicleOperational(root)
                    c.points[root] = (c.operational[root] or c.safetyAwake) and getVehiclePoints(root) or {}
                    c.adActive[root] = isAutoDriveActive(root)
                    for _, p in ipairs(c.points[root]) do gridInsert(c.grid, p.x, p.z, root) end
                    -- Index full unit footprints for independent parked-body safety.
                    for first=1,#c.points[root],7 do
                        local minX, maxX, minZ, maxZ = math.huge, -math.huge, math.huge, -math.huge
                        for i=first+3,first+6 do
                            local p = c.points[root][i]
                            minX, maxX = math.min(minX,p.x), math.max(maxX,p.x)
                            minZ, maxZ = math.min(minZ,p.z), math.max(maxZ,p.z)
                        end
                        local loX, hiX, loZ, hiZ = math.floor(minX/25), math.floor(maxX/25), math.floor(minZ/25), math.floor(maxZ/25)
                        if (hiX-loX+1)*(hiZ-loZ+1) > 256 then c.largeBodyFallback = true
                        else
                            for cx=loX,hiX do for cz=loZ,hiZ do gridInsert(c.grid,cx*25,cz*25,root) end end
                        end
                    end
                    -- AD can use a component node distinct from rootNode.
                    if c.adActive[root] then
                        local x, z = getVehicleWorldXZ(root)
                        if x ~= nil then gridInsert(c.grid, x, z, root) end
                    end
                end
            end
        end
    end
    c.vehiclesConsidered = #c.roots
    if c.optimized then
        eachPlayer(function(p)
            local node = p.rootNode or p.node
            if validNode(node) then
                local x, _, z = getWorldTranslation(node)
                c.players[#c.players+1] = {x=x, z=z}
            end
        end)
    end
    return c
end

local function shouldCheckGate(owner, gate, c)
    if not c.optimized then return true end
    local openDepth = gate.triggerOpenDistance or AUTO_OPEN_DISTANCE
    local closeDepth = math.max(openDepth, gate.triggerCloseDistance or AUTO_CLOSE_DISTANCE)
    local openWidth = gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE
    local closeWidth = math.max(openWidth, gate.triggerCloseHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
    local extent = math.sqrt(closeDepth*closeDepth + closeWidth*closeWidth)
    local safetyDepth, safetyWidth = gate.safetyDepth or DEFAULT_SAFETY_DEPTH, gate.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH
    local key = gate.animatedObject or gate
    local radius = math.max(owner.spatialAwake ~= nil and owner.spatialAwake[key] and 25 or 20, extent, gate.objectType==OBJECT_INTERACTION and (math.sqrt((gate.interactionOffsetX or 0)^2+(gate.interactionOffsetZ or 0)^2)+math.sqrt((gate.interactionDepth or .75)^2+(gate.interactionHalfWidth or 5)^2)+25) or 0)
    local routeRadius = gatePreOpenDistance(gate) + AD_PREOPEN_GATE_DEPTH + math.max(gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE, AD_PREOPEN_MIN_HALF_WIDTH)
    local interactionRadius=0
    if gate.objectType==OBJECT_INTERACTION then
        interactionRadius=math.sqrt((gate.interactionOffsetX or 0)^2+(gate.interactionOffsetZ or 0)^2)
            +math.sqrt((gate.interactionDepth or .75)^2+(gate.interactionHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE)^2)+25
    end
    local queryRadius = math.max(radius, routeRadius, interactionRadius, math.sqrt(safetyDepth*safetyDepth + safetyWidth*safetyWidth))
    local candidates = c.largeBodyFallback and c.roots or gridQuery(c.grid, gate.x, gate.z, queryRadius, c.roots)
    c.currentRoots = candidates
    local animation = gate.animatedObject ~= nil and gate.animatedObject.animation or nil
    local awake = gate.occupied == true or gate.preOpenReserved == true or gate.clearSince ~= nil
        or (owner.spatialSafetyAwake[key] or 0) > nowMs()
        or gate.interactionLatched == true or gate.interactionWasOccupied == true
        or (gate.interactionRepeatRemaining or 0) > 0
        or (animation ~= nil and (tonumber(animation.direction) or 0) ~= 0)
    local mode = gate.mode or MODE_ALL
    if awake then c.awake[key] = true; return true end
    for _, root in ipairs(candidates) do
        c.vehicleGateComparisons = c.vehicleGateComparisons + 1
        if gate.objectType~=OBJECT_INTERACTION and (mode == MODE_ALL or mode == MODE_VEHICLES or mode == MODE_DISABLED) and c.adActive[root] then
            local x, z = getVehicleWorldXZ(root)
            if x ~= nil and (x-gate.x)^2 + (z-gate.z)^2 <= routeRadius*routeRadius then awake = true end
        end
        for _, p in ipairs(c.points[root]) do
            if (mode == MODE_ALL or mode == MODE_VEHICLES) and c.operational[root]
                and (p.x-gate.x)^2 + (p.z-gate.z)^2 <= radius*radius then awake = true end
            -- Safety independently wakes even a manually opened gate for a parked body.
            if animation ~= nil and logicalAnimationTime(gate) > 0.001
                and pointInGateBox(gate, p.x, p.z, safetyDepth, safetyWidth) then awake = true end
        end
        if animation ~= nil and logicalAnimationTime(gate) > 0.001
            and bodyIntersectsGateBox(gate, c.points[root], safetyDepth, safetyWidth) then awake = true end
        if awake then break end
    end
    if mode == MODE_ALL or mode == MODE_PLAYERS then
        for _, p in ipairs(c.players) do
            if (p.x-gate.x)^2 + (p.z-gate.z)^2 <= radius*radius then awake = true end
        end
    end
    c.awake[key] = awake
    return awake
end

local function finishScan(owner, c, duration)
    c.scanDurationMs = duration
    c.timingAvailable = performanceTimingAvailable
    c.triggerDurationMs = math.max(0, duration - c.preparationDurationMs - c.animationDurationMs)
    c.currentRoots = nil
    owner.lastScanMetrics = {}
    for key, value in pairs(c) do
        if type(value) ~= "table" then owner.lastScanMetrics[key] = value end
    end
    owner.spatialAwake = c.awake
    local w = owner.performanceWindow or {count=0, elapsed=0, sum=0, max=0,
        gatesChecked=0, vehiclesConsidered=0, vehicleGateComparisons=0, gatesActivated=0,
        gateOpenCommands=0, gateCloseCommands=0, animationStateChanges=0,
        preparationDurationMs=0, triggerDurationMs=0, animationDurationMs=0, timingAvailable=true}
    owner.performanceWindow = w
    w.count = w.count + 1; w.elapsed = w.elapsed + c.scanIntervalMs
    w.timingAvailable = w.timingAvailable and c.timingAvailable
    w.sum = w.sum + duration; w.max = math.max(w.max, duration)
    for _, key in ipairs({"gatesChecked", "vehiclesConsidered", "vehicleGateComparisons", "gatesActivated", "gateOpenCommands", "gateCloseCommands", "animationStateChanges", "preparationDurationMs", "triggerDurationMs", "animationDurationMs"}) do
        w[key] = w[key] + c[key]
    end
    if w.elapsed >= 10000 then
        if owner.performanceDiagnostics ~= false then
            print(string.format("[SmartGate][PERF] mode=%s timing=%s scanIntervalMs=%.1f scanDurationMs=%.3f scanMaxMs=%.3f gatesRegistered=%d gatesChecked=%.1f vehiclesConsidered=%.1f vehicleGateComparisons=%.1f gatesActivated=%d gateOpenCommands=%d gateCloseCommands=%d animationStateChanges=%d discoveryDurationMs=%.3f preparationDurationMs=%.3f triggerDurationMs=%.3f animationDurationMs=%.3f scans=%d",
                c.optimized and "spatial" or "baseline", w.timingAvailable and "cpu" or "unavailable", w.elapsed/w.count, w.sum/w.count, w.max,
                c.gatesRegistered, w.gatesChecked/w.count, w.vehiclesConsidered/w.count,
                w.vehicleGateComparisons/w.count, w.gatesActivated, w.gateOpenCommands,
                w.gateCloseCommands, w.animationStateChanges, owner.discoveryDurationMs or 0,
                w.preparationDurationMs/w.count, w.triggerDurationMs/w.count, w.animationDurationMs/w.count, w.count))
        end
        owner.performanceWindow = nil
    end
end

-- Test-only, server-local switch; changes neither XML nor multiplayer state.
function SmartGate:consolePerformance(mode)
    if g_server == nil then return "SmartGate: server only / nur auf dem Server" end
    if mode == "baseline" then self.spatialScanEnabled = false
    elseif mode == "spatial" then self.spatialScanEnabled = true
    elseif mode == "off" then self.performanceDiagnostics = false
    elseif mode == "on" then self.performanceDiagnostics = true
    else return "sgPerformance spatial|baseline|on|off" end
    self.performanceWindow = nil
    return "SmartGate PERF spatial=" .. tostring(self.spatialScanEnabled ~= false) .. " diagnostics=" .. tostring(self.performanceDiagnostics ~= false)
end

function SmartGate:update(dt)
    updateTimeMs = updateTimeMs + dt
    self.scanTimer = self.scanTimer + dt
    self.rescanTimer = self.rescanTimer + dt
    self.stateSyncTimer = self.stateSyncTimer + dt
    if self.rescanTimer >= GATE_RESCAN_MS then
        self.rescanTimer = 0
        self:installPersistenceHook()
        performanceTimingAvailable = true
        local discoveryStart = cpuMs()
        self:rescan()
        self.discoveryDurationMs = elapsedCpuMs(discoveryStart)
        self.discoveryTimingAvailable = performanceTimingAvailable
    end
    if g_server ~= nil and self.stateSyncTimer >= STATE_SYNC_INTERVAL_MS then
        self.stateSyncTimer = 0
        SmartGateStateSyncEvent.sendToClients(self.gates)
    end

    if not self.hornHookInstalled then self:installHornHook() end

    -- Config mode is deliberately SmartGate-owned. No cross-mod editor-state
    -- dependency is required; AutoDrive can remain installed or absent.

    self:updateConfigCursorInput()
    self.configPanelRefreshTimer = (self.configPanelRefreshTimer or 0) + dt
    local localVehicle = getConfigVehicle()
    if self.configModeEnabled and self.configPanelRefreshTimer >= 150 then
        self.configPanelRefreshTimer = 0
        local selected=self:findConfigGate(localVehicle)
        local selectedId=selected~=nil and (self:hasGateIdCollision(selected.id) and selected.animatedObject or selected.id) or nil
        if selectedId~=self.configProfileGateId then
            self.configGeometryProfile=selected~=nil and selected.objectType or nil
            self.configProfileGateId=selectedId
        end
        self.configPanelGate=selected
    elseif not self.configModeEnabled then
        self.configPanelGate = nil
    end
    if localVehicle ~= self.lastPolledVehicle then
        self.lastPolledVehicle = localVehicle
        self.lastPolledHorn = nil
    end
    if localVehicle ~= nil and localVehicle.spec_honk ~= nil then
        local horn = localVehicle.spec_honk.isPlaying == true
        if self.lastPolledHorn == nil or horn ~= self.lastPolledHorn then
            self.lastPolledHorn = horn
            self:onHonk(localVehicle, horn)
        end
    end

    if g_server ~= nil and self.scanTimer >= SCAN_INTERVAL_MS then
        scanContext = nil
        performanceTimingAvailable = true
        local scanStart = cpuMs()
        local c = prepareScan(self, self.scanTimer)
        c.preparationDurationMs = elapsedCpuMs(scanStart)
        scanContext = c
        self.scanTimer = 0
        for _, gate in ipairs(self.gates) do
          if shouldCheckGate(self, gate, c) then
            c.gatesChecked = c.gatesChecked + 1
            local wasOccupied = gate.occupied == true
            local mode = gate.mode or MODE_ALL
            if gate.serviceControl~=nil then
                -- A service lease controls this explicitly configured platform.
                -- Ordinary gate safety and all other objects keep their paths.
                gate.interactionRepeatRemaining=0;gate.interactionNextTriggerTime=nil
            elseif gate.blacklisted or (mode == MODE_DISABLED and gate.objectType == OBJECT_INTERACTION) then
                gate.occupied = false
                gate.clearSince = nil
                gate.preOpenReserved = false
            else
                local depth = gate.occupied and (gate.triggerCloseDistance or AUTO_CLOSE_DISTANCE) or (gate.triggerOpenDistance or AUTO_OPEN_DISTANCE)
                local sideDistance = gate.occupied and (gate.triggerCloseHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE) or (gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
                -- Never use a smaller exit region than the entry region. Keep saved values intact.
                if gate.occupied then
                    depth = math.max(depth, gate.triggerOpenDistance or AUTO_OPEN_DISTANCE)
                    sideDistance = math.max(sideDistance, gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
                end
                local probe=gate
                if gate.objectType==OBJECT_INTERACTION then
                    probe=interactionProbe(gate)
                    depth=gate.interactionDepth or .75
                    sideDistance=gate.interactionHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE
                end
                local vehicleModeEnabled = mode == MODE_ALL or mode == MODE_VEHICLES
                local vehicleHit = vehicleModeEnabled and vehicleNearGate(probe, depth, sideDistance, true)
                local playerHit = (mode == MODE_ALL or mode == MODE_PLAYERS) and playerNearGate(probe, depth, sideDistance)

                if gate.objectType == OBJECT_INTERACTION then
                    local interactionHit = vehicleHit or playerHit
                    local wasOccupied = gate.interactionWasOccupied == true
                    local now = g_currentMission ~= nil and g_currentMission.time or nowMs()
                    gate.preOpenReserved = false
                    gate.clearSince = nil
                    gate.occupied = interactionHit

                    if gate.washPoint == true then
                        -- Wash points keep the proven single-trigger-per-entry behavior.
                        if interactionHit then
                            gate.interactionClearSince = nil
                            if not gate.interactionLatched then
                                local triggered, method = triggerInteractiveObject(gate)
                                if triggered then
                                    gate.interactionLatched = true
                                    print(string.format("[SmartGate][INTERACTION][WASH] triggered '%s' via %s", tostring(gate.displayName or gate.id), tostring(method)))
                                end
                            end
                        elseif gate.interactionLatched then
                            gate.interactionClearSince = gate.interactionClearSince or now
                            if now - gate.interactionClearSince >= DEFAULT_INTERACTION_REARM_MS then
                                gate.interactionLatched = false
                                gate.interactionClearSince = nil
                            end
                        end
                    else
                        local triggerMode = tonumber(gate.interactionTriggerMode) or INTERACTION_TRIGGER_ENTER
                        local eventMatched = false
                        if triggerMode == INTERACTION_TRIGGER_ENTER then
                            eventMatched = interactionHit and not wasOccupied
                        elseif triggerMode == INTERACTION_TRIGGER_EXIT then
                            eventMatched = (not interactionHit) and wasOccupied
                        elseif triggerMode == INTERACTION_TRIGGER_ENTER_EXIT then
                            eventMatched = interactionHit ~= wasOccupied
                        elseif triggerMode == INTERACTION_TRIGGER_OCCUPIED then
                            eventMatched = interactionHit and not wasOccupied
                        end

                        if eventMatched then
                            gate.interactionRepeatRemaining = math.max(1, tonumber(gate.interactionRepeatCount) or DEFAULT_INTERACTION_REPEAT_COUNT)
                            gate.interactionNextTriggerTime = now
                            gate.interactionLatched = true
                        end

                        if triggerMode == INTERACTION_TRIGGER_OCCUPIED and not interactionHit then
                            gate.interactionRepeatRemaining = 0
                            gate.interactionNextTriggerTime = nil
                            gate.interactionLatched = false
                        end

                        if (gate.interactionRepeatRemaining or 0) > 0 and gate.interactionNextTriggerTime ~= nil and now >= gate.interactionNextTriggerTime then
                            if triggerMode ~= INTERACTION_TRIGGER_OCCUPIED or interactionHit then
                                local triggered, method = triggerInteractiveObject(gate)
                                if triggered then
                                    gate.interactionRepeatRemaining = math.max(0, (gate.interactionRepeatRemaining or 1) - 1)
                                    gate.interactionNextTriggerTime = gate.interactionRepeatRemaining > 0 and (now + (gate.interactionRepeatDelayMs or DEFAULT_INTERACTION_REPEAT_DELAY_MS)) or nil
                                    print(string.format("[SmartGate][INTERACTION] triggered '%s' via %s; remaining=%d", tostring(gate.displayName or gate.id), tostring(method), gate.interactionRepeatRemaining or 0))
                                elseif tostring(method) == "animation already running" then
                                    gate.interactionNextTriggerTime = now + 250
                                else
                                    print(string.format("[SmartGate][INTERACTION][WARN] could not trigger '%s': %s", tostring(gate.displayName or gate.id), tostring(method)))
                                    gate.interactionRepeatRemaining = 0
                                    gate.interactionNextTriggerTime = nil
                                end
                            end
                        end

                        if (gate.interactionRepeatRemaining or 0) <= 0 then
                            gate.interactionLatched = false
                        end
                    end
                    gate.interactionWasOccupied = interactionHit
                else
                    local preOpenHit, preOpenVehicle, preOpenDistance = false, nil, nil
                    if vehicleModeEnabled or mode==MODE_DISABLED then
                        preOpenHit, preOpenVehicle, preOpenDistance = autoDriveRouteWillCrossGate(gate, gatePreOpenDistance(gate))
                    end

                    if preOpenHit ~= gate.preOpenReserved then
                        gate.preOpenReserved = preOpenHit
                        if preOpenHit then
                            print(string.format("[SmartGate][AD] pre-open reserved gate '%s' at %.1fm", tostring(gate.displayName or gate.id), tonumber(preOpenDistance) or -1))
                            SmartGatePreOpenNotifyEvent.send(preOpenVehicle, gate.displayName or gate.id, preOpenDistance)
                        else
                            print(string.format("[SmartGate][AD] pre-open reservation released for gate '%s'", tostring(gate.displayName or gate.id)))
                        end
                    end

                    local testOpening = gate.configTestOpen == true and logicalAnimationTime(gate) < 0.999
                    if not testOpening then gate.configTestOpen = nil end
                    local triggerHit = vehicleHit or playerHit or preOpenHit or testOpening
                    local animationTime = logicalAnimationTime(gate)
                    local animationDirection = gate.animatedObject ~= nil and gate.animatedObject.animation ~= nil and tonumber(gate.animatedObject.animation.direction) or 0
                    local gateIsOpenOrMoving = animationTime > 0.001 or animationDirection ~= 0 or gate.occupied == true
                    local safetyNeeded = not c.optimized or gateIsOpenOrMoving or triggerHit
                        or (self.spatialSafetyAwake[gate.animatedObject or gate] or 0) > nowMs()
                    local safetyHit = safetyNeeded and vehicleInSafetyZone(gate)
                    if c.optimized and (gateIsOpenOrMoving or triggerHit) then
                        self.spatialSafetyAwake[gate.animatedObject or gate] = nowMs() + 5000
                    end

                    if triggerHit then
                        gate.clearSince = nil
                        if not gate.occupied then
                            gate.occupied = true
                        end
                        setGateOpen(gate, true)
                    elseif safetyHit and gateIsOpenOrMoving then
                        gate.clearSince = nil
                        gate.occupied = true
                        setGateOpen(gate, true)
                    elseif gate.occupied then
                        local now = nowMs()
                        if gate.clearSince == nil then gate.clearSince = now end
                        if now - gate.clearSince >= (gate.safetyClearDelayMs or DEFAULT_SAFETY_CLEAR_DELAY_MS) then
                            gate.clearSince = nil
                            gate.occupied = false
                            setGateOpen(gate, false)
                        end
                    else
                        gate.clearSince = nil
                    end
                end
            end
            if gate.occupied and not wasOccupied then c.gatesActivated = c.gatesActivated + 1 end
          end
        end
        scanContext = nil
        finishScan(self, c, elapsedCpuMs(scanStart))
    end
    -- Keep service ticks in the originally registered entry point. A listener
    -- profiler may capture this method before later modules extend the class.
    -- Run after the gate scan, preserving the original wrapper's order.
    if self.serviceInfrastructure~=nil and type(self.serviceInfrastructure.update)=="function" then self.serviceInfrastructure:update(dt) end
end

local function getTerrainY(x, z, fallbackY)
    if g_currentMission ~= nil and g_currentMission.terrainRootNode ~= nil and getTerrainHeightAtWorldPos ~= nil then
        local ok, y = pcall(getTerrainHeightAtWorldPos, g_currentMission.terrainRootNode, x, 0, z)
        if ok and y ~= nil then return y + 0.08 end
    end
    return (fallbackY or 0) + 0.08
end

local function drawGateRectangle(gate, halfDepth, halfWidth, r, g, b)
    if drawDebugLine == nil or gate == nil then return end
    local fx, fz, rx, rz = getGateAxes(gate)
    local corners = {
        {gate.x + fx*halfDepth + rx*halfWidth, gate.z + fz*halfDepth + rz*halfWidth},
        {gate.x + fx*halfDepth - rx*halfWidth, gate.z + fz*halfDepth - rz*halfWidth},
        {gate.x - fx*halfDepth - rx*halfWidth, gate.z - fz*halfDepth - rz*halfWidth},
        {gate.x - fx*halfDepth + rx*halfWidth, gate.z - fz*halfDepth + rz*halfWidth}
    }
    for i=1,4 do
        local a, c = corners[i], corners[(i % 4) + 1]
        local ay = getTerrainY(a[1], a[2], gate.y)
        local cy = getTerrainY(c[1], c[2], gate.y)
        drawDebugLine(a[1], ay, a[2], r,g,b, c[1], cy, c[2], r,g,b, false)
    end
end

local function drawWashBox(gate)
    if drawDebugLine == nil or gate == nil then return end
    local bay=legacyWashBay(gate)
    local width = math.max(0.1, tonumber(bay~=nil and bay.width or gate.washWidth) or DEFAULT_WASH_WIDTH)
    local height = math.max(0.1, tonumber(bay~=nil and bay.height or gate.washHeight) or DEFAULT_WASH_HEIGHT)
    local length = math.max(0.1, tonumber(bay~=nil and bay.length or gate.washLength) or DEFAULT_WASH_LENGTH)
    local cx, cy, cz = getWashBoxCenter(gate)
    local fx, fz, rx, rz = getGateAxes(gate)
    if bay~=nil then fx,fz,rx,rz=math.sin(bay.yaw),math.cos(bay.yaw),math.cos(bay.yaw),-math.sin(bay.yaw) end
    local hd, hw, hh = length*0.5, width*0.5, height*0.5
    local corners = {}
    for yi, sy in ipairs({-1, 1}) do
        for zi, sz in ipairs({-1, 1}) do
            for xi, sx in ipairs({-1, 1}) do
                table.insert(corners, {
                    cx + fx*(sz*hd) + rx*(sx*hw),
                    cy + sy*hh,
                    cz + fz*(sz*hd) + rz*(sx*hw)
                })
            end
        end
    end
    local edges = {
        {1,2},{1,3},{2,4},{3,4},
        {5,6},{5,7},{6,8},{7,8},
        {1,5},{2,6},{3,7},{4,8}
    }
    for _, e in ipairs(edges) do
        local a, b = corners[e[1]], corners[e[2]]
        drawDebugLine(a[1],a[2],a[3], VISUAL_WASHBOX_R,VISUAL_WASHBOX_G,VISUAL_WASHBOX_B,
            b[1],b[2],b[3], VISUAL_WASHBOX_R,VISUAL_WASHBOX_G,VISUAL_WASHBOX_B, false)
    end
end

local function drawWashPointMarker(gate)
    if drawDebugLine == nil or gate == nil then return end
    local cx, cy, cz = getWashBoxCenter(gate)
    local fx, fz, rx, rz = getGateAxes(gate)
    local r = 0.75
    drawDebugLine(cx-rx*r, cy, cz-rz*r, 1,1,1, cx+rx*r, cy, cz+rz*r, 1,1,1, false)
    drawDebugLine(cx-fx*r, cy, cz-fz*r, 1,1,1, cx+fx*r, cy, cz+fz*r, 1,1,1, false)
    drawDebugLine(cx, cy-0.6, cz, 1,1,1, cx, cy+2.2, cz, 1,1,1, false)
    if project ~= nil and renderText ~= nil then
        local sx, sy, depth = project(cx, cy + 2.35, cz)
        if depth ~= nil and depth > 0 and depth < 1 then
            setTextAlignment(RenderText.ALIGN_CENTER)
            setTextBold(true)
            renderText(sx, sy, 0.011, uiText("ERKANNTER WASCHPUNKT", "DETECTED WASH POINT"))
            renderText(sx, sy - 0.014, 0.009, tostring(gate.displayName or gate.id or "SmartGate"))
            setTextBold(false)
            setTextAlignment(RenderText.ALIGN_LEFT)
        end
    end
end

function SmartGate:drawConfigInversionMarker(gate)
    if not self.configModeEnabled or gate.animationInverted ~= true or type(project) ~= "function" then return end
    if gate.x == nil or gate.z == nil then return end
    local sx, sy, depth = project(gate.x, (gate.y or 0) + 2, gate.z)
    if depth == nil or depth <= 0 or depth >= 1 or sx < 0 or sx > 1 or sy < 0 or sy > 1 then return end
    if self.inversionMarkerOverlay ~= nil and type(renderOverlay) == "function" then
        local w = 0.035
        renderOverlay(self.inversionMarkerOverlay, sx - w/2, sy - 0.004, w, w * (g_screenAspectRatio or 16/9))
    end
end

function SmartGate:drawGateZones(gate)
    if gate == nil then return end
    self:drawConfigInversionMarker(gate)
    local interactionView=gate.objectType==OBJECT_INTERACTION
    if self.configModeEnabled and self.configPanelGate==gate and self.configGeometryProfile~=nil then interactionView=self.configGeometryProfile==OBJECT_INTERACTION end
    if interactionView then
        -- Interaction mode visualizes SmartGate's activation area. A wash point
        -- additionally visualizes its explicit 3D WashBox. The foreign object's
        -- own work/vehicle triggers remain its responsibility.
        drawGateRectangle(interactionProbe(gate), gate.interactionDepth or .75, gate.interactionHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE, VISUAL_TRIGGER_R, VISUAL_TRIGGER_G, VISUAL_TRIGGER_B)
        if gate.washPoint == true then
            drawWashBox(gate)
            if g_smartGate ~= nil and g_smartGate.configModeEnabled == true then
                drawWashPointMarker(gate)
            end
        end
        return
    end
    drawGateRectangle(gate, gate.triggerCloseDistance or AUTO_CLOSE_DISTANCE, gate.triggerCloseHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE, VISUAL_CLOSE_R, VISUAL_CLOSE_G, VISUAL_CLOSE_B)
    drawGateRectangle(gate, gate.triggerOpenDistance or AUTO_OPEN_DISTANCE, gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE, VISUAL_TRIGGER_R, VISUAL_TRIGGER_G, VISUAL_TRIGGER_B)
    drawGateRectangle(gate, gate.safetyDepth or DEFAULT_SAFETY_DEPTH, gate.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH, VISUAL_SAFETY_R, VISUAL_SAFETY_G, VISUAL_SAFETY_B)
end


local CONFIG_PANEL_GATE_ROWS = {
    {de="AD-Voröffnung",en="AD pre-open",field="preOpenMode",choices={0,1,2},kind="preOpenMode"},
    {de="AD-Vorlauf",en="AD lookahead",field="preOpenDistance",choices={10,20,30,40,55,75,100,125,150,175,200,250,300,400,500},kind="preOpenDistance"},
    {de="Open-Länge", en="Open length", field="triggerOpenDistance", choices=PANEL_LENGTH_CHOICES},
    {de="Open-Breite", en="Open width", field="triggerOpenHalfWidth", choices=PANEL_WIDTH_CHOICES},
    {de="Close-Länge", en="Close length", field="triggerCloseDistance", choices=PANEL_LENGTH_CHOICES},
    {de="Close-Breite", en="Close width", field="triggerCloseHalfWidth", choices=PANEL_WIDTH_CHOICES},
    {de="Safety-Länge", en="Safety length", field="safetyDepth", choices=PANEL_LENGTH_CHOICES},
    {de="Safety-Breite", en="Safety width", field="safetyHalfWidth", choices=PANEL_WIDTH_CHOICES},
    {de="Safety-Delay", en="Safety delay", field="safetyClearDelayMs", choices=PANEL_DELAY_CHOICES}
}

local CONFIG_PANEL_INTERACTION_ROWS = {
    {de="Auslösebereich-Länge", en="Activation length", field="interactionDepth", choices=PANEL_LENGTH_CHOICES},
    {de="Auslösebereich-Breite", en="Activation width", field="interactionHalfWidth", choices=PANEL_WIDTH_CHOICES},
    {de="Offset X",en="Offset X",field="interactionOffsetX",choices=PANEL_OFFSET_CHOICES},
    {de="Offset Z",en="Offset Z",field="interactionOffsetZ",choices=PANEL_OFFSET_CHOICES},
    {de="Drehung (Grad)",en="Rotation (degrees)",field="interactionYaw",choices={-180,-165,-150,-135,-120,-105,-90,-75,-60,-45,-30,-15,0,15,30,45,60,75,90,105,120,135,150,165,180},kind="degrees"},
    {de="Auslösekriterium", en="Trigger condition", field="interactionTriggerMode", choices=PANEL_INTERACTION_TRIGGER_CHOICES, kind="triggerMode"},
    {de="Wiederholungen", en="Repeats", field="interactionRepeatCount", choices=PANEL_REPEAT_CHOICES, kind="count"},
    {de="Pause", en="Delay", field="interactionRepeatDelayMs", choices=PANEL_DELAY_CHOICES, kind="delay"}
}

local function getConfigPanelRows(gate,profile)
    local selected=profile
    if selected==nil then selected=gate~=nil and gate.objectType or OBJECT_GATE end
    return selected==OBJECT_INTERACTION and CONFIG_PANEL_INTERACTION_ROWS or CONFIG_PANEL_GATE_ROWS
end

local function pointInUiRect(px, py, x, y, w, h)
    return px >= x and px <= x + w and py >= y and py <= y + h
end

-- Normalized screen coordinates follow the existing overlay renderer. They are
-- independent of framebuffer resolution and are clamped against actual panel
-- extents on every draw/hit-test (including a different row count after edits).
function SmartGate:getConfigOverlayRect(key, w, h, defaultX, defaultY)
    local positions = self.settings ~= nil and self.settings.uiPositions or self.configOverlayPositions
    local pos = positions ~= nil and positions[key] or nil
    local x, y = pos ~= nil and pos.x or defaultX, pos ~= nil and pos.y or defaultY
    w, h = math.min(w, .98), math.min(h, .98)
    return {key=key, x=math.max(.01, math.min(1-w-.01, x)),
        y=math.max(h+.01, math.min(.99, y)), w=w, h=h}
end

function SmartGate:finishConfigOverlayDrag()
    if self.configOverlayDrag == nil then return end
    self.configOverlayDrag = nil
    if self.settings ~= nil and g_dedicatedServer == nil then self.settings:save() end
end

function SmartGate:handleConfigOverlayDrag(rect, headerHeight, px, py, isDown, isUp, button)
    if g_dedicatedServer ~= nil then return false end
    local left = Input == nil or Input.MOUSE_BUTTON_LEFT == nil or button == Input.MOUSE_BUTTON_LEFT
    local drag = self.configOverlayDrag
    if drag ~= nil then
        if drag.key ~= rect.key then return false end
        local x = math.max(.01, math.min(1-rect.w-.01, px-drag.dx))
        local y = math.max(rect.h+.01, math.min(.99, py-drag.dy))
        local positions = self.settings ~= nil and self.settings.uiPositions or self.configOverlayPositions
        if positions == nil then
            positions = {}
            if self.settings ~= nil then self.settings.uiPositions = positions else self.configOverlayPositions = positions end
        end
        positions[rect.key] = {x=x,y=y}
        if isUp and left then self:finishConfigOverlayDrag() end
        return true
    end
    if isDown and left and pointInUiRect(px,py,rect.x,rect.y-headerHeight,rect.w,headerHeight) then
        self.configOverlayDrag = {key=rect.key,dx=px-rect.x,dy=py-rect.y,vehicle=getConfigVehicle()}
        return true
    end
    return false
end

function SmartGate:getGatePanelRect(gate)
    local rows=getConfigPanelRows(gate,self.configGeometryProfile)
    return self:getConfigOverlayRect("panel",CONFIG_PANEL_W,.098+#rows*CONFIG_PANEL_ROW_H+.250+.066,CONFIG_PANEL_X,CONFIG_PANEL_Y)
end
function SmartGate:getInteractionDescription(gate)
    local ao=gate~=nil and gate.animatedObject
    if ao==nil or type(ao.setDirection)~="function" or ao.animation==nil then return uiText("Unbekannt / keine Freigabe","Unknown / not approved") end
    local text=ao.activatable~=nil and ao.activatable.activateText or "AnimatedObject"
    return tostring(text or "AnimatedObject"):gsub("[%c]"," "):sub(1,60)
end

function SmartGate:drawConfigPanel()
    local gate = self.configPanelGate
    if not self.configModeEnabled or gate == nil then return end

    local rect = self:getGatePanelRect(gate)
    local x, y = rect.x, rect.y-.066
    local w = CONFIG_PANEL_W
    local rowH = CONFIG_PANEL_ROW_H
    local rows = getConfigPanelRows(gate,self.configGeometryProfile)
    local interactionProfile=rows==CONFIG_PANEL_INTERACTION_ROWS
    local totalH = 0.098 + (#rows * rowH) + 0.250

    if drawFilledRect ~= nil then
        drawFilledRect(x, y - totalH, w, totalH, 0.03, 0.03, 0.03, 0.82)
        drawFilledRect(x, y - 0.038, w, 0.038, 0.09, 0.09, 0.09, 0.95)
    end

    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(true)
    renderText(x + 0.010, y - 0.026, 0.014, uiText("SmartGate - Objekt konfigurieren", "SmartGate - Configure object"))
    setTextBold(false)
    renderText(x + 0.010, y - 0.050, 0.010, self:getGateName(gate))

    local status = gate.customGeometry and "CUSTOM" or "GLOBAL DEFAULTS"
    renderText(x + w - 0.082, y - 0.050, 0.009, status)

    for i, row in ipairs(rows) do
        local ry = y - 0.075 - (i - 1) * rowH
        local value = gate[row.field]
        local display
        if row.kind=="preOpenMode" then
            display=({[0]=uiText("Global","Global"),[1]="Auto",[2]=uiText("Manuell","Manual")})[gate.preOpenMode or 0]
        elseif row.kind=="preOpenDistance" then
            display=string.format("%.0f m",gatePreOpenDistance(gate))
        elseif row.kind == "triggerMode" then
            display = getInteractionTriggerText(value)
        elseif row.kind == "degrees" then
            display=string.format("%g°",tonumber(value) or 0)
        elseif row.kind == "count" then
            display = tostring(math.floor(tonumber(value) or 1)) .. "x"
        elseif row.kind == "delay" or row.field == "safetyClearDelayMs" then
            value=tonumber(value) or (row.field=="safetyClearDelayMs" and DEFAULT_SAFETY_CLEAR_DELAY_MS or DEFAULT_INTERACTION_REPEAT_DELAY_MS)
            display = value >= 1000 and string.format("%.1f s", value / 1000) or tostring(value) .. " ms"
        else
            display = string.format("%g m", tonumber(value) or 0)
        end

        renderText(x + 0.010, ry, 0.010, uiText(row.de or row.label or "", row.en or row.label or ""))
        local editable=row.kind~="preOpenDistance" or gate.preOpenMode==2
        if editable then renderText(x + 0.150, ry, 0.010, "<") end
        setTextAlignment(RenderText.ALIGN_CENTER)
        renderText(x + 0.184, ry, 0.010, display)
        setTextAlignment(RenderText.ALIGN_LEFT)
        if editable then renderText(x + 0.222, ry, 0.010, ">") end
    end

    local typeY = y - 0.088 - (#rows * rowH)
    if drawFilledRect ~= nil then
        drawFilledRect(x + 0.010, typeY, w - 0.020, 0.028, 0.12, 0.12, 0.12, 0.95)
    end
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(x + w/2, typeY + 0.007, 0.010, gate.objectType == OBJECT_INTERACTION and uiText("Objekttyp: INTERAKTIV", "Object type: INTERACTIVE") or uiText("Objekttyp: TOR", "Object type: GATE"))

    local profileY=typeY-.034
    if drawFilledRect~=nil then drawFilledRect(x+.010,profileY,w-.020,.028,.10,.18,.12,.95) end
    renderText(x+w/2,profileY+.007,.009,uiText("Profil bearbeiten: ","Edit profile: ")..(interactionProfile and "INTERACTIVE" or "TOR / GATE"))
    local axisY=profileY-.034
    if drawFilledRect ~= nil then
        drawFilledRect(x + 0.010, axisY, w - 0.020, 0.028, 0.12, 0.12, 0.12, 0.95)
    end
    renderText(x + w/2, axisY + 0.007, 0.010, interactionProfile and (uiText("Erkannt: ","Detected: ")..self:getInteractionDescription(gate)) or gate.axisSwapped and uiText("Achsen tauschen: 90°", "Swap axes: 90°") or uiText("Achsen tauschen: NORMAL", "Swap axes: NORMAL"))

    local invertY = axisY - 0.034
    local modeY = invertY - 0.034
    local testY = modeY - 0.034
    if drawFilledRect ~= nil then
        drawFilledRect(x + 0.010, invertY, w - 0.020, 0.028, 0.12, 0.12, 0.12, 0.95)
        drawFilledRect(x + 0.010, modeY, w - 0.020, 0.028, 0.12, 0.12, 0.12, 0.95)
        drawFilledRect(x + 0.010, testY, w - 0.020, 0.028, 0.12, 0.12, 0.12, 0.95)
    end
    renderText(x + w/2, invertY + 0.007, 0.009, uiText("Animationsrichtung invertieren: ", "Invert animation direction: ") .. (gate.animationInverted and uiText("EIN", "ON") or uiText("AUS", "OFF")))
    local modeTexts = g_languageShort == "de" and MODE_TEXT_DE or {[0]="DISABLED",[1]="VEHICLES + PLAYERS",[2]="VEHICLES ONLY",[3]="PLAYERS ONLY"}
    renderText(x + w/2, modeY + 0.007, 0.009, uiText("Modus: ", "Mode: ") .. (modeTexts[gate.mode or MODE_ALL] or "?"))
    renderText(x + w*0.26, testY + 0.007, 0.009, uiText("Test: Öffnen", "Test: Open"))
    renderText(x + w*0.74, testY + 0.007, 0.009, uiText("Test: Schließen", "Test: Close"))
    local by = testY - 0.034
    if drawFilledRect ~= nil then
        drawFilledRect(x + 0.010, by, w - 0.020, 0.028, 0.15, 0.15, 0.15, 0.95)
    end
    renderText(x + w/2, by + 0.007, 0.010, interactionProfile and uiText("Interaktionsprofil zurücksetzen","Reset interaction profile") or uiText("Torprofil: globale Defaults","Gate profile: global defaults"))
    setTextAlignment(RenderText.ALIGN_LEFT)
    renderText(x + 0.010, by - 0.016, 0.009, self:getConfigCursorHelp())
end

function SmartGate:mouseEvent(posX,posY,isDown,isUp,button)
    -- A GIANTS listener may retain this original callback. Resolve the editor
    -- implementation at dispatch time, rather than replacing the callback later.
    if self.handleConfigEditorMouseEvent~=nil then return self:handleConfigEditorMouseEvent(posX,posY,isDown,isUp,button) end
    return self:handleGateConfigMouseEvent(posX,posY,isDown,isUp,button)
end
function SmartGate:handleGateConfigMouseEvent(posX, posY, isDown, isUp, button)
    if not self.configModeEnabled or self.configPanelGate == nil or configGuiVisible() then return end
    if g_inputBinding == nil or type(g_inputBinding.getShowMouseCursor) ~= "function" or not g_inputBinding:getShowMouseCursor() then return end
    local gate = self.configPanelGate
    local rect = self:getGatePanelRect(gate)
    if self:handleConfigOverlayDrag(rect,.038,posX,posY,isDown,isUp,button) then return end
    if not isDown then return end
    if Input ~= nil and Input.MOUSE_BUTTON_LEFT ~= nil and button ~= nil and button ~= Input.MOUSE_BUTTON_LEFT then return end
    local x, y = rect.x, rect.y-.066
    local rowH = CONFIG_PANEL_ROW_H
    local rows = getConfigPanelRows(gate,self.configGeometryProfile)

    for i, row in ipairs(rows) do
        local ry = y - 0.075 - (i - 1) * rowH - 0.004
        if pointInUiRect(posX, posY, x + 0.137, ry, 0.030, 0.024) then
            self:stepGateSetting(gate, row.field, row.choices, -1)
            return
        elseif pointInUiRect(posX, posY, x + 0.207, ry, 0.030, 0.024) then
            self:stepGateSetting(gate, row.field, row.choices, 1)
            return
        end
    end

    local typeY = y - 0.088 - (#rows * rowH)
    if pointInUiRect(posX, posY, x + 0.010, typeY, CONFIG_PANEL_W - 0.020, 0.028) then
        self:requestGateObjectType(gate, gate.objectType ~= OBJECT_INTERACTION)
        return
    end

    local profileY=typeY-.034
    if pointInUiRect(posX,posY,x+.010,profileY,CONFIG_PANEL_W-.020,.028) then
        local current=self.configGeometryProfile
        if current==nil then current=gate.objectType end
        self.configGeometryProfile=current==OBJECT_INTERACTION and OBJECT_GATE or OBJECT_INTERACTION
        return
    end
    local axisY=profileY-.034
    if rows~=CONFIG_PANEL_INTERACTION_ROWS and pointInUiRect(posX,posY,x+.010,axisY,CONFIG_PANEL_W-.020,.028) then
        gate.axisSwapped=not gate.axisSwapped
        gate.customGeometry=true; self.savedCustomGeometry[gate.id]=true
        self:requestGateGeometry(gate,false); return
    end
    local invertY = axisY - 0.034
    if pointInUiRect(posX, posY, x + 0.010, invertY, CONFIG_PANEL_W - 0.020, 0.028) then
        self:applyLocalGateGeometry(gate, "animationInverted", gate.animationInverted ~= true)
        self:requestGateGeometry(gate, false)
        return
    end
    local modeY = invertY - 0.034
    if pointInUiRect(posX, posY, x + 0.010, modeY, CONFIG_PANEL_W - 0.020, 0.028) then
        SmartGateConfigEvent.send(gate)
        return
    end
    local testY = modeY - 0.034
    if pointInUiRect(posX, posY, x + 0.010, testY, CONFIG_PANEL_W - 0.020, 0.028) then
        SmartGateAnimationTestEvent.send(gate, posX < x + CONFIG_PANEL_W/2)
        return
    end
    local by = testY - 0.034
    if pointInUiRect(posX, posY, x + 0.010, by, CONFIG_PANEL_W - 0.020, 0.028) then
        if rows==CONFIG_PANEL_INTERACTION_ROWS then
            gate.interactionDepth=.75; gate.interactionHalfWidth=DEFAULT_TRIGGER_SIDE_DISTANCE
            gate.interactionOffsetX,gate.interactionOffsetZ,gate.interactionYaw=0,0,0
            gate.interactionTriggerMode=INTERACTION_TRIGGER_ENTER
            gate.interactionRepeatCount,gate.interactionRepeatDelayMs=1,DEFAULT_INTERACTION_REPEAT_DELAY_MS
            self:requestGateGeometry(gate,false)
        else
            self:requestGateGeometry(gate, true)
            showNotification(uiText("SmartGate: Objekt nutzt wieder globale Defaults", "SmartGate: Object uses global defaults again"), 3000, FSBaseMission.INGAME_NOTIFICATION_OK)
        end
    end
end

function SmartGate:draw()
    if configGuiVisible() then return end
    -- Keep a subtle persistent reminder on screen while SmartGate configuration
    -- mode is active. This also explains why the selected gate visualization
    -- cannot be hidden until config mode is left.
    if self.configModeEnabled then
        setTextAlignment(RenderText.ALIGN_CENTER)
        setTextBold(true)
        renderText(0.5, 0.025, 0.012, uiText("SmartGate Config-Modus aktiv", "SmartGate config mode active") .. " | " .. self:getConfigCursorHelp())
        setTextBold(false)
        setTextAlignment(RenderText.ALIGN_LEFT)
    end

    local showZones = self.configModeEnabled or self.showZonesAlways
    local visualGate = nil
    if showZones then
        visualGate = self.markerGate
        if visualGate == nil or (self.markerUntil > 0 and nowMs() > self.markerUntil) then
            visualGate = self:findConfigGate(getLocalVehicle())
        end
        if visualGate ~= nil then self:drawGateZones(visualGate) end
    end

    if self.configModeEnabled then
        self:drawConfigPanel()
    end

    if not self.configModeEnabled then return end
    if self.markerGate == nil or nowMs() > self.markerUntil then return end
    local gate = self.markerGate
    local mx, my, mz = self:getMarkerWorldPosition(gate)
    local sx, sy, depth = project(mx, my + 2.5, mz)
    if depth == nil or depth <= 0 or depth >= 1 then return end
    local w, h = 0.035, 0.035 * g_screenAspectRatio
    if self.markerOverlay ~= nil then renderOverlay(self.markerOverlay, sx - w/2, sy, w, h) end
    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextBold(true)
    local stateText = self.markerBlacklisted and BLACKLIST_TEXT or (MODE_TEXT_DE[self.markerMode] or "SMARTGATE")
    renderText(sx, sy - 0.018, 0.013, stateText)
    renderText(sx, sy - 0.034, 0.010, self:getGateName(gate))
    setTextBold(false)
    setTextAlignment(RenderText.ALIGN_LEFT)
end

function SmartGate:restorePersistedConfig()
    if g_server == nil then return false end

    local loaded = self:loadConfig()
    if not loaded then
        return false
    end

    self.persistenceRestorePass = true
    self:rescan()
    self.persistenceRestorePass = false

    return true
end

function SmartGate:loadMap()
    self.newGatesEnabled=true
    self.serviceAdFunctionEnv=nil
    if type(addConsoleCommand)=="function" and type(self.consoleServiceADDebug)=="function" then
        addConsoleCommand("sgServiceADDebug","Service AD diagnostics: on|off (manual refresh only)","consoleServiceADDebug",self)
    end
    if g_server ~= nil and addConsoleCommand ~= nil then
        addConsoleCommand("sgPerformance", "SmartGate scan test / Scan-Test: spatial|baseline|on|off", "consolePerformance", self)
    end
    print("[SmartGate] Agriculture Science SmartGate v0.1.3.8 Interactive + WashBox RC loaded")
    if g_currentMission ~= nil then
        g_currentMission.agricultureScienceSmartGateAPI = SmartGateAPI
        print("[SmartGate][API] shared API registered on mission")
    end
    self:installPersistenceHook()
    local restored = false
    if g_server ~= nil then
        restored = self:restorePersistedConfig()
    end
    if not restored then
        self:rescan()
    end
    self.configModeEnabled = false
    self:releaseConfigInputReservation()
    self:setConfigCursorEnabled(false)
    self.configPanelGate = nil
    self.configProfileGateId,self.configGeometryProfile=nil,nil
    self.serviceAdXmlCache=nil
    self.hornHookInstalled = false
    if createImageOverlay ~= nil then
        self.markerOverlay = createImageOverlay(MOD_DIR .. "config_marker.dds")
        if g_dedicatedServer == nil then self.inversionMarkerOverlay = createImageOverlay(MOD_DIR .. "inversion_marker.dds") end
    end
    if not self:installHornHook() then
        print("[SmartGate][CONFIG] horn hook not available yet; update loop will retry")
    end
end

function SmartGate:onStartMission()
    if g_server == nil then return end
    self:installPersistenceHook()
    print("[SmartGate][PERSIST] mission started; reloading authoritative savegame config")
    local restored = self:restorePersistedConfig()
    if not restored then
        print("[SmartGate][PERSIST][WARN] authoritative restore skipped: no readable savegame config")
        self:rescan()
    end
    SmartGateStateSyncEvent.sendToClients(self.gates)
end

function SmartGate:deleteMap()
    if type(removeConsoleCommand)=="function" then removeConsoleCommand("sgServiceADDebug") end
    if removeConsoleCommand ~= nil then removeConsoleCommand("sgPerformance") end
    self.spatialAwake = nil
    self.spatialSafetyAwake = nil
    self.lastScanMetrics = nil
    self.performanceWindow = nil
    scanContext = nil
    if g_server ~= nil then
        self:saveConfig()
    end
    self:removePersistenceHook()
    self.configModeEnabled = false
    self:setConfigCursorEnabled(false)
    self:updateConfigCursorInput()
    for id in pairs(self.configCursorEvents or {}) do
        if g_inputBinding ~= nil and type(g_inputBinding.removeActionEvent) == "function" then pcall(g_inputBinding.removeActionEvent, g_inputBinding, id) end
    end
    self.configCursorEvents, self.configInputGeneration, self.configPendingADRestores, self.configInputEventObjects = nil, nil, nil, nil
    self.configFootLookHeld, self.configFootLookPending = nil, nil
    self.configPanelGate = nil
    if g_currentMission ~= nil and g_currentMission.agricultureScienceSmartGateAPI == SmartGateAPI then
        g_currentMission.agricultureScienceSmartGateAPI = nil
        print("[SmartGate][API] shared API unregistered from mission")
    end
    if self.markerOverlay ~= nil then delete(self.markerOverlay); self.markerOverlay = nil end
    if self.inversionMarkerOverlay ~= nil then delete(self.inversionMarkerOverlay); self.inversionMarkerOverlay = nil end
end

-- Dedicated-server-safe AutoDrive pre-open notification. The server broadcasts
-- the causing vehicle; each client only displays the message when that vehicle
-- is the one locally controlled by the player.
SmartGatePreOpenNotifyEvent = {}
local SmartGatePreOpenNotifyEvent_mt = Class(SmartGatePreOpenNotifyEvent, Event)
InitEventClass(SmartGatePreOpenNotifyEvent, "SmartGatePreOpenNotifyEvent")
function SmartGatePreOpenNotifyEvent.emptyNew() return Event.new(SmartGatePreOpenNotifyEvent_mt) end
function SmartGatePreOpenNotifyEvent.new(vehicle, gateName, distance)
    local self = SmartGatePreOpenNotifyEvent.emptyNew()
    self.vehicle = getRootVehicle(vehicle) or vehicle
    self.gateName = tostring(gateName or "Tor")
    self.distance = tonumber(distance) or -1
    return self
end
function SmartGatePreOpenNotifyEvent:writeStream(streamId, connection)
    NetworkUtil.writeNodeObject(streamId, self.vehicle)
    streamWriteString(streamId, self.gateName or "Tor")
    streamWriteFloat32(streamId, self.distance or -1)
end
function SmartGatePreOpenNotifyEvent:readStream(streamId, connection)
    self.vehicle = NetworkUtil.readNodeObject(streamId)
    self.gateName = streamReadString(streamId)
    self.distance = streamReadFloat32(streamId)
    self:run(connection)
end
function SmartGatePreOpenNotifyEvent:run(connection)
    if g_client == nil then return end
    local localRoot = getRootVehicle(getLocalVehicle())
    local eventRoot = getRootVehicle(self.vehicle)
    if localRoot ~= nil and eventRoot ~= nil and localRoot == eventRoot then
        local distanceText = self.distance ~= nil and self.distance >= 0 and string.format(" (%.0f m)", self.distance) or ""
        showNotification("SmartGate: Tor voraus vorgeöffnet" .. distanceText, 3000, FSBaseMission.INGAME_NOTIFICATION_OK)
    end
end
function SmartGatePreOpenNotifyEvent.send(vehicle, gateName, distance)
    if vehicle == nil then return end
    local event = SmartGatePreOpenNotifyEvent.new(vehicle, gateName, distance)
    if g_server ~= nil then
        g_server:broadcastEvent(event, false)
        -- Listen server / singleplayer does not receive its own broadcast.
        if g_client ~= nil then event:run(nil) end
    end
end

-- Config request: client -> server. The descriptor fallback is important for
-- modded placeables whose runtime AnimatedObject/node identity can differ between
-- dedicated server and client even though they represent the same visible gate.
SmartGateConfigEvent = {}
local SmartGateConfigEvent_mt = Class(SmartGateConfigEvent, Event)
InitEventClass(SmartGateConfigEvent, "SmartGateConfigEvent")
function SmartGateConfigEvent.emptyNew() return Event.new(SmartGateConfigEvent_mt) end
function SmartGateConfigEvent.new(id, ownerKey, nodeKey, x, z)
    local self=SmartGateConfigEvent.emptyNew(); self.id=id; self.ownerKey=ownerKey; self.nodeKey=nodeKey; self.x=x; self.z=z; return self
end
function SmartGateConfigEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or ""); streamWriteString(streamId, self.ownerKey or ""); streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0); streamWriteFloat32(streamId, self.z or 0)
end
function SmartGateConfigEvent:readStream(streamId, connection)
    self.id=streamReadString(streamId); self.ownerKey=streamReadString(streamId); self.nodeKey=streamReadString(streamId)
    self.x=streamReadFloat32(streamId); self.z=streamReadFloat32(streamId); self:run(connection)
end
function SmartGateConfigEvent:run(connection)
    if connection ~= nil and not connection:getIsServer() and g_smartGate ~= nil then
        g_smartGate:cycleGate(self.id, self.ownerKey, self.nodeKey, self.x, self.z)
    end
end
function SmartGateConfigEvent.send(gate)
    if gate == nil then return end
    local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
    if g_server ~= nil then g_smartGate:cycleGate(id, ownerKey, nodeKey, x, z)
    elseif g_client ~= nil then g_client:getServerConnection():sendEvent(SmartGateConfigEvent.new(id, ownerKey, nodeKey, x, z)) end
end

-- Mode update: server -> all clients. Clients resolve by exact id first and then
-- by the stable descriptor so mod-placeable runtime ids no longer have to match.
SmartGateModeEvent = {}
local SmartGateModeEvent_mt = Class(SmartGateModeEvent, Event)
InitEventClass(SmartGateModeEvent, "SmartGateModeEvent")
function SmartGateModeEvent.emptyNew() return Event.new(SmartGateModeEvent_mt) end
function SmartGateModeEvent.new(id, ownerKey, nodeKey, x, z, mode)
    local self=SmartGateModeEvent.emptyNew(); self.id=id; self.ownerKey=ownerKey; self.nodeKey=nodeKey; self.x=x; self.z=z; self.mode=mode; return self
end
function SmartGateModeEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or ""); streamWriteString(streamId, self.ownerKey or ""); streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0); streamWriteFloat32(streamId, self.z or 0); streamWriteUIntN(streamId, self.mode or 0, 2)
end
function SmartGateModeEvent:readStream(streamId, connection)
    self.id=streamReadString(streamId); self.ownerKey=streamReadString(streamId); self.nodeKey=streamReadString(streamId)
    self.x=streamReadFloat32(streamId); self.z=streamReadFloat32(streamId); self.mode=streamReadUIntN(streamId,2); self:run(connection)
end
function SmartGateModeEvent:run(connection)
    if connection ~= nil and connection:getIsServer() and g_smartGate ~= nil then
        local gate = g_smartGate:resolveGate(self.id, self.ownerKey, self.nodeKey, self.x, self.z)
        if gate ~= nil then gate.mode=self.mode; g_smartGate.savedModes[gate.id]=self.mode; g_smartGate:notifyMode(gate,self.mode) end
    end
end
function SmartGateModeEvent.sendToClients(gate, mode)
    if g_server ~= nil and gate ~= nil then
        local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
        g_server:broadcastEvent(SmartGateModeEvent.new(id, ownerKey, nodeKey, x, z, mode), false)
        if g_smartGate ~= nil then g_smartGate:notifyMode(gate, mode) end
    end
end

-- Blacklist request: client -> server.
SmartGateBlacklistRequestEvent = {}
local SmartGateBlacklistRequestEvent_mt = Class(SmartGateBlacklistRequestEvent, Event)
InitEventClass(SmartGateBlacklistRequestEvent, "SmartGateBlacklistRequestEvent")
function SmartGateBlacklistRequestEvent.emptyNew() return Event.new(SmartGateBlacklistRequestEvent_mt) end
function SmartGateBlacklistRequestEvent.new(id, ownerKey, nodeKey, x, z)
    local self=SmartGateBlacklistRequestEvent.emptyNew(); self.id=id; self.ownerKey=ownerKey; self.nodeKey=nodeKey; self.x=x; self.z=z; return self
end
function SmartGateBlacklistRequestEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or ""); streamWriteString(streamId, self.ownerKey or ""); streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0); streamWriteFloat32(streamId, self.z or 0)
end
function SmartGateBlacklistRequestEvent:readStream(streamId, connection)
    self.id=streamReadString(streamId); self.ownerKey=streamReadString(streamId); self.nodeKey=streamReadString(streamId)
    self.x=streamReadFloat32(streamId); self.z=streamReadFloat32(streamId); self:run(connection)
end
function SmartGateBlacklistRequestEvent:run(connection)
    if connection ~= nil and not connection:getIsServer() and g_smartGate ~= nil then
        g_smartGate:toggleBlacklist(self.id, self.ownerKey, self.nodeKey, self.x, self.z)
    end
end
function SmartGateBlacklistRequestEvent.send(gate)
    if gate == nil then return end
    local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
    if g_server ~= nil then g_smartGate:toggleBlacklist(id, ownerKey, nodeKey, x, z)
    elseif g_client ~= nil then g_client:getServerConnection():sendEvent(SmartGateBlacklistRequestEvent.new(id, ownerKey, nodeKey, x, z)) end
end

-- Blacklist update: server -> all clients.
SmartGateBlacklistEvent = {}
local SmartGateBlacklistEvent_mt = Class(SmartGateBlacklistEvent, Event)
InitEventClass(SmartGateBlacklistEvent, "SmartGateBlacklistEvent")
function SmartGateBlacklistEvent.emptyNew() return Event.new(SmartGateBlacklistEvent_mt) end
function SmartGateBlacklistEvent.new(id, ownerKey, nodeKey, x, z, blacklisted)
    local self=SmartGateBlacklistEvent.emptyNew(); self.id=id; self.ownerKey=ownerKey; self.nodeKey=nodeKey; self.x=x; self.z=z; self.blacklisted=blacklisted == true; return self
end
function SmartGateBlacklistEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or ""); streamWriteString(streamId, self.ownerKey or ""); streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0); streamWriteFloat32(streamId, self.z or 0); streamWriteBool(streamId, self.blacklisted)
end
function SmartGateBlacklistEvent:readStream(streamId, connection)
    self.id=streamReadString(streamId); self.ownerKey=streamReadString(streamId); self.nodeKey=streamReadString(streamId)
    self.x=streamReadFloat32(streamId); self.z=streamReadFloat32(streamId); self.blacklisted=streamReadBool(streamId); self:run(connection)
end
function SmartGateBlacklistEvent:run(connection)
    if connection ~= nil and connection:getIsServer() and g_smartGate ~= nil then
        local gate = g_smartGate:resolveGate(self.id, self.ownerKey, self.nodeKey, self.x, self.z)
        if gate ~= nil then
            gate.blacklisted = self.blacklisted
            if self.blacklisted then g_smartGate.savedBlacklist[gate.id]=true else g_smartGate.savedBlacklist[gate.id]=nil end
            g_smartGate:notifyBlacklist(gate, self.blacklisted)
        end
    end
end
function SmartGateBlacklistEvent.sendToClients(gate, blacklisted)
    if g_server ~= nil and gate ~= nil then
        local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
        g_server:broadcastEvent(SmartGateBlacklistEvent.new(id, ownerKey, nodeKey, x, z, blacklisted), false)
        if g_smartGate ~= nil then g_smartGate:notifyBlacklist(gate, blacklisted) end
    end
end

-- Periodic full-state sync. This deliberately avoids depending on a specific
-- join callback: a late-joining MP client receives modes and blacklist state
-- within STATE_SYNC_INTERVAL_MS even if it missed earlier per-gate events.

function SmartGate:applyGateGeometryOnServer(id, ownerKey, nodeKey, x, z, resetToDefaults, values, connection)
    if g_server == nil then return end
    local gate = self:resolveGate(id, ownerKey, nodeKey, x, z)
    if gate == nil then return end
    if connection~=nil and not self:canTestGate(gate,connection) then return end
    local service=self.serviceInfrastructure
    local deferred=service~=nil and service.loaded and type(service.captureGateGeometry)=="function"
        and type(service.deferGateGeometry)=="function" and (connection~=nil or self.configModeEnabled)
    local before=deferred and service:captureGateGeometry(gate)
    local function persist()
        if deferred then service:deferGateGeometry(gate,connection,before) else self:saveConfig() end
    end

    if not resetToDefaults then
        local limits={interactionDepth={.1,100},interactionHalfWidth={.1,100},interactionOffsetX={-100,100},interactionOffsetZ={-100,100},interactionYaw={-360,360},preOpenMode={0,2},preOpenDistance={10,500}}
        for field,limit in pairs(limits) do
            local value=values[field]
            if value~=nil and (type(value)~="number" or value~=value or value<limit[1] or value>limit[2]) then return end
        end
        if values.preOpenMode~=nil and values.preOpenMode~=math.floor(values.preOpenMode) then return end
    end
    if not resetToDefaults and values.preOpenOnly==true then
        gate.preOpenMode=tonumber(values.preOpenMode) or gate.preOpenMode or 0
        gate.preOpenDistance=preOpenManualDistance(values.preOpenDistance or gate.preOpenDistance)
        local cfg=self.savedGateSettings[gate.id] or {}
        cfg.preOpenMode=gate.preOpenMode;cfg.preOpenDistance=gate.preOpenDistance;self.savedGateSettings[gate.id]=cfg
        persist();SmartGateStateSyncEvent.sendToClients(self.gates)
        return
    end
    local nextType = not resetToDefaults and tonumber(values.objectType) == OBJECT_INTERACTION and OBJECT_INTERACTION or OBJECT_GATE
    if gate.objectType ~= nextType then
        if self.configPanelGate==gate then self.configGeometryProfile=nextType end
        gate.interactionClearSince=nil
        gate.interactionLatched,gate.interactionWasOccupied=false,false
        gate.interactionRepeatRemaining,gate.interactionNextTriggerTime=0,nil
        gate.configTestOpen=nil
    end
    gate.gateOpenDistance,gate.gateOpenHalfWidth=nil,nil

    if resetToDefaults then
        local defaults = self.settings ~= nil and self.settings.values or nil
        gate.customGeometry = false
        local defaultWidth = tonumber(defaults and defaults.triggerSideDistance) or DEFAULT_TRIGGER_SIDE_DISTANCE
        gate.triggerOpenDistance = tonumber(defaults and defaults.triggerOpenDistance) or AUTO_OPEN_DISTANCE
        gate.triggerOpenHalfWidth = defaultWidth
        gate.triggerCloseDistance = tonumber(defaults and defaults.triggerCloseDistance) or AUTO_CLOSE_DISTANCE
        gate.triggerCloseHalfWidth = defaultWidth
        gate.triggerSideDistance = defaultWidth
        gate.safetyDepth = tonumber(defaults and defaults.safetyDepth) or DEFAULT_SAFETY_DEPTH
        gate.safetyHalfWidth = tonumber(defaults and defaults.safetyHalfWidth) or DEFAULT_SAFETY_HALF_WIDTH
        gate.configDepth = CONFIG_ZONE_LENGTH
        gate.configHalfWidth = CONFIG_ZONE_HALF_WIDTH
        gate.axisSwapped = false
        gate.preOpenMode=0;gate.preOpenDistance=AD_PREOPEN_DISTANCE
        gate.safetyClearDelayMs = tonumber(defaults and defaults.safetyClearDelayMs) or DEFAULT_SAFETY_CLEAR_DELAY_MS
        self.savedCustomGeometry[gate.id] = nil
        print("[SmartGate][CONFIG] gate reset to global defaults: " .. tostring(gate.id))
    else
        gate.customGeometry = true
        gate.interactionDepth = tonumber(values.interactionDepth) or gate.interactionDepth or .75
        gate.interactionHalfWidth = tonumber(values.interactionHalfWidth) or gate.interactionHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE
        gate.interactionOffsetX = tonumber(values.interactionOffsetX) or gate.interactionOffsetX or 0
        gate.interactionOffsetZ = tonumber(values.interactionOffsetZ) or gate.interactionOffsetZ or 0
        gate.interactionYaw = tonumber(values.interactionYaw) or gate.interactionYaw or 0
        gate.triggerOpenDistance = tonumber(values.triggerOpenDistance) or gate.triggerOpenDistance
        gate.triggerOpenHalfWidth = tonumber(values.triggerOpenHalfWidth) or gate.triggerOpenHalfWidth or gate.triggerSideDistance
        gate.triggerCloseDistance = tonumber(values.triggerCloseDistance) or gate.triggerCloseDistance
        gate.triggerCloseHalfWidth = tonumber(values.triggerCloseHalfWidth) or gate.triggerCloseHalfWidth or gate.triggerSideDistance
        gate.triggerSideDistance = gate.triggerOpenHalfWidth or gate.triggerSideDistance
        gate.safetyDepth = tonumber(values.safetyDepth) or gate.safetyDepth
        gate.safetyHalfWidth = tonumber(values.safetyHalfWidth) or gate.safetyHalfWidth
        gate.configDepth = tonumber(values.configDepth) or gate.configDepth or CONFIG_ZONE_LENGTH
        gate.configHalfWidth = tonumber(values.configHalfWidth) or gate.configHalfWidth or CONFIG_ZONE_HALF_WIDTH
        gate.axisSwapped = values.axisSwapped == true
        gate.animationInverted = values.animationInverted == true
        gate.preOpenMode=tonumber(values.preOpenMode) or gate.preOpenMode or 0
        gate.preOpenDistance=preOpenManualDistance(values.preOpenDistance or gate.preOpenDistance)
        gate.objectType = tonumber(values.objectType) == OBJECT_INTERACTION and OBJECT_INTERACTION or OBJECT_GATE
        gate.washPoint = gate.objectType == OBJECT_INTERACTION and values.washPoint == true
        gate.interactionLatched = false
        gate.interactionWasOccupied = false
        gate.interactionRepeatRemaining = 0
        gate.interactionNextTriggerTime = nil
        gate.safetyClearDelayMs = tonumber(values.safetyClearDelayMs) or gate.safetyClearDelayMs
        gate.interactionTriggerMode = math.max(INTERACTION_TRIGGER_ENTER, math.min(INTERACTION_TRIGGER_OCCUPIED, tonumber(values.interactionTriggerMode) or gate.interactionTriggerMode or INTERACTION_TRIGGER_ENTER))
        gate.interactionRepeatCount = math.max(1, tonumber(values.interactionRepeatCount) or gate.interactionRepeatCount or DEFAULT_INTERACTION_REPEAT_COUNT)
        gate.interactionRepeatDelayMs = math.max(250, tonumber(values.interactionRepeatDelayMs) or gate.interactionRepeatDelayMs or DEFAULT_INTERACTION_REPEAT_DELAY_MS)
        gate.washWidth = tonumber(values.washWidth) or gate.washWidth or DEFAULT_WASH_WIDTH
        gate.washHeight = tonumber(values.washHeight) or gate.washHeight or DEFAULT_WASH_HEIGHT
        gate.washLength = tonumber(values.washLength) or gate.washLength or DEFAULT_WASH_LENGTH
        gate.washOffsetX = tonumber(values.washOffsetX) or gate.washOffsetX or 0
        gate.washOffsetY = tonumber(values.washOffsetY) or gate.washOffsetY or 0
        gate.washOffsetZ = tonumber(values.washOffsetZ) or gate.washOffsetZ or 0
        gate.washGeometryManual = values.washGeometryManual == true
        gate.washGeometrySource = tonumber(values.washGeometrySource) or gate.washGeometrySource or WASH_SOURCE_TRIGGER
        self.savedCustomGeometry[gate.id] = true
        print("[SmartGate][CONFIG] custom geometry applied: " .. tostring(gate.id))
    end

    self.savedGateSettings[gate.id] = {
        gateOpenDistance=gate.gateOpenDistance, gateOpenHalfWidth=gate.gateOpenHalfWidth,
        interactionDepth=gate.interactionDepth,
        interactionHalfWidth=gate.interactionHalfWidth,
        interactionOffsetX=gate.interactionOffsetX,
        interactionOffsetZ=gate.interactionOffsetZ,
        interactionYaw=gate.interactionYaw,
        triggerOpenDistance=gate.triggerOpenDistance,
        triggerOpenHalfWidth=gate.triggerOpenHalfWidth,
        triggerCloseDistance=gate.triggerCloseDistance,
        triggerCloseHalfWidth=gate.triggerCloseHalfWidth,
        triggerSideDistance=gate.triggerSideDistance,
        safetyDepth=gate.safetyDepth,
        safetyHalfWidth=gate.safetyHalfWidth,
        configDepth=gate.configDepth,
        configHalfWidth=gate.configHalfWidth,
        axisSwapped=gate.axisSwapped == true, animationInverted=gate.animationInverted == true,
        preOpenMode=gate.preOpenMode or 0,preOpenDistance=preOpenManualDistance(gate.preOpenDistance),
        objectType=gate.objectType or OBJECT_GATE,
        washPoint=gate.washPoint == true,
        safetyClearDelayMs=gate.safetyClearDelayMs,
        interactionTriggerMode=gate.interactionTriggerMode,
        interactionRepeatCount=gate.interactionRepeatCount,
        interactionRepeatDelayMs=gate.interactionRepeatDelayMs,
        washWidth=gate.washWidth, washHeight=gate.washHeight, washLength=gate.washLength,
        washOffsetX=gate.washOffsetX, washOffsetY=gate.washOffsetY, washOffsetZ=gate.washOffsetZ,
        washGeometryManual=gate.washGeometryManual == true, washGeometrySource=gate.washGeometrySource
    }

    local record = self:findSavedGateRecord(gate,true)
    if record == nil then
        record = {}
        table.insert(self.savedGateRecords, record)
        self.savedGateIdentitySource=nil
    end
    record.id = gate.id
    record.ownerKey = gate.ownerKey or ""
    record.nodeKey = gate.nodeKey or ""
    record.x = gate.x
    record.z = gate.z
    record.mode = gate.mode
    record.blacklisted = gate.blacklisted == true
    record.customGeometry = gate.customGeometry == true
    record.settings = self.savedGateSettings[gate.id]

    self.geometryRevision=(self.geometryRevision or 0)+1
    persist()
    SmartGateStateSyncEvent.sendToClients(self.gates)
end

SmartGateGateSettingsEvent = {}
local SmartGateGateSettingsEvent_mt = Class(SmartGateGateSettingsEvent, Event)
InitEventClass(SmartGateGateSettingsEvent, "SmartGateGateSettingsEvent")
function SmartGateGateSettingsEvent.emptyNew() return Event.new(SmartGateGateSettingsEvent_mt) end
function SmartGateGateSettingsEvent.new(gate, resetToDefaults)
    local self = SmartGateGateSettingsEvent.emptyNew()
    self.id, self.ownerKey, self.nodeKey, self.x, self.z = g_smartGate:getGateDescriptor(gate)
    self.resetToDefaults = resetToDefaults == true
    self.values = {
        interactionDepth=gate.interactionDepth,
        interactionHalfWidth=gate.interactionHalfWidth,
        interactionOffsetX=gate.interactionOffsetX,
        interactionOffsetZ=gate.interactionOffsetZ,
        interactionYaw=gate.interactionYaw,
        triggerOpenDistance=gate.triggerOpenDistance,
        triggerOpenHalfWidth=gate.triggerOpenHalfWidth,
        triggerCloseDistance=gate.triggerCloseDistance,
        triggerCloseHalfWidth=gate.triggerCloseHalfWidth,
        triggerSideDistance=gate.triggerSideDistance,
        safetyDepth=gate.safetyDepth,
        safetyHalfWidth=gate.safetyHalfWidth,
        configDepth=gate.configDepth,
        configHalfWidth=gate.configHalfWidth,
        axisSwapped=gate.axisSwapped == true, animationInverted=gate.animationInverted == true,
        preOpenMode=gate.preOpenMode or 0,preOpenDistance=preOpenManualDistance(gate.preOpenDistance),
        objectType=gate.objectType or OBJECT_GATE,
        washPoint=gate.washPoint == true,
        safetyClearDelayMs=gate.safetyClearDelayMs,
        interactionTriggerMode=gate.interactionTriggerMode,
        interactionRepeatCount=gate.interactionRepeatCount,
        interactionRepeatDelayMs=gate.interactionRepeatDelayMs,
        washWidth=gate.washWidth, washHeight=gate.washHeight, washLength=gate.washLength,
        washOffsetX=gate.washOffsetX, washOffsetY=gate.washOffsetY, washOffsetZ=gate.washOffsetZ,
        washGeometryManual=gate.washGeometryManual == true, washGeometrySource=gate.washGeometrySource
    }
    return self
end
function SmartGateGateSettingsEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.id or "")
    streamWriteString(streamId, self.ownerKey or "")
    streamWriteString(streamId, self.nodeKey or "")
    streamWriteFloat32(streamId, self.x or 0)
    streamWriteFloat32(streamId, self.z or 0)
    streamWriteBool(streamId, self.resetToDefaults == true)
    streamWriteFloat32(streamId, self.values.triggerOpenDistance or AUTO_OPEN_DISTANCE)
    streamWriteFloat32(streamId, self.values.triggerOpenHalfWidth or self.values.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
    streamWriteFloat32(streamId, self.values.triggerCloseDistance or AUTO_CLOSE_DISTANCE)
    streamWriteFloat32(streamId, self.values.triggerCloseHalfWidth or self.values.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE)
    streamWriteFloat32(streamId, self.values.safetyDepth or DEFAULT_SAFETY_DEPTH)
    streamWriteFloat32(streamId, self.values.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH)
    streamWriteFloat32(streamId, self.values.interactionDepth or .75)
    streamWriteFloat32(streamId, self.values.interactionHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE)
    streamWriteFloat32(streamId, self.values.interactionOffsetX or 0)
    streamWriteFloat32(streamId, self.values.interactionOffsetZ or 0)
    streamWriteFloat32(streamId, self.values.interactionYaw or 0)
    streamWriteFloat32(streamId, self.values.configDepth or CONFIG_ZONE_LENGTH)
    streamWriteFloat32(streamId, self.values.configHalfWidth or CONFIG_ZONE_HALF_WIDTH)
    streamWriteBool(streamId, self.values.axisSwapped == true)
    streamWriteBool(streamId, self.values.animationInverted == true)
    streamWriteUIntN(streamId,self.values.preOpenMode or 0,2)
    streamWriteFloat32(streamId,preOpenManualDistance(self.values.preOpenDistance))
    streamWriteBool(streamId,self.values.preOpenOnly==true)
    streamWriteUIntN(streamId, self.values.objectType or OBJECT_GATE, 1)
    streamWriteBool(streamId, self.values.washPoint == true)
    streamWriteUInt16(streamId, self.values.safetyClearDelayMs or DEFAULT_SAFETY_CLEAR_DELAY_MS)
    streamWriteUIntN(streamId, math.max(1, math.min(4, self.values.interactionTriggerMode or INTERACTION_TRIGGER_ENTER)) - 1, 2)
    streamWriteUIntN(streamId, math.max(1, math.min(255, self.values.interactionRepeatCount or DEFAULT_INTERACTION_REPEAT_COUNT)), 8)
    streamWriteUInt16(streamId, math.max(250, math.min(65535, self.values.interactionRepeatDelayMs or DEFAULT_INTERACTION_REPEAT_DELAY_MS)))
    streamWriteFloat32(streamId, self.values.washWidth or DEFAULT_WASH_WIDTH)
    streamWriteFloat32(streamId, self.values.washHeight or DEFAULT_WASH_HEIGHT)
    streamWriteFloat32(streamId, self.values.washLength or DEFAULT_WASH_LENGTH)
    streamWriteFloat32(streamId, self.values.washOffsetX or 0)
    streamWriteFloat32(streamId, self.values.washOffsetY or 0)
    streamWriteFloat32(streamId, self.values.washOffsetZ or 0)
    streamWriteBool(streamId, self.values.washGeometryManual == true)
    streamWriteUIntN(streamId, math.max(0, math.min(3, self.values.washGeometrySource or WASH_SOURCE_TRIGGER)), 2)
end
function SmartGateGateSettingsEvent:readStream(streamId, connection)
    self.id = streamReadString(streamId)
    self.ownerKey = streamReadString(streamId)
    self.nodeKey = streamReadString(streamId)
    self.x = streamReadFloat32(streamId)
    self.z = streamReadFloat32(streamId)
    self.resetToDefaults = streamReadBool(streamId)
    self.values = {
        triggerOpenDistance=streamReadFloat32(streamId),
        triggerOpenHalfWidth=streamReadFloat32(streamId),
        triggerCloseDistance=streamReadFloat32(streamId),
        triggerCloseHalfWidth=streamReadFloat32(streamId),
        safetyDepth=streamReadFloat32(streamId),
        safetyHalfWidth=streamReadFloat32(streamId),
        interactionDepth=streamReadFloat32(streamId),
        interactionHalfWidth=streamReadFloat32(streamId),
        interactionOffsetX=streamReadFloat32(streamId),
        interactionOffsetZ=streamReadFloat32(streamId),
        interactionYaw=streamReadFloat32(streamId),
        configDepth=streamReadFloat32(streamId),
        configHalfWidth=streamReadFloat32(streamId),
        axisSwapped=streamReadBool(streamId), animationInverted=streamReadBool(streamId),
        preOpenMode=streamReadUIntN(streamId,2),preOpenDistance=streamReadFloat32(streamId),preOpenOnly=streamReadBool(streamId),
        objectType=streamReadUIntN(streamId,1),
        washPoint=streamReadBool(streamId),
        safetyClearDelayMs=streamReadUInt16(streamId),
        interactionTriggerMode=streamReadUIntN(streamId,2) + 1,
        interactionRepeatCount=streamReadUIntN(streamId,8),
        interactionRepeatDelayMs=streamReadUInt16(streamId),
        washWidth=streamReadFloat32(streamId), washHeight=streamReadFloat32(streamId), washLength=streamReadFloat32(streamId),
        washOffsetX=streamReadFloat32(streamId), washOffsetY=streamReadFloat32(streamId), washOffsetZ=streamReadFloat32(streamId),
        washGeometryManual=streamReadBool(streamId), washGeometrySource=streamReadUIntN(streamId,2)
    }
    self:run(connection)
end
function SmartGateGateSettingsEvent:run(connection)
    if g_server ~= nil and connection ~= nil and not connection:getIsServer() and g_smartGate ~= nil then
        g_smartGate:applyGateGeometryOnServer(self.id, self.ownerKey, self.nodeKey, self.x, self.z, self.resetToDefaults, self.values, connection)
    end
end
function SmartGateGateSettingsEvent.send(gate, resetToDefaults)
    if gate == nil or g_smartGate == nil then return end
    if g_server ~= nil then
        local id, ownerKey, nodeKey, x, z = g_smartGate:getGateDescriptor(gate)
        g_smartGate:applyGateGeometryOnServer(id, ownerKey, nodeKey, x, z, resetToDefaults == true, {
            interactionDepth=gate.interactionDepth,
            interactionHalfWidth=gate.interactionHalfWidth,
            interactionOffsetX=gate.interactionOffsetX,
            interactionOffsetZ=gate.interactionOffsetZ,
            interactionYaw=gate.interactionYaw,
            triggerOpenDistance=gate.triggerOpenDistance,
            triggerOpenHalfWidth=gate.triggerOpenHalfWidth,
            triggerCloseDistance=gate.triggerCloseDistance,
            triggerCloseHalfWidth=gate.triggerCloseHalfWidth,
            triggerSideDistance=gate.triggerSideDistance,
            safetyDepth=gate.safetyDepth,
            safetyHalfWidth=gate.safetyHalfWidth,
            configDepth=gate.configDepth,
            configHalfWidth=gate.configHalfWidth,
            axisSwapped=gate.axisSwapped == true, animationInverted=gate.animationInverted == true,
        preOpenMode=gate.preOpenMode or 0,preOpenDistance=preOpenManualDistance(gate.preOpenDistance),
            objectType=gate.objectType or OBJECT_GATE,
            washPoint=gate.washPoint == true,
            safetyClearDelayMs=gate.safetyClearDelayMs,
            interactionTriggerMode=gate.interactionTriggerMode,
            interactionRepeatCount=gate.interactionRepeatCount,
            interactionRepeatDelayMs=gate.interactionRepeatDelayMs,
            washWidth=gate.washWidth, washHeight=gate.washHeight, washLength=gate.washLength,
            washOffsetX=gate.washOffsetX, washOffsetY=gate.washOffsetY, washOffsetZ=gate.washOffsetZ,
            washGeometryManual=gate.washGeometryManual == true, washGeometrySource=gate.washGeometrySource
        })
    elseif g_client ~= nil and g_client.getServerConnection ~= nil then
        g_client:getServerConnection():sendEvent(SmartGateGateSettingsEvent.new(gate, resetToDefaults))
    end
end

SmartGateAnimationTestEvent = {}
local SmartGateAnimationTestEvent_mt = Class(SmartGateAnimationTestEvent, Event)
InitEventClass(SmartGateAnimationTestEvent, "SmartGateAnimationTestEvent")
function SmartGateAnimationTestEvent.emptyNew() return Event.new(SmartGateAnimationTestEvent_mt) end
function SmartGateAnimationTestEvent.new(gate, shouldOpen)
    local self = SmartGateAnimationTestEvent.emptyNew()
    self.id,self.ownerKey,self.nodeKey,self.x,self.z = g_smartGate:getGateDescriptor(gate)
    self.shouldOpen = shouldOpen == true
    return self
end
function SmartGateAnimationTestEvent:writeStream(streamId, connection)
    streamWriteString(streamId,self.id); streamWriteString(streamId,self.ownerKey); streamWriteString(streamId,self.nodeKey)
    streamWriteFloat32(streamId,self.x); streamWriteFloat32(streamId,self.z); streamWriteBool(streamId,self.shouldOpen)
    streamWriteBool(streamId,self.isReply == true); streamWriteBool(streamId,self.accepted == true)
end
function SmartGateAnimationTestEvent:readStream(streamId, connection)
    self.id=streamReadString(streamId); self.ownerKey=streamReadString(streamId); self.nodeKey=streamReadString(streamId)
    self.x=streamReadFloat32(streamId); self.z=streamReadFloat32(streamId); self.shouldOpen=streamReadBool(streamId)
    self.isReply=streamReadBool(streamId); self.accepted=streamReadBool(streamId)
    self:run(connection)
end
function SmartGateAnimationTestEvent:run(connection)
    if connection ~= nil and connection:getIsServer() and self.isReply == true then
        showNotification(self.accepted and uiText("SmartGate: Animationstest ausgelöst", "SmartGate: Animation test started")
            or uiText("SmartGate: Test blockiert (Safety/Berechtigung/Objekttyp)", "SmartGate: Test blocked (safety/access/object type)"),3000,
            self.accepted and FSBaseMission.INGAME_NOTIFICATION_OK or FSBaseMission.INGAME_NOTIFICATION_WARNING)
    elseif connection ~= nil and not connection:getIsServer() and self.isReply ~= true and g_smartGate ~= nil then
        self.accepted = g_smartGate:testGateAnimation(self.id,self.ownerKey,self.nodeKey,self.x,self.z,self.shouldOpen,connection) == true
        self.isReply = true
        connection:sendEvent(self)
    end
end
function SmartGateAnimationTestEvent.send(gate, shouldOpen)
    if gate == nil or g_smartGate == nil then return end
    if g_server ~= nil then
        local id,ownerKey,nodeKey,x,z = g_smartGate:getGateDescriptor(gate)
        local ok = g_smartGate:testGateAnimation(id,ownerKey,nodeKey,x,z,shouldOpen == true,nil)
        if not ok then showNotification(uiText("SmartGate: Test blockiert (Safety/Berechtigung/Objekttyp)", "SmartGate: Test blocked (safety/access/object type)"),3000,FSBaseMission.INGAME_NOTIFICATION_WARNING) end
    elseif g_client ~= nil then
        g_client:getServerConnection():sendEvent(SmartGateAnimationTestEvent.new(gate,shouldOpen))
    end
end

SmartGateStateSyncEvent = {}
local SmartGateStateSyncEvent_mt = Class(SmartGateStateSyncEvent, Event)
InitEventClass(SmartGateStateSyncEvent, "SmartGateStateSyncEvent")
function SmartGateStateSyncEvent.emptyNew() return Event.new(SmartGateStateSyncEvent_mt) end
function SmartGateStateSyncEvent.new(gates)
    local self = SmartGateStateSyncEvent.emptyNew()
    self.entries = {}
    for _, gate in ipairs(gates or {}) do
        table.insert(self.entries, {
            id=gate.id, ownerKey=gate.ownerKey or "", nodeKey=gate.nodeKey or "", x=gate.x or 0, z=gate.z or 0,
            mode=gate.mode or MODE_ALL, blacklisted=gate.blacklisted == true,
            customGeometry=gate.customGeometry == true,
            interactionDepth=gate.interactionDepth,
            interactionHalfWidth=gate.interactionHalfWidth,
            interactionOffsetX=gate.interactionOffsetX,
            interactionOffsetZ=gate.interactionOffsetZ,
            interactionYaw=gate.interactionYaw,
            triggerOpenDistance=gate.triggerOpenDistance or AUTO_OPEN_DISTANCE,
            triggerOpenHalfWidth=gate.triggerOpenHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE,
            triggerCloseDistance=gate.triggerCloseDistance or AUTO_CLOSE_DISTANCE,
            triggerCloseHalfWidth=gate.triggerCloseHalfWidth or gate.triggerSideDistance or DEFAULT_TRIGGER_SIDE_DISTANCE,
            safetyDepth=gate.safetyDepth or DEFAULT_SAFETY_DEPTH,
            safetyHalfWidth=gate.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH,
            configDepth=gate.configDepth or CONFIG_ZONE_LENGTH,
            configHalfWidth=gate.configHalfWidth or CONFIG_ZONE_HALF_WIDTH,
            axisSwapped=gate.axisSwapped == true, animationInverted=gate.animationInverted == true,
        preOpenMode=gate.preOpenMode or 0,preOpenDistance=preOpenManualDistance(gate.preOpenDistance),
            objectType=gate.objectType or OBJECT_GATE,
            washPoint=gate.washPoint == true,
            safetyClearDelayMs=gate.safetyClearDelayMs or DEFAULT_SAFETY_CLEAR_DELAY_MS,
            interactionTriggerMode=gate.interactionTriggerMode or INTERACTION_TRIGGER_ENTER,
            interactionRepeatCount=gate.interactionRepeatCount or DEFAULT_INTERACTION_REPEAT_COUNT,
            interactionRepeatDelayMs=gate.interactionRepeatDelayMs or DEFAULT_INTERACTION_REPEAT_DELAY_MS,
            washWidth=gate.washWidth or DEFAULT_WASH_WIDTH, washHeight=gate.washHeight or DEFAULT_WASH_HEIGHT, washLength=gate.washLength or DEFAULT_WASH_LENGTH,
            washOffsetX=gate.washOffsetX or 0, washOffsetY=gate.washOffsetY or 0, washOffsetZ=gate.washOffsetZ or 0,
            washGeometryManual=gate.washGeometryManual == true, washGeometrySource=gate.washGeometrySource or WASH_SOURCE_TRIGGER
        })
    end
    return self
end
function SmartGateStateSyncEvent:writeStream(streamId, connection)
    streamWriteUInt16(streamId, #self.entries)
    for _, entry in ipairs(self.entries) do
        streamWriteString(streamId, entry.id or "")
        streamWriteString(streamId, entry.ownerKey or "")
        streamWriteString(streamId, entry.nodeKey or "")
        streamWriteFloat32(streamId, entry.x or 0)
        streamWriteFloat32(streamId, entry.z or 0)
        streamWriteUIntN(streamId, entry.mode or MODE_ALL, 2)
        streamWriteBool(streamId, entry.blacklisted == true)
        streamWriteBool(streamId, entry.customGeometry == true)
        streamWriteFloat32(streamId, entry.triggerOpenDistance or AUTO_OPEN_DISTANCE)
        streamWriteFloat32(streamId, entry.triggerOpenHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE)
        streamWriteFloat32(streamId, entry.triggerCloseDistance or AUTO_CLOSE_DISTANCE)
        streamWriteFloat32(streamId, entry.triggerCloseHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE)
        streamWriteFloat32(streamId, entry.safetyDepth or DEFAULT_SAFETY_DEPTH)
        streamWriteFloat32(streamId, entry.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH)
        streamWriteFloat32(streamId, entry.interactionDepth or .75)
        streamWriteFloat32(streamId, entry.interactionHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE)
        streamWriteFloat32(streamId, entry.interactionOffsetX or 0)
        streamWriteFloat32(streamId, entry.interactionOffsetZ or 0)
        streamWriteFloat32(streamId, entry.interactionYaw or 0)
        streamWriteFloat32(streamId, entry.configDepth or CONFIG_ZONE_LENGTH)
        streamWriteFloat32(streamId, entry.configHalfWidth or CONFIG_ZONE_HALF_WIDTH)
        streamWriteBool(streamId, entry.axisSwapped == true)
        streamWriteBool(streamId, entry.animationInverted == true)
        streamWriteUIntN(streamId,entry.preOpenMode or 0,2)
        streamWriteFloat32(streamId,preOpenManualDistance(entry.preOpenDistance))
        streamWriteUIntN(streamId, entry.objectType or OBJECT_GATE, 1)
        streamWriteBool(streamId, entry.washPoint == true)
        streamWriteUInt16(streamId, entry.safetyClearDelayMs or DEFAULT_SAFETY_CLEAR_DELAY_MS)
        streamWriteUIntN(streamId, math.max(1, math.min(4, entry.interactionTriggerMode or INTERACTION_TRIGGER_ENTER)) - 1, 2)
        streamWriteUIntN(streamId, math.max(1, math.min(255, entry.interactionRepeatCount or DEFAULT_INTERACTION_REPEAT_COUNT)), 8)
        streamWriteUInt16(streamId, math.max(250, math.min(65535, entry.interactionRepeatDelayMs or DEFAULT_INTERACTION_REPEAT_DELAY_MS)))
        streamWriteFloat32(streamId, entry.washWidth or DEFAULT_WASH_WIDTH)
        streamWriteFloat32(streamId, entry.washHeight or DEFAULT_WASH_HEIGHT)
        streamWriteFloat32(streamId, entry.washLength or DEFAULT_WASH_LENGTH)
        streamWriteFloat32(streamId, entry.washOffsetX or 0)
        streamWriteFloat32(streamId, entry.washOffsetY or 0)
        streamWriteFloat32(streamId, entry.washOffsetZ or 0)
        streamWriteBool(streamId, entry.washGeometryManual == true)
        streamWriteUIntN(streamId, math.max(0, math.min(3, entry.washGeometrySource or WASH_SOURCE_TRIGGER)), 2)
    end
end
function SmartGateStateSyncEvent:readStream(streamId, connection)
    self.entries = {}
    local count = streamReadUInt16(streamId)
    for i=1,count do
        self.entries[i] = {
            id=streamReadString(streamId),
            ownerKey=streamReadString(streamId),
            nodeKey=streamReadString(streamId),
            x=streamReadFloat32(streamId),
            z=streamReadFloat32(streamId),
            mode=streamReadUIntN(streamId,2),
            blacklisted=streamReadBool(streamId),
            customGeometry=streamReadBool(streamId),
            triggerOpenDistance=streamReadFloat32(streamId),
            triggerOpenHalfWidth=streamReadFloat32(streamId),
            triggerCloseDistance=streamReadFloat32(streamId),
            triggerCloseHalfWidth=streamReadFloat32(streamId),
            safetyDepth=streamReadFloat32(streamId),
            safetyHalfWidth=streamReadFloat32(streamId),
            interactionDepth=streamReadFloat32(streamId),
            interactionHalfWidth=streamReadFloat32(streamId),
            interactionOffsetX=streamReadFloat32(streamId),
            interactionOffsetZ=streamReadFloat32(streamId),
            interactionYaw=streamReadFloat32(streamId),
            configDepth=streamReadFloat32(streamId),
            configHalfWidth=streamReadFloat32(streamId),
            axisSwapped=streamReadBool(streamId), animationInverted=streamReadBool(streamId),
        preOpenMode=streamReadUIntN(streamId,2),preOpenDistance=streamReadFloat32(streamId),
            objectType=streamReadUIntN(streamId,1),
            washPoint=streamReadBool(streamId),
            safetyClearDelayMs=streamReadUInt16(streamId),
            interactionTriggerMode=streamReadUIntN(streamId,2) + 1,
            interactionRepeatCount=streamReadUIntN(streamId,8),
            interactionRepeatDelayMs=streamReadUInt16(streamId),
            washWidth=streamReadFloat32(streamId), washHeight=streamReadFloat32(streamId), washLength=streamReadFloat32(streamId),
            washOffsetX=streamReadFloat32(streamId), washOffsetY=streamReadFloat32(streamId), washOffsetZ=streamReadFloat32(streamId),
            washGeometryManual=streamReadBool(streamId), washGeometrySource=streamReadUIntN(streamId,2)
        }
    end
    self:run(connection)
end
function SmartGateStateSyncEvent:run(connection)
    if connection ~= nil and connection:getIsServer() and g_smartGate ~= nil then
        local blacklistCount = 0
        local resolvedCount = 0
        for _, entry in ipairs(self.entries or {}) do
            local gate = g_smartGate:resolveGate(entry.id, entry.ownerKey, entry.nodeKey, entry.x, entry.z)
            if gate ~= nil then
                resolvedCount = resolvedCount + 1
                gate.mode = entry.mode
                gate.blacklisted = entry.blacklisted == true
                gate.customGeometry = entry.customGeometry == true
                gate.interactionDepth = entry.interactionDepth or .75
                gate.interactionHalfWidth = entry.interactionHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE
                gate.interactionOffsetX = entry.interactionOffsetX or 0
                gate.interactionOffsetZ = entry.interactionOffsetZ or 0
                gate.interactionYaw = entry.interactionYaw or 0
                gate.triggerOpenDistance = entry.triggerOpenDistance or AUTO_OPEN_DISTANCE
                gate.triggerOpenHalfWidth = entry.triggerOpenHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE
                gate.triggerCloseDistance = entry.triggerCloseDistance or AUTO_CLOSE_DISTANCE
                gate.triggerCloseHalfWidth = entry.triggerCloseHalfWidth or DEFAULT_TRIGGER_SIDE_DISTANCE
                gate.triggerSideDistance = gate.triggerOpenHalfWidth
                gate.safetyDepth = entry.safetyDepth or DEFAULT_SAFETY_DEPTH
                gate.safetyHalfWidth = entry.safetyHalfWidth or DEFAULT_SAFETY_HALF_WIDTH
                gate.configDepth = entry.configDepth or CONFIG_ZONE_LENGTH
                gate.configHalfWidth = entry.configHalfWidth or CONFIG_ZONE_HALF_WIDTH
                gate.axisSwapped = entry.axisSwapped == true
                gate.animationInverted = entry.animationInverted == true
                gate.preOpenMode=(entry.preOpenMode==1 or entry.preOpenMode==2) and entry.preOpenMode or 0
                gate.preOpenDistance=preOpenManualDistance(entry.preOpenDistance)
                g_smartGate.geometryRevision=(g_smartGate.geometryRevision or 0)+1
                local incomingType=entry.objectType == OBJECT_INTERACTION and OBJECT_INTERACTION or OBJECT_GATE
                if gate.objectType~=incomingType and g_smartGate.configPanelGate==gate then g_smartGate.configGeometryProfile=incomingType end
                gate.objectType = incomingType
                gate.washPoint = gate.objectType == OBJECT_INTERACTION and entry.washPoint == true
                gate.interactionLatched = false
                gate.interactionWasOccupied = false
                gate.interactionRepeatRemaining = 0
                gate.interactionNextTriggerTime = nil
                gate.safetyClearDelayMs = entry.safetyClearDelayMs or DEFAULT_SAFETY_CLEAR_DELAY_MS
                gate.interactionTriggerMode = entry.interactionTriggerMode or INTERACTION_TRIGGER_ENTER
                gate.interactionRepeatCount = entry.interactionRepeatCount or DEFAULT_INTERACTION_REPEAT_COUNT
                gate.interactionRepeatDelayMs = entry.interactionRepeatDelayMs or DEFAULT_INTERACTION_REPEAT_DELAY_MS
                gate.washWidth = entry.washWidth or DEFAULT_WASH_WIDTH
                gate.washHeight = entry.washHeight or DEFAULT_WASH_HEIGHT
                gate.washLength = entry.washLength or DEFAULT_WASH_LENGTH
                gate.washOffsetX = entry.washOffsetX or 0
                gate.washOffsetY = entry.washOffsetY or 0
                gate.washOffsetZ = entry.washOffsetZ or 0
                gate.washGeometryManual = entry.washGeometryManual == true
                gate.washGeometrySource = entry.washGeometrySource or WASH_SOURCE_TRIGGER
                g_smartGate.savedModes[gate.id] = entry.mode
                if gate.customGeometry then
                    g_smartGate.savedCustomGeometry[gate.id] = true
                else
                    g_smartGate.savedCustomGeometry[gate.id] = nil
                end
                g_smartGate.savedGateSettings[gate.id] = {
                    interactionDepth=gate.interactionDepth,
                    interactionHalfWidth=gate.interactionHalfWidth,
                    interactionOffsetX=gate.interactionOffsetX,
                    interactionOffsetZ=gate.interactionOffsetZ,
                    interactionYaw=gate.interactionYaw,
                    triggerOpenDistance=gate.triggerOpenDistance, triggerOpenHalfWidth=gate.triggerOpenHalfWidth,
                    triggerCloseDistance=gate.triggerCloseDistance, triggerCloseHalfWidth=gate.triggerCloseHalfWidth,
                    triggerSideDistance=gate.triggerSideDistance, safetyDepth=gate.safetyDepth,
                    safetyHalfWidth=gate.safetyHalfWidth, configDepth=gate.configDepth, configHalfWidth=gate.configHalfWidth,
                    axisSwapped=gate.axisSwapped == true, animationInverted=gate.animationInverted == true,
        preOpenMode=gate.preOpenMode or 0,preOpenDistance=preOpenManualDistance(gate.preOpenDistance), objectType=gate.objectType or OBJECT_GATE, washPoint=gate.washPoint == true, safetyClearDelayMs=gate.safetyClearDelayMs,
                    interactionTriggerMode=gate.interactionTriggerMode, interactionRepeatCount=gate.interactionRepeatCount, interactionRepeatDelayMs=gate.interactionRepeatDelayMs,
                    washWidth=gate.washWidth, washHeight=gate.washHeight, washLength=gate.washLength,
                    washOffsetX=gate.washOffsetX, washOffsetY=gate.washOffsetY, washOffsetZ=gate.washOffsetZ,
                    washGeometryManual=gate.washGeometryManual == true, washGeometrySource=gate.washGeometrySource
                }

                -- Keep the descriptor cache current as well. Otherwise a later
                -- ID/descriptor fallback in the same session could resurrect
                -- geometry from the initial load.
                local updatedRecord = g_smartGate:findSavedGateRecord(gate,true)
                if updatedRecord == nil then
                    updatedRecord = {}
                    table.insert(g_smartGate.savedGateRecords, updatedRecord)
                    g_smartGate.savedGateIdentitySource=nil
                end
                updatedRecord.id = gate.id
                updatedRecord.ownerKey = gate.ownerKey or entry.ownerKey or ""
                updatedRecord.nodeKey = gate.nodeKey or entry.nodeKey or ""
                updatedRecord.x = gate.x
                updatedRecord.z = gate.z
                updatedRecord.mode = gate.mode
                updatedRecord.blacklisted = gate.blacklisted == true
                updatedRecord.customGeometry = gate.customGeometry == true
                updatedRecord.settings = g_smartGate.savedGateSettings[gate.id]
                if entry.blacklisted then
                    g_smartGate.savedBlacklist[gate.id] = true
                    blacklistCount = blacklistCount + 1
                else
                    g_smartGate.savedBlacklist[gate.id] = nil
                end
            end
        end
        debugLog("state sync received: %d/%d resolved, %d blacklisted", resolvedCount, #(self.entries or {}), blacklistCount)
    end
end
function SmartGateStateSyncEvent.sendToClients(gates)
    if g_server ~= nil then
        g_server:broadcastEvent(SmartGateStateSyncEvent.new(gates), false)
    end
end

-- Public, optional integration API (e.g. APS). Keep this surface small and
-- independent from SmartGate internals so external mods do not need hard links.
SmartGateAPI = SmartGateAPI or {}
SmartGateAPI.VERSION = "1.6"

function SmartGateAPI.isAvailable()
    return g_smartGate ~= nil and type(g_smartGate.findGateById) == "function"
end


function SmartGateAPI.findNearestInteraction(x, z, maxDistance)
    if g_smartGate == nil then return nil end
    x = tonumber(x)
    z = tonumber(z)
    maxDistance = tonumber(maxDistance) or 25
    if x == nil or z == nil or maxDistance <= 0 then return nil end

    local best = nil
    local bestDistance = maxDistance

    for _, gate in ipairs(g_smartGate.gates or {}) do
        if gate.objectType == OBJECT_INTERACTION and gate.x ~= nil and gate.z ~= nil then
            local dx = x - gate.x
            local dz = z - gate.z
            local distance = math.sqrt(dx * dx + dz * dz)
            if distance <= bestDistance then
                best = gate
                bestDistance = distance
            end
        end
    end

    if best == nil then return nil end
    return {
        id = best.id,
        name = tostring(best.displayName or best.id),
        distance = bestDistance,
        washPoint = best.washPoint == true,
        running = best.animatedObject ~= nil
            and best.animatedObject.animation ~= nil
            and (tonumber(best.animatedObject.animation.direction) or 0) ~= 0
    }
end

function SmartGateAPI.findNearestWashPoint(x, z, maxDistance)
    if g_smartGate == nil then return nil end
    x = tonumber(x)
    z = tonumber(z)
    maxDistance = tonumber(maxDistance) or 25
    if x == nil or z == nil or maxDistance <= 0 then return nil end

    local best = nil
    local bestDistance = maxDistance
    for _, gate in ipairs(g_smartGate.gates or {}) do
        if gate.objectType == OBJECT_INTERACTION and gate.washPoint == true and (legacyWashBay(gate)==nil or legacyWashBay(gate).capabilities.WASH) and gate.x ~= nil and gate.z ~= nil then
            local centerX, _, centerZ = getWashBoxCenter(gate)
            local dx = x - centerX
            local dz = z - centerZ
            local distance = math.sqrt(dx * dx + dz * dz)
            if distance <= bestDistance then
                best = gate
                bestDistance = distance
            end
        end
    end

    if best == nil then return nil end
    local bay=legacyWashBay(best)
    local usableLength = math.max(0.1, tonumber(bay~=nil and bay.length or best.washLength) or DEFAULT_WASH_LENGTH)
    local usableWidth = math.max(0.1, tonumber(bay~=nil and bay.width or best.washWidth) or DEFAULT_WASH_WIDTH)
    local usableHeight = math.max(0.1, tonumber(bay~=nil and bay.height or best.washHeight) or DEFAULT_WASH_HEIGHT)
    local centerX, centerY, centerZ = getWashBoxCenter(best)
    return {
        id = best.id,
        name = tostring(best.displayName or best.id),
        distance = bestDistance,
        washPoint = true,
        halfLength = usableLength * 0.5,
        halfWidth = usableWidth * 0.5,
        usableLength = usableLength,
        usableWidth = usableWidth,
        usableHeight = usableHeight,
        washCenterX = centerX, washCenterY = centerY, washCenterZ = centerZ,
        washGeometrySource = bay~=nil and "CONFIGURED_SERVICE_BAY" or getWashSourceText(best.washGeometrySource),
        running = best.animatedObject ~= nil
            and best.animatedObject.animation ~= nil
            and (tonumber(best.animatedObject.animation.direction) or 0) ~= 0
    }
end

function SmartGateAPI.requestNearestInteraction(x, z, maxDistance)
    local found = SmartGateAPI.findNearestInteraction(x, z, maxDistance)
    if found == nil then
        return false, "no interaction in range", nil
    end

    local ok, detail = SmartGateAPI.requestInteraction(found.id)
    return ok, detail, found
end

function SmartGateAPI.requestInteraction(gateId,ownerKey,nodeKey,x,z)
    if g_server == nil then
        return false, "server only"
    end
    if g_smartGate == nil then
        return false, "SmartGate unavailable"
    end

    local gate
    if ownerKey~=nil and nodeKey~=nil and type(x)=="number" and type(z)=="number" then
        gate=g_smartGate:resolveGate(tostring(gateId or ""),ownerKey,nodeKey,x,z)
    elseif not g_smartGate:hasGateIdCollision(tostring(gateId or "")) then
        gate=g_smartGate:findGateById(tostring(gateId or ""))
    end
    if gate == nil then
        return false, "interaction not found"
    end
    if gate.objectType ~= OBJECT_INTERACTION then
        return false, "target is not INTERAKTIV"
    end

    local triggered, method = triggerInteractiveObject(gate)
    if triggered then
        gate.interactionLatched = true
        gate.interactionClearSince = nil
        print(string.format("[SmartGate][INTERACTION] external request triggered '%s' via %s", tostring(gate.displayName or gate.id), tostring(method)))
    end
    return triggered, method
end

function SmartGateAPI.isInteractionRunning(gateId)
    if g_smartGate == nil then return false end
    local gate = g_smartGate:findGateById(tostring(gateId or ""))
    local ao = gate ~= nil and gate.animatedObject or nil
    return ao ~= nil and ao.animation ~= nil and (tonumber(ao.animation.direction) or 0) ~= 0
end

function SmartGateAPI.getInteractionState(gateId)
    if g_smartGate == nil then return nil end
    local gate = g_smartGate:findGateById(tostring(gateId or ""))
    if gate == nil or gate.objectType ~= OBJECT_INTERACTION then return nil end
    local ao = gate.animatedObject
    return {
        id = gate.id,
        running = ao ~= nil and ao.animation ~= nil and (tonumber(ao.animation.direction) or 0) ~= 0,
        animationTime = ao ~= nil and ao.animation ~= nil and (tonumber(ao.animation.time) or 0) or 0,
        latched = gate.interactionLatched == true
    }
end

-- Phase-1 service discovery is read-only. Occupancy of the activation rectangle
-- is not service-bay occupancy; capacity, permissions and AD targets stay unknown.
function SmartGateAPI.listServicePoints()
    if g_smartGate == nil then return nil, "UNKNOWN" end
    local result = {}
    for _, gate in ipairs(g_smartGate.gates or {}) do
        if gate.objectType == OBJECT_INTERACTION and gate.washPoint == true then
            local farmId
            if gate.owner ~= nil and type(gate.owner.getOwnerFarmId) == "function" then
                local ok, value = pcall(gate.owner.getOwnerFarmId, gate.owner)
                if ok and type(value) == "number" and value > 0 then farmId = value end
            end
            local x, y, z = getWashBoxCenter(gate)
            result[#result+1] = {
                id=gate.id, reference=gate.id, provider="SmartGate", name=gate.displayName,
                capabilities={WASH=true}, farmId=farmId, access="UNKNOWN",
                dimensions={width=gate.washWidth, height=gate.washHeight, length=gate.washLength},
                position={x=x,y=y,z=z}, capacity="UNKNOWN", physicalOccupancy="UNKNOWN",
                adTarget="UNKNOWN", waitingArea="UNKNOWN", operational="UNKNOWN",
                activationOccupied=gate.occupied, running=SmartGateAPI.isInteractionRunning(gate.id),
                geometrySource=getWashSourceText(gate.washGeometrySource)
            }
        end
    end
    return result, "KNOWN"
end

-- Same source order as the proven APS wash lookup; a single service destination path.
-- AutoDrive itself is read-only. Marker IDs are never waypoint IDs.
local function serviceAdGraph()
    if type(ADGraphManager)=="table" then return ADGraphManager,"DIRECT_GRAPH" end
    local ok,env=pcall(getfenv,0)
    if ok and type(env)=="table" then
        local root=rawget(env,"_G")
        local adEnv=rawget(env,"FS25_AutoDrive") or (type(root)=="table" and rawget(root,"FS25_AutoDrive"))
        if type(adEnv)=="table" and type(adEnv.ADGraphManager)=="table" then return adEnv.ADGraphManager,"MOD_GRAPH" end
    end
    return nil,"NO_GRAPH"
end
local function savedServiceAdDestinations(owner,force)
    if g_server==nil then return nil,"CLIENT_SAVEGAME_DISABLED" end
    if not force and owner.serviceAdXmlCache~=nil then return owner.serviceAdXmlCache.targets,owner.serviceAdXmlCache.reason end
    local info=g_currentMission~=nil and g_currentMission.missionInfo
    local dir=info~=nil and info.savegameDirectory
    if (dir==nil or dir=="") and info~=nil and info.savegameIndex~=nil and type(getUserProfileAppPath)=="function" then dir=getUserProfileAppPath().."savegame"..tostring(info.savegameIndex) end
    if type(dir)~="string" or dir=="" then return nil,"NO_SAVEGAME_PATH" end
    local path=dir:gsub("[\\/]$","").."/AutoDrive_config.xml"
    if type(fileExists)~="function" or not fileExists(path) then return nil,"NO_SAVED_AD_XML" end
    local xml
    local ok,result=pcall(function()
        xml=loadXMLFile("sgServiceAdLookup",path)
        if xml==nil or xml==0 then error("XML_OPEN_FAILED") end
        local function csv(value) local t={}; for part in tostring(value or ""):gmatch("([^,]+)") do t[#t+1]=part end; return t end
        local ids=csv(getXMLString(xml,"AutoDrive.waypoints.id")); local xs=csv(getXMLString(xml,"AutoDrive.waypoints.x")); local zs=csv(getXMLString(xml,"AutoDrive.waypoints.z"))
        local points={}
        for i,v in ipairs(ids) do local id,x,z=tonumber(v),tonumber(xs[i]),tonumber(zs[i]); if id~=nil and x~=nil and z~=nil then points[id]={x=x,z=z} end end
        local targets={}
        for index=1,16384 do
            local key="AutoDrive.mapmarker.mm"..index; local waypoint=getXMLFloat(xml,key..".id")
            if waypoint==nil then break end
            local point=points[tonumber(waypoint)]
            if point~=nil then targets[index]={id=index,name=getXMLString(xml,key..".name"),x=point.x,z=point.z}
            else targets[index]={id=index,invalidReason="NO_SAVED_WAYPOINT"} end
        end
        return targets
    end)
    if xml~=nil and xml~=0 and type(delete)=="function" then pcall(delete,xml) end
    if not ok then return nil,"SAVED_XML_READ_FAILED" end
    owner.serviceAdXmlCache={targets=result,reason="SAVED_XML_SNAPSHOT"}
    return result,"SAVED_XML_SNAPSHOT"
end
function SmartGate:getServiceDestinations(force)
    local ad,environment=resolveAutoDriveApi()
    if ad==nil then
        for _,list in ipairs(getGateVehicleLists()) do
            for _,v in pairs(list) do
                if type(v.startAutoDrive)=="function" and type(getfenv)=="function" then
                    local ok,env=pcall(getfenv,v.startAutoDrive)
                    if ok and type(env)=="table" and type(env.AutoDrive)=="table" then
                        ad,environment=env.AutoDrive,"VEHICLE_FUNCTION_ENV";self.serviceAdFunctionEnv=env;break
                    end
                end
            end
            if ad~=nil then break end
        end
    end
    local diagnostics={resolved=environment,apiPresent=type(ad)=="table" and type(ad.GetAvailableDestinations)=="function",raw=0,accepted=0,rejected=0,reasons={},source="UNAVAILABLE"}
    local function reject(reason) diagnostics.rejected=diagnostics.rejected+1; diagnostics.reasons[reason]=(diagnostics.reasons[reason] or 0)+1 end
    local function normalize(raw,source)
        if type(raw)~="table" then return nil end
        local result={}; local accepted=0
        for key,v in pairs(raw) do
            diagnostics.raw=diagnostics.raw+1
            local id=type(v)=="table" and tonumber(v.id or key) or nil
            if type(v)~="table" then reject("NOT_TABLE")
            elseif v.invalidReason=="NO_SAVED_WAYPOINT" then reject("NO_SAVED_WAYPOINT")
            elseif id==nil or id~=id or id<1 or id>16777215 or id~=math.floor(id) then reject("INVALID_MARKER_ID")
            elseif result[id]~=nil then reject("DUPLICATE_MARKER_ID")
            elseif accepted>=16384 then reject("TARGET_LIMIT")
            else
                local name=type(v.name)=="string" and v.name~="" and v.name or "Marker "..id
                result[id]={id=id,name=name:gsub("[%c]"," "):sub(1,128),x=tonumber(v.x),z=tonumber(v.z)}; accepted=accepted+1
            end
        end
        if accepted>0 then diagnostics.accepted=accepted; diagnostics.source=source; return result end
    end
    if diagnostics.apiPresent then
        local ok,raw=pcall(ad.GetAvailableDestinations,ad)
        diagnostics.apiResult=ok and type(raw) or "ERROR"
        if ok then local result=normalize(raw,"AUTODRIVE_API"); if result~=nil then return result,diagnostics end end
    else diagnostics.apiResult="MISSING" end
    local graph,graphSource=serviceAdGraph(); if graph==nil and self.serviceAdFunctionEnv~=nil then graph=self.serviceAdFunctionEnv.ADGraphManager;graphSource="VEHICLE_FUNCTION_GRAPH" end; diagnostics.graph=graphSource
    if graph~=nil and type(graph.getMapMarkers)=="function" then
        local ok,markers=pcall(graph.getMapMarkers,graph)
        if ok and type(markers)=="table" then
            local raw={}
            for key,marker in pairs(markers) do
                if type(marker)=="table" then
                    local pointOk,point=false,nil
                    if type(graph.getWayPointById)=="function" then pointOk,point=pcall(graph.getWayPointById,graph,marker.id) end
                    if pointOk and type(point)=="table" then raw[key]={id=marker.markerIndex or key,name=marker.name,x=point.x,z=point.z}
                    else diagnostics.raw=diagnostics.raw+1; reject("NO_WAYPOINT") end
                else diagnostics.raw=diagnostics.raw+1; reject("INVALID_GRAPH_MARKER") end
            end
            local result=normalize(raw,"AD_GRAPH"); if result~=nil then return result,diagnostics end
        end
    end
    local saved,reason=savedServiceAdDestinations(self,force); diagnostics.fallback=reason
    local result=normalize(saved,"SAVED_XML"); return result,diagnostics
end

function SmartGateAPI.checkServiceDimensions(size, limits, margins)
    if type(size) ~= "table" or type(limits) ~= "table" then return nil, "UNKNOWN" end
    for _, axis in ipairs({"width", "height", "length"}) do
        local actual, allowed = tonumber(size[axis]), tonumber(limits[axis])
        local margin = tonumber(margins ~= nil and margins[axis] or 0)
        if actual == nil or allowed == nil or margin == nil or actual ~= actual
            or allowed ~= allowed or margin ~= margin or actual <= 0 or allowed <= 0
            or actual == math.huge or allowed == math.huge or margin < 0 or margin == math.huge then
            return nil, "UNKNOWN"
        end
        if actual > math.max(0,allowed-margin) then return false, axis end
    end
    return true, "KNOWN"
end

g_smartGate = SmartGate.new()
installConfigInputHook()
addModEventListener(g_smartGate)
