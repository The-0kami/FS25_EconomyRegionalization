-- Smart Gate - Agriculture Science
-- Independent Agriculture Science menu integration; gameplay settings unchanged.

SmartGateSettings = {}
local SmartGateSettings_mt = Class(SmartGateSettings)

local OPEN_CHOICES  = {0.5, 0.75, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 8, 10, 11, 12, 14, 16, 18, 20, 22, 24}
local CLOSE_CHOICES = {0.5, 0.75, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 8, 10, 11, 12, 14, 16, 18, 20, 22, 24}
local SIDE_CHOICES  = {0.5, 0.75, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 8, 10, 12}
local SAFETY_DEPTH_CHOICES = {0.5, 0.75, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 8, 10, 11, 12, 14, 16, 18, 20, 22, 24}
local SAFETY_WIDTH_CHOICES = {0.5, 0.75, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 8, 10, 12}
local DELAY_CHOICES = {500, 1000, 1500, 1800, 2000, 2500, 3000, 4000, 5000}

local DEFAULTS = {
    triggerOpenDistance = 11.0,
    triggerCloseDistance = 14.0,
    triggerSideDistance = 5.0,
    safetyDepth = 4.5,
    safetyHalfWidth = 4.5,
    safetyClearDelayMs = 1800,
    visualizationDefault = false
}

local function safeI18n(key, fallback)
    if g_i18n ~= nil and g_i18n.getText ~= nil then
        local value = g_i18n:getText(key)
        if value ~= nil and value ~= "" and value ~= key and not tostring(value):find("Missing",1,true) then return value end
    end
    return fallback or key
end

local function copyDefaults()
    local t = {}
    for k, v in pairs(DEFAULTS) do t[k] = v end
    return t
end

local function nearestIndex(choices, value)
    value = tonumber(value)
    if value == nil then return 1 end
    local best, bestD = 1, math.huge
    for i, v in ipairs(choices) do
        local d = math.abs(v - value)
        if d < bestD then best, bestD = i, d end
    end
    return best
end

local function labelsMeters(values)
    local out = {}
    for _, v in ipairs(values) do out[#out+1] = string.format("%g m", v) end
    return out
end

local function labelsDelay(values)
    local out = {}
    for _, v in ipairs(values) do
        if v >= 1000 then out[#out+1] = string.format("%g s", v/1000) else out[#out+1] = tostring(v) .. " ms" end
    end
    return out
end

local function findRowTemplate(layout, wanted)
    if layout ~= nil and layout.asTemplates ~= nil then return layout.asTemplates[wanted] end
    if layout == nil or layout.elements == nil then return nil end
    for _, row in ipairs(layout.elements) do
        if row ~= nil and row.elements ~= nil and #row.elements >= 2 then
            local control = row.elements[1]
            if control ~= nil then
                if wanted == "binary" and (control.profile == "fs25_settingsBinaryOption" or (control.id ~= nil and string.find(control.id, "check"))) then
                    return row
                elseif wanted == "multi" and (control.profile == "fs25_settingsMultiTextOption" or (control.id ~= nil and string.find(control.id, "multi"))) then
                    return row
                end
            end
        end
    end
    return nil
end

local function findSectionTemplate(layout)
    if layout ~= nil and layout.asTemplates ~= nil then return layout.asTemplates.section end
    if layout == nil or layout.elements == nil then return nil end
    for _, element in ipairs(layout.elements) do
        if element ~= nil and element.name == "sectionHeader" then return element end
    end
    return nil
end

local function setTooltip(row, opt, lbl, text)
    text = text or ""
    if opt ~= nil then
        opt.toolTipText = text
        if opt.setToolTipText ~= nil then opt:setToolTipText(text) end
        if opt.elements ~= nil and opt.elements[1] ~= nil and opt.elements[1].setText ~= nil then opt.elements[1]:setText(text) end
    end
    if lbl ~= nil then
        lbl.toolTipText = text
        if lbl.setToolTipText ~= nil then lbl:setToolTipText(text) end
    end
    if row ~= nil then
        row.toolTipText = text
        if row.setToolTipText ~= nil then row:setToolTipText(text) end
    end
end

function SmartGateSettings.new(owner)
    local self = setmetatable({}, SmartGateSettings_mt)
    self.owner = owner
    self.values = copyDefaults()
    self.injectedLayout = nil
    self.retryTimer = 0
    self:load()
    return self
end

function SmartGateSettings:getPath()
    if getUserProfileAppPath == nil then return nil end
    local app = getUserProfileAppPath()
    if app == nil or app == "" then return nil end
    return app .. "modSettings/FS25_SmartGate_AgricultureScience.xml"
end

function SmartGateSettings:load()
    self.values = copyDefaults()
    self.uiPositions = {}
    local path = self:getPath()
    if path == nil or fileExists == nil or not fileExists(path) then return end
    local xml = loadXMLFile("smartGateGlobalSettings", path)
    if xml == nil or xml == 0 then return end
    local function num(attr, fallback)
        local v = getXMLFloat(xml, "smartGateSettings.geometry#" .. attr)
        return v ~= nil and v or fallback
    end
    self.values.triggerOpenDistance = num("triggerOpenDistance", DEFAULTS.triggerOpenDistance)
    self.values.triggerCloseDistance = num("triggerCloseDistance", DEFAULTS.triggerCloseDistance)
    self.values.triggerSideDistance = num("triggerSideDistance", DEFAULTS.triggerSideDistance)
    self.values.safetyDepth = num("safetyDepth", DEFAULTS.safetyDepth)
    self.values.safetyHalfWidth = num("safetyHalfWidth", DEFAULTS.safetyHalfWidth)
    local d = getXMLInt(xml, "smartGateSettings.geometry#safetyClearDelayMs")
    if d ~= nil then self.values.safetyClearDelayMs = d end
    local vis = getXMLBool(xml, "smartGateSettings.client#visualizationDefault")
    if vis ~= nil then self.values.visualizationDefault = vis == true end
    if g_dedicatedServer == nil then
        for _, key in ipairs({"panel","selector"}) do
            local x=getXMLFloat(xml,"smartGateSettings.client."..key.."#x")
            local y=getXMLFloat(xml,"smartGateSettings.client."..key.."#y")
            if type(x)=="number" and x==x and x>=0 and x<=1 and type(y)=="number" and y==y and y>=0 and y<=1 then
                self.uiPositions[key]={x=x,y=y}
            end
        end
    end
    delete(xml)
end

function SmartGateSettings:save()
    local path = self:getPath()
    if path == nil then return false end
    local xml = createXMLFile("smartGateGlobalSettings", path, "smartGateSettings")
    if xml == nil or xml == 0 then return false end
    setXMLFloat(xml, "smartGateSettings.geometry#triggerOpenDistance", self.values.triggerOpenDistance)
    setXMLFloat(xml, "smartGateSettings.geometry#triggerCloseDistance", self.values.triggerCloseDistance)
    setXMLFloat(xml, "smartGateSettings.geometry#triggerSideDistance", self.values.triggerSideDistance)
    setXMLFloat(xml, "smartGateSettings.geometry#safetyDepth", self.values.safetyDepth)
    setXMLFloat(xml, "smartGateSettings.geometry#safetyHalfWidth", self.values.safetyHalfWidth)
    setXMLInt(xml, "smartGateSettings.geometry#safetyClearDelayMs", self.values.safetyClearDelayMs)
    setXMLBool(xml, "smartGateSettings.client#visualizationDefault", self.values.visualizationDefault == true)
    if g_dedicatedServer == nil then
        for key,pos in pairs(self.uiPositions or {}) do
            if key=="panel" or key=="selector" then
                setXMLFloat(xml,"smartGateSettings.client."..key.."#x",pos.x)
                setXMLFloat(xml,"smartGateSettings.client."..key.."#y",pos.y)
            end
        end
    end
    saveXMLFile(xml)
    delete(xml)
    return true
end

function SmartGateSettings:applyGeometryOnServer()
    if g_server == nil or self.owner == nil then return false end
    local applied = 0
    for _, gate in ipairs(self.owner.gates or {}) do
        if gate.customGeometry ~= true then
            gate.triggerOpenDistance = self.values.triggerOpenDistance
            gate.triggerOpenHalfWidth = self.values.triggerSideDistance
            gate.triggerCloseDistance = self.values.triggerCloseDistance
            gate.triggerCloseHalfWidth = self.values.triggerSideDistance
            gate.triggerSideDistance = self.values.triggerSideDistance
            gate.safetyDepth = self.values.safetyDepth
            gate.safetyHalfWidth = self.values.safetyHalfWidth
            gate.safetyClearDelayMs = self.values.safetyClearDelayMs
            self.owner.savedGateSettings[gate.id] = {
                triggerOpenDistance=gate.triggerOpenDistance,
                triggerOpenHalfWidth=gate.triggerOpenHalfWidth,
                triggerCloseDistance=gate.triggerCloseDistance,
                triggerCloseHalfWidth=gate.triggerCloseHalfWidth,
                triggerSideDistance=gate.triggerSideDistance,
                safetyDepth=gate.safetyDepth,
                safetyHalfWidth=gate.safetyHalfWidth,
                configDepth=gate.configDepth,
                configHalfWidth=gate.configHalfWidth,
                axisSwapped=gate.axisSwapped == true,
                animationInverted=gate.animationInverted == true,
                objectType=gate.objectType or 0,
                safetyClearDelayMs=gate.safetyClearDelayMs
            }
            applied = applied + 1
        end
    end
    self.owner:saveConfig()
    if SmartGateStateSyncEvent ~= nil then SmartGateStateSyncEvent.sendToClients(self.owner.gates) end
    print(string.format("[SmartGate][SETTINGS] applied global geometry to %d non-custom gate(s)", applied))
    return true
end

function SmartGateSettings:sendGeometryToServer()
    if g_server ~= nil then
        self:applyGeometryOnServer()
    elseif g_client ~= nil and g_client.getServerConnection ~= nil then
        g_client:getServerConnection():sendEvent(SmartGateGlobalSettingsEvent.new(self.values))
    end
end

function SmartGateSettings:setValue(name, value, geometry)
    if name=="newGatesEnabled" then
        local service=self.owner~=nil and self.owner.serviceInfrastructure
        if service~=nil then service:request("NEW_GATE_DEFAULT",nil,value and 1 or 0) end
        if self.newGateControl~=nil then self.newGateControl:setState(self.owner.newGatesEnabled~=false and 2 or 1,false) end
        return
    end
    if name=="discoveryAutoConfigure" then
        local d=self.owner~=nil and self.owner.interactionDiscovery
        if d~=nil then d:request(value and "AUTO_ON" or "AUTO_OFF") end
        return
    end
    self.values[name] = value
    if name == "visualizationDefault" and self.owner ~= nil then
        self.owner.showZonesAlways = value == true
    end
    self:save()
    if geometry then self:sendGeometryToServer() end
    print(string.format("[SmartGate][SETTINGS] %s -> %s", tostring(name), tostring(value)))
end

function SmartGateSettings:createSection(layout)
    local template = findSectionTemplate(layout)
    if template == nil then return nil end
    local section = template:clone(layout)
    section.id = nil
    if section.setText ~= nil then section:setText(safeI18n("SmartGate_settingsGroup", "Agriculture Science – SmartGate")) end
    layout:addElement(section)
    return section
end

function SmartGateSettings:createMulti(layout, labelKey, labelFallback, tooltipKey, tooltipFallback, values, labels, current, field)
    local template = findRowTemplate(layout, "multi")
    if template == nil then return nil end
    local row = template:clone(layout)
    row.id = nil
    local opt, lbl = row.elements[1], row.elements[2]
    if opt == nil then return nil end
    opt.id = nil; opt.target = layout.asTemplates ~= nil and layout.target or nil
    if lbl ~= nil then lbl.id = nil end
    if opt.setTexts ~= nil then opt:setTexts(labels) end
    local state = nearestIndex(values, current)
    if opt.setState ~= nil then opt:setState(state, false) end
    opt.onClickCallback = function(first, second, element)
        local newState = opt.target ~= nil and first == opt.target and second or first
        local idx = math.max(1, math.min(#values, tonumber(newState) or 1))
        self:setValue(field, values[idx], true)
    end
    if lbl ~= nil and lbl.setText ~= nil then lbl:setText(safeI18n(labelKey, labelFallback)) end
    setTooltip(row, opt, lbl, safeI18n(tooltipKey, tooltipFallback))
    layout:addElement(row)
    return opt
end

function SmartGateSettings:createBinary(layout, labelKey, labelFallback, tooltipKey, tooltipFallback, current, field)
    local template = findRowTemplate(layout, "binary")
    if template == nil then return nil end
    local row = template:clone(layout)
    row.id = nil
    local opt, lbl = row.elements[1], row.elements[2]
    if opt == nil then return nil end
    opt.id = nil; opt.target = layout.asTemplates ~= nil and layout.target or nil
    if lbl ~= nil then lbl.id = nil end
    opt.onClickCallback = function(first, second, element)
        local newState = opt.target ~= nil and first == opt.target and second or first
        local enabled = (newState == 2) or (CheckedOptionElement ~= nil and newState == CheckedOptionElement.STATE_CHECKED)
        self:setValue(field, enabled, false)
    end
    if lbl ~= nil and lbl.setText ~= nil then lbl:setText(safeI18n(labelKey, labelFallback)) end
    setTooltip(row, opt, lbl, safeI18n(tooltipKey, tooltipFallback))
    layout:addElement(row)
    if opt.setState ~= nil then opt:setState(current and 2 or 1, false) end
    if opt.setIsChecked ~= nil then opt:setIsChecked(current == true, true) end
    return opt
end

function SmartGateSettings:confirmPreOpenRecalculation()
    local s=self.owner~=nil and self.owner.serviceInfrastructure
    if s==nil or YesNoDialog==nil or type(YesNoDialog.show)~="function" then return end
    local mission,epoch,revision=g_currentMission,s.epoch,s.configRevision
    local de=tostring(g_languageShort or "en"):sub(1,2)=="de"
    YesNoDialog.show(function(_,yes)
        if yes and self.owner.serviceInfrastructure==s and not s.disposed and g_currentMission==mission and s.epoch==epoch and s.configRevision==revision then
            s:request("PREOPEN_AUTO_ALL")
        end
    end,self,de and "AD-Voröffnungen automatisch berechnen?\n\nNormale Tore werden auf Automatik (50 km/h und 2 s Reserve) umgestellt. Manuelle Ausnahmen bleiben erhalten. Ohne verlässliche Animationsdauer gelten 55 m. Aktivierung und Blacklist bleiben unverändert."
        or "Calculate AD pre-opening automatically?\n\nNormal gates switch to automatic (50 km/h and a 2 s margin). Manual overrides are retained. Unknown animation duration falls back to 55 m. Activation and blacklist remain unchanged.")
end
function SmartGateSettings:createDiscoveryButton(layout,kind)
    local template=findRowTemplate(layout,"multi")
    local native=layout.asTemplates~=nil and layout.asTemplates.button
    if template==nil or native==nil then return nil end
    local row=template:clone(layout); row.id=nil
    local old=row.elements[1]; local label=row.elements[2]
    local position={old.position[1],old.position[2]}; local size={old.size[1],old.size[2]}
    local anchors=old.anchors~=nil and {unpack(old.anchors)} or {1,1,.5,.5}
    local pivot=old.pivot~=nil and {unpack(old.pivot)} or {1,.5}
    old:delete()
    local button=native:clone(row); button.target=layout.target; button.id=nil
    button.anchors=anchors; button.pivot=pivot; button.anchorDeltas={}
    button.fitToContent=false
    button.textAutoWidth,button.textAutoHeight=false,false
    if button.setSelected~=nil then button:setSelected(false) end
    if button.setDisabled~=nil then button:setDisabled(false) end
    if button.setPosition~=nil then button:setPosition(position[1],position[2]) end
    if button.setSize~=nil then button:setSize(size[1],size[2]) end
    local de=tostring(g_languageShort or "en"):sub(1,2)=="de"
    if kind=="preopen" then
        if label~=nil then label:setText(de and "AD-Voröffnungen automatisch berechnen" or "Calculate AD pre-opening automatically") end
        button:setText(de and "Berechnen…" or "Calculate…")
        button.onClickCallback=function() self:confirmPreOpenRecalculation() end
        setTooltip(row,button,label,de and "Einmalige Sammelaktion mit Bestätigung. Manuelle Torwerte bleiben erhalten. Nur Serveradministrator." or "One-time action with confirmation. Manual gate overrides are retained. Server administrator only.")
    else
        if label~=nil then label:setText(de and "Interaktions-Discovery" or "Interaction discovery") end
        button:setText(de and "Vorschau erneut öffnen" or "Reopen preview")
        button.onClickCallback=function() local d=self.owner~=nil and self.owner.interactionDiscovery; if d~=nil then d:request("OPEN") end end
        setTooltip(row,button,label,de and "Persistierte Kandidaten erneut prüfen. Keine Ausführung durch Vorkonfiguration." or "Review persisted candidates. Preconfiguration does not execute actions.")
    end
    layout:addElement(row); return button
end

function SmartGateSettings:tryInject()
    local host = AgricultureScienceSettings
    local layout = host ~= nil and host.getLayout("LEGS", self) or nil
    if layout == nil then
        return false
    end
    if self.injectedLayout == layout then return true end
    layout = host.beginSection("LEGS", self)
    if layout == nil then return false end
    local ok, result = pcall(function()
        if self:createSection(layout) == nil then
            print("[SmartGate][SETTINGS] injection failed: section template not found")
            return false
        end

        local created = 0
        if self:createMulti(layout, "SmartGate_settingOpen", "SmartGate: Öffnungsdistanz", "SmartGate_settingOpenTip", "Distanz vor/hinter dem Tor, ab der ein geschlossenes Tor geöffnet wird.", OPEN_CHOICES, labelsMeters(OPEN_CHOICES), self.values.triggerOpenDistance, "triggerOpenDistance") ~= nil then created = created + 1 end
        if self:createMulti(layout, "SmartGate_settingClose", "SmartGate: Schließdistanz", "SmartGate_settingCloseTip", "Hysterese-Distanz, bis zu der ein bereits geöffnetes Tor offen gehalten wird.", CLOSE_CHOICES, labelsMeters(CLOSE_CHOICES), self.values.triggerCloseDistance, "triggerCloseDistance") ~= nil then created = created + 1 end
        if self:createMulti(layout, "SmartGate_settingSide", "SmartGate: Triggerbreite", "SmartGate_settingSideTip", "Seitliche halbe Breite des Fahrzeug-/Personen-Triggers.", SIDE_CHOICES, labelsMeters(SIDE_CHOICES), self.values.triggerSideDistance, "triggerSideDistance") ~= nil then created = created + 1 end
        if self:createMulti(layout, "SmartGate_settingSafetyDepth", "SmartGate: Safety-Tiefe", "SmartGate_settingSafetyDepthTip", "Halbe Tiefe der Safety-Zone, die ein Schließen bei Hindernissen verhindert.", SAFETY_DEPTH_CHOICES, labelsMeters(SAFETY_DEPTH_CHOICES), self.values.safetyDepth, "safetyDepth") ~= nil then created = created + 1 end
        if self:createMulti(layout, "SmartGate_settingSafetyWidth", "SmartGate: Safety-Breite", "SmartGate_settingSafetyWidthTip", "Halbe Breite der Safety-Zone.", SAFETY_WIDTH_CHOICES, labelsMeters(SAFETY_WIDTH_CHOICES), self.values.safetyHalfWidth, "safetyHalfWidth") ~= nil then created = created + 1 end
        if self:createMulti(layout, "SmartGate_settingSafetyDelay", "SmartGate: Safety-Verzögerung", "SmartGate_settingSafetyDelayTip", "Wartezeit nach dem Freiwerden der Safety-Zone, bevor das Tor schließen darf.", DELAY_CHOICES, labelsDelay(DELAY_CHOICES), self.values.safetyClearDelayMs, "safetyClearDelayMs") ~= nil then created = created + 1 end
        if self:createBinary(layout, "SmartGate_settingVisualization", "SmartGate: Visualisierung standardmäßig", "SmartGate_settingVisualizationTip", "Zeigt den ausgewählten Trigger außerhalb des Config-Modus standardmäßig an. Im Config-Modus bleibt die Visualisierung immer aktiv.", self.values.visualizationDefault, "visualizationDefault") ~= nil then created = created + 1 end

        local de=tostring(g_languageShort or "en"):sub(1,2)=="de"
        local d=self.owner~=nil and self.owner.interactionDiscovery
        self.discoveryAutoControl=self:createBinary(layout,"SmartGate_discoveryAuto",de and "Neue Interaktionspunkte automatisch vorkonfigurieren" or "Automatically preconfigure new interaction points",
            "SmartGate_discoveryAutoTip",de and "Serverweite Option, standardmäßig AUS. Nur neue Gebäude prüfen; keine automatische Ausführung." or "Server option, OFF by default. Inspect new buildings only; never execute automatically.",d~=nil and d.auto==true,"discoveryAutoConfigure")
        if self.discoveryAutoControl~=nil then created=created+1 end
        if self:createDiscoveryButton(layout)~=nil then created=created+1 end
        if self:createDiscoveryButton(layout,"preopen")~=nil then created=created+1 end
        self.newGateControl=self:createBinary(layout,"SmartGate_newGatesEnabled",de and "Neue Tore standardmäßig aktivieren" or "Enable new gates by default",
            "SmartGate_newGatesEnabledTip",de and "Serverweite Vorgabe nur für neue Tore. Bestehende Torzustände bleiben erhalten." or "Server default for new gates only. Existing gate states remain unchanged.",self.owner.newGatesEnabled~=false,"newGatesEnabled")
        if self.newGateControl~=nil then created=created+1 end
        if created ~= 11 then
            print("[SmartGate][SETTINGS] injection failed: no compatible setting-row template found")
            return false
        end

        pcall(function() layout:invalidateLayout(true) end)
        pcall(function() layout:updateAbsolutePosition() end)
        self.injectedLayout = layout
        print(string.format("[SmartGate][SETTINGS] Agriculture Science section ready (%d/11 rows)", created))
        return true
    end)
    host.finishSection("LEGS", self, ok and result == true)
    if not ok or result ~= true then
        self.injectedLayout = nil
        print("[SmartGate][SETTINGS] section creation deferred: " .. tostring(result))
        return false
    end
    return true
end

function SmartGateSettings:update(dt)
    self.retryTimer = self.retryTimer + (dt or 0)
    if self.retryTimer < 500 then return end
    self.retryTimer = 0
    local layout = AgricultureScienceSettings ~= nil and AgricultureScienceSettings.getLayout("LEGS", self) or nil
    if layout ~= nil and self.injectedLayout ~= layout then
        self:tryInject()
    end
end

function SmartGateSettings:onLoadMap()
    self.injectedLayout = nil
    self.retryTimer = 0
    self:load()
    if self.owner ~= nil then self.owner.showZonesAlways = self.values.visualizationDefault == true end
    if g_server ~= nil then self:applyGeometryOnServer() end
end

-- Server-authoritative geometry update request.
SmartGateGlobalSettingsEvent = {}
local SmartGateGlobalSettingsEvent_mt = Class(SmartGateGlobalSettingsEvent, Event)
InitEventClass(SmartGateGlobalSettingsEvent, "SmartGateGlobalSettingsEvent")
function SmartGateGlobalSettingsEvent.emptyNew() return Event.new(SmartGateGlobalSettingsEvent_mt) end
function SmartGateGlobalSettingsEvent.new(values)
    local self = SmartGateGlobalSettingsEvent.emptyNew()
    self.values = values or copyDefaults()
    return self
end
function SmartGateGlobalSettingsEvent:writeStream(streamId, connection)
    streamWriteFloat32(streamId, self.values.triggerOpenDistance or DEFAULTS.triggerOpenDistance)
    streamWriteFloat32(streamId, self.values.triggerCloseDistance or DEFAULTS.triggerCloseDistance)
    streamWriteFloat32(streamId, self.values.triggerSideDistance or DEFAULTS.triggerSideDistance)
    streamWriteFloat32(streamId, self.values.safetyDepth or DEFAULTS.safetyDepth)
    streamWriteFloat32(streamId, self.values.safetyHalfWidth or DEFAULTS.safetyHalfWidth)
    streamWriteUInt16(streamId, self.values.safetyClearDelayMs or DEFAULTS.safetyClearDelayMs)
end
function SmartGateGlobalSettingsEvent:readStream(streamId, connection)
    self.values = {
        triggerOpenDistance=streamReadFloat32(streamId),
        triggerCloseDistance=streamReadFloat32(streamId),
        triggerSideDistance=streamReadFloat32(streamId),
        safetyDepth=streamReadFloat32(streamId),
        safetyHalfWidth=streamReadFloat32(streamId),
        safetyClearDelayMs=streamReadUInt16(streamId),
        visualizationDefault=false
    }
    self:run(connection)
end
function SmartGateGlobalSettingsEvent:run(connection)
    if g_server ~= nil and connection ~= nil and not connection:getIsServer() and g_smartGate ~= nil and g_smartGate.settings ~= nil then
        local s = g_smartGate.settings
        s.values.triggerOpenDistance = self.values.triggerOpenDistance
        s.values.triggerCloseDistance = self.values.triggerCloseDistance
        s.values.triggerSideDistance = self.values.triggerSideDistance
        s.values.safetyDepth = self.values.safetyDepth
        s.values.safetyHalfWidth = self.values.safetyHalfWidth
        s.values.safetyClearDelayMs = self.values.safetyClearDelayMs
        s:save()
        s:applyGeometryOnServer()
    end
end

if g_smartGate ~= nil then
    g_smartGate.settings = SmartGateSettings.new(g_smartGate)

    -- Dedicated lifecycle listener. Do not rely on monkey-patching SmartGate's
    -- already-registered event-listener methods: on some FS25 load orders that
    -- leaves the settings updater dormant and the shared menu is never seen.
    SmartGateSettingsListener = SmartGateSettingsListener or {}

    function SmartGateSettingsListener:loadMap()
        if g_smartGate ~= nil and g_smartGate.settings ~= nil then
            g_smartGate.settings:onLoadMap()
            -- Immediate attempt for the common case; update() keeps retrying
            -- until the native GUI is available for our independent host.
            g_smartGate.settings:tryInject()
        end
    end

    function SmartGateSettingsListener:update(dt)
        if g_smartGate ~= nil and g_smartGate.settings ~= nil then
            g_smartGate.settings:update(dt)
        end
    end

    function SmartGateSettingsListener:deleteMap()
        if g_smartGate ~= nil and g_smartGate.settings ~= nil then
            g_smartGate.settings.injectedLayout = nil
            g_smartGate.settings.retryTimer = 0
        end
    end

    addModEventListener(SmartGateSettingsListener)
    print("[SmartGate][SETTINGS] dedicated settings lifecycle listener registered")
end
