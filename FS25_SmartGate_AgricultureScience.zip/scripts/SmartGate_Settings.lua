-- Smart Gate - Agriculture Science
-- Shared Enhanced Settings integration.
-- Uses the cross-mod InGameMenuSettingsFrame.ENHANCED_SETTINGS_LAYOUT convention.

SmartGateSettings = {}
local SmartGateSettings_mt = Class(SmartGateSettings)

local OPEN_CHOICES  = {6, 8, 10, 11, 12, 14, 16, 18, 20}
local CLOSE_CHOICES = {8, 10, 12, 14, 16, 18, 20, 22, 24}
local SIDE_CHOICES  = {3, 4, 5, 6, 7, 8}
local SAFETY_DEPTH_CHOICES = {2.5, 3.5, 4.5, 5.5, 6.5, 8}
local SAFETY_WIDTH_CHOICES = {2.5, 3.5, 4.5, 5.5, 6.5, 8}
local DELAY_CHOICES = {500, 1000, 1500, 1800, 2000, 2500, 3000, 4000, 5000}

local DEFAULTS = {
    triggerOpenDistance = 11.0,
    triggerCloseDistance = 14.0,
    triggerSideDistance = 5.0,
    safetyDepth = 4.5,
    safetyHalfWidth = 4.5,
    safetyClearDelayMs = 1800,
    visualizationDefault = false
}

local function safeI18n(key, fallback)
    if g_i18n ~= nil and g_i18n.getText ~= nil then
        local value = g_i18n:getText(key)
        if value ~= nil and value ~= "" and value ~= key then return value end
    end
    return fallback or key
end

local function copyDefaults()
    local t = {}
    for k, v in pairs(DEFAULTS) do t[k] = v end
    return t
end

local function nearestIndex(choices, value)
    value = tonumber(value)
    if value == nil then return 1 end
    local best, bestD = 1, math.huge
    for i, v in ipairs(choices) do
        local d = math.abs(v - value)
        if d < bestD then best, bestD = i, d end
    end
    return best
end

local function labelsMeters(values)
    local out = {}
    for _, v in ipairs(values) do out[#out+1] = string.format("%g m", v) end
    return out
end

local function labelsDelay(values)
    local out = {}
    for _, v in ipairs(values) do
        if v >= 1000 then out[#out+1] = string.format("%g s", v/1000) else out[#out+1] = tostring(v) .. " ms" end
    end
    return out
end

local function findRowTemplate(layout, wanted)
    if layout == nil or layout.elements == nil then return nil end
    for _, row in ipairs(layout.elements) do
        if row ~= nil and row.elements ~= nil and #row.elements >= 2 then
            local control = row.elements[1]
            if control ~= nil then
                if wanted == "binary" and (control.profile == "fs25_settingsBinaryOption" or (control.id ~= nil and string.find(control.id, "check"))) then
                    return row
                elseif wanted == "multi" and (control.profile == "fs25_settingsMultiTextOption" or (control.id ~= nil and string.find(control.id, "multi"))) then
                    return row
                end
            end
        end
    end
    return nil
end

local function findSectionTemplate(layout)
    if layout == nil or layout.elements == nil then return nil end
    for _, element in ipairs(layout.elements) do
        if element ~= nil and element.name == "sectionHeader" then return element end
    end
    return nil
end

local function setTooltip(row, opt, lbl, text)
    text = text or ""
    if opt ~= nil then
        opt.toolTipText = text
        if opt.setToolTipText ~= nil then opt:setToolTipText(text) end
        if opt.elements ~= nil and opt.elements[1] ~= nil and opt.elements[1].setText ~= nil then opt.elements[1]:setText(text) end
    end
    if lbl ~= nil then
        lbl.toolTipText = text
        if lbl.setToolTipText ~= nil then lbl:setToolTipText(text) end
    end
    if row ~= nil then
        row.toolTipText = text
        if row.setToolTipText ~= nil then row:setToolTipText(text) end
    end
end

function SmartGateSettings.new(owner)
    local self = setmetatable({}, SmartGateSettings_mt)
    self.owner = owner
    self.values = copyDefaults()
    self.injectedLayout = nil
    self.retryTimer = 0
    self:load()
    return self
end

function SmartGateSettings:getPath()
    if getUserProfileAppPath == nil then return nil end
    local app = getUserProfileAppPath()
    if app == nil or app == "" then return nil end
    return app .. "modSettings/FS25_SmartGate_AgricultureScience.xml"
end

function SmartGateSettings:load()
    self.values = copyDefaults()
    local path = self:getPath()
    if path == nil or fileExists == nil or not fileExists(path) then return end
    local xml = loadXMLFile("smartGateGlobalSettings", path)
    if xml == nil or xml == 0 then return end
    local function num(attr, fallback)
        local v = getXMLFloat(xml, "smartGateSettings.geometry#" .. attr)
        return v ~= nil and v or fallback
    end
    self.values.triggerOpenDistance = num("triggerOpenDistance", DEFAULTS.triggerOpenDistance)
    self.values.triggerCloseDistance = num("triggerCloseDistance", DEFAULTS.triggerCloseDistance)
    self.values.triggerSideDistance = num("triggerSideDistance", DEFAULTS.triggerSideDistance)
    self.values.safetyDepth = num("safetyDepth", DEFAULTS.safetyDepth)
    self.values.safetyHalfWidth = num("safetyHalfWidth", DEFAULTS.safetyHalfWidth)
    local d = getXMLInt(xml, "smartGateSettings.geometry#safetyClearDelayMs")
    if d ~= nil then self.values.safetyClearDelayMs = d end
    local vis = getXMLBool(xml, "smartGateSettings.client#visualizationDefault")
    if vis ~= nil then self.values.visualizationDefault = vis == true end
    delete(xml)
end

function SmartGateSettings:save()
    local path = self:getPath()
    if path == nil then return false end
    local xml = createXMLFile("smartGateGlobalSettings", path, "smartGateSettings")
    if xml == nil or xml == 0 then return false end
    setXMLFloat(xml, "smartGateSettings.geometry#triggerOpenDistance", self.values.triggerOpenDistance)
    setXMLFloat(xml, "smartGateSettings.geometry#triggerCloseDistance", self.values.triggerCloseDistance)
    setXMLFloat(xml, "smartGateSettings.geometry#triggerSideDistance", self.values.triggerSideDistance)
    setXMLFloat(xml, "smartGateSettings.geometry#safetyDepth", self.values.safetyDepth)
    setXMLFloat(xml, "smartGateSettings.geometry#safetyHalfWidth", self.values.safetyHalfWidth)
    setXMLInt(xml, "smartGateSettings.geometry#safetyClearDelayMs", self.values.safetyClearDelayMs)
    setXMLBool(xml, "smartGateSettings.client#visualizationDefault", self.values.visualizationDefault == true)
    saveXMLFile(xml)
    delete(xml)
    return true
end

function SmartGateSettings:applyGeometryOnServer()
    if g_server == nil or self.owner == nil then return false end
    for _, gate in ipairs(self.owner.gates or {}) do
        gate.triggerOpenDistance = self.values.triggerOpenDistance
        gate.triggerCloseDistance = self.values.triggerCloseDistance
        gate.triggerSideDistance = self.values.triggerSideDistance
        gate.safetyDepth = self.values.safetyDepth
        gate.safetyHalfWidth = self.values.safetyHalfWidth
        gate.safetyClearDelayMs = self.values.safetyClearDelayMs
        self.owner.savedGateSettings[gate.id] = {
            triggerOpenDistance=gate.triggerOpenDistance,
            triggerCloseDistance=gate.triggerCloseDistance,
            triggerSideDistance=gate.triggerSideDistance,
            safetyDepth=gate.safetyDepth,
            safetyHalfWidth=gate.safetyHalfWidth,
            safetyClearDelayMs=gate.safetyClearDelayMs
        }
    end
    self.owner:saveConfig()
    if SmartGateStateSyncEvent ~= nil then SmartGateStateSyncEvent.sendToClients(self.owner.gates) end
    print(string.format("[SmartGate][SETTINGS] applied global geometry to %d gate(s)", #(self.owner.gates or {})))
    return true
end

function SmartGateSettings:sendGeometryToServer()
    if g_server ~= nil then
        self:applyGeometryOnServer()
    elseif g_client ~= nil and g_client.getServerConnection ~= nil then
        g_client:getServerConnection():sendEvent(SmartGateGlobalSettingsEvent.new(self.values))
    end
end

function SmartGateSettings:setValue(name, value, geometry)
    self.values[name] = value
    if name == "visualizationDefault" and self.owner ~= nil then
        self.owner.showZonesAlways = value == true
    end
    self:save()
    if geometry then self:sendGeometryToServer() end
    print(string.format("[SmartGate][SETTINGS] %s -> %s", tostring(name), tostring(value)))
end

function SmartGateSettings:createSection(layout)
    local template = findSectionTemplate(layout)
    if template == nil then return nil end
    local section = template:clone(layout)
    section.id = nil
    if section.setText ~= nil then section:setText(safeI18n("SmartGate_settingsGroup", "Agriculture Science – SmartGate")) end
    layout:addElement(section)
    return section
end

function SmartGateSettings:createMulti(layout, labelKey, labelFallback, tooltipKey, tooltipFallback, values, labels, current, field)
    local template = findRowTemplate(layout, "multi")
    if template == nil then return nil end
    local row = template:clone(layout)
    row.id = nil
    local opt, lbl = row.elements[1], row.elements[2]
    if opt == nil then return nil end
    opt.id = nil; opt.target = nil
    if lbl ~= nil then lbl.id = nil end
    if opt.setTexts ~= nil then opt:setTexts(labels) end
    local state = nearestIndex(values, current)
    if opt.setState ~= nil then opt:setState(state, false) end
    opt.onClickCallback = function(newState, element)
        local idx = math.max(1, math.min(#values, tonumber(newState) or 1))
        self:setValue(field, values[idx], true)
    end
    if lbl ~= nil and lbl.setText ~= nil then lbl:setText(safeI18n(labelKey, labelFallback)) end
    setTooltip(row, opt, lbl, safeI18n(tooltipKey, tooltipFallback))
    layout:addElement(row)
    return opt
end

function SmartGateSettings:createBinary(layout, labelKey, labelFallback, tooltipKey, tooltipFallback, current, field)
    local template = findRowTemplate(layout, "binary")
    if template == nil then return nil end
    local row = template:clone(layout)
    row.id = nil
    local opt, lbl = row.elements[1], row.elements[2]
    if opt == nil then return nil end
    opt.id = nil; opt.target = nil
    if lbl ~= nil then lbl.id = nil end
    opt.onClickCallback = function(newState, element)
        local enabled = (newState == 2) or (CheckedOptionElement ~= nil and newState == CheckedOptionElement.STATE_CHECKED)
        self:setValue(field, enabled, false)
    end
    if lbl ~= nil and lbl.setText ~= nil then lbl:setText(safeI18n(labelKey, labelFallback)) end
    setTooltip(row, opt, lbl, safeI18n(tooltipKey, tooltipFallback))
    layout:addElement(row)
    if opt.setState ~= nil then opt:setState(current and 2 or 1, false) end
    if opt.setIsChecked ~= nil then opt:setIsChecked(current == true, true) end
    return opt
end

function SmartGateSettings:tryInject()
    if InGameMenuSettingsFrame == nil then return false end
    local layout = InGameMenuSettingsFrame.ENHANCED_SETTINGS_LAYOUT
    if layout == nil then return false end
    if self.injectedLayout == layout then return true end

    if self:createSection(layout) == nil then return false end
    self:createMulti(layout, "SmartGate_settingOpen", "SmartGate: Öffnungsdistanz", "SmartGate_settingOpenTip", "Distanz vor/hinter dem Tor, ab der ein geschlossenes Tor geöffnet wird.", OPEN_CHOICES, labelsMeters(OPEN_CHOICES), self.values.triggerOpenDistance, "triggerOpenDistance")
    self:createMulti(layout, "SmartGate_settingClose", "SmartGate: Schließdistanz", "SmartGate_settingCloseTip", "Hysterese-Distanz, bis zu der ein bereits geöffnetes Tor offen gehalten wird.", CLOSE_CHOICES, labelsMeters(CLOSE_CHOICES), self.values.triggerCloseDistance, "triggerCloseDistance")
    self:createMulti(layout, "SmartGate_settingSide", "SmartGate: Triggerbreite", "SmartGate_settingSideTip", "Seitliche halbe Breite des Fahrzeug-/Personen-Triggers.", SIDE_CHOICES, labelsMeters(SIDE_CHOICES), self.values.triggerSideDistance, "triggerSideDistance")
    self:createMulti(layout, "SmartGate_settingSafetyDepth", "SmartGate: Safety-Tiefe", "SmartGate_settingSafetyDepthTip", "Halbe Tiefe der Safety-Zone, die ein Schließen bei Hindernissen verhindert.", SAFETY_DEPTH_CHOICES, labelsMeters(SAFETY_DEPTH_CHOICES), self.values.safetyDepth, "safetyDepth")
    self:createMulti(layout, "SmartGate_settingSafetyWidth", "SmartGate: Safety-Breite", "SmartGate_settingSafetyWidthTip", "Halbe Breite der Safety-Zone.", SAFETY_WIDTH_CHOICES, labelsMeters(SAFETY_WIDTH_CHOICES), self.values.safetyHalfWidth, "safetyHalfWidth")
    self:createMulti(layout, "SmartGate_settingSafetyDelay", "SmartGate: Safety-Verzögerung", "SmartGate_settingSafetyDelayTip", "Wartezeit nach dem Freiwerden der Safety-Zone, bevor das Tor schließen darf.", DELAY_CHOICES, labelsDelay(DELAY_CHOICES), self.values.safetyClearDelayMs, "safetyClearDelayMs")
    self:createBinary(layout, "SmartGate_settingVisualization", "SmartGate: Visualisierung standardmäßig", "SmartGate_settingVisualizationTip", "Zeigt den ausgewählten Trigger außerhalb des Config-Modus standardmäßig an. Im Config-Modus bleibt die Visualisierung immer aktiv.", self.values.visualizationDefault, "visualizationDefault")

    pcall(function() layout:invalidateLayout(true) end)
    pcall(function() layout:updateAbsolutePosition() end)
    self.injectedLayout = layout
    print("[SmartGate][SETTINGS] injected into shared Enhanced Settings tab")
    return true
end

function SmartGateSettings:update(dt)
    self.retryTimer = self.retryTimer + (dt or 0)
    if self.retryTimer < 500 then return end
    self.retryTimer = 0
    if InGameMenuSettingsFrame ~= nil and self.injectedLayout ~= InGameMenuSettingsFrame.ENHANCED_SETTINGS_LAYOUT then
        self:tryInject()
    end
end

function SmartGateSettings:onLoadMap()
    self.injectedLayout = nil
    self.retryTimer = 0
    self:load()
    if self.owner ~= nil then self.owner.showZonesAlways = self.values.visualizationDefault == true end
    if g_server ~= nil then self:applyGeometryOnServer() end
end

-- Server-authoritative geometry update request.
SmartGateGlobalSettingsEvent = {}
local SmartGateGlobalSettingsEvent_mt = Class(SmartGateGlobalSettingsEvent, Event)
InitEventClass(SmartGateGlobalSettingsEvent, "SmartGateGlobalSettingsEvent")
function SmartGateGlobalSettingsEvent.emptyNew() return Event.new(SmartGateGlobalSettingsEvent_mt) end
function SmartGateGlobalSettingsEvent.new(values)
    local self = SmartGateGlobalSettingsEvent.emptyNew()
    self.values = values or copyDefaults()
    return self
end
function SmartGateGlobalSettingsEvent:writeStream(streamId, connection)
    streamWriteFloat32(streamId, self.values.triggerOpenDistance or DEFAULTS.triggerOpenDistance)
    streamWriteFloat32(streamId, self.values.triggerCloseDistance or DEFAULTS.triggerCloseDistance)
    streamWriteFloat32(streamId, self.values.triggerSideDistance or DEFAULTS.triggerSideDistance)
    streamWriteFloat32(streamId, self.values.safetyDepth or DEFAULTS.safetyDepth)
    streamWriteFloat32(streamId, self.values.safetyHalfWidth or DEFAULTS.safetyHalfWidth)
    streamWriteUInt16(streamId, self.values.safetyClearDelayMs or DEFAULTS.safetyClearDelayMs)
end
function SmartGateGlobalSettingsEvent:readStream(streamId, connection)
    self.values = {
        triggerOpenDistance=streamReadFloat32(streamId),
        triggerCloseDistance=streamReadFloat32(streamId),
        triggerSideDistance=streamReadFloat32(streamId),
        safetyDepth=streamReadFloat32(streamId),
        safetyHalfWidth=streamReadFloat32(streamId),
        safetyClearDelayMs=streamReadUInt16(streamId),
        visualizationDefault=false
    }
    self:run(connection)
end
function SmartGateGlobalSettingsEvent:run(connection)
    if g_server ~= nil and connection ~= nil and not connection:getIsServer() and g_smartGate ~= nil and g_smartGate.settings ~= nil then
        local s = g_smartGate.settings
        s.values.triggerOpenDistance = self.values.triggerOpenDistance
        s.values.triggerCloseDistance = self.values.triggerCloseDistance
        s.values.triggerSideDistance = self.values.triggerSideDistance
        s.values.safetyDepth = self.values.safetyDepth
        s.values.safetyHalfWidth = self.values.safetyHalfWidth
        s.values.safetyClearDelayMs = self.values.safetyClearDelayMs
        s:save()
        s:applyGeometryOnServer()
    end
end

if g_smartGate ~= nil then
    g_smartGate.settings = SmartGateSettings.new(g_smartGate)
    SmartGate.update = Utils.appendedFunction(SmartGate.update, function(self, dt)
        if self.settings ~= nil then self.settings:update(dt) end
    end)
    SmartGate.loadMap = Utils.appendedFunction(SmartGate.loadMap, function(self)
        if self.settings ~= nil then self.settings:onLoadMap() end
    end)
end
