-- One small native text dialog, shared by service names and the AD list filter.
-- No gameplay data lives here; the existing service requests validate changes.
SGServiceTextDialog={}
local D=SGServiceTextDialog
local directory=g_currentModDirectory or ""
local function tr(de,en) return tostring(g_languageShort or "en"):sub(1,2)=="de" and de or en end
function D.open(title,value,callback,owner)
    if g_dedicatedServer~=nil or g_gui==nil or DialogElement==nil or type(g_gui.loadGui)~="function" or type(g_gui.showDialog)~="function" then return false end
    if D.instance==nil then
        D.mt=Class(D,DialogElement)
        local dialog=DialogElement.new(nil,D.mt)
        -- Gui:loadGui exposes XML IDs through FrameElement:exposeControlsAsFields.
        -- LS25 has no registerControls method on this class.
        local ok,result=pcall(g_gui.loadGui,g_gui,directory.."gui/SG_ServiceTextDialog.xml","ASServiceTextDialog",dialog)
        if not ok or result==nil then return false end
        D.instance=dialog
    end
    local d=D.instance
    if d.callback~=nil then return false end
    d.callback,d.owner,d.dialogTitle,d.initialValue=callback,owner,title,value or ""
    if owner~=nil and owner.configCursorOwned==true then
        d.restoreCursorOwner=owner;owner:setConfigCursorEnabled(false)
    end
    g_gui:showDialog("ASServiceTextDialog")
    return true
end
function D:onOpen()
    DialogElement.onOpen(self)
    self.title:setText(self.dialogTitle)
    self.input:setText(self.initialValue)
    self.accept:setText(tr("Übernehmen","Apply"));self.cancel:setText(tr("Abbrechen","Cancel"))
    if FocusManager~=nil and type(FocusManager.setFocus)=="function" then FocusManager:setFocus(self.input) end
end
function D:onClickAccept()
    local value=self.input:getText()
    if type(value)~="string" or #value>64 or value:find("[%c]") then
        self.title:setText(tr("Maximal 64 Bytes; keine Steuerzeichen","Maximum 64 bytes; no control characters"));return
    end
    local callback=self.callback
    self:close()
    if callback~=nil then callback(value:match("^%s*(.-)%s*$")) end
end
function D:onClose()
    local restore=self.restoreCursorOwner;self.restoreCursorOwner=nil
    self.callback,self.owner=nil,nil
    DialogElement.onClose(self)
    if restore~=nil then restore.serviceDialogRestoreCursor=true end
end
function D.cancel(owner)
    if D.instance~=nil and D.instance.owner==owner then D.instance:close() end
end
