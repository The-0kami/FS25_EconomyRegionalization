-- One small native text dialog, shared by service names and the AD list filter.
-- No gameplay data lives here; the existing service requests validate changes.
SGServiceTextDialog={}
local D=SGServiceTextDialog
local directory=g_currentModDirectory or ""
local function tr(de,en) return tostring(g_languageShort or "en"):sub(1,2)=="de" and de or en end
local function blocked(reason,detail)
    D.lastError=reason
    print("[SmartGate][SERVICE][DIALOG] event=BLOCKED reason="..reason.." detail="..tostring(detail or "-"):gsub("[%c]"," "):sub(1,500))
    return false,reason
end
function D.open(title,value,callback,owner,options)
    if g_dedicatedServer~=nil then return blocked("HEADLESS") end
    if g_gui==nil or DialogElement==nil or type(g_gui.loadGui)~="function" or type(g_gui.showDialog)~="function" then
        return blocked("GUI_UNAVAILABLE","gui="..tostring(g_gui~=nil).." dialogClass="..tostring(DialogElement~=nil))
    end
    if D.instance==nil then
        D.mt=Class(D,DialogElement)
        local dialog=DialogElement.new(nil,D.mt)
        -- Gui:loadGui exposes XML IDs through FrameElement:exposeControlsAsFields.
        -- LS25 has no registerControls method on this class.
        local ok,result=pcall(g_gui.loadGui,g_gui,directory.."gui/SG_ServiceTextDialog.xml","ASServiceTextDialog",dialog)
        if not ok or result==nil then return blocked("LOAD_FAILED",ok and directory.."gui/SG_ServiceTextDialog.xml" or result) end
        D.instance=dialog
    end
    local d=D.instance
    if d.callback~=nil then return blocked("DIALOG_BUSY") end
    for _,field in ipairs({"title","label","hint","input","accept","cancel"}) do
        if type(d[field])~="table" or type(d[field].setText)~="function" then return blocked("CONTROLS_MISSING",field) end
    end
    d.callback,d.owner,d.dialogTitle,d.initialValue=callback,owner,title,value or ""
    options=options or {}
    d.inputLabel=options.label or tr("Name eingeben:","Enter name:")
    d.acceptLabel=options.accept or tr("Übernehmen","Apply")
    d.hintText=options.hint or tr("Leer lassen für automatische Nummerierung.","Leave empty for automatic numbering.")
    if owner~=nil and owner.configCursorOwned==true then
        d.restoreCursorOwner=owner;owner:setConfigCursorEnabled(false)
    end
    d.dialogOpened=false
    local shown,result=pcall(g_gui.showDialog,g_gui,"ASServiceTextDialog")
    if not shown or not d.dialogOpened then
        pcall(d.close,d)
        -- A show failure may occur before the native close callback is active.
        local restore=d.restoreCursorOwner;d.restoreCursorOwner=nil;d.callback,d.owner=nil,nil
        if restore~=nil then restore.serviceDialogRestoreCursor=true end
        return blocked("SHOW_FAILED",shown and "onOpen not reached" or result)
    end
    D.lastError=nil
    return true
end
function D:onOpen()
    DialogElement.onOpen(self)
    self.title:setText(self.dialogTitle)
    self.label:setText(self.inputLabel)
    self.hint:setText(self.hintText)
    self.input:setText(self.initialValue)
    self.accept:setText(self.acceptLabel);self.cancel:setText(tr("Zurück","Back"))
    if FocusManager~=nil and type(FocusManager.setFocus)=="function" then FocusManager:setFocus(self.input) end
    if type(self.input.setForcePressed)=="function" then self.input:setForcePressed(true) end
    self.dialogOpened=true
    print("[SmartGate][SERVICE][DIALOG] event=OPENED client="..tostring(g_client~=nil).." server="..tostring(g_server~=nil))
end
function D:onClickAccept()
    local value=self.input:getText()
    if type(value)~="string" or #value>64 or value:find("[%c]") then
        self.hint:setText(tr("Maximal 64 Bytes; keine Steuerzeichen.","Maximum 64 bytes; no control characters."));return
    end
    local callback=self.callback
    self:close()
    if callback~=nil then callback(value:match("^%s*(.-)%s*$")) end
end
function D:onClose()
    self.dialogOpened=false
    local restore=self.restoreCursorOwner;self.restoreCursorOwner=nil
    self.callback,self.owner=nil,nil
    DialogElement.onClose(self)
    if restore~=nil then restore.serviceDialogRestoreCursor=true end
end
function D.cancel(owner)
    if D.instance~=nil and D.instance.owner==owner then D.instance:close() end
end
