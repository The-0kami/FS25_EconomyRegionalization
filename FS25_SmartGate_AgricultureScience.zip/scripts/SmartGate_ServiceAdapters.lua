-- Native service contracts. No vehicle-value writes, pricing replacement or
-- foreign source patches. Existing bays, leases and captured units remain owners.
local S=SGServiceInfrastructure
local TOKEN={}
local function finite(v) return type(v)=="number" and v==v and math.abs(v)<math.huge end
local function call(o,k,...)
    if o~=nil and type(o[k])=="function" then local ok,a,b=pcall(o[k],o,...);if ok then return a,b end end
end
local function energy(id)
    local info=call(g_fillTypeManager,"getFillTypeByIndex",id)
    local name=info and info.name
    if name==nil and FillType~=nil then for _,key in ipairs({"DIESEL","DEF","ELECTRICCHARGE","METHANE"}) do if FillType[key]==id then name=key end end end
    return name=="DIESEL" or name=="DEF" or name=="ELECTRICCHARGE" or name=="METHANE"
end
local function loadTriggers(owner)
    local station=call(owner,"getBuyingStation") or (owner.spec_buyingStation or {}).buyingStation
        or (owner.spec_silo or {}).loadingStation
    local result={}
    for _,trigger in ipairs(station~=nil and station.loadTriggers or {}) do
        local types=call(trigger.source,"getSupportedFillTypes")
        if type(types)=="table" and type(trigger.setIsLoading)=="function" and type(trigger.getAllowsActivation)=="function"
            and type(trigger.fillableObjects)=="table" then
            for fillType,supported in pairs(types) do
                if supported and energy(fillType) and (trigger.fillTypes==nil or trigger.fillTypes[fillType]) then result[#result+1]=trigger;break end
            end
        end
    end
    return result
end
function SmartGate:getServiceSourceCapabilities(source)
    if g_server==nil and source~=nil and source.serverTemplate==true then return source.capabilities end
    local owner=source and source.owner
    if owner==nil or owner.isDeleted or owner.isDeleting then return nil end
    local caps={WASH=false,REPAIR=false,REFUEL=false};local spec=owner.spec_automaticCarWash
    if type(spec)=="table" and type(owner.CleanCar)=="function" and type(owner.CleanOneVehicle)=="function"
        and type(spec.vehiclesInTrigger)=="table" and finite(spec.timerLength) and spec.timerLength>0 then
        caps.WASH=finite(spec.dirtAmount) and spec.dirtAmount<0
        caps.REPAIR=finite(spec.damageAmount) and spec.damageAmount<0
    end
    caps.REFUEL=#loadTriggers(owner)>0
    return (caps.WASH or caps.REPAIR or caps.REFUEL) and caps or nil
end
-- Public map fuel/charging stations remain public. A farm-owned provider may
-- reference them only when the native source explicitly permits that farm.
-- This is not permission to use another farm's tank or a public workshop.
function SmartGate:canUsePublicRefuelSource(source,farmId)
    local publicFarm=FarmManager~=nil and FarmManager.SPECTATOR_FARM_ID
    if g_server==nil or not finite(publicFarm) or not finite(farmId) or farmId<1 or farmId%1~=0
        or source==nil or call(source.owner,"getOwnerFarmId")~=publicFarm then return false end
    local caps=self:getServiceSourceCapabilities(source)
    if caps==nil or not caps.REFUEL or caps.WASH or caps.REPAIR then return false end
    for _,trigger in ipairs(loadTriggers(source.owner)) do
        if call(trigger.source,"getIsFillAllowedToFarm",farmId)==true then return true end
    end
    return false
end
-- Core gate IDs stay unchanged. New service bindings use persistent placeable
-- identity even before a second copy is built, so adding/removing a copy cannot
-- change a source's canonical identity. Unique legacy IDs remain readable.
function SmartGate:getServiceSourceId(gate)
    if gate==nil then return nil end
    if gate.serviceSynthetic then return gate.id end
    local uid=call(gate.owner,"getUniqueId")
    if type(uid)~="string" or uid=="" or uid:find("|",1,true) then
        return not self:hasGateIdCollision(gate.id) and gate.id or nil
    end
    local count=0
    for _,other in ipairs(self.gates or {}) do if other.id==gate.id and other.owner==gate.owner then count=count+1 end end
    local id="AS-GATE:"..uid.."|"..gate.id
    return count==1 and #id<=1024 and id or nil
end
function SmartGate:serviceCandidates()
    local s=self.serviceInfrastructure;if s==nil then return {} end
    if s.sourceCandidatesAt~=nil and s.clock-s.sourceCandidatesAt<10000 and s.sourceGateList==self.gates then return s.sourceCandidates or {} end
    local result,seen,owners={},{},{}
    for _,gate in ipairs(self.gates or {}) do
        if gate.objectType==1 and self:getServiceSourceCapabilities(gate)~=nil then
            local id=self:getServiceSourceId(gate)
            if id~=nil then
                local entry=id==gate.id and gate or setmetatable({id=id,runtimeGate=gate},{__index=gate})
                result[#result+1]=entry;seen[gate.owner]=true
            end
        end
    end
    local system=g_currentMission and g_currentMission.placeableSystem
    for _,owner in pairs(system~=nil and system.placeables or {}) do
        local uid=call(owner,"getUniqueId")
        if type(uid)=="string" then owners[uid]=owners[uid]==nil and owner or owners[uid]==owner and owner or false end
        if not seen[owner] then
            local id=uid
            local candidate={id=type(id)=="string" and "AS-SERVICE:"..id or nil,owner=owner,objectType=1,
                displayName=call(owner,"getName"),mode=1,serviceSynthetic=true}
            if candidate.id~=nil and #candidate.id<=1024 and self:getServiceSourceCapabilities(candidate)~=nil then
                result[#result+1]=candidate;seen[owner]=true
            end
        end
    end
    table.sort(result,function(a,b)return a.id<b.id end)
    s.sourceCandidates=result;s.sourceOwnersById=owners;s.sourceCandidatesAt=s.clock;s.sourceGateList=self.gates
    return result
end
function SmartGate:findServiceSource(id)
    if type(id)~="string" then return nil end
    local synced=self.serviceInfrastructure and self.serviceInfrastructure.serverSourceById
    if g_server==nil and synced~=nil then return synced[id] end
    if id:sub(1,11)=="AS-SERVICE:" then
        local uid=id:sub(12);local system=g_currentMission and g_currentMission.placeableSystem;local found
        if system~=nil and type(system.placableByUniqueId)=="table" then found=system.placableByUniqueId[uid]
        else
            self:serviceCandidates()
            local s=self.serviceInfrastructure;found=s and s.sourceOwnersById and s.sourceOwnersById[uid]
        end
        if found and call(found,"getUniqueId")==uid then return {id=id,owner=found,objectType=1,mode=1,serviceSynthetic=true,displayName=call(found,"getName")} end
        return nil
    end
    if id:sub(1,8)=="AS-GATE:" then
        local uid,gateId=id:match("^AS%-GATE:([^|]+)|(.+)$");local found
        for _,gate in ipairs(self.gates or {}) do
            if gate.id==gateId and call(gate.owner,"getUniqueId")==uid then
                if found~=nil then return nil end;found=gate
            end
        end
        return found
    end
    if self:hasGateIdCollision(id) then return nil end
    local gate=self:findGateById(id);if gate~=nil then return gate end
    for _,source in ipairs(self:serviceCandidates()) do if source.id==id then return source end end
end
local originalTemplate=SmartGate.getWashPointTemplate
function SmartGate:getWashPointTemplate(id)
    if g_server==nil then
        local synced=self.serviceInfrastructure and self.serviceInfrastructure.serverSourceById
        if synced~=nil then return synced[id] end
    end
    local source=self:findServiceSource(id);if source==nil then return nil end
    -- A tiny read-only facade passes the exact instance to the existing geometry
    -- function. It does not replace or hook the global/instance gate lookup.
    local target=id==source.id and self or setmetatable({findGateById=function()return source end},{__index=self})
    local old=originalTemplate(target,id)
    if old~=nil then old.capabilities={WASH=true,REPAIR=false,REFUEL=false};return old end
    local caps=self:getServiceSourceCapabilities(source)
    if source==nil or caps==nil or source.owner.rootNode==nil then return nil end
    local x,y,z=getWorldTranslation(source.owner.rootNode)
    local fx,_,fz=localDirectionToWorld(source.owner.rootNode,0,0,1)
    if not (finite(x) and finite(y) and finite(z) and finite(fx) and finite(fz)) then return nil end
    return {id=id,name=source.displayName or call(source.owner,"getName") or id,x=x,y=y,z=z,yaw=math.atan2(fx,fz),
        width=source.washWidth or 5,height=source.washHeight or 5,length=source.washLength or 12,
        farmId=call(source.owner,"getOwnerFarmId"),capabilities=caps}
end
-- Persistent Placeable uniqueIds are not an authoritative client/server wire
-- identity. Send server-selected, read-only templates over the existing state
-- event; edit requests still resolve and authorize the real source on server.
local function sourcePosition(source)
    if source~=nil and source.serverTemplate then return source.sourceX,source.sourceZ end
    local owner=source and source.owner;local spec=owner and owner.spec_automaticCarWash
    local node=spec and spec.triggerNode or owner and owner.rootNode
    if node~=nil then local x,_,z=getWorldTranslation(node);if finite(x) and finite(z) then return x,z end end
    return source and source.x,source and source.z
end
function S:sourceTemplateDTOs()
    if self.sourceTemplateCache~=nil and self.sourceTemplateCheckAt~=nil and self.clock-self.sourceTemplateCheckAt<1000
        and self.sourceTemplateGateList==self.owner.gates then return self.sourceTemplateCache end
    self.sourceTemplateCheckAt=self.clock;self.sourceTemplateGateList=self.owner.gates
    local result={}
    for _,source in ipairs(self.owner:serviceCandidates()) do
        local template=self.owner:getWashPointTemplate(source.id)
        if template~=nil and type(template.id)=="string" and #template.id>0 and #template.id<=1024 and not template.id:find("[%c]")
            and type(template.farmId)=="number" and template.farmId%1==0 and template.farmId>=0 and template.farmId<=65535 then
            local dto={id=template.id,name=tostring(template.name or ""):gsub("[%c]"," "):sub(1,64),farmId=template.farmId,capabilities={}}
            dto.sourceX,dto.sourceZ=sourcePosition(source)
            local valid=finite(dto.sourceX) and finite(dto.sourceZ) and math.abs(dto.sourceX)<=1000000 and math.abs(dto.sourceZ)<=1000000
            for _,key in ipairs({"x","y","z","yaw","width","height","length"}) do
                dto[key]=template[key];valid=valid and finite(dto[key]) and math.abs(dto[key])<=1000000
            end
            for _,cap in ipairs({"WASH","REPAIR","REFUEL"}) do dto.capabilities[cap]=template.capabilities[cap]==true end
            if valid and #result<512 then result[#result+1]=dto end
        end
    end
    local previous=self.sourceTemplateCache;local changed=previous==nil or #previous~=#result
    if not changed then for i,dto in ipairs(result) do
        local old=previous[i]
        for _,key in ipairs({"id","name","farmId","x","y","z","yaw","width","height","length","sourceX","sourceZ"}) do if old[key]~=dto[key] then changed=true end end
        for _,cap in ipairs({"WASH","REPAIR","REFUEL"}) do if old.capabilities[cap]~=dto.capabilities[cap] then changed=true end end
    end end
    if changed then self.sourceTemplateCache=result;self:changed() end
    return self.sourceTemplateCache or result
end
function S:serviceSourceInProvider(provider,source)
    if provider==nil then return true end
    local area=provider.area or provider.visualArea
    if type(area)~="table" then return false end
    for _,key in ipairs({"x","z","yaw","width","length"}) do if not finite(area[key]) then return false end end
    -- Source position must come from the native source, never from a currently
    -- linked bay's geometry (which could make a remote source appear local).
    local x,z=sourcePosition(source)
    if not finite(x) or not finite(z) then return false end
    local dx,dz=x-area.x,z-area.z;local c,s=math.cos(area.yaw),math.sin(area.yaw)
    return math.abs(dx*c-dz*s)<=area.width*.5+.05 and math.abs(dx*s+dz*c)<=area.length*.5+.05
end
local function resolve(id,vehicleId,service)
    local sg=g_smartGate;local s=sg and sg.serviceInfrastructure
    if g_server==nil or s==nil or s.disposed or not s.loaded or not s.persistenceSafe then return nil,"SERVICE_UNAVAILABLE" end
    local b=s.bays[id];local root=s.roots[vehicleId];local p=b and s.providers[b.providerId]
    local source=b and sg:findServiceSource(b.legacyWashGateId)
    local caps=sg:getServiceSourceCapabilities(source)
    if b==nil or p==nil or root==nil or not root.complete or not caps or not caps[service]
        or not b.capabilities[service] or b.operational~="OPEN" then return nil,"NO_SUPPORTED_SERVICE_BINDING" end
    if b.adTarget>0 and s:boundDestinationStatus(b)~="KNOWN" then return nil,"AD_TARGET_REASSIGN_REQUIRED" end
    if root.farmId~=p.farmId or (call(source.owner,"getOwnerFarmId")~=p.farmId
        and not (service=="REFUEL" and sg:canUsePublicRefuelSource(source,p.farmId))) then return nil,"SOURCE_OR_FARM_CHANGED" end
    if not s:serviceSourceInProvider(p,source) then return nil,"SOURCE_OUTSIDE_PROVIDER" end
    if source.blacklisted or source.mode==0 then return nil,"SOURCE_DISABLED" end
    local spec=source.owner.spec_automaticCarWash
    if service~="REFUEL" and (spec==nil or spec.initialized~=true) then return nil,"SOURCE_NOT_READY" end
    if service=="WASH" and b.serviceLift then return nil,"LIFT_REQUIRES_REPAIR_JOB" end
    local fields={b.id,b.providerId,b.legacyWashGateId,b.adTarget,b.x,b.y,b.z,b.yaw,b.width,b.height,b.length,b.operational,
        tostring(b.serviceLift==true),tostring(b.serviceInteraction==true),b.serviceLiftDelayMs or 0,service,tostring(source.animationInverted==true),
        spec and spec.damageAmount or 0,spec and spec.timerLength or 0}
    for i,value in ipairs(fields) do fields[i]=tostring(value) end
    return {sg=sg,s=s,b=b,root=root,source=source,spec=spec,service=service,signature=table.concat(fields,"|")}
end
local function ownLease(a,job,owner,epoch)
    local r=a.b.reservation
    return a.s.epoch==epoch and r~=nil and r.jobId==job and r.ownerId==owner and r.vehicleId==call(a.root.vehicle,"getUniqueId")
        and a.s.clock<r.expiresAt and a.s:admissionValid(a.b,r.vehicleId)
end
local function liftTime(token)
    local ao=token.source.animatedObject;local anim=ao and ao.animation
    if anim==nil or not finite(anim.time) or not finite(anim.direction) then return nil end
    local time=anim.time;if token.source.animationInverted then time=1-time end
    return time,anim.direction
end
local function moveLift(token,up)
    local time,direction=liftTime(token);if time==nil then return false,"LIFT_STATE_UNKNOWN" end
    if (up and time>=.999 or not up and time<=.001) and direction==0 then return true end
    if direction~=0 then return true,"LIFT_MOVING" end
    local ao=token.source.animatedObject
    if type(ao.getCanBeTriggered)=="function" and call(ao,"getCanBeTriggered")~=true then return false,"LIFT_DEPENDENCY_BLOCKED" end
    local gate=token.source
    local ok,reason=SmartGateAPI.requestInteraction(gate.id,gate.ownerKey,gate.nodeKey,gate.x,gate.z)
    return ok,reason
end
function SmartGateAPI.getServiceWorkMotionState(token)
    local a=type(token)=="table" and token.a
    if g_server==nil or a==nil or token[TOKEN]~=a.s or a.s.disposed or token.closed or not token.lift
        or g_smartGate~=a.sg or not ownLease(a,token.job,token.owner,token.epoch) then return nil,"NO_OWN_LIFT" end
    local gate=a.sg:findServiceSource(a.b.legacyWashGateId)
    if gate==nil or gate.owner~=token.source.owner or gate.animatedObject~=token.source.animatedObject
        or gate.serviceControl~=token then return nil,"LIFT_OWNERSHIP_LOST" end
    local time,direction=liftTime({source=gate})
    if time==nil then return nil,"LIFT_STATE_UNKNOWN" end
    return {held=true,moving=direction~=0,time=time,direction=direction,verticalLimit=a.b.height},"KNOWN"
end
function SmartGateAPI.getServiceWorkAction(id,vehicleId,service)
    local a,why=resolve(id,vehicleId,service);if a==nil then return nil,why end
    local own={};for _,unit in ipairs(a.root.units) do own[unit]=true end
    local contact,foreign,loading=false,false,false
    if service~="REFUEL" then
        local nodes={};for unit in pairs(own) do nodes[unit.rootNode]=true end
        for _,node in pairs(a.spec.vehiclesInTrigger) do if nodes[node] then contact=true else foreign=true end end
    else
        for _,trigger in ipairs(loadTriggers(a.source.owner)) do
            for _,entry in pairs(trigger.fillableObjects) do if own[entry.object] then contact=true else foreign=true end end
            if trigger.isLoading and own[trigger.currentFillableObject] then loading=true end
        end
    end
    local info=a.s:inspect(id,vehicleId,{[service]=true})
    return {signature=a.signature,source=a.source.owner,adTarget=a.b.adTarget,epoch=a.s.epoch,revision=a.b.revision,
        nativeOccupied=contact,foreignNative=foreign,positionKnown=info.ownOccupied==true,positioned=info.ownOccupied==true,
        running=service~="REFUEL" and a.spec.timerId~=nil or loading,animationRunning=false,
        -- AutomaticCarWash:CleanOneVehicle repairs only while damage >= .005.
        -- Describe this backend's service limit, not a global vehicle target.
        serviceBackend=service=="REPAIR" and "AUTOMATIC_CAR_WASH" or "LOAD_TRIGGER",
        repairStopBelow=service=="REPAIR" and .005 or nil,
        reservation=a.b.reservation,serviceLift=a.b.serviceLift==true,liftDelayMs=a.b.serviceLiftDelayMs or 0},"KNOWN"
end
function SmartGateAPI.prepareServiceWork(id,job,vehicleId,owner,epoch,signature,service)
    local a,why=resolve(id,vehicleId,service);if a==nil then return nil,why end
    if a.signature~=signature or not ownLease(a,job,owner,epoch) then return nil,"NO_OWN_LEASE" end
    local token={[TOKEN]=a.s,a=a,source=a.source,job=job,owner=owner,epoch=epoch,vehicleId=vehicleId,service=service,signature=signature,
        bindingId=a.b.legacyWashGateId,
        lift=a.b.serviceLift==true and service=="REPAIR",interaction=a.b.serviceInteraction==true and service=="REPAIR",loading={}}
    if token.lift or token.interaction then
        if service~="REPAIR" or a.source.serviceSynthetic or a.source.animatedObject==nil or a.source.serviceControl~=nil then return nil,"LIFT_UNAVAILABLE_OR_BUSY" end
        local t,d=liftTime(token);if t==nil or token.lift and t>.001 or d~=0 then return nil,"LIFT_NOT_LOWERED" end
        a.source.serviceControl=token
        a.source.interactionRepeatRemaining=0;a.source.interactionNextTriggerTime=nil
    end
    a.s.serviceWorkTokens=a.s.serviceWorkTokens or {};a.s.serviceWorkTokens[token]=true
    return token
end
function SmartGateAPI.startServiceWork(token,fuelTarget)
    local a=token and token.a
    if g_server==nil or a==nil or token[TOKEN]~=a.s or a.s.disposed or token.closed or not ownLease(a,token.job,token.owner,token.epoch) then return false,"NO_OWN_LEASE" end
    local current,why=resolve(a.b.id,token.vehicleId,token.service)
    if current==nil or current.signature~=token.signature or current.source.owner~=token.source.owner
        or current.source.animatedObject~=token.source.animatedObject then return false,why or "BINDING_CHANGED" end
    if (token.lift or token.interaction) and current.source.serviceControl~=token then return false,"LIFT_OWNERSHIP_LOST" end
    token.source=current.source;a.source=current.source
    -- Require a genuine standstill before first raising the platform. Once it
    -- carries the vehicle, total speed also contains its vertical movement;
    -- the coordinator keeps enforcing owned-lift and horizontal-motion guards.
    if not (token.lift and token.platformStarted) and (call(a.root.vehicle,"getLastSpeed") or math.huge)>.1 then return false,"VEHICLE_NOT_STOPPED" end
    local observed=SmartGateAPI.getServiceWorkAction(a.b.id,token.vehicleId,token.service)
    if observed==nil or observed.foreignNative or not observed.positionKnown then return false,"NOT_IN_OWN_NATIVE_TRIGGER" end
    if token.interaction and not token.lift and not token.triggered then
        local gate=token.source
        local ok,why=SmartGateAPI.requestInteraction(gate.id,gate.ownerKey,gate.nodeKey,gate.x,gate.z);if not ok then return false,why end
        token.triggered=true
    end
    if not observed.nativeOccupied then return true,"WAIT_MATCHING_NATIVE_TRIGGER" end
    if token.lift then
        token.arrivedAt=token.arrivedAt or a.s.clock
        if a.s.clock-token.arrivedAt<(a.b.serviceLiftDelayMs or 0) then return true,"WAIT_LIFT_DELAY" end
        local ok,reason=moveLift(token,true);if not ok then return false,reason end
        token.platformStarted=true
        local t,d=liftTime(token);if t<.999 or d~=0 then return true,"LIFT_RAISING" end
    end
    if token.service=="REPAIR" then
        if a.spec.timerId==nil then local ok=pcall(a.source.owner.CleanCar,a.source.owner);if not ok then return false,"NATIVE_REPAIR_START_FAILED" end end
        return true,"NATIVE_REPAIR_OBSERVED"
    end
    -- FillTrigger owns prices, stock, effects and FillUnit writes. Explicitly
    -- address a captured consumer, never whichever vehicle the local GUI selected.
    local started=false;local targets={}
    fuelTarget=finite(fuelTarget) and math.max(.5,math.min(1,fuelTarget)) or .99
    for _,trigger in ipairs(loadTriggers(a.source.owner)) do
        if trigger.isLoading and trigger.currentFillableObject~=nil then
            targets[trigger.currentFillableObject]=targets[trigger.currentFillableObject] or {}
            targets[trigger.currentFillableObject][trigger.fillUnitIndex]=true
        end
    end
    for _,trigger in ipairs(loadTriggers(a.source.owner)) do
        if trigger.isLoading then
            if token.loading[trigger]~=nil then started=true
            elseif trigger.automaticFilling or trigger.autoStart then
                local own=false;for _,unit in ipairs(a.root.units) do own=own or unit==trigger.currentFillableObject end
                if not own or not energy(trigger.selectedFillType) then return false,"FOREIGN_OR_MANUAL_LOADING" end
                started=true -- observe automatic native loading without owning/stopping it
            else return false,"FOREIGN_OR_MANUAL_LOADING" end
        else
            local types=call(trigger.source,"getSupportedFillTypes")
            for _,entry in pairs(trigger.fillableObjects) do
                local consumers=entry.object.spec_motorized and entry.object.spec_motorized.consumers or {}
                for _,consumer in pairs(consumers) do
                    if consumer.fillUnitIndex==entry.fillUnitIndex and energy(consumer.fillType) and types and types[consumer.fillType]
                        and (trigger.fillTypes==nil or trigger.fillTypes[consumer.fillType]) and call(trigger,"getAllowsActivation",entry.object)==true
                        and (call(a.source.owner,"getOwnerFarmId")==a.root.farmId or call(trigger.source,"getIsFillAllowedToFarm",a.root.farmId)==true)
                        and call(entry.object,"getFillUnitAllowsFillType",entry.fillUnitIndex,consumer.fillType)==true
                        and call(entry.object,"getOwnerFarmId")==a.root.farmId then
                        local own=false;for _,unit in ipairs(a.root.units) do own=own or unit==entry.object end
                        local level=call(entry.object,"getFillUnitFillLevel",entry.fillUnitIndex);local cap=call(entry.object,"getFillUnitCapacity",entry.fillUnitIndex)
                        if own and not (targets[entry.object] and targets[entry.object][entry.fillUnitIndex])
                            and finite(level) and finite(cap) and cap>0 and level/cap<fuelTarget then
                            -- Record the intended ownership before native code:
                            -- even a partially successful native exception must
                            -- remain eligible for guarded cleanup.
                            token.loading[trigger]={object=entry.object,index=entry.fillUnitIndex,fillType=consumer.fillType}
                            local ok=pcall(trigger.setIsLoading,trigger,true,entry.object,entry.fillUnitIndex,consumer.fillType)
                            if not ok then return false,"NATIVE_REFUEL_START_FAILED" end
                            if trigger.isLoading and trigger.currentFillableObject==entry.object then
                                token.loading[trigger]={object=entry.object,index=entry.fillUnitIndex,fillType=consumer.fillType};started=true
                                targets[entry.object]=targets[entry.object] or {};targets[entry.object][entry.fillUnitIndex]=true
                            end
                            break
                        end
                    end
                end
                if trigger.isLoading then break end
            end
        end
    end
    return true,started and "NATIVE_REFUEL_STARTED" or "WAIT_MATCHING_NATIVE_CONSUMER"
end
function SmartGateAPI.finishServiceWork(token)
    if type(token)~="table" or g_server==nil or token.a==nil or token[TOKEN]~=token.a.s
        or token.a.s.disposed or g_smartGate==nil or g_smartGate.serviceInfrastructure~=token.a.s then return false,"UNKNOWN_TOKEN" end
    if token.closed then return true,"READY_TO_LEAVE" end
    for trigger,entry in pairs(token.loading) do
        if trigger.isLoading and trigger.currentFillableObject==entry.object and trigger.fillUnitIndex==entry.index
            and trigger.selectedFillType==entry.fillType then trigger:setIsLoading(false) end
    end
    token.loading={}
    if token.lift then
        local ok,why=moveLift(token,false);if not ok then return false,why end
        local t,d=liftTime(token);if t==nil or t>.001 or d~=0 then return true,"LIFT_LOWERING" end
        -- Keep regular entry/exit toggles suppressed until the bay is vacant;
        -- otherwise the stopped vehicle could immediately raise the lift again.
        token.departing=true
    elseif token.interaction then
        local _,direction=liftTime(token);if direction==nil then return false,"ANIMATION_STATE_UNKNOWN" end
        if direction~=0 then return true,"WAIT_SERVICE_ANIMATION" end
        token.departing=true
    end
    token.closed=true
    if not token.departing then token.a.s.serviceWorkTokens[token]=nil end
    return true,"READY_TO_LEAVE"
end
function SmartGateAPI.cancelServiceWork(token)
    if type(token)~="table" or token.closed or g_server==nil then return end
    token.cancelled=true
    local ok,why=SmartGateAPI.finishServiceWork(token)
    if not ok then print("[SmartGate][SERVICE] cancel holds vehicle; "..tostring(why)) end
end
local oldWashAction=SmartGateAPI.getServiceWashAction
function SmartGateAPI.getServiceWashAction(id,vehicleId)
    local action,why=oldWashAction(id,vehicleId);if action~=nil then return action,why end
    action,why=SmartGateAPI.getServiceWorkAction(id,vehicleId,"WASH")
    if action~=nil then action.nativeServiceAuto=true end
    return action,why
end
local oldWashStart=SmartGateAPI.startServiceWash
function SmartGateAPI.startServiceWash(id,job,vehicleId,owner,epoch,signature)
    local action=SmartGateAPI.getServiceWashAction(id,vehicleId)
    if action==nil or not action.nativeServiceAuto then return oldWashStart(id,job,vehicleId,owner,epoch,signature) end
    local a,why=resolve(id,vehicleId,"WASH");if a==nil then return false,why end
    if a.signature~=signature or not ownLease(a,job,owner,epoch) or not action.nativeOccupied or action.foreignNative
        or (call(a.root.vehicle,"getLastSpeed") or math.huge)>.1 then return false,"NO_OWN_NATIVE_SERVICE_POSITION" end
    if a.spec.timerId==nil then local ok=pcall(a.source.owner.CleanCar,a.source.owner);if not ok then return false,"NATIVE_START_FAILED" end end
    return true,"NATIVE_AUTOMATIC_SERVICE"
end
local oldDispose=S.dispose
function S:dispose()
    for token in pairs(self.serviceWorkTokens or {}) do
        if token.source.serviceControl==token then token.source.serviceControl=nil end
    end
    self.serviceWorkTokens=nil;self.sourceCandidates=nil
    oldDispose(self)
end
local oldUpdate=S.update
function S:update(dt)
    oldUpdate(self,dt)
    if g_server==nil or self.disposed or self.serviceWorkTokens==nil or self.clock-(self.serviceWorkPollAt or 0)<500 then return end
    self.serviceWorkPollAt=self.clock
    for token in pairs(self.serviceWorkTokens) do
        if token.departing and token.a.b.occupancy=="FREE" then
            if token.source.serviceControl==token then token.source.serviceControl=nil end
            local current=self.owner:findServiceSource(token.bindingId)
            if current~=nil and current.serviceControl==token then current.serviceControl=nil end
            self.serviceWorkTokens[token]=nil
        elseif token.cancelled and not token.closed then SmartGateAPI.finishServiceWork(token) end
    end
end
