-- L.E.G.S. service infrastructure schema 2. No driving or service execution.
SGServiceInfrastructure={}
local S=SGServiceInfrastructure
local MAX_PROVIDERS,MAX_BAYS=128,512
local CELL,SCAN_MS,SYNC_MS=25,1000,5000
local EDIT_MARGIN_METRES=10
local LENGTH_ALIGNMENT_DOT=math.cos(math.rad(1))
local LENGTH_CLEARANCE_METRES=.05
local epochSerial=0
local CAPS={"WASH","REPAIR","REFUEL"}
local AREA_FIELDS={"x","y","z","yaw","width","length"}
local ORIGIN_FIELDS={"x","y","z","yaw"}
local FIELDS={"x","y","z","yaw","width","height","length","adTarget"}
local function finite(v) return type(v)=="number" and v==v and v>-math.huge and v<math.huge end
local function integer(v,lo,hi) return finite(v) and v==math.floor(v) and v>=lo and v<=hi end
local function text(v) return type(v)=="string" and #v>0 and #v<=64 and not v:find("[%c]") end
local function call(v,name,...)
    if type(v)~="table" or type(v[name])~="function" then return nil end
    local ok,a,b,c=pcall(v[name],v,...); if ok then return a,b,c end
end
local function clone(v)
    if type(v)~="table" then return v end
    local out={}; for k,item in pairs(v) do out[k]=clone(item) end; return out
end
-- Original hitch translations are stored relative to the node's parent by
-- GIANTS. Restore them mathematically, never by moving a runtime node.
local function hitchPoint(vehicle,desc,input)
    if type(desc)~="table" or type(localToLocal)~="function" or type(getParent)~="function" or type(vehicle.components)~="table"
        or vehicle.components[1]==nil or vehicle.components[1].node~=vehicle.rootNode then return nil end
    local node=input and desc.node or desc.jointTransform
    if node==nil or not entityExists(node) or call(vehicle,"getParentComponent",node)~=vehicle.rootNode then return nil end
    local pos=desc.jointOrigTrans;local rot=desc.jointOrigRotOffsetComponent
    if type(pos)~="table" or type(rot)~="table" then return nil end
    for i=1,3 do if not finite(pos[i]) or not finite(rot[i]) then return nil end end
    local x,y,z=pos[1],pos[2],pos[3]
    if not input and desc.jointPositionOffset~=nil then
        for i=1,3 do if not finite(desc.jointPositionOffset[i]) then return nil end end
        x=x+desc.jointPositionOffset[1];y=y+desc.jointPositionOffset[2];z=z+desc.jointPositionOffset[3]
    end
    local parentOK,parentNode=pcall(getParent,node)
    if not parentOK or parentNode==nil then return nil end
    local ok,px,_,pz=pcall(localToLocal,parentNode,vehicle.rootNode,x,y,z)
    if not ok or not finite(px) or not finite(pz) then return nil end
    return {x=px,z=pz,rot=rot}
end
local function hitchLength(entry)
    local centres={[entry.vehicle]=0};local pending=#entry.units-1
    for _=1,#entry.units do
        local advanced=false
        for _,unit in ipairs(entry.units) do if centres[unit]==nil then
            local link=entry.links[unit];local parent=link~=nil and link.parent
            if parent~=nil and centres[parent]~=nil then
                local out=call(parent,"getAttacherJointByJointDescIndex",link.jointDescIndex)
                local index=link.inputJointDescIndex or call(unit,"getActiveInputAttacherJointDescIndex")
                local incoming=call(unit,"getInputAttacherJointByJointDescIndex",index)
                if out==nil or incoming==nil or call(unit,"getAttacherVehicle")~=parent then return nil,"HITCH_API_OR_IDENTITY" end
                local a,b=hitchPoint(parent,out,false),hitchPoint(unit,incoming,true)
                if a==nil or b==nil then return nil,"HITCH_COMPONENT_OR_REFERENCE" end
                -- The hitch itself must belong directly to the root component.
                -- Extra axle components do not change that reference frame.
                -- Oblique/reversed original frames and hitches on internal
                -- moving component chains stay unsupported until reconstructed.
                for i=1,3 do
                    local delta=(a.rot[i]-b.rot[i]+math.pi)%(2*math.pi)-math.pi
                    if math.abs(delta)>math.rad(1) then return nil,"HITCH_FRAME_ALIGNMENT" end
                end
                if math.abs(a.x-b.x)>.05 then return nil,"HITCH_LATERAL_OFFSET" end
                centres[unit]=centres[parent]+a.z-b.z;pending=pending-1;advanced=true
            end
        end end
        if pending==0 then break end
        if not advanced then return nil,"HITCH_TREE_INCOMPLETE" end
    end
    if pending~=0 then return nil,"HITCH_TREE_INCOMPLETE" end
    local lo,hi=math.huge,-math.huge
    for _,unit in ipairs(entry.units) do
        local centre=centres[unit]+(tonumber(unit.size.lengthOffset) or 0)
        lo=math.min(lo,centre-unit.size.length*.5);hi=math.max(hi,centre+unit.size.length*.5)
    end
    return hi-lo+LENGTH_CLEARANCE_METRES
end
local function sorted(t)
    local out={}; for _,v in pairs(t) do out[#out+1]=v end
    table.sort(out,function(a,b)
        local an,bn=tonumber(a.id:match("%-(%d+)$")),tonumber(b.id:match("%-(%d+)$"))
        if an~=nil and bn~=nil and an~=bn then return an<bn end
        return a.id<b.id
    end); return out
end
local function count(t) local n=0; for _ in pairs(t) do n=n+1 end; return n end
local function tr(de,en) return tostring(g_languageShort or "en"):sub(1,2)=="de" and de or en end
local function guiOpen() return g_gui~=nil and call(g_gui,"getIsGuiVisible")==true end
local function actor(connection)
    if connection~=nil then
        if call(connection,"getIsServer")~=false or call(connection,"getIsConnected")==false then return nil end
        local mission=g_currentMission
        return call(mission~=nil and mission.playerSystem or nil,"getPlayerByConnection",connection)
    end
    return g_localPlayer
end
local function poseOperation(op)
    return op=="NEW_PROVIDER" or op=="NEW_BAY" or op=="PLACE_PROVIDER" or op=="PLACE_BAY"
end
local function pose(player,lookYaw)
    local vehicle=call(player,"getCurrentVehicle")
    local node=vehicle~=nil and vehicle.rootNode or player~=nil and player.rootNode
    if node==nil or type(entityExists)~="function" or not entityExists(node) then return nil end
    local x,y,z=getWorldTranslation(node)
    local fx,_,fz=localDirectionToWorld(node,0,0,1)
    if not finite(x) or not finite(y) or not finite(z) or not finite(fx) or not finite(fz) or fx*fx+fz*fz<.001 then return nil end
    local mission=g_currentMission
    if type(getTerrainHeightAtWorldPos)=="function" and mission~=nil and mission.terrainRootNode~=nil then
        local ground=getTerrainHeightAtWorldPos(mission.terrainRootNode,x,0,z); if finite(ground) then y=ground end
    end
    local yaw=math.atan2(fx,fz)
    if vehicle==nil then
        if not finite(lookYaw) and player==g_localPlayer then
            local _,_,cameraYaw=call(player,"getMapPositionAndLookYaw");lookYaw=cameraYaw
        end
        if not finite(lookYaw) then lookYaw=call(player,"getMovementYaw") end
        if finite(lookYaw) then yaw=(lookYaw+math.pi)%(2*math.pi)-math.pi end
    end
    return {x=x,y=y,z=z,yaw=yaw}
end
local function validArea(a)
    if type(a)~="table" then return false end
    for _,f in ipairs({"x","y","z"}) do if not finite(a[f]) or math.abs(a[f])>1000000 then return false end end
    return finite(a.yaw) and math.abs(a.yaw)<=math.pi*2 and finite(a.width) and a.width>=1 and a.width<=500
        and finite(a.length) and a.length>=1 and a.length<=500
end
local function origin(b)
    local out={}; for _,f in ipairs(ORIGIN_FIELDS) do out[f]=b[f] end; return out
end
local BAY_GEOMETRY={"x","y","z","yaw","width","height","length"}
local function geometryKind(op,field)
    if op=="PLACE_BAY" or op=="RESET_BAY_POSE" then return "bay" end
    if op=="PLACE_PROVIDER" then return "provider" end
    local fields=op=="SET_BAY" and BAY_GEOMETRY or op=="SET_PROVIDER_AREA" and AREA_FIELDS
    for _,name in ipairs(fields or {}) do if name==field then return op=="SET_BAY" and "bay" or "provider" end end
end
local function geometryValues(value,kind)
    if value==nil then return false end
    local out={};for _,field in ipairs(kind=="bay" and BAY_GEOMETRY or AREA_FIELDS) do out[field]=value[field] end
    return out
end
local function sameGeometry(a,b)
    if a==false or b==false then return a==b end
    for key,value in pairs(a) do
        local other=b[key]
        if type(value)=="number" and type(other)=="number" then
            local difference=key=="yaw" and (value-other+math.pi)%(2*math.pi)-math.pi or value-other
            if math.abs(difference)>0.000001 then return false end
        elseif value~=other then return false end
    end
    return true
end
function S:geometrySaved()
    self.pendingGeometry=nil;self.geometryUnsaved=false
end
function S:captureGateGeometry(gate)
    return clone(self.owner.savedGateSettings[gate.id]) or false
end
function S:deferGateGeometry(gate,connection,before)
    local key="gate:"..gate.id
    self.pendingGeometry=self.pendingGeometry or {}
    local player=actor(connection)
    local entry=self.pendingGeometry[key] or {before=before,farmId=player and player.farmId,actor=connection or self}
    entry.actor=connection or self
    local after=self:captureGateGeometry(gate)
    local unchanged=sameGeometry(entry.before,after) and sameGeometry(after,entry.before)
    self.pendingGeometry[key]=not unchanged and entry or nil
    if next(self.pendingGeometry)==nil then self.pendingGeometry=nil end
    self.geometryUnsaved=self.pendingGeometry~=nil
end
function S:flushGeometry()
    if self.pendingGeometry==nil or next(self.pendingGeometry)==nil then return true,"GEOMETRY_UNCHANGED" end
    local called,ok=pcall(self.owner.saveConfig,self.owner,nil,"SERVICE_GEOMETRY_CLOSE")
    if not called or not ok then
        print("[SmartGate][SERVICE][GEOMETRY] save failed; edits remain pending detail="..tostring(ok))
        return false,"GEOMETRY_SAVE_FAILED"
    end
    return true,"GEOMETRY_SAVED"
end
local function validName(value) return type(value)=="string" and #value<=64 and not value:find("[%c]") end
local function customName(v)
    if v.name=="" then return false end
    if v.nameCustom~=nil then return v.nameCustom end
    local n=tostring(v.id):match("%-(%d+)$")
    for _,prefix in ipairs({"Provider ","Bay ","Service area ","Servicebereich ","Serviceplatz "}) do if v.name==prefix..tostring(n) then return false end end
    return true
end
local function validBay(b,p)
    if type(b)~="table" or not text(b.id) or not b.id:match("^SGSB%-%d+$") or b.providerId~=p.id or not validName(b.name) then return false end
    if b.serviceLift~=nil and type(b.serviceLift)~="boolean" or b.serviceInteraction~=nil and type(b.serviceInteraction)~="boolean"
        or b.serviceLiftDelayMs~=nil and not integer(b.serviceLiftDelayMs,0,10000) then return false end
    for _,field in ipairs({"x","y","z"}) do if not finite(b[field]) or math.abs(b[field])>1000000 then return false end end
    if not finite(b.yaw) or math.abs(b.yaw)>math.pi*2 then return false end
    for _,field in ipairs({"width","height","length"}) do if not finite(b[field]) or b[field]<.5 or b[field]>100 then return false end end
    if not integer(b.adTarget,-1,16777215) or b.adTarget==0 or type(b.capabilities)~="table" then return false end
    local any=false
    for _,cap in ipairs(CAPS) do if type(b.capabilities[cap])~="boolean" then return false end; any=any or b.capabilities[cap] end
    if b.legacyWashGateId~=nil and (type(b.legacyWashGateId)~="string" or #b.legacyWashGateId>1024 or b.legacyWashGateId=="") then return false end
    if b.origin~=nil then
        for _,f in ipairs(ORIGIN_FIELDS) do if not finite(b.origin[f]) or math.abs(b.origin[f])>(f=="yaw" and math.pi*2 or 1000000) then return false end end
    end
    return any and (b.operational=="OPEN" or b.operational=="CLOSED")
end
local function box(x,z,yaw,w,l)
    return {x=x,z=z,fx=math.sin(yaw),fz=math.cos(yaw),rx=math.cos(yaw),rz=-math.sin(yaw),w=w*.5,l=l*.5}
end
local function overlap(a,b)
    for _,axis in ipairs({{a.fx,a.fz},{a.rx,a.rz},{b.fx,b.fz},{b.rx,b.rz}}) do
        local x,z=axis[1],axis[2]
        local distance=math.abs((b.x-a.x)*x+(b.z-a.z)*z)
        local radius=a.l*math.abs(a.fx*x+a.fz*z)+a.w*math.abs(a.rx*x+a.rz*z)
            +b.l*math.abs(b.fx*x+b.fz*z)+b.w*math.abs(b.rx*x+b.rz*z)
        if distance>radius+.05 then return false end
    end
    return true
end
local function cells(rect,fn)
    local dx=math.abs(rect.fx)*rect.l+math.abs(rect.rx)*rect.w+.05
    local dz=math.abs(rect.fz)*rect.l+math.abs(rect.rz)*rect.w+.05
    local loX,hiX=math.floor((rect.x-dx)/CELL),math.floor((rect.x+dx)/CELL)
    local loZ,hiZ=math.floor((rect.z-dz)/CELL),math.floor((rect.z+dz)/CELL)
    if (hiX-loX+1)*(hiZ-loZ+1)>256 then return false end
    for x=loX,hiX do for z=loZ,hiZ do fn(x..":"..z) end end; return true
end
function S.new(owner)
    epochSerial=epochSerial+1
    return setmetatable({owner=owner,providers={},bays={},grid={},providerSerial=0,baySerial=0,
        revision=1,configRevision=1,epoch="SGSERVICE:"..epochSerial..":"..tostring({}),clock=0,scanTimer=0,syncTimer=0,
        persistenceSafe=true,loaded=false,ready=false,roots={},selectedProvider=nil,selectedBay=nil}, {__index=S})
end
function S:invalidateSource(placeable)
    local ids={}
    local uid=call(placeable,"getUniqueId");if type(uid)=="string" then ids["AS-SERVICE:"..uid]=true end
    for _,gate in ipairs(self.owner.gates or {}) do
        if gate.owner==placeable then
            if type(self.owner.getServiceSourceId)=="function" then local id=self.owner:getServiceSourceId(gate);if id~=nil then ids[id]=true end end
            ids[gate.id]=true;gate.mode=0;gate.interactionRepeatRemaining=0;gate.interactionNextTriggerTime=nil
        end
    end
    local changed=false
    for _,b in pairs(self.bays) do
        if b.legacyWashGateId~=nil and ids[b.legacyWashGateId] then
            b.operational="CLOSED"; b.reservation=nil; b.releaseReason="SOURCE_REMOVED"; b.revision=b.revision+1; changed=true
        end
    end
    if changed then self.configRevision=self.configRevision+1; self:changed(); SGServiceStateEvent.send(self) end
    return changed
end
function S:getLegacyWashBay(id)
    return self.legacyWashByGate~=nil and self.legacyWashByGate[id] or nil
end
function S:hasData() return next(self.providers)~=nil or self.providerSerial>0 or self.baySerial>0 end
function S:refreshDisplayNames()
    self.displayLanguage=tostring(g_languageShort or "en"); self.displayNames={}
    for index,p in ipairs(sorted(self.providers)) do
        local label=tr("Bereich ","Area ")..index
        self.displayNames[p.id]=label..(customName(p) and " – "..p.name or "")
        for number,b in ipairs(sorted(p.bays)) do self.displayNames[b.id]=tr("Serviceplatz ","Bay ")..number..(customName(b) and " – "..b.name or "") end
    end
end
function S:displayName(v,kind)
    if v==nil then return kind=="provider" and tr("Kein Bereich","No area") or tr("Kein Platz","No bay") end
    if self.displayNames==nil or self.displayLanguage~=tostring(g_languageShort or "en") then self:refreshDisplayNames() end
    return self.displayNames[v.id] or (kind=="provider" and tr("Bereich","Area") or tr("Serviceplatz","Bay"))
end
function S:reindex()
    self.bays={}; self.grid={}; self.legacyWashByGate={}
    for _,p in pairs(self.providers) do
        -- Visual bounds only; this rectangle is never inserted into the occupancy grid.
        local loX,hiX,loZ,hiZ,y
        for _,b in pairs(p.bays) do
            local r=box(b.x,b.z,b.yaw,b.width,b.length)
            local dx=math.abs(r.fx)*r.l+math.abs(r.rx)*r.w
            local dz=math.abs(r.fz)*r.l+math.abs(r.rz)*r.w
            loX=math.min(loX or math.huge,b.x-dx); hiX=math.max(hiX or -math.huge,b.x+dx)
            loZ=math.min(loZ or math.huge,b.z-dz); hiZ=math.max(hiZ or -math.huge,b.z+dz); y=math.min(y or b.y,b.y)
        end
        p.visualArea=loX~=nil and {x=(loX+hiX)*.5,y=y,z=(loZ+hiZ)*.5,yaw=0,width=hiX-loX+2,length=hiZ-loZ+2} or nil
        for _,b in pairs(p.bays) do
        self.bays[b.id]=b; if b.legacyWashGateId~=nil then self.legacyWashByGate[b.legacyWashGateId]=b end; b.rect=box(b.x,b.z,b.yaw,b.width,b.length)
        cells(b.rect,function(key) self.grid[key]=self.grid[key] or {}; self.grid[key][b.id]=b end)
    end end
    self:refreshDisplayNames()
end
function S:changed()
    self.revision=self.revision+1; self.syncTimer=SYNC_MS
end
function S:readXML(xml)
    local base="smartGate.serviceInfrastructure"
    if not hasXMLProperty(xml,base) then self.providers={}; self.providerSerial=0; self.baySerial=0; self.persistenceSafe=true; self.loaded=true; self.configRevision=self.configRevision+1; self:reindex(); self:changed(); return true end
    local providers={}; local seen={}; local legacySeen={}; local total=0
    local ps,bs=getXMLInt(xml,base.."#providerSerial"),getXMLInt(xml,base.."#baySerial")
    local valid=getXMLInt(xml,base.."#schema")==2 and integer(ps,0,2147483647) and integer(bs,0,2147483647)
    local i=0
    while valid and hasXMLProperty(xml,base..string.format(".providers.provider(%d)",i)) do
        local key=base..string.format(".providers.provider(%d)",i)
        local p={id=getXMLString(xml,key.."#id"),name=getXMLString(xml,key.."#name"),nameCustom=getXMLBool(xml,key.."#nameCustom"),farmId=getXMLInt(xml,key.."#farmId"),bays={}}
        if hasXMLProperty(xml,key.."#areaX") then
            p.area={}; for _,f in ipairs(AREA_FIELDS) do p.area[f]=getXMLFloat(xml,key.."#area"..f:sub(1,1):upper()..f:sub(2)) end
        end
        local serial=type(p.id)=="string" and tonumber(p.id:match("^SGSP%-(%d+)$")) or nil
        valid=i<MAX_PROVIDERS and text(p.id) and integer(serial,1,2147483647) and serial<=ps and providers[p.id]==nil
            and validName(p.name) and integer(p.farmId,1,65535) and (p.area==nil or validArea(p.area))
        local j=0
        while valid and hasXMLProperty(xml,key..string.format(".bays.bay(%d)",j)) do
            local bk=key..string.format(".bays.bay(%d)",j)
            local b={id=getXMLString(xml,bk.."#id"),providerId=p.id,name=getXMLString(xml,bk.."#name"),nameCustom=getXMLBool(xml,bk.."#nameCustom"),
                operational=getXMLString(xml,bk.."#operational"),legacyWashGateId=getXMLString(xml,bk.."#legacyWashGateId"),capabilities={},occupancy="UNKNOWN",occupants={},revision=1}
            for _,field in ipairs(FIELDS) do b[field]=getXMLFloat(xml,bk.."#"..field) end
            if hasXMLProperty(xml,bk.."#originX") then
                b.origin={}; for _,f in ipairs(ORIGIN_FIELDS) do b.origin[f]=getXMLFloat(xml,bk.."#origin"..f:sub(1,1):upper()..f:sub(2)) end
            else b.origin=origin(b) end
            b.serviceLift=getXMLBool(xml,bk.."#serviceLift")==true;b.serviceInteraction=getXMLBool(xml,bk.."#serviceInteraction")==true
            b.serviceLiftDelayMs=getXMLInt(xml,bk.."#serviceLiftDelayMs") or 0
            for _,cap in ipairs(CAPS) do b.capabilities[cap]=getXMLBool(xml,bk.."#"..cap) end
            local number=type(b.id)=="string" and tonumber(b.id:match("^SGSB%-(%d+)$")) or nil
            valid=total<MAX_BAYS and validBay(b,p) and integer(number,1,2147483647) and number<=bs and not seen[b.id] and (b.legacyWashGateId==nil or not legacySeen[b.legacyWashGateId])
            if valid then p.bays[b.id]=b; seen[b.id]=true; if b.legacyWashGateId~=nil then legacySeen[b.legacyWashGateId]=true end; total=total+1 end
            j=j+1
        end
        if valid then providers[p.id]=p end; i=i+1
    end
    if not valid then self.persistenceSafe=false; self.loaded=false; self.ready=false; print("[SmartGate][SERVICE] invalid persisted schema; writes blocked, original XML preserved"); return false end
    self.providers=providers; self.providerSerial=ps; self.baySerial=bs; self.persistenceSafe=true
    self.loaded=true; self.ready=false; self.configRevision=self.configRevision+1; self:reindex(); self:changed(); return true
end
function S:writeXML(xml)
    if not self.persistenceSafe then error("Service infrastructure not safely restored") end
    local base="smartGate.serviceInfrastructure"
    setXMLInt(xml,base.."#schema",2); setXMLInt(xml,base.."#providerSerial",self.providerSerial); setXMLInt(xml,base.."#baySerial",self.baySerial)
    for i,p in ipairs(sorted(self.providers)) do
        local key=base..string.format(".providers.provider(%d)",i-1)
        setXMLString(xml,key.."#id",p.id); setXMLString(xml,key.."#name",p.name); setXMLInt(xml,key.."#farmId",p.farmId); setXMLBool(xml,key.."#nameCustom",customName(p))
        if p.area~=nil then for _,f in ipairs(AREA_FIELDS) do setXMLFloat(xml,key.."#area"..f:sub(1,1):upper()..f:sub(2),p.area[f]) end end
        for j,b in ipairs(sorted(p.bays)) do
            local bk=key..string.format(".bays.bay(%d)",j-1)
            setXMLString(xml,bk.."#id",b.id); setXMLString(xml,bk.."#name",b.name); setXMLString(xml,bk.."#operational",b.operational); setXMLBool(xml,bk.."#nameCustom",customName(b))
            if b.legacyWashGateId~=nil then setXMLString(xml,bk.."#legacyWashGateId",b.legacyWashGateId) end
            setXMLBool(xml,bk.."#serviceLift",b.serviceLift==true);setXMLInt(xml,bk.."#serviceLiftDelayMs",b.serviceLiftDelayMs or 0)
            setXMLBool(xml,bk.."#serviceInteraction",b.serviceInteraction==true)
            for _,field in ipairs(FIELDS) do setXMLFloat(xml,bk.."#"..field,b[field]) end
            for _,f in ipairs(ORIGIN_FIELDS) do setXMLFloat(xml,bk.."#origin"..f:sub(1,1):upper()..f:sub(2),(b.origin or b)[f]) end
            for _,cap in ipairs(CAPS) do setXMLBool(xml,bk.."#"..cap,b.capabilities[cap]) end
        end
    end
end
function S:logAdDiagnostics(stage,bayId)
    local d=self.adDiagnostics or {}; local reasons={}
    for reason,n in pairs(d.reasons or {}) do reasons[#reasons+1]=reason..":"..n end; table.sort(reasons)
    local bay=self.bays[bayId or self.selectedBay]
    print(string.format("[SmartGate][SERVICE][AD] stage=%s resolved=%s api=%s apiResult=%s source=%s raw=%d accepted=%d rejected=%d reasons=%s guiTargets=%d selected=%s savedMarker=%s",
        stage,tostring(d.resolved or "UNKNOWN"),tostring(d.apiPresent==true),tostring(d.apiResult or "UNKNOWN"),tostring(d.source or "UNAVAILABLE"),
        d.raw or 0,d.accepted or 0,d.rejected or 0,table.concat(reasons,","),count(self.adDestinations or {}),tostring(bayId or self.selectedBay or "NONE"),tostring(bay~=nil and bay.adTarget or "NONE")))
end
function S:refreshDestinations(explicit)
    local destinations,diagnostics=call(self.owner,"getServiceDestinations",explicit==true)
    self.adDiagnostics=diagnostics or {source="UNAVAILABLE"}
    self.adLocalUnavailable=type(destinations)~="table" or next(destinations)==nil
    if g_server==nil and self.adLocalUnavailable and self.serverDestinations~=nil then
        destinations=clone(self.serverDestinations); self.adDiagnostics.source="SERVER_STATE:"..tostring(self.serverAdSource)
    end
    self.adDestinations=destinations; self.adObservedAt=self.clock
    if g_server~=nil then
        local parts={};for id,v in pairs(destinations or {}) do parts[#parts+1]=id..":"..v.name end;table.sort(parts)
        local signature=table.concat(parts,"|")..":"..tostring(self.adDiagnostics.source)
        if self.adSignature~=signature then self.adSignature=signature; self:changed() end
    elseif explicit then
        self.adAwaitingManual=true; self:request("REFRESH_AD")
    end
    if explicit and self.adDebug then self:logAdDiagnostics("MANUAL_REFRESH") end
    return destinations
end
function S:destinationStatus(id)
    local source=self.adDiagnostics~=nil and self.adDiagnostics.source or "UNAVAILABLE"
    if source:find("SAVED_XML",1,true) then return "UNKNOWN" end -- a saved snapshot is not proof of a current live marker
    return type(self.adDestinations)=="table" and self.adDestinations[id]~=nil and "KNOWN" or "UNKNOWN"
end
function S:scan()
    if g_server==nil or self.disposed then return false end
    self.roots={}; self.metrics={units=0,comparisons=0,bays=count(self.bays),unknownReasons={},unknownSamples={}}
    if self.adObservedAt==nil or self.clock-self.adObservedAt>=10000 then self:refreshDestinations() end
    if next(self.bays)==nil then self.ready=true; self.lastScan=self.clock; return true end
    local mission=g_currentMission; local vs=mission~=nil and mission.vehicleSystem or nil
    local lists={}; if vs~=nil and type(vs.vehicles)=="table" then lists[#lists+1]=vs.vehicles end
    if mission~=nil and type(mission.vehicles)=="table" then lists[#lists+1]=mission.vehicles end
    local unknown=#lists==0; local seen={}; local hits={}
    local function uncertain(reason,v)
        unknown=true
        local reasons=self.metrics.unknownReasons;reasons[reason]=(reasons[reason] or 0)+1
        local samples=self.metrics.unknownSamples
        if #samples<6 then samples[#samples+1]={reason=reason,id=tostring(call(v,"getUniqueId") or "UNKNOWN"),
            name=tostring(call(v,"getName") or "UNKNOWN"),xml=tostring(v~=nil and v.configFileName or "UNKNOWN")} end
    end
    if unknown then uncertain("VEHICLE_LIST_UNAVAILABLE") end
    for id in pairs(self.bays) do hits[id]={} end
    local function visit(v,root)
        if type(v)~="table" or seen[v] then return end; seen[v]=true
        self.metrics.units=self.metrics.units+1
        local rootId=call(root,"getUniqueId")
        local node=v.rootNode; local size=v.size
        local valid=type(rootId)=="string" and rootId~="" and node~=nil and entityExists(node) and type(size)=="table"
            and finite(size.width) and finite(size.length) and size.width>0 and size.length>0
        local entry=self.roots[rootId or false]
        if entry==nil then entry={vehicle=root,units={},footprints={},links={},complete=true,farmId=call(root,"getOwnerFarmId"),identityValid=true}; self.roots[rootId or false]=entry end
        if entry.vehicle~=root or (vs~=nil and type(vs.vehicleByUniqueId)=="table" and vs.vehicleByUniqueId[rootId]~=root) then
            entry.complete=false; entry.identityValid=false; uncertain("ROOT_IDENTITY",v)
        end
        entry.units[#entry.units+1]=v
        if not valid then uncertain("IDENTITY_NODE_OR_FOOTPRINT",v); entry.complete=false else
            local x,y,z=getWorldTranslation(node); local fx,_,fz=localDirectionToWorld(node,0,0,1)
            if not finite(x) or not finite(z) or not finite(fx) or not finite(fz) or fx*fx+fz*fz<.001 then uncertain("WORLD_POSE",v); entry.complete=false else
                local yaw=math.atan2(fx,fz); local offset=tonumber(size.lengthOffset) or 0
                if not finite(offset) then offset=0; uncertain("LENGTH_OFFSET",v);entry.complete=false end
                local rect=box(x+math.sin(yaw)*offset,z+math.cos(yaw)*offset,yaw,size.width,size.length)
                entry.footprints[v]=rect
                local candidates={}
                local indexed=cells(rect,function(key) for id,b in pairs(self.grid[key] or {}) do candidates[id]=b end end)
                if not indexed then candidates=self.bays end
                for id,b in pairs(candidates) do self.metrics.comparisons=self.metrics.comparisons+1
                    if overlap(rect,b.rect) then hits[id][rootId]=true end
                end
            end
        end
        if type(v.getAttachedImplements)=="function" then
            local attached=call(v,"getAttachedImplements")
            if type(attached)~="table" then uncertain("ATTACHMENTS_UNREADABLE",v); entry.complete=false else
                for _,item in pairs(attached) do if type(item)=="table" and type(item.object)=="table" then
                    if entry.links[item.object]~=nil and entry.links[item.object].parent~=v then entry.complete=false end
                    entry.links[item.object]={parent=v,jointDescIndex=item.jointDescIndex,inputJointDescIndex=item.inputJointDescIndex}
                    visit(item.object,root)
                else uncertain("ATTACHMENT_ENTRY_INVALID",v); entry.complete=false end end
            end
        elseif v.getAttachedImplements~=nil or v.spec_attacherJoints~=nil then
            uncertain("ATTACHMENT_API_MISSING",v);entry.complete=false
        end
        -- GIANTS leaf vehicles need no AttacherJoints specialization. Its
        -- optional accessor being absent is not an unreadable attachment tree.
    end
    for _,list in ipairs(lists) do for _,v in pairs(list) do if type(v)=="table" and not v.isDeleted then visit(v,call(v,"getRootVehicle") or v) end end end
    for _,entry in pairs(self.roots) do
        local width,height,length=0,0,0; local complete=entry.complete
        for _,v in ipairs(entry.units) do local size=v.size
            if type(size)~="table" or not finite(size.width) or not finite(size.height) or not finite(size.length)
                or size.width<=0 or size.height<=0 or size.length<=0 then complete=false else
                width=math.max(width,size.width); height=math.max(height,size.height); length=length+size.length
            end
        end
        entry.declaredLength=complete and length or nil
        entry.lengthMethod=complete and "DECLARED_SUM" or "UNKNOWN";entry.lengthFallbackReason=complete and "SINGLE_UNIT" or "UNKNOWN_GEOMETRY"
        if complete and #entry.units>1 then
            local assembled,hitchReason=hitchLength(entry)
            entry.hitchFallbackReason=hitchReason
            if assembled~=nil and finite(assembled) and assembled>0 then
                length=assembled;entry.lengthMethod="HITCH_ASSEMBLY";entry.lengthFallbackReason=nil
            else
            local frame=entry.footprints[entry.vehicle]
            local lo,hi=math.huge,-math.huge
            local aligned=frame~=nil
            entry.lengthFallbackReason=aligned and "NOT_ALIGNED" or "NO_ROOT_FOOTPRINT"
            if aligned then for _,unit in ipairs(entry.units) do
                local rect=entry.footprints[unit]
                if rect==nil or rect.fx*frame.fx+rect.fz*frame.fz<LENGTH_ALIGNMENT_DOT then aligned=false;break end
                local centre=(rect.x-frame.x)*frame.fx+(rect.z-frame.z)*frame.fz
                -- Use full half-length instead of cosine-shortening it. This
                -- slightly overbounds the <=1 degree accepted alignment.
                local radius=rect.l+rect.w*math.abs(rect.rx*frame.fx+rect.rz*frame.fz)
                lo=math.min(lo,centre-radius);hi=math.max(hi,centre+radius)
            end end
            if aligned and finite(hi-lo) and hi>lo then
                length=hi-lo+LENGTH_CLEARANCE_METRES
                entry.lengthMethod="ALIGNED_ENVELOPE";entry.lengthFallbackReason=nil
            end
            end
        end
        entry.dimensions=complete and {width=width,height=height,length=length} or nil
    end
    for id,b in pairs(self.bays) do
        local state=unknown and "UNKNOWN" or next(hits[id])~=nil and "OCCUPIED" or "FREE"
        local differs=b.occupancy~=state
        for key in pairs(hits[id]) do if not (b.occupants or {})[key] then differs=true end end
        for key in pairs(b.occupants or {}) do if not hits[id][key] then differs=true end end
        b.occupants=hits[id]; b.occupancy=state; b.observedAt=self.clock
        local reservation=b.reservation
        if reservation~=nil then
            local root=self.roots[reservation.vehicleId]
            local reason
            if self.clock>=reservation.expiresAt then reason="LEASE_EXPIRED"
            elseif root==nil or not root.identityValid or root.farmId~=reservation.farmId then reason="VEHICLE_OR_FARM_CHANGED"
            elseif b.operational~="OPEN" or state=="UNKNOWN" then reason="BAY_UNAVAILABLE"
            elseif self.admissions~=nil and self.admissions[reservation]~=nil and self.admissions[reservation].foldedProof~=nil
                and not self:admissionValid(b,reservation.vehicleId) then reason="FOLDED_GEOMETRY_CHANGED"
            else for occupant in pairs(hits[id]) do if occupant~=reservation.vehicleId then reason="FOREIGN_BLOCKER" end end end
            if reason~=nil then b.reservation=nil; b.releaseReason=reason; differs=true end
        end
        if differs then b.revision=b.revision+1; self:changed() end
    end
    self.ready=true; self.lastScan=self.clock; return true
end
function S:logUnknownOccupancy(b)
    local metrics=self.metrics or {};local counts={}
    for reason,count in pairs(metrics.unknownReasons or {}) do counts[#counts+1]=reason.."="..count end
    table.sort(counts)
    print("[SmartGate][SERVICE][OCCUPANCY] bay="..tostring(b.id).." state=UNKNOWN reasons="..table.concat(counts,","))
    for _,sample in ipairs(metrics.unknownSamples or {}) do
        local function bounded(v) return tostring(v):gsub("[\r\n]"," "):sub(1,180) end
        print("[SmartGate][SERVICE][OCCUPANCY_SOURCE] reason="..sample.reason.." id="..bounded(sample.id).." name="..bounded(sample.name).." xml="..bounded(sample.xml))
    end
end
function S:reserve(id,jobId,vehicleId,ownerId,farmId,services,revision,epoch,foldedProof)
    if g_server==nil or self.disposed or not self.persistenceSafe or not self.loaded then return false,"SERVER_ONLY_OR_DISPOSED" end
    if epoch~=self.epoch or not text(jobId) or not text(vehicleId) or not text(ownerId) then return false,"INVALID_IDENTITY" end
    local b=self.bays[id]; if b==nil or revision~=b.revision then return false,"STALE_BAY" end
    if self.pendingGeometry~=nil and self.pendingGeometry["bay:"..id]~=nil then return false,"GEOMETRY_UNSAVED" end
    self:scan(); if revision~=b.revision then return false,"STALE_BAY" end
    if b.occupancy=="UNKNOWN" then self:logUnknownOccupancy(b) end
    local p=self.providers[b.providerId]; local root=self.roots[vehicleId]
    if not integer(farmId,1,65535) or p.farmId~=farmId or root==nil or root.farmId~=farmId or not root.complete then return false,"ACCESS_OR_UNKNOWN_VEHICLE" end
    if b.operational~="OPEN" or b.occupancy=="UNKNOWN" or type(services)~="table" or next(services)==nil then return false,"BAY_UNAVAILABLE" end
    for service,needed in pairs(services) do if needed~=true or b.capabilities[service]~=true then return false,"CAPABILITY" end end
    for occupant in pairs(b.occupants) do if occupant~=vehicleId then return false,"FOREIGN_BLOCKER" end end
    local size=root.dimensions; if size==nil then return false,"UNKNOWN_SIZE" end
    local acceptedProof
    if size.width>b.width or size.height>b.height or size.length>b.length then
        if self.validateFoldedGeometryProof==nil or not self:validateFoldedGeometryProof(foldedProof,b,root,false) then return false,"SIZE" end
        size={width=foldedProof.dimensions.width,height=math.max(size.height,foldedProof.dimensions.height),
            length=math.max(size.length,foldedProof.dimensions.length)}
        acceptedProof=foldedProof
        if size.width>b.width or size.height>b.height or size.length>b.length then return false,"SIZE" end
    end
    for _,other in pairs(self.bays) do if other.reservation~=nil and overlap(b.rect,other.rect) then return false,"RESERVED_OR_OVERLAP" end end
    local admitted={}
    for _,unit in ipairs(root.units) do
        admitted[unit]={width=unit.size.width,height=unit.size.height,length=unit.size.length,lengthOffset=tonumber(unit.size.lengthOffset) or 0,
            parent=root.links[unit]~=nil and root.links[unit].parent or nil,
            jointDescIndex=root.links[unit]~=nil and root.links[unit].jointDescIndex or nil,
            inputJointDescIndex=root.links[unit]~=nil and root.links[unit].inputJointDescIndex or nil}
    end
    b.reservation={jobId=jobId,vehicleId=vehicleId,ownerId=ownerId,farmId=farmId,expiresAt=self.clock+60000,epoch=self.epoch}
    -- Private runtime metadata must never enter provider copies or MP DTOs.
    self.admissions=self.admissions or setmetatable({},{__mode="k"})
    self.admissions[b.reservation]={units=admitted,count=#root.units,foldedProof=acceptedProof}
    if acceptedProof~=nil then acceptedProof.consumed=true end
    b.revision=b.revision+1; self:changed(); return true,b.revision
end
function S:admissionValid(b,vehicleId)
    local r=b.reservation;local root=self.roots[vehicleId]
    local admission=r~=nil and self.admissions~=nil and self.admissions[r]
    if r==nil or r.vehicleId~=vehicleId or root==nil or not root.complete or root.farmId~=r.farmId
        or admission==nil or admission.count~=#root.units then return false end
    for _,unit in ipairs(root.units) do
        local saved=admission.units[unit];local size=unit.size
        if saved==nil or size==nil or saved.width~=size.width or saved.height~=size.height or saved.length~=size.length
            or saved.lengthOffset~=(tonumber(size.lengthOffset) or 0)
            or saved.parent~=(root.links[unit]~=nil and root.links[unit].parent or nil)
            or saved.jointDescIndex~=(root.links[unit]~=nil and root.links[unit].jointDescIndex or nil)
            or saved.inputJointDescIndex~=(root.links[unit]~=nil and root.links[unit].inputJointDescIndex or nil) then return false end
    end
    if admission.foldedProof~=nil and (self.validateFoldedGeometryProof==nil
        or not self:validateFoldedGeometryProof(admission.foldedProof,b,root,true)) then return false end
    return true
end
function S:release(id,jobId,ownerId,revision,epoch)
    if g_server==nil or self.disposed then return false,"SERVER_ONLY_OR_DISPOSED" end
    local b=self.bays[id]; local r=b~=nil and b.reservation or nil
    if epoch~=self.epoch or b==nil or revision~=b.revision or r==nil or r.jobId~=jobId or r.ownerId~=ownerId then return false,"STALE_OR_FOREIGN_RESERVATION" end
    b.reservation=nil; b.releaseReason="EXPLICIT_RELEASE"; b.revision=b.revision+1; self:changed(); return true
end
function S:renew(id,jobId,ownerId,revision,epoch)
    if g_server==nil or self.disposed or not self.persistenceSafe then return false,"SERVER_ONLY_OR_DISPOSED" end
    local b=self.bays[id]; local r=b~=nil and b.reservation or nil
    if epoch~=self.epoch or b==nil or revision~=b.revision or r==nil or r.jobId~=jobId or r.ownerId~=ownerId or self.clock>=r.expiresAt then return false,"STALE_OR_FOREIGN_RESERVATION" end
    self:scan()
    -- The synchronous refresh can legitimately advance the DTO revision when
    -- the lease's own vehicle enters/leaves the bay. Its reservation identity
    -- must survive; a foreign blocker/unknown state revokes it in scan().
    -- Caller revisions are still checked above, before our own refresh.
    if b.reservation~=r or b.occupancy=="UNKNOWN" then return false,"BAY_UNAVAILABLE" end
    r.expiresAt=self.clock+60000; b.revision=b.revision+1; self:changed(); return true,b.revision
end
function S:providerDTOs() local result={}; for _,p in ipairs(sorted(self.providers)) do result[#result+1]={id=p.id,name=self:displayName(p,"provider"),farmId=p.farmId,bayCount=count(p.bays),visualArea=clone(p.area or p.visualArea)} end; return result end
function S:bayDTOs(private)
    local result={}
    for _,b in ipairs(sorted(self.bays)) do
        local occupants={}; for id in pairs(b.occupants or {}) do occupants[#occupants+1]=id end; table.sort(occupants)
        local r=b.reservation
        local dto={id=b.id,providerId=b.providerId,name=self:displayName(b,"bay"),farmId=self.providers[b.providerId].farmId,
            capabilities=clone(b.capabilities),dimensions={width=b.width,height=b.height,length=b.length},
            position={x=b.x,y=b.y,z=b.z},yaw=b.yaw,operational=b.operational,
            occupancy=self.ready and b.occupancy or "UNKNOWN",occupants=occupants,
            adTarget=b.adTarget>0 and b.adTarget or "UNKNOWN",adTargetStatus="UNKNOWN",reachable="UNKNOWN",revision=b.revision,epoch=self.epoch,
            reservationStatus=r~=nil and "RESERVED" or "FREE",reservationVehicleId=r~=nil and r.vehicleId or nil,
            reservationExpiresAt=r~=nil and r.expiresAt or nil,ownOccupied=false,foreignBlockers={},reservationConflicts={}}
        for _,id in ipairs(occupants) do if r~=nil and r.vehicleId==id then dto.ownOccupied=true else dto.foreignBlockers[#dto.foreignBlockers+1]=id end end
        if b.adTarget>0 then dto.adTargetStatus=self:destinationStatus(b.adTarget) end
        for _,other in pairs(self.bays) do if other.id~=b.id and other.reservation~=nil and overlap(b.rect,other.rect) then dto.reservationConflicts[#dto.reservationConflicts+1]=other.id end end
        table.sort(dto.reservationConflicts)
        if private and r~=nil then dto.reservation={jobId=r.jobId,vehicleId=r.vehicleId,ownerId=r.ownerId,
            farmId=r.farmId,expiresAt=r.expiresAt,epoch=r.epoch} end
        if private then dto.observedAt=b.observedAt end
        result[#result+1]=dto
    end
    return result
end
function S:inspect(id,vehicleId,services)
    local b=self.bays[id]
    if b==nil or self.disposed or not self.persistenceSafe then return {provider="UNKNOWN",bay="UNKNOWN",technicallySuitable="UNKNOWN",physicallyFree="UNKNOWN"} end
    local root=self.roots[vehicleId]; local size=root~=nil and root.dimensions or nil
    local admission=b.reservation~=nil and self.admissions~=nil and self.admissions[b.reservation] or nil
    local measured=admission~=nil and admission.foldedProof~=nil and self:admissionValid(b,vehicleId)
    if measured then size={width=admission.foldedProof.dimensions.width,
        height=math.max(size.height,admission.foldedProof.dimensions.height),
        length=math.max(size.length,admission.foldedProof.dimensions.length)} end
    local technical="UNKNOWN"
    if size~=nil and type(services)=="table" and next(services)~=nil then
        technical=size.width<=b.width and size.height<=b.height and size.length<=b.length
        for capability,requested in pairs(services) do if requested~=true or b.capabilities[capability]~=true then technical=false end end
    end
    local allowed="UNKNOWN"; if root~=nil then allowed=root.farmId==self.providers[b.providerId].farmId end
    return {provider="KNOWN",bay="KNOWN",providerId=b.providerId,bayId=b.id,technicallySuitable=technical,
        dimensions=clone(size),sizeSource=measured and "EXACT_FOLDED_COLLISION_CERTIFICATE" or "DECLARED",
        declaredLength=root~=nil and root.declaredLength or nil,
        admissionValid=self:admissionValid(b,vehicleId),hitchFallbackReason=root~=nil and root.hitchFallbackReason or nil,
        lengthMethod=root~=nil and root.lengthMethod or "UNKNOWN",lengthFallbackReason=root~=nil and root.lengthFallbackReason or nil,
        bayDimensions={width=b.width,height=b.height,length=b.length},
        physicallyFree=b.occupancy=="UNKNOWN" and "UNKNOWN" or b.occupancy=="FREE",
        ownOccupied=(b.occupants or {})[vehicleId]==true,reserved=b.reservation~=nil,
        operational=b.operational=="OPEN",adTarget=b.adTarget>0 and b.adTarget or "UNKNOWN",
        adTargetStatus=self:destinationStatus(b.adTarget),
        reachable="UNKNOWN",farmAllowed=allowed,revision=b.revision,epoch=self.epoch}
end
-- Temporary editing consent is not persisted and never changes farm access.
local function providerDistance(p,where)
    local a=p~=nil and (p.area or p.visualArea)
    if where==nil or not validArea(a) then return nil,false end
    local dx,dz=where.x-a.x,where.z-a.z
    local r=box(a.x,a.z,a.yaw,a.width,a.length)
    local lateral,forward=math.abs(dx*r.rx+dz*r.rz),math.abs(dx*r.fx+dz*r.fz)
    local inside=lateral<=r.w and forward<=r.l
    -- Distance to the rotated rectangle, not its centre. Corner clearance is
    -- Euclidean, so the edit margin cannot accidentally become 14 m diagonally.
    local outsideX,outsideZ=math.max(0,lateral-r.w),math.max(0,forward-r.l)
    return math.sqrt(outsideX*outsideX+outsideZ*outsideZ),inside
end
local function remoteAdmin(connection)
    if connection==nil then return g_dedicatedServer==nil and g_localPlayer~=nil end
    local user=call(g_currentMission~=nil and g_currentMission.userManager,"getUserByConnection",connection)
    return call(user,"getIsMasterUser")==true
end
function S:editorContext()
    return {providerId=self.selectedProvider or "",bayId=self.selectedBay or "",revision=self.configRevision or 1,epoch=self.epoch}
end
function S:contextMatches(c)
    return c~=nil and c.providerId==(self.selectedProvider or "") and c.bayId==(self.selectedBay or "") and c.epoch==self.epoch and c.revision==(self.configRevision or 1)
end
function S:setSelectedProvider(id)
    if self.selectedProvider==id then return end
    self.selectedProvider=id;self.selectedBay=nil;self.adProposal=nil;self.remoteEditProvider=nil;self.remoteEditUntil=nil
    self:request("EDIT_CONTEXT")
end
function S:beginEditor()
    self.remoteEditProvider=nil;self.remoteEditUntil=nil;self.adProposal=nil
    local where=pose(g_localPlayer);local candidate;local matches=0
    for id,p in pairs(self.providers) do local _,inside=providerDistance(p,where)
        if inside then matches=matches+1;candidate=id end
    end
    if matches==1 then self:setSelectedProvider(candidate)
    elseif matches>1 then self.lastError=tr("Überlappende Bereiche: Bereich bewusst auswählen","Overlapping areas: select the provider explicitly") end
    self.editorAutoProvider=matches==1 and candidate or nil
    self.editorAutoCheckAt=self.clock
    self:request("EDIT_CONTEXT") -- also revoke a previous grant when reopening the same provider
end
function S:updateEditorProviderSelection()
    local owner=self.owner
    if g_localPlayer==nil or g_dedicatedServer~=nil or owner==nil
        or not owner.configModeEnabled or not owner.serviceConfigView then
        self.editorAutoProvider=nil;self.editorAutoCheckAt=nil;return
    end
    if self.editorAutoCheckAt~=nil and self.clock-self.editorAutoCheckAt<500 then return end
    self.editorAutoCheckAt=self.clock
    if guiOpen() or owner.configOverlayDrag~=nil or self.panelWheelFlight~=nil or self.geometryUnsaved then return end
    local where=pose(g_localPlayer)
    if where==nil then return end
    local candidate,matches=nil,0
    for id,p in pairs(self.providers) do
        local _,inside=providerDistance(p,where)
        if inside then candidate=id;matches=matches+1 end
    end
    -- Ambiguous overlaps never override deliberate manual selection.
    if matches>1 then return end
    if matches==0 then
        local distance=providerDistance(self.providers[self.editorAutoProvider],where)
        -- Rearm only beyond a small edge buffer to avoid repeated boundary flips.
        if distance==nil or distance>.5 then self.editorAutoProvider=nil end
        return
    end
    if self.editorAutoProvider==candidate then return end
    self.editorAutoProvider=candidate
    self:resetPanelWheel()
    self:setSelectedProvider(candidate) -- existing context/remote-consent lifecycle
end
function S:canEditHere()
    local distance=providerDistance(self.providers[self.selectedProvider],pose(g_localPlayer))
    return distance~=nil and distance<=EDIT_MARGIN_METRES
        or self.remoteEditProvider==self.selectedProvider and self.clock<(self.remoteEditUntil or 0)
end
function S:edit(op,providerId,bayId,field,value,name,revision,epoch,connection)
    if g_server==nil or self.disposed or not self.persistenceSafe or not self.loaded then return false,"NOT_AUTHORITATIVE_OR_UNSAFE" end
    if op=="SAVE_GEOMETRY" then
        if epoch~=self.epoch then return false,"STALE_CONFIG" end
        local player=actor(connection);local key=connection or self;local relevant=false
        for _,entry in pairs(self.pendingGeometry or {}) do
            if entry.actor==key or player~=nil and entry.farmId==player.farmId then relevant=true;break end
        end
        if not relevant then return true,"GEOMETRY_UNCHANGED" end
        if player==nil then return false,"NO_AUTHORIZED_FARM" end
        return self:flushGeometry()
    end
    local deferred=type(op)=="string" and op:sub(1,6)=="DRAFT_"
    if deferred then op=op:sub(7);if geometryKind(op,field)==nil then return false,"INVALID_GEOMETRY_OPERATION" end end
    if type(name)=="string" then name=name:match("^%s*(.-)%s*$") end
    if revision~=(self.configRevision or 1) or epoch~=self.epoch then return false,"STALE_CONFIG" end
    local player=actor(connection); local farm=player~=nil and player.farmId or nil
    if not integer(farm,1,65535) then return false,"NO_AUTHORIZED_FARM" end
    local lookYaw
    if poseOperation(op) and field=="poseYaw" then
        if not finite(value) or math.abs(value)>math.pi*2 then return false,"INVALID_POSE_YAW" end
        lookYaw=value
    end
    local p=self.providers[providerId]; local b=self.bays[bayId]
    if op=="EDIT_CONTEXT" then
        if self.remoteEditGrants~=nil then self.remoteEditGrants[connection or self]=nil end
        return true,providerId
    end
    if op~="NEW_PROVIDER" and op~="PROVIDER_FROM_SOURCE" and (p==nil or p.farmId~=farm) then return false,"FARM_ACCESS" end
    if (op=="SET_BAY" or op=="REMOVE_BAY" or op=="PLACE_BAY" or op=="RESET_BAY_POSE" or op=="BIND_WASH" or op=="UNBIND_WASH") and b==nil then return false,"UNKNOWN_BAY" end
    if b~=nil and b.providerId~=providerId then return false,"WRONG_PROVIDER" end
    self.remoteEditGrants=self.remoteEditGrants or setmetatable({},{__mode="k"})
    local actorKey=connection or self
    if op=="UNLOCK_REMOTE" then
        if not remoteAdmin(connection) then return false,"REMOTE_ADMIN_REQUIRED" end
        self.remoteEditGrants[actorKey]={providerId=providerId,untilTime=self.clock+300000}
        return true,providerId
    end
    local previousGrant=self.remoteEditGrants[actorKey]
    if previousGrant~=nil and previousGrant.providerId~=providerId then self.remoteEditGrants[actorKey]=nil end
    if p~=nil and op~="NEW_PROVIDER" and op~="PROVIDER_FROM_SOURCE" then
        local distance=providerDistance(p,pose(player));local grant=self.remoteEditGrants[actorKey]
        if not (distance~=nil and distance<=EDIT_MARGIN_METRES) and not (remoteAdmin(connection) and grant~=nil and grant.providerId==p.id and self.clock<grant.untilTime) then return false,"REMOTE_CONFIRM_REQUIRED" end
    end
    local kind=geometryKind(op,field)
    local before
    if kind~=nil then before=geometryValues(kind=="bay" and b or p~=nil and p.area,kind) end
    if kind~=nil and (op=="SET_BAY" or op=="SET_PROVIDER_AREA") and before and finite(value) and before[field]==value then
        return true,self.pendingGeometry~=nil and "GEOMETRY_PENDING" or "GEOMETRY_UNCHANGED"
    end
    local previous=not deferred and clone(self.providers) or nil; local selected
    if op=="NEW_PROVIDER" or op=="PROVIDER_FROM_SOURCE" then
        local where=pose(player,lookYaw); local source
        if op=="PROVIDER_FROM_SOURCE" then
            source=self.owner:getWashPointTemplate(field)
            if source==nil or source.farmId~=farm then
                print("[SmartGate][SERVICE][SOURCE_REJECT] op=PROVIDER_FROM_SOURCE id="..tostring(field):gsub("[%c]"," "):sub(1,160).." actorFarm="..tostring(farm).." template="..tostring(source~=nil).." sourceFarm="..tostring(source and source.farmId))
                return false,"SOURCE_ACCESS_OR_UNKNOWN"
            end
            where=source
        end
        if count(self.providers)>=MAX_PROVIDERS or self.providerSerial>=2147483647 then return false,"PROVIDER_LIMIT" end
        self.providerSerial=self.providerSerial+1
        local id="SGSP-"..self.providerSerial
        local area=where~=nil and {x=where.x,y=where.y,z=where.z,yaw=where.yaw,width=source~=nil and source.width or 20,length=source~=nil and source.length or 20} or nil
        if area~=nil and not validArea(area) then area=nil end
        self.providers[id]={id=id,name=source~=nil and source.name or "",nameCustom=source~=nil,farmId=farm,bays={},area=area}; selected=id
    elseif op=="REMOVE_PROVIDER" then self.providers[p.id]=nil
    elseif op=="NEW_BAY" then
        local where=pose(player,lookYaw)
        if where==nil or count(self.bays)>=MAX_BAYS or self.baySerial>=2147483647 then return false,"POSE_OR_BAY_LIMIT" end
        self.baySerial=self.baySerial+1
        local id="SGSB-"..self.baySerial
        p.bays[id]={id=id,providerId=p.id,name="",nameCustom=false,x=where.x,y=where.y,z=where.z,yaw=where.yaw,
            width=5,height=5,length=12,adTarget=-1,capabilities={WASH=true,REPAIR=false,REFUEL=false},
            operational="CLOSED",occupancy="UNKNOWN",occupants={},revision=1}; selected=id
    elseif op=="RENAME_PROVIDER" then if not validName(name) then return false,"INVALID_NAME" end; p.name=name; p.nameCustom=name~=""
    elseif op=="PLACE_PROVIDER" or op=="SET_PROVIDER_AREA" then
        local a=clone(p.area or p.visualArea)
        if op=="PLACE_PROVIDER" then
            local where=pose(player,lookYaw); if where==nil then return false,"UNKNOWN_POSE" end
            if not validArea(a) then a={width=20,length=20} end; for _,f in ipairs(ORIGIN_FIELDS) do a[f]=where[f] end
        else
            if a==nil then return false,"POSITION_PROVIDER_FIRST" end
            local permitted=false; for _,f in ipairs(AREA_FIELDS) do permitted=permitted or f==field end
            if not permitted or not finite(value) then return false,"INVALID_AREA_FIELD" end
            a[field]=value
        end
        if not validArea(a) then return false,"INVALID_PROVIDER_AREA" end
        p.area=a
    elseif b==nil and op~="IMPORT_WASH" then return false,"UNKNOWN_BAY"
    elseif op=="IMPORT_WASH" then
        local original=self.owner:getWashPointTemplate(field)
        if original==nil or original.farmId~=farm then
            print("[SmartGate][SERVICE][SOURCE_REJECT] op=IMPORT_WASH id="..tostring(field):gsub("[%c]"," "):sub(1,160).." actorFarm="..tostring(farm).." template="..tostring(original~=nil).." sourceFarm="..tostring(original and original.farmId))
            return false,"WASH_SOURCE_ACCESS_OR_UNKNOWN"
        end
        if self.serviceSourceInProvider~=nil and not self:serviceSourceInProvider(p,self.owner:findServiceSource(field)) then return false,"SOURCE_OUTSIDE_PROVIDER" end
        local existing=self:getLegacyWashBay(original.id)
        if existing==nil and type(self.owner.findServiceSource)=="function" then
            local source=self.owner:findServiceSource(original.id)
            if source~=nil and not self.owner:hasGateIdCollision(source.id) then existing=self:getLegacyWashBay(source.id) end
        end
        if existing~=nil then return true,existing.id end
        if count(self.bays)>=MAX_BAYS or self.baySerial>=2147483647 then return false,"BAY_LIMIT" end
        for _,f in ipairs({"width","height","length"}) do if not finite(original[f]) or original[f]<.5 or original[f]>100 then return false,"LEGACY_DIMENSIONS_OUTSIDE_BAY_LIMITS" end end
        self.baySerial=self.baySerial+1; local id="SGSB-"..self.baySerial
        p.bays[id]={id=id,providerId=p.id,name=original.name,x=original.x,y=original.y,z=original.z,yaw=original.yaw,
            width=original.width,height=original.height,length=original.length,adTarget=-1,
            capabilities=clone(original.capabilities or {WASH=true,REPAIR=false,REFUEL=false}),legacyWashGateId=original.id,
            operational="CLOSED",occupancy="UNKNOWN",occupants={},revision=1}; selected=id
    elseif op=="BIND_WASH" or op=="UNBIND_WASH" then
        if b.reservation~=nil then return false,"WASH_BINDING_RESERVED" end
        if op=="BIND_WASH" then
            if type(field)~="string" or #field==0 or #field>1024 then return false,"WASH_SOURCE_ACCESS_OR_UNKNOWN" end
            local gate
            if type(self.owner.findServiceSource)=="function" then gate=self.owner:findServiceSource(field) else gate=self.owner:findGateById(field) end
            local caps=type(self.owner.getServiceSourceCapabilities)=="function" and self.owner:getServiceSourceCapabilities(gate) or nil
            if gate==nil or gate.blacklisted or gate.mode==0 or not (caps~=nil or call(self.owner,"isServiceWashSource",gate)==true)
                or call(gate.owner,"getOwnerFarmId")~=farm then return false,"WASH_SOURCE_ACCESS_OR_UNKNOWN" end
            if self.serviceSourceInProvider~=nil and not self:serviceSourceInProvider(p,gate) then return false,"SOURCE_OUTSIDE_PROVIDER" end
            if caps~=nil then local shared=false;for cap,active in pairs(b.capabilities) do shared=shared or active and caps[cap]==true end;if not shared then return false,"SERVICE_CAPABILITY_MISMATCH" end
            elseif not b.capabilities.WASH then return false,"WASH_CAPABILITY_REQUIRED" end
            local sourceId=type(self.owner.getServiceSourceId)=="function" and self.owner:getServiceSourceId(gate) or gate.id
            if sourceId==nil then return false,"WASH_SOURCE_ACCESS_OR_UNKNOWN" end
            local existing=self:getLegacyWashBay(sourceId)
            if existing==nil and not self.owner:hasGateIdCollision(gate.id) then existing=self:getLegacyWashBay(gate.id) end
            if existing~=nil and existing.id~=b.id then return false,"WASH_SOURCE_ALREADY_BOUND" end
            if b.legacyWashGateId==sourceId then return true,b.id end
            b.legacyWashGateId=sourceId
        else b.legacyWashGateId=nil end
        b.releaseReason="WASH_BINDING_CHANGED";b.revision=b.revision+1
    elseif op=="REMOVE_BAY" then p.bays[b.id]=nil
    elseif op=="PLACE_BAY" or op=="RESET_BAY_POSE" then
        local where=op=="RESET_BAY_POSE" and b.origin or pose(player,lookYaw); if where==nil then return false,"UNKNOWN_POSE" end
        if b.origin==nil then b.origin=origin(b) end
        for _,f in ipairs({"x","y","z","yaw"}) do b[f]=where[f] end
        b.reservation=nil; b.occupancy="UNKNOWN"; b.occupants={}; b.revision=b.revision+1
    elseif op=="SET_BAY" then
        if field~="name" and not finite(value) then return false,"INVALID_VALUE" end
        if (field=="operational" or field=="WASH" or field=="REPAIR" or field=="REFUEL") and value~=0 and value~=1 then return false,"INVALID_BOOLEAN" end
        if field=="name" then if not validName(name) then return false,"INVALID_NAME" end; b.name=name; b.nameCustom=name~=""
        elseif field=="operational" then b.operational=value==1 and "OPEN" or "CLOSED"; b.reservation=nil
        elseif field=="WASH" or field=="REPAIR" or field=="REFUEL" then
            local caps=clone(b.capabilities); caps[field]=value==1
            if not (caps.WASH or caps.REPAIR or caps.REFUEL) then return false,"NO_CAPABILITY" end
            if b.reservation~=nil then b.releaseReason="CAPABILITIES_CHANGED" end
            b.capabilities=caps; b.reservation=nil
        elseif field=="serviceLift" or field=="serviceLiftDelayMs" or field=="serviceInteraction" then
            if b.reservation~=nil then return false,"WASH_BINDING_RESERVED" end
            if field=="serviceLift" or field=="serviceInteraction" then if value~=0 and value~=1 then return false,"INVALID_BOOLEAN" end;b[field]=value==1
            else if not integer(value,0,10000) then return false,"INVALID_VALUE" end;b.serviceLiftDelayMs=value end
        elseif field=="adTarget" then if not integer(value,-1,16777215) or value==0 then return false,"INVALID_TARGET" end; b.adTarget=value; b.reservation=nil; self.adObservedAt=nil
        elseif field=="width" or field=="height" or field=="length" then
            if not finite(value) or value<.5 or value>100 then return false,"INVALID_DIMENSION" end
            b[field]=value; b.reservation=nil; b.occupancy="UNKNOWN"
        elseif field=="x" or field=="y" or field=="z" then
            if not finite(value) or math.abs(value)>1000000 then return false,"INVALID_POSITION" end
            b[field]=value; b.reservation=nil; b.occupancy="UNKNOWN"; b.occupants={}
        elseif field=="yaw" then if not finite(value) or math.abs(value)>math.pi*2 then return false,"INVALID_YAW" end; b.yaw=value; b.reservation=nil; b.occupancy="UNKNOWN"
        else return false,"INVALID_FIELD" end
        if field=="x" or field=="y" or field=="z" or field=="yaw" or field=="width" or field=="height" or field=="length" then
            b.occupants={}; b.releaseReason="GEOMETRY_CHANGED"
        end
        b.revision=b.revision+1
    else return false,"INVALID_OPERATION" end
    for _,provider in pairs(self.providers) do for _,bay in pairs(provider.bays) do if bay.origin==nil then bay.origin=origin(bay) end end end
    self:reindex()
    if deferred then
        local target=kind=="bay" and b or p.area;local id=kind=="bay" and b.id or p.id
        local key=kind..":"..id
        self.pendingGeometry=self.pendingGeometry or {}
        local entry=self.pendingGeometry[key] or {before=before,farmId=farm,actor=connection or self}
        entry.actor=connection or self
        self.pendingGeometry[key]=not sameGeometry(entry.before,geometryValues(target,kind)) and entry or nil
        if next(self.pendingGeometry)==nil then self.pendingGeometry=nil end
        self.geometryUnsaved=self.pendingGeometry~=nil
        self.configRevision=(self.configRevision or 1)+1;self:changed()
        -- Geometry is live, but an edited bay cannot be reserved until saved.
        -- Occupancy is refreshed by the unchanged periodic service scan.
        -- Do not force an additional scan on the next frame for each click.
        return true,self.geometryUnsaved and "GEOMETRY_PENDING" or "GEOMETRY_UNCHANGED"
    end
    if not self.owner:saveConfig(nil,"SERVICE_CONFIG") then
        self.providers=previous; self:reindex(); return false,"PERSISTENCE_FAILED"
    end
    self.configRevision=(self.configRevision or 1)+1; self:changed(); self:scan()
    if op=="SET_BAY" and field=="adTarget" and self.adDebug then self:logAdDiagnostics("MARKER_SAVED",b.id) end
    if selected~=nil then if op=="NEW_PROVIDER" or op=="PROVIDER_FROM_SOURCE" then self.selectedProvider=selected else self.selectedBay=selected end end
    return true,selected
end
function S:request(op,field,value,name,context)
    if context~=nil and not self:contextMatches(context) then self.lastError="STALE_EDITOR_SELECTION";return end
    local c=context or self:editorContext()
    if poseOperation(op) then
        -- The server keeps the authoritative actor position. Only the local
        -- camera heading is supplied, in the existing bounded scalar field.
        local where=pose(g_localPlayer)
        if where==nil then self.lastError="UNKNOWN_POSE";return end
        field="poseYaw";value=where.yaw
    end
    if self.owner.configModeEnabled and geometryKind(op,field)~=nil then op="DRAFT_"..op end
    local mutates=op~="SAVE_GEOMETRY" and op~="NEW_PROVIDER" and op~="PROVIDER_FROM_SOURCE" and op~="EDIT_CONTEXT" and op~="UNLOCK_REMOTE" and op~="PREOPEN_AUTO_ALL"
    if mutates and self.providers[c.providerId]~=nil and not self:canEditHere() then self.lastError="REMOTE_CONFIRM_REQUIRED";return end
    local request=SGServiceEditEvent.new(op,c.providerId,c.bayId,field or "",value or 0,name or "",c.revision,c.epoch)
    if g_server~=nil then request:run(nil) elseif g_client~=nil then g_client:getServerConnection():sendEvent(request) end
end

-- A separate versioned event avoids changing the gate protocol/IDs. Full state
-- arrives on the same modest 5s schedule, including late joins; no join hook.
SGServiceEditEvent={}
local Edit_mt=Class(SGServiceEditEvent,Event)
InitEventClass(SGServiceEditEvent,"SGServiceEditEvent")
function SGServiceEditEvent.emptyNew() return Event.new(Edit_mt) end
function SGServiceEditEvent.new(op,p,b,f,v,n,revision,epoch)
    local e=SGServiceEditEvent.emptyNew(); e.op=op; e.providerId=p; e.bayId=b; e.field=f; e.value=v; e.name=n; e.revision=revision; e.epoch=epoch; return e
end
function SGServiceEditEvent:writeStream(id)
    for _,key in ipairs({"op","providerId","bayId","field","name","epoch"}) do streamWriteString(id,self[key]) end
    streamWriteFloat32(id,self.value); streamWriteInt32(id,self.revision)
end
function SGServiceEditEvent:readStream(id,connection)
    for _,key in ipairs({"op","providerId","bayId","field","name","epoch"}) do self[key]=streamReadString(id) end
    self.value=streamReadFloat32(id); self.revision=streamReadInt32(id); self:run(connection)
end
function SGServiceEditEvent:run(connection)
    local s=g_smartGate~=nil and g_smartGate.serviceInfrastructure or nil
    if s==nil or g_server==nil or (connection~=nil and call(connection,"getIsServer")~=false) then return end
    if self.op=="PREOPEN_AUTO_ALL" then
        local permitted=connection==nil and g_dedicatedServer==nil
        if connection~=nil then
            local user=call(g_currentMission~=nil and g_currentMission.userManager,"getUserByConnection",connection)
            permitted=call(user,"getIsMasterUser")==true
        end
        if permitted and s.loaded and s.persistenceSafe and self.epoch==s.epoch and self.revision==s.configRevision then
            local ok=s.owner:recalculateADPreOpen()
            if ok then
                s.configRevision=s.configRevision+1;s:changed()
                SmartGateStateSyncEvent.sendToClients(s.owner.gates)
            end
        end
        if connection~=nil then connection:sendEvent(SGServiceStateEvent.new(s)) else SGServiceStateEvent.send(s) end
        return
    end
    if self.op=="NEW_GATE_DEFAULT" then
        local permitted=connection==nil and g_dedicatedServer==nil
        if connection~=nil then
            local user=call(g_currentMission~=nil and g_currentMission.userManager,"getUserByConnection",connection)
            permitted=call(user,"getIsMasterUser")==true
        end
        if permitted and (self.value==0 or self.value==1) and self.epoch==s.epoch and self.revision==s.configRevision then
            local previous=s.owner.newGatesEnabled;s.owner.newGatesEnabled=self.value==1
            if not s.owner:saveConfig(nil,"NEW_GATE_DEFAULT") then s.owner.newGatesEnabled=previous else s.configRevision=s.configRevision+1;s:changed() end
        end
        if connection~=nil then connection:sendEvent(SGServiceStateEvent.new(s)) else SGServiceStateEvent.send(s) end
        return
    end
    if self.op=="REFRESH_AD" then
        local player=actor(connection)
        if player~=nil and integer(player.farmId,1,65535) then
            s:refreshDestinations(true); s:changed()
            if connection~=nil then connection:sendEvent(SGServiceStateEvent.new(s)) else SGServiceStateEvent.send(s) end
        end
        return
    end
    local ok,reason=s:edit(self.op,self.providerId,self.bayId,self.field,self.value,self.name,self.revision,self.epoch,connection)
    if not ok then print("[SmartGate][SERVICE][CONFIG] rejected="..tostring(reason)) elseif self.op~="EDIT_CONTEXT" and self.op~="UNLOCK_REMOTE" then SGServiceStateEvent.send(s) end
    local reply=SGServiceEditResultEvent.new(ok,self.op,reason or "",s.epoch)
    if connection~=nil then connection:sendEvent(reply) else reply:apply(s) end
end
SGServiceEditResultEvent={}
local Result_mt=Class(SGServiceEditResultEvent,Event)
InitEventClass(SGServiceEditResultEvent,"SGServiceEditResultEvent")
function SGServiceEditResultEvent.emptyNew() return Event.new(Result_mt) end
function SGServiceEditResultEvent.new(ok,op,result,epoch) local e=SGServiceEditResultEvent.emptyNew(); e.ok=ok; e.op=op; e.result=result; e.epoch=epoch; return e end
function SGServiceEditResultEvent:writeStream(id) streamWriteBool(id,self.ok); streamWriteString(id,self.op); streamWriteString(id,self.result); streamWriteString(id,self.epoch) end
function SGServiceEditResultEvent:readStream(id,connection)
    self.ok=streamReadBool(id); self.op=streamReadString(id); self.result=streamReadString(id); self.epoch=streamReadString(id)
    if g_server==nil and call(connection,"getIsServer")==true and g_smartGate~=nil then self:apply(g_smartGate.serviceInfrastructure) end
end
function SGServiceEditResultEvent:apply(s)
    if s==nil or s.disposed or s.epoch~=self.epoch then return end
    if self.ok then if self.op~="EDIT_CONTEXT" then s.lastError=nil end else s.lastError=self.result end
    if self.ok and self.result=="GEOMETRY_PENDING" then s.geometryUnsaved=true end
    if self.ok and (self.op=="SAVE_GEOMETRY" or self.result=="GEOMETRY_UNCHANGED") then s.geometryUnsaved=false end
    if not self.ok and self.result=="GEOMETRY_SAVE_FAILED" then
        s.geometryUnsaved=true
        s.lastError=tr("Geometrie nicht gespeichert! Erneut öffnen und schließen, um zu speichern.","Geometry not saved! Reopen and close configuration to retry saving.")
        call(s.owner,"notifyServiceGeometrySaveFailed")
    end
    if not self.ok then
        local messages={
            SOURCE_OUTSIDE_PROVIDER=tr("Servicequelle liegt außerhalb des ausgewählten Bereichs.","Service source is outside the selected provider bounds."),
            WASH_BINDING_RESERVED=tr("Zuordnung während einer Reservierung gesperrt.","Binding cannot change while the bay is reserved."),
            WASH_CAPABILITY_REQUIRED=tr("Zuerst die Fähigkeit WASH aktivieren.","Enable the WASH capability first."),
            WASH_SOURCE_ALREADY_BOUND=tr("Quelle bereits mit anderem Serviceplatz verknüpft. Dort zuerst lösen.","Source already linked to another bay. Unlink it there first."),
            WASH_SOURCE_ACCESS_OR_UNKNOWN=tr("Servicequelle fehlt, ist gesperrt, nicht unterstützt oder gehört einem anderen Hof.","Service source is missing, disabled, unsupported or owned by another farm.")}
        s.lastError=messages[self.result] or s.lastError
    end
    if self.ok and self.op=="UNLOCK_REMOTE" and s.selectedProvider==self.result then s.remoteEditProvider=self.result;s.remoteEditUntil=s.clock+300000 end
    if self.ok and (self.op=="NEW_PROVIDER" or self.op=="PROVIDER_FROM_SOURCE") then s.selectedProvider=self.result; s.selectedBay=nil;s.remoteEditProvider=nil;s.remoteEditUntil=nil;s.adProposal=nil
    elseif self.ok and (self.op=="NEW_BAY" or self.op=="IMPORT_WASH") then s.selectedBay=self.result; if self.op=="IMPORT_WASH" and s.bays[self.result]~=nil then s.selectedProvider=s.bays[self.result].providerId end end
    if s.panelWheelFlight~=nil and s.panelWheelFlight.op==self.op then s:finishWheelRequest(self.ok) end
end
SGServiceStateEvent={}
local State_mt=Class(SGServiceStateEvent,Event)
InitEventClass(SGServiceStateEvent,"SGServiceStateEvent")
function SGServiceStateEvent.emptyNew() return Event.new(State_mt) end
function SGServiceStateEvent.new(s)
    local sources=type(s.sourceTemplateDTOs)=="function" and s:sourceTemplateDTOs() or {}
    local e=SGServiceStateEvent.emptyNew(); e.providers=clone(s.providers); e.epoch=s.epoch; e.revision=s.revision
    e.sourceTemplates=clone(sources)
    e.configRevision=s.configRevision or 1; e.providerSerial=s.providerSerial; e.baySerial=s.baySerial; e.clock=s.clock; e.safe=s.persistenceSafe and s.loaded; e.adDestinations=clone(s.adDestinations or {}); e.adSource=s.adDiagnostics~=nil and s.adDiagnostics.source or "UNAVAILABLE";e.newGatesEnabled=s.owner.newGatesEnabled~=false; return e
end
function SGServiceStateEvent:writeStream(id)
    streamWriteString(id,self.epoch); streamWriteInt32(id,self.revision); streamWriteInt32(id,self.configRevision)
    streamWriteInt32(id,self.providerSerial); streamWriteInt32(id,self.baySerial); streamWriteFloat32(id,self.clock); streamWriteBool(id,self.safe)
    streamWriteBool(id,self.newGatesEnabled~=false)
    streamWriteString(id,self.adSource)
    local ids={};for key in pairs(self.adDestinations) do ids[#ids+1]=key end;table.sort(ids)
    streamWriteUInt16(id,math.min(#ids,16384))
    for i=1,math.min(#ids,16384) do local marker=ids[i];streamWriteInt32(id,marker);streamWriteString(id,self.adDestinations[marker].name)
        local v=self.adDestinations[marker];local hasPosition=finite(v.x) and finite(v.z)
        streamWriteBool(id,hasPosition);if hasPosition then streamWriteFloat32(id,v.x);streamWriteFloat32(id,v.z) end
    end
    streamWriteUInt16(id,#self.sourceTemplates)
    for _,source in ipairs(self.sourceTemplates) do
        streamWriteString(id,source.id);streamWriteString(id,source.name);streamWriteUInt16(id,source.farmId)
        for _,field in ipairs({"x","y","z","yaw","width","height","length","sourceX","sourceZ"}) do streamWriteFloat32(id,source[field]) end
        for _,cap in ipairs(CAPS) do streamWriteBool(id,source.capabilities[cap]) end
    end
    local providers=sorted(self.providers); streamWriteUInt16(id,#providers)
    for _,p in ipairs(providers) do
        streamWriteString(id,p.id); streamWriteString(id,p.name); streamWriteBool(id,customName(p)); streamWriteUInt16(id,p.farmId)
        streamWriteBool(id,p.area~=nil)
        if p.area~=nil then for _,f in ipairs(AREA_FIELDS) do streamWriteFloat32(id,p.area[f]) end end
        local bays=sorted(p.bays); streamWriteUInt16(id,#bays)
        for _,b in ipairs(bays) do
            streamWriteString(id,b.id); streamWriteString(id,b.name); streamWriteBool(id,customName(b)); streamWriteString(id,b.legacyWashGateId or "")
            streamWriteBool(id,b.serviceLift==true);streamWriteUInt16(id,b.serviceLiftDelayMs or 0)
            streamWriteBool(id,b.serviceInteraction==true)
            for _,f in ipairs(FIELDS) do streamWriteFloat32(id,b[f]) end
            for _,f in ipairs(ORIGIN_FIELDS) do streamWriteFloat32(id,(b.origin or b)[f]) end
            for _,cap in ipairs(CAPS) do streamWriteBool(id,b.capabilities[cap]) end
            streamWriteBool(id,b.operational=="OPEN"); streamWriteString(id,b.occupancy or "UNKNOWN"); streamWriteInt32(id,b.revision)
            local occupants={}; for occupant in pairs(b.occupants or {}) do occupants[#occupants+1]=occupant end; table.sort(occupants)
            streamWriteUInt16(id,math.min(#occupants,512)); for i=1,math.min(#occupants,512) do streamWriteString(id,occupants[i]) end
            streamWriteBool(id,b.reservation~=nil)
            if b.reservation~=nil then streamWriteString(id,b.reservation.vehicleId); streamWriteFloat32(id,b.reservation.expiresAt) end
        end
    end
end
function SGServiceStateEvent:readStream(id,connection)
    self.epoch=streamReadString(id); self.revision=streamReadInt32(id); self.configRevision=streamReadInt32(id)
    self.providerSerial=streamReadInt32(id); self.baySerial=streamReadInt32(id); self.clock=streamReadFloat32(id); self.safe=streamReadBool(id); self.providers={}
    self.newGatesEnabled=streamReadBool(id)
    self.adSource=streamReadString(id);self.adDestinations={}
    local targets=streamReadUInt16(id);if targets>16384 then return end
    for _=1,targets do local marker,name=streamReadInt32(id),streamReadString(id)
        if not integer(marker,1,16777215) or type(name)~="string" or #name>128 or self.adDestinations[marker]~=nil then return end
        self.adDestinations[marker]={id=marker,name=name}
        if streamReadBool(id) then local x,z=streamReadFloat32(id),streamReadFloat32(id);if not finite(x) or not finite(z) then return end;self.adDestinations[marker].x=x;self.adDestinations[marker].z=z end
    end
    self.sourceTemplates={};local sources=streamReadUInt16(id);if sources>512 then return end
    local sourceIds={}
    for _=1,sources do
        local source={id=streamReadString(id),name=streamReadString(id),farmId=streamReadUInt16(id),capabilities={}}
        if type(source.id)~="string" or #source.id<1 or #source.id>1024 or source.id:find("[%c]") or sourceIds[source.id] or not validName(source.name)
            or not integer(source.farmId,1,65535) then return end
        for _,field in ipairs({"x","y","z","yaw","width","height","length","sourceX","sourceZ"}) do
            source[field]=streamReadFloat32(id);if not finite(source[field]) or math.abs(source[field])>1000000 then return end
        end
        for _,cap in ipairs(CAPS) do source.capabilities[cap]=streamReadBool(id) end
        sourceIds[source.id]=true;self.sourceTemplates[#self.sourceTemplates+1]=source
    end
    local total,seen=0,{}; local n=streamReadUInt16(id); if n>MAX_PROVIDERS then return end
    for _=1,n do
        local p={id=streamReadString(id),name=streamReadString(id),nameCustom=streamReadBool(id),farmId=streamReadUInt16(id),bays={}}
        if streamReadBool(id) then
            p.area={}; for _,f in ipairs(AREA_FIELDS) do p.area[f]=streamReadFloat32(id) end
            if not validArea(p.area) then return end
        end
        local m=streamReadUInt16(id); total=total+m; if total>MAX_BAYS or self.providers[p.id]~=nil then return end
        for _=1,m do
            local b={id=streamReadString(id),providerId=p.id,name=streamReadString(id),nameCustom=streamReadBool(id),capabilities={}}
            local legacy=streamReadString(id); if legacy~="" then b.legacyWashGateId=legacy end
            b.serviceLift=streamReadBool(id);b.serviceLiftDelayMs=streamReadUInt16(id)
            b.serviceInteraction=streamReadBool(id)
            for _,f in ipairs(FIELDS) do b[f]=streamReadFloat32(id) end
            b.origin={}; for _,f in ipairs(ORIGIN_FIELDS) do b.origin[f]=streamReadFloat32(id) end
            for _,cap in ipairs(CAPS) do b.capabilities[cap]=streamReadBool(id) end
            b.operational=streamReadBool(id) and "OPEN" or "CLOSED"; b.occupancy=streamReadString(id); b.revision=streamReadInt32(id); b.occupants={}
            local occupants=streamReadUInt16(id); if occupants>512 then return end
            for _=1,occupants do b.occupants[streamReadString(id)]=true end
            if streamReadBool(id) then b.reservation={vehicleId=streamReadString(id),expiresAt=streamReadFloat32(id)} end
            if not validBay(b,p) or seen[b.id] then return end
            seen[b.id]=true
            p.bays[b.id]=b
        end
        if not text(p.id) or not validName(p.name) or not integer(p.farmId,1,65535) then return end
        self.providers[p.id]=p
    end
    self:run(connection)
end
function SGServiceStateEvent:run(connection)
    if g_server~=nil or g_smartGate==nil or call(connection,"getIsServer")~=true then return end
    local s=g_smartGate.serviceInfrastructure
    if s==nil or s.disposed or not text(self.epoch) or not integer(self.revision,1,2147483647) then return end
    if s.remoteEpoch==self.epoch and self.revision<=s.revision then return end
    if s.remoteEpoch~=nil and s.remoteEpoch~=self.epoch then return end -- new map constructs a fresh core
    s.providers=self.providers; s.epoch=self.epoch; s.remoteEpoch=self.epoch; s.revision=self.revision
    s.configRevision=self.configRevision; s.providerSerial=self.providerSerial; s.baySerial=self.baySerial
    s.serverClock=self.clock; s.ready=true; s.persistenceSafe=self.safe; s.loaded=self.safe; s:reindex()
    s.serverSourceTemplates=self.sourceTemplates or {};s.serverSourceById={};s.cachedLegacyTemplates=nil;s.legacySourceCheckAt=nil
    for _,source in ipairs(s.serverSourceTemplates) do
        source.serverTemplate=true;source.objectType=1;source.displayName=source.name
        s.serverSourceById[source.id]=source
    end
    g_smartGate.newGatesEnabled=self.newGatesEnabled
    if g_smartGate.settings~=nil and g_smartGate.settings.newGateControl~=nil then g_smartGate.settings.newGateControl:setState(self.newGatesEnabled and 2 or 1,false) end
    s.serverDestinations=self.adDestinations;s.serverAdSource=self.adSource
    if s.adLocalUnavailable~=false then s.adDestinations=clone(self.adDestinations) end
    if s.adAwaitingManual then
        if s.adDebug then s.adDiagnostics=s.adDiagnostics or {};s.adDiagnostics.source="SERVER_STATE:"..self.adSource;s:logAdDiagnostics("SERVER_LIST_RECEIVED") end
        s.adAwaitingManual=nil
    end
end
function SGServiceStateEvent.send(s)
    if g_server~=nil and type(g_server.broadcastEvent)=="function" then g_server:broadcastEvent(SGServiceStateEvent.new(s),false) end
end
function S:update(dt)
    if self.disposed or not finite(dt) or dt<0 then return end
    self.clock=self.clock+dt
    self:updateEditorProviderSelection()
    if g_server==nil then
        if next(self.bays)~=nil and (self.adObservedAt==nil or self.clock-self.adObservedAt>=10000) then self:refreshDestinations() end
        return
    end
    -- Service-only maps must recover a late savegame path even with zero gates.
    if not self.loaded and self.clock-(self.lastLoadAttempt or 0)>=10000 then
        self.lastLoadAttempt=self.clock; call(self.owner,"loadConfig")
        if self.owner.persistenceConfigMissing then self.loaded=true end
    end
    self.scanTimer=self.scanTimer+dt; self.syncTimer=self.syncTimer+dt
    if self.scanTimer>=SCAN_MS then self.scanTimer=0; self:scan() end
    if self.syncTimer>=SYNC_MS then
        self.syncTimer=0
        for _,entry in pairs(self.pendingGeometry or {}) do
            if entry.actor~=self and call(entry.actor,"getIsConnected")==false then self:flushGeometry();break end
        end
        SGServiceStateEvent.send(self)
    end
end
function S:dispose()
    self:updatePanelZoomInput(false);self:resetPanelWheel()
    self.pendingGeometry=nil;self.geometryUnsaved=nil
    self.serverSourceTemplates=nil;self.serverSourceById=nil;self.sourceTemplateCache=nil
    self.sourceTemplateCheckAt=nil;self.sourceTemplateGateList=nil
    self.admissions=nil
    self.disposed=true; self.providers={}; self.bays={}; self.roots={}; self.grid={}; self.owner=nil; self.ready=false; self.adDestinations=nil; self.legacyWashByGate=nil; self.cachedLegacyTemplates=nil; self.legacyGateList=nil;self.remoteEditGrants=nil;self.remoteEditProvider=nil;self.remoteEditUntil=nil
end

local function selectNext(s,kind,delta)
    local p=s.providers[s.selectedProvider]
    local list=sorted(kind=="provider" and s.providers or p~=nil and p.bays or {})
    if #list==0 then return end
    local selected=kind=="provider" and s.selectedProvider or s.selectedBay; local index=1
    for i,item in ipairs(list) do if item.id==selected then index=i end end
    local id=list[(index-1+delta)%#list+1].id
    if kind=="provider" then s:setSelectedProvider(id) else s.selectedBay=id;s.adProposal=nil end
end
function S:legacyTemplates()
    if g_server==nil then return self.serverSourceTemplates or {} end
    if self.legacyGateList~=self.owner.gates or self.legacyGateRevision~=self.owner.geometryRevision
        or self.legacySourceCheckAt==nil or self.clock-self.legacySourceCheckAt>=1000 then
        self.legacyGateList=self.owner.gates; self.legacyGateRevision=self.owner.geometryRevision
        self.legacySourceCheckAt=self.clock
        local sources={}
        local candidates=type(self.owner.serviceCandidates)=="function" and self.owner:serviceCandidates() or self.owner.gates or {}
        for _,gate in ipairs(candidates) do
            if gate.objectType==1 and (gate.washPoint==true or type(self.owner.getServiceSourceCapabilities)=="function" and self.owner:getServiceSourceCapabilities(gate)~=nil or type(self.owner.isServiceWashSource)=="function" and self.owner:isServiceWashSource(gate)) then
                sources[#sources+1]=gate
            end
        end
        table.sort(sources,function(a,b) return a.id<b.id end); self.cachedLegacyTemplates=sources
    end
    return self.cachedLegacyTemplates or {}
end
function S:openName(kind)
    local p=self.providers[self.selectedProvider];local b=self.bays[self.selectedBay]
    local item=kind=="provider" and p or b
    if item==nil then return end
    if not self:canEditHere() then self.lastError="REMOTE_CONFIRM_REQUIRED";return end
    local context=self:editorContext()
    local function save(value)
        self:request(kind=="provider" and "RENAME_PROVIDER" or "SET_BAY","name",0,value,context)
    end
    local title=kind=="provider" and tr("BEREICH UMBENENNEN","RENAME AREA") or tr("SERVICEPLATZ UMBENENNEN","RENAME SERVICE BAY")
    local label=kind=="provider" and tr("Bereichsname:","Area name:") or tr("Serviceplatzname:","Service bay name:")
    if SGServiceTextDialog==nil or not SGServiceTextDialog.open(title,customName(item) and item.name or "",save,self.owner,
        {label=label,accept=tr("Umbenennen","Rename")}) then self.lastError=tr("Texteingabe noch nicht verfügbar; sgServiceName verwenden","Text input not ready; use sgServiceName") end
end
function S:openFilter()
    if SGServiceTextDialog==nil or not SGServiceTextDialog.open(tr("AD-ZIELE FILTERN","FILTER AD TARGETS"),self.adFilter or "",function(value) self.adFilter=value:lower() end,self.owner,
        {label=tr("Name oder Marker-ID:","Name or marker ID:"),accept=tr("Filtern","Filter"),hint=tr("Leer lassen, um alle Ziele anzuzeigen.","Leave empty to show all targets.")}) then self.lastError=tr("Texteingabe noch nicht verfügbar","Text input not ready") end
end
function S:destinationChoices()
    local result={};local query=(self.adFilter or ""):lower();local bay=self.bays[self.selectedBay]
    local distances={}
    for id,v in pairs(self.adDestinations or {}) do
        if query=="" or v.name:lower():find(query,1,true) or tostring(id):find(query,1,true) then
            result[#result+1]=id
            if bay~=nil and finite(v.x) and finite(v.z) then distances[id]=(v.x-bay.x)^2+(v.z-bay.z)^2 end
        end
    end
    table.sort(result,function(a,b)
        local da,db=distances[a],distances[b]
        if da~=db then if da==nil then return false elseif db==nil then return true else return da<db end end
        local an,bn=self.adDestinations[a].name:lower(),self.adDestinations[b].name:lower()
        if an~=bn then return an<bn end;return a<b
    end)
    table.insert(result,1,-1);return result
end

function S:proposeTarget()
    local b=self.bays[self.selectedBay];self.adProposal=nil
    if b==nil then return end
    local radius=math.sqrt(b.width*b.width+b.length*b.length)*.5+5;local candidates={}
    for id,v in pairs(self.adDestinations or {}) do
        if finite(v.x) and finite(v.z) and (v.x-b.x)^2+(v.z-b.z)^2<=radius*radius then candidates[#candidates+1]=id end
    end
    table.sort(candidates)
    if #candidates==1 then self.adProposal={id=candidates[1],bayId=b.id,targets=self.adDestinations,revision=self.configRevision};self.lastError=nil
    elseif #candidates==0 then self.lastError=tr("Kein räumlich passender Marker bekannt","No nearby marker with known position")
    else
        local ids={};for i=1,math.min(3,#candidates) do ids[#ids+1]="#"..candidates[i] end
        self.lastError=tr("Mehrdeutig: ","Ambiguous: ")..table.concat(ids,", ")..(#candidates>3 and " (+"..(#candidates-3)..")" or "")
    end
end
function S:applyProposedTarget()
    local b=self.bays[self.selectedBay];local proposal=self.adProposal
    if b==nil or proposal==nil or proposal.bayId~=b.id then return end
    if proposal.targets~=self.adDestinations or proposal.revision~=self.configRevision or self.adDestinations[proposal.id]==nil then self.lastError=tr("Vorschlag bitte aktualisieren","Please refresh the proposal");return end
    if b.adTarget>0 and b.adTarget~=proposal.id then self.lastError=tr("Bestehende Zuordnung bleibt erhalten; zuerst bewusst leeren","Existing assignment retained; clear it explicitly first");return end
    self:request("SET_BAY","adTarget",proposal.id)
end
function S:panelRows()
    local providers=sorted(self.providers)
    if self.providers[self.selectedProvider]==nil then self.selectedProvider=providers[1]~=nil and providers[1].id or nil;self.remoteEditProvider=nil;self.remoteEditUntil=nil;self.adProposal=nil end
    local p=self.providers[self.selectedProvider]; local bays=sorted(p~=nil and p.bays or {})
    if self.bays[self.selectedBay]==nil or (self.bays[self.selectedBay]~=nil and self.bays[self.selectedBay].providerId~=self.selectedProvider) then self.selectedBay=bays[1]~=nil and bays[1].id or nil end
    local b=self.bays[self.selectedBay]; local rows={}
    local category=self.panelCategory or (b~=nil and "geometry" or "management")
    if category~="management" and category~="geometry" and category~="ad" and category~="services" then category="geometry" end
    local editingProvider=self.editProviderArea and category=="geometry"
    local adPage=category=="ad"
    local section="management"
    local function row(label,left,right,help) rows[#rows+1]={label=label,left=left,right=right,help=help,section=section} end
    local function action(label,callback,help)
        row(label,callback,callback,help);rows[#rows].action=true
    end
    row(tr("Bereiche verwalten","Manage areas"),function() if p then self:request("REMOVE_PROVIDER") end end,function() self:request("NEW_PROVIDER") end,
        tr("Links: Bereich entfernen. Rechts: neuen Bereich anlegen.","Left: remove area. Right: create a new area."))
    rows[#rows].minusPlus=true
    rows[#rows].managementOrder=10
    section="common"
    row(p~=nil and self:displayName(p,"provider").." ["..p.farmId.."]" or tr("Kein Bereich","No provider"),function() selectNext(self,"provider",-1) end,function() selectNext(self,"provider",1) end,
        tr("Bereich auswählen. Die Zahl in Klammern ist die Farm-ID.","Select an area. The number in brackets is its farm ID."))
    rows[#rows].selection=true
    rows[#rows].managementOrder=20
    section="management"
    if p~=nil then action(tr("Bereich benennen","Rename area"),function() self:openName("provider") end,
        tr("Anzeigenamen des ausgewählten Bereichs ändern.","Change the selected area's display name."));rows[#rows].managementOrder=40 end
    row(tr("Serviceplätze verwalten","Manage bays"),function() if b then self:request("REMOVE_BAY") end end,function() if p then self:request("NEW_BAY") end end,
        tr("Links: Serviceplatz entfernen. Rechts: Platz im Bereich anlegen.","Left: remove bay. Right: create a bay in this area."))
    rows[#rows].minusPlus=true
    rows[#rows].managementOrder=50
    section="common"
    row(b~=nil and self:displayName(b,"bay") or tr("Kein Platz","No bay"),function() selectNext(self,"bay",-1) end,function() selectNext(self,"bay",1) end,
        tr("Serviceplatz innerhalb des ausgewählten Bereichs wechseln.","Switch between bays in the selected area."))
    rows[#rows].selection=true
    rows[#rows].managementOrder=60
    section="management"
    action(tr("Serviceplatz benennen","Rename bay"),b~=nil and function() self:openName("bay") end or nil,
        b~=nil and tr("Anzeigenamen des ausgewählten Serviceplatzes ändern.","Change the selected bay's display name.")
        or tr("Zuerst einen Serviceplatz anlegen oder auswählen.","Create or select a bay first."))
    rows[#rows].disabled=b==nil;rows[#rows].managementOrder=70
    local distance,inside=providerDistance(p,pose(g_localPlayer))
    local location=distance~=nil and string.format(" %.1f m",distance)..tr(" vom Bereich"," from area") or tr(" Entfernung unbekannt"," Distance unknown")
    if p~=nil and not self:canEditHere() then
        section="common"
        action(tr("Entfernt gesperrt","Remote locked")..location..tr(" – freigeben"," – unlock"),function() self:request("UNLOCK_REMOTE") end)
        rows[#rows].managementOrder=30
    else
        section="geometry"
        row(tr("Bearbeiten: ","Edit: ")..(self.editProviderArea and tr("Bereichsrahmen","Provider bounds") or tr("Serviceplatz","Service bay"))..(inside and tr(" (vor Ort)"," (local)") or location),
            function() self.editProviderArea=not self.editProviderArea end,function() self.editProviderArea=not self.editProviderArea end,
            tr("Zwischen Bereichsrahmen und Servicebox umschalten. Bearbeitung bis 10 m außerhalb des Bereichs möglich; darüber bewusst fernfreigeben.",
                "Switch between area bounds and service bay. Editing is allowed up to 10 m outside the area; unlock remote editing beyond that."))
    end
    local step=self.editStep or .1
    local steps={.1,.5,1,5}
    local function setStep(delta)
        local at=1;for i,v in ipairs(steps) do if v==step then at=i end end
        self.editStep=steps[(at-1+delta)%#steps+1]
    end
    section="geometry"
    row(tr("Schrittweite: ","Step size: ")..step..tr(" m / "," m / ")..(step<1 and 1 or 15).."°",function() setStep(-1) end,function() setStep(1) end,
        tr("Schrittgröße für Position, Abmessungen und Drehung wählen.","Choose the increment for position, dimensions and rotation."))
    local function refreshRow()
        section="ad"
        action(tr("AD-Ziele aktualisieren","Refresh AD destinations"),function() self:refreshDestinations(true) end,
            tr("Bekannte AutoDrive-Ziele neu einlesen. Ändert keine Zuordnung.","Reload known AutoDrive targets. Does not change the assignment."))
    end
    if not editingProvider and b==nil then refreshRow() end
    local legacy=self:legacyTemplates()
    if p~=nil and self.serviceSourceInProvider~=nil then
        local filtered={}
        for _,source in ipairs(legacy) do if self:serviceSourceInProvider(p,source) then filtered[#filtered+1]=source end end
        legacy=filtered
    end
    section="sources"
    if #legacy>0 then
        local index=math.max(1,math.min(#legacy,self.legacySelection or 1)); self.legacySelection=index
        local source=legacy[index]
        row(tr("Gebäudekandidat: ","Building candidate: ")..tostring(source.displayName or source.name or tr("Waschstation ","Wash station ")..index):sub(1,25),
            function() self.legacySelection=(index-2)%#legacy+1 end,function() self.legacySelection=index%#legacy+1 end)
        section="management"
            action(tr("Bereich aus Kandidat erstellen","Create provider from candidate"),function() self:request("PROVIDER_FROM_SOURCE",source.id) end)
            rows[#rows].managementOrder=90
            action(tr("Servicevorlage in Bereich übernehmen","Import service template into provider"),function() if p then self:request("IMPORT_WASH",source.id) end end)
            rows[#rows].managementOrder=100
            section="services"
            if b~=nil then
                local context=self:editorContext()
                action(tr("Servicequelle mit Serviceplatz verknüpfen","Link service source to bay"),function() self:request("BIND_WASH",source.id,nil,nil,context) end,
                    tr("Verknüpft den gewählten Kandidaten mit diesem Serviceplatz. Maße, Position, Fähigkeiten und AD-Ziel bleiben erhalten. Eine Quelle kann nur einem Serviceplatz zugeordnet sein.",
                        "Links the selected candidate to this bay. Dimensions, position, capabilities and AD target are retained. A source can be linked to one bay only."))
            end
    else
        row(tr("Keine unterstützte Servicequelle erkannt","No supported service source detected"),nil,nil,
            tr("Nur anhand unterstützter nativer Funktionen erkannte Quellen werden angeboten. Eine Fähigkeit allein verknüpft keinen Service.",
                "Only sources with supported native contracts are offered. A capability alone does not bind a service."))
    end
    section="services"
    if b~=nil then
        local sourceName=tr("Nicht verknüpft","Not linked")
        if b.legacyWashGateId~=nil then
            sourceName=tr("Nicht verfügbar","Unavailable")
            local displayId=b.legacyWashGateId
            if type(self.owner.findServiceSource)=="function" then
                local source=self.owner:findServiceSource(displayId)
                if source~=nil then displayId=self.owner:getServiceSourceId(source) or displayId end
            end
            for _,candidate in ipairs(legacy) do if candidate.id==displayId then sourceName=tostring(candidate.displayName or candidate.name or candidate.id):sub(1,25);break end end
        end
        row(tr("Servicequelle: ","Service source: ")..sourceName,nil,nil,
            tr("Für automatischen Service muss eine unterstützte Quelle ausdrücklich verknüpft sein. Fähigkeiten allein lösen keinen Service aus.",
                "Automatic service requires an explicitly linked supported source. Capabilities alone do not start service."))
        if b.legacyWashGateId~=nil then
            local context=self:editorContext()
            action(tr("Servicequelle lösen","Unlink service source"),function() self:request("UNBIND_WASH",nil,nil,nil,context) end,
                tr("Löst nur die Anlagenzuordnung. Serviceplatz und seine Einstellungen bleiben erhalten. Während einer Reservierung gesperrt.",
                    "Removes only the station binding. The bay and its settings remain intact. Blocked while reserved."))
        end
    end
    local function geometry(v,operation,fields)
        section="geometry"
        local labels={x="X",z="Z",width=tr("Breite","Width"),height=tr("Höhe","Height"),length=tr("Länge","Length"),yaw=tr("Ausrichtung","Orientation")}
        for _,key in ipairs(fields) do local field=key
            local angle=field=="yaw"; local delta=angle and ((step<1 and 1 or 15)*math.pi/180) or step
            local function adjustedValue(sign)
                local value=v[field]+sign*delta
                if angle then value=value%(math.pi*2)
                elseif field=="width" or field=="height" or field=="length" then value=math.max(operation=="SET_BAY" and .5 or 1,math.min(operation=="SET_BAY" and 100 or 500,value)) end
                return value
            end
            local function adjust(sign)
                self:request(operation,field,adjustedValue(sign))
            end
            row(labels[field]..": "..string.format("%.2f",angle and v[field]*180/math.pi or v[field])..(angle and "°" or " m"),function() adjust(-1) end,function() adjust(1) end,
                angle and tr("Ausrichtung in Grad ändern; Pfeil zeigt die Längsrichtung.","Change orientation in degrees; the arrow shows the length axis.")
                or (field=="x" or field=="z") and tr("Weltposition um die gewählte Schrittweite verschieben.","Move the world position by the selected increment.")
                or tr("Abmessung der ausgewählten Box in Metern ändern.","Change the selected box dimension in metres."))
            rows[#rows].wheelKey=operation..":"..tostring(self.selectedProvider)..":"..tostring(self.selectedBay)..":"..field
            rows[#rows].wheelOperation=operation;rows[#rows].wheelCurrent=v[field];rows[#rows].wheelValue=adjustedValue
            rows[#rows].wheel=function(direction,factor) adjust(direction*factor) end
            rows[#rows].help=rows[#rows].help..tr(" Mausrad: ändern; zügiges Scrollen beschleunigt bis 5x."," Mouse wheel: adjust; sustained scrolling accelerates up to 5x.")
        end
    end
    section="geometry"
    if editingProvider then
        if p then
            action(tr("Rahmen hier positionieren","Position bounds here"),function() self:request("PLACE_PROVIDER") end)
            local area=p.area or p.visualArea
            if area then geometry(area,"SET_PROVIDER_AREA",{"x","z","yaw","width","length"}) end
            row(tr("Nur Zuordnung, keine Belegungsfläche","Grouping only; no occupancy area"))
        end
    elseif b~=nil then
        if not adPage then
        action(tr("Hier positionieren + ausrichten","Place + orient here"),function() self:request("PLACE_BAY") end,
            tr("Box an die aktuelle Position und Blickrichtung setzen.","Place the box at the current position and facing direction."))
        geometry(b,"SET_BAY",{"x","z","width","height","length","yaw"})
        action(tr("Zur Ausgangsposition zurück","Reset to initial position"),function() self:request("RESET_BAY_POSE") end,
            tr("Position und Ausrichtung auf den Ausgangswert zurücksetzen.","Restore the initial position and orientation."))
        end
        section="ad"
        if adPage then
        local function target(delta)
            local ids=self:destinationChoices(); local index=1; for i,id in ipairs(ids) do if id==b.adTarget then index=i end end
            self:request("SET_BAY","adTarget",ids[(index-1+delta)%#ids+1])
        end
        local destination=(self.adDestinations or {})[b.adTarget]
        local targetName=b.adTarget<0 and tr("Kein Ziel","No target") or destination~=nil and (destination.name:sub(1,18).." (#"..b.adTarget..")") or tr("Ziel fehlt / unbekannt (#","Missing / unknown target (#")..b.adTarget..")"
        if destination~=nil and tostring(self.adDiagnostics~=nil and self.adDiagnostics.source or ""):find("SAVED_XML",1,true) then targetName=tr("Gespeichert: ","Saved: ")..targetName end
        local distanceText=""
        if destination~=nil and finite(destination.x) and finite(destination.z) then distanceText=string.format(" | %.0f m",math.sqrt((destination.x-b.x)^2+(destination.z-b.z)^2)) end
        row("AD: "..targetName:sub(1,distanceText~="" and 28 or 34)..distanceText,function() target(-1) end,function() target(1) end)
        action(tr("AD-Ziele suchen: ","Search AD targets: ")..(self.adFilter or ""),function() self:openFilter() end)
        end
        -- Shared AD block on both bay pages, immediately above service/status.
        refreshRow()
        section="bayTarget"
        if not adPage then
        local destination=(self.adDestinations or {})[b.adTarget]
        local name=b.adTarget<0 and tr("Kein Ziel","No target") or destination~=nil and (destination.name:sub(1,24).." (#"..b.adTarget..")") or tr("Fehlt / unbekannt (#","Missing / unknown (#")..b.adTarget..")"
        row(tr("AD-Ziel: ","AD target: ")..name,nil,nil,
            tr("Zugeordnetes AD-Ziel. Auf der AD-Seite ändern; keine Erreichbarkeitsgarantie.","Assigned AD target. Change it on the AD page; reachability is not guaranteed."))
        end
        section="ad"
        action(tr("Räumlichen Marker vorschlagen","Suggest nearby marker"),function() self:proposeTarget() end)
        if self.adProposal~=nil and self.adProposal.bayId==b.id then
            local marker=(self.adDestinations or {})[self.adProposal.id]
            action(tr("Übernehmen: ","Apply: ")..tostring(marker~=nil and marker.name or self.adProposal.id):sub(1,25),function() self:applyProposedTarget() end)
        end
        section="services"
        for _,cap in ipairs(CAPS) do local capability=cap
            local names={WASH=tr("Waschen","Wash"),REPAIR=tr("Reparieren","Repair"),REFUEL=tr("Tanken / Laden","Refuel / charge")}
            local active=b.capabilities[capability]==true
            row((active and "[X] " or "[ ] ")..names[capability].." ("..capability.."): "..(active and tr("EIN","ON") or tr("AUS","OFF")),
                function() self:request("SET_BAY",capability,b.capabilities[capability] and 0 or 1) end,
                function() self:request("SET_BAY",capability,b.capabilities[capability] and 0 or 1) end)
            rows[#rows].capability=capability; rows[#rows].active=active
        end
        row(tr("Betrieb","Operational")..": "..b.operational,function() self:request("SET_BAY","operational",b.operational=="OPEN" and 0 or 1) end,function() self:request("SET_BAY","operational",b.operational=="OPEN" and 0 or 1) end,
            tr("Serviceplatz für den Betrieb freigeben oder sperren.","Enable or disable this bay for operation."))
        row(tr("Belegung","Occupancy")..": "..(b.occupancy or "UNKNOWN")..(b.reservation~=nil and " / RESERVED" or ""),nil,nil,
            tr("Physische Belegung und Reservierung; UNKNOWN ist keine Freigabe.","Physical occupancy and reservation; UNKNOWN does not mean free."))
        if b.capabilities.REPAIR then
        row(tr("Service per Interaktion starten","Start service by interaction")..": "..(b.serviceInteraction and tr("EIN","ON") or tr("AUS","OFF")),
            function() self:request("SET_BAY","serviceInteraction",b.serviceInteraction and 0 or 1) end,function() self:request("SET_BAY","serviceInteraction",b.serviceInteraction and 0 or 1) end,
            tr("Reparaturauslöser nach dem Halt einmal betätigen. AUS: automatischen Gebäudeservice beobachten. Für Hebebühnen die eigene Halteoption verwenden.","Activate the repair interaction once after stopping. OFF: observe automatic building service. Use the separate hold option for lifting platforms."))
        row(tr("Hebebühne halten","Hold lifting platform")..": "..(b.serviceLift and tr("EIN","ON") or tr("AUS","OFF")),
            function() self:request("SET_BAY","serviceLift",b.serviceLift and 0 or 1) end,function() self:request("SET_BAY","serviceLift",b.serviceLift and 0 or 1) end,
            tr("Nur für eine ausdrücklich verknüpfte Bühne: nach dem Halt anheben, bis Reparaturende halten und vor Weiterfahrt vollständig absenken.","Only for an explicitly linked platform: raise after stopping, hold until repair completes, fully lower before departure."))
        row(tr("Bühnenverzögerung","Platform delay")..": "..string.format("%.1f s",(b.serviceLiftDelayMs or 0)/1000),
            function() self:request("SET_BAY","serviceLiftDelayMs",math.max(0,(b.serviceLiftDelayMs or 0)-500)) end,
            function() self:request("SET_BAY","serviceLiftDelayMs",math.min(10000,(b.serviceLiftDelayMs or 0)+500)) end)
        end
    end
    if self.geometryUnsaved then
        section="common"
        row(tr("Geometrie geändert – Speichern beim Schließen","Geometry changed – saved when closing"),nil,nil,
            tr("Position, Ausrichtung und Maße werden beim Verlassen des Config-Modus gesammelt gespeichert. Ungespeicherte Serviceplätze sind für neue Reservierungen gesperrt.",
                "Position, orientation and dimensions are saved together when leaving config mode. Unsaved bays cannot receive new reservations."))
    end
    for _,item in ipairs(rows) do
        if item.help==nil then
            if item.capability~=nil then
                item.help=tr("Servicefähigkeit einzeln umschalten. Mindestens eine muss aktiv bleiben.","Toggle this service capability. At least one must remain enabled.")
            elseif item.label:find("AD",1,true) then
                item.help=tr("AD-Zuordnung bearbeiten oder Ziele aktualisieren. Ein Ziel beweist keine Erreichbarkeit.","Edit the AD assignment or refresh targets. A target does not prove reachability.")
            elseif item.action then
                item.help=tr("Anklicken, um diese Aktion einmal auszuführen.","Click to perform this action once.")
            elseif item.left~=nil or item.right~=nil then
                item.help=tr("Links: vorheriger Wert / verringern. Rechts: nächster Wert / erhöhen oder Aktion ausführen.","Left: previous value / decrease. Right: next value / increase or perform action.")
            else
                item.help=tr("Statusanzeige des ausgewählten Platzes. UNKNOWN bedeutet unbekannt.","Selected bay status. UNKNOWN means the information is not known.")
            end
        end
    end
    local visible={}
    -- Common selection always precedes category actions. Pending status stays
    -- at the bottom; categorization never changes the authoritative data.
    for _,item in ipairs(rows) do if item.selection then visible[#visible+1]=item end end
    for _,item in ipairs(rows) do if item.section=="common" and not item.selection
        or item.section==category or item.section=="sources" and (category=="management" or category=="services")
        or item.section=="bayTarget" and (category=="geometry" or category=="services") then visible[#visible+1]=item end end
    if category=="management" then
        table.sort(visible,function(a,b) return (a.managementOrder or (a.section=="sources" and 80 or 110))<(b.managementOrder or (b.section=="sources" and 80 or 110)) end)
    end
    return visible
end
local X,Y,W,H=.735,.835,.245,.030
local ROW_START=.085
local CATEGORY_IDS={"management","geometry","ad","services"}
function S:panelCategoryLabels()
    return {tr("Verwaltung","Manage"),tr("Geometrie","Geometry"),tr("AD-Ziel","AD target"),tr("Services","Services")}
end
function S:panelBodyHeight(rows) return .128+#rows*H end
-- Local editor gestures only; the normal request path validates every value.
function S:wheelNow() return finite(g_time) and g_time or self.clock end
function S:resetPanelWheel() self.panelWheel=nil;self.panelWheelFlight=nil end
function S:hoveredGeometryRow()
    if self.disposed or self.owner==nil or not self.owner.configModeEnabled or not self.owner.serviceConfigView
        or g_dedicatedServer~=nil or guiOpen() or call(g_inputBinding,"getShowMouseCursor")~=true
        or self.owner.configOverlayDrag~=nil then return nil end
    local rows=self:panelRows();local r=self.owner:getConfigEditorRect()
    local mx,my=self.panelMouseX,self.panelMouseY
    if mx==nil or my==nil or mx<r.x+.007 or mx>r.x+r.w-.007 then return nil end
    for i,row in ipairs(rows) do
        local y=r.y-.066-ROW_START-(i-1)*H
        if row.wheel~=nil and my>=y-.005 and my<=y+.021 then return row end
    end
end
function S:scrollGeometry(row,direction)
    if not self:canEditHere() then self.lastError="REMOTE_CONFIRM_REQUIRED";return end
    local now=self:wheelNow();local last=self.panelWheel
    local key=row.wheelKey..":"..tostring(self.editStep or .1)
    local count=1
    if last and last.key==key and last.direction==direction and now>=last.at and now-last.at<=450 then count=math.min(9,last.count+1) end
    local factor=count>=9 and 5 or count>=5 and 2 or 1
    self.panelWheel={key=key,direction=direction,at=now,count=count,factor=factor}
    local flight=self.panelWheelFlight
    if flight and flight.key==row.wheelKey then flight.extra=math.max(-50,math.min(50,flight.extra+direction*factor))
    else self:sendWheelRow(row,direction*factor) end
end
function S:sendWheelRow(row,steps)
    if g_server==nil and g_client~=nil then
        self.panelWheelFlight={key=row.wheelKey,op="DRAFT_"..row.wheelOperation,value=row.wheelValue(steps),extra=0,epoch=self.epoch,revision=self.configRevision}
    end
    row.wheel(steps,1)
end
function S:finishWheelRequest(ok)
    local flight=self.panelWheelFlight;self.panelWheelFlight=nil
    if not ok or flight==nil or flight.extra==0 or flight.epoch~=self.epoch or self.configRevision<=flight.revision then return end
    local row=self:hoveredGeometryRow();local gesture=self.panelWheel
    if row==nil or row.wheelKey~=flight.key or gesture==nil or self:wheelNow()-gesture.at>450
        or math.abs(row.wheelCurrent-flight.value)>.005 then return end
    -- Rebuild from the acknowledged server snapshot; never optimistically mutate
    -- geometry or send a burst carrying the same stale configuration revision.
    self:sendWheelRow(row,flight.extra)
end
function S:openPanelHelp()
    if self.disposed or g_dedicatedServer~=nil or guiOpen() then return false end
    if InfoDialog==nil or InfoDialog.INSTANCE==nil or type(InfoDialog.show)~="function" or g_gui==nil then
        self.lastError=tr("Hilfe-Dialog noch nicht verfügbar","Help dialog is not ready");return false
    end
    local category=self.panelCategory or (self.bays[self.selectedBay] and "geometry" or "management")
    local help={
        management=tr("VERWALTUNG\n\nBereiche gruppieren Serviceplätze und grenzen deren Servicequellen räumlich ein. Mit - entfernen, mit + anlegen; anschließend Bereich und Platz auswählen und benennen. Farmrechte gelten weiterhin; entfernte Bearbeitung muss ausdrücklich freigegeben werden.\n\nBei ausgewähltem Bereich erscheinen nur Gebäudekandidaten innerhalb seines Rahmens. Ausschlaggebend ist der native Servicepunkt, ersatzweise die Gebäudeposition. Ohne gewählten Bereich ist die Erstauswahl global. Gleichartige Gebäude werden über ihre jeweilige Gebäude-ID unterschieden.\n\n'Bereich aus Kandidat' legt einen Bereich an; 'Servicevorlage in Bereich' übernimmt eine Vorlage in den gewählten Bereich. Die erkannten Fähigkeiten prüfen. Verknüpft wird die konkrete Quelle unter Services. Eine Vorlage allein startet keinen Service.",
            "MANAGE\n\nAreas group service bays and spatially limit their service sources. Use - to remove or + to create; then select and name the area and bay. Farm permissions still apply; remote editing requires explicit approval.\n\nWith an area selected, only building candidates inside its bounds are offered. The native service point is used, or the building position as fallback. Without a selected area, the initial selection is global. Identical buildings are distinguished by their individual building IDs.\n\n'Create provider from candidate' creates an area; 'Import service template' imports a template into that area. Check the detected capabilities. Link the exact source under Services. A template alone does not start service."),
        geometry=tr("GEOMETRIE\n\nBearbeiten wechselt zwischen Bereichsrahmen und Serviceplatz. Der Bereichsrahmen begrenzt die Servicequellen; die Servicebox beschreibt Größe und Belegungsfläche.\n\nX/Z verschieben die Box; Breite, Höhe und Länge ändern ihre Abmessungen. Ausrichtung dreht die Längsachse. 'Hier positionieren' übernimmt deine Position und Blickrichtung. Zurücksetzen betrifft die Ausgangsposition und Ausrichtung.\n\nPfeile oder Mausrad über einem Zahlenfeld verwenden. Zügiges Scrollen erhöht nach 4 Schritten auf 2x, nach 8 auf 5x. Pause, Richtungs- oder Feldwechsel setzt zurück. Die Grundschrittweite bleibt unverändert.\n\nGeometrie wird beim Schließen des Config-Modus gesammelt gespeichert. Bis dahin sind geänderte Bays für neue Reservierungen gesperrt.",
            "GEOMETRY\n\nEdit switches between area bounds and service bay. Area bounds limit service sources; a service box defines size limits and its occupancy area.\n\nX/Z move the box; width, height and length change its dimensions. Orientation rotates its length axis. 'Place + orient here' uses your position and facing. Reset restores the initial position and orientation.\n\nUse arrows or hover a numeric field and scroll. Sustained scrolling increases to 2x after 4 steps and 5x after 8. A pause, reversal or field change resets it. The base increment is retained.\n\nGeometry is saved together when leaving config mode. Changed bays cannot receive new reservations until saved."),
        ad=tr("AD-ZIEL\n\nDas Ziel gehört zum ausgewählten Serviceplatz. Manuell mit den Pfeilen wählen oder nach Name/Marker-ID suchen. Aktualisieren liest die verfügbaren Ziele neu ein und ändert keine Zuordnung.\n\nDer räumliche Vorschlag ist nur eine Hilfe. Bestehende Zuordnungen werden nicht still ersetzt; bewusst leeren und Vorschlag übernehmen.\n\nDas Ziel so wählen, dass das Gespann an einer geeigneten Serviceposition zum Stehen kommt. Die tatsächliche Halteposition hängt auch von Fahrzeug und AutoDrive ab.\n\nEin gesetztes Ziel beweist keine Erreichbarkeit. AutoDrive bleibt für die Navigation verantwortlich; Geometrie und Servicequelle separat prüfen.",
            "AD TARGET\n\nThe target belongs to the selected bay. Select it with the arrows or search by name/marker ID. Refresh reloads available targets without changing the assignment.\n\nThe nearby-marker proposal is only a suggestion. Existing assignments are not silently replaced; clear them deliberately before applying a new proposal.\n\nChoose a target that stops the train in a suitable service position. The actual stopping position also depends on the vehicle and AutoDrive.\n\nAn assigned marker does not prove reachability. AutoDrive remains responsible for navigation; check geometry and service source separately."),
        services=tr("SERVICES\n\nWASH, REPAIR und REFUEL sind kombinierbare Angebote; mindestens eine Fähigkeit muss aktiv bleiben. Quelle auswählen und ausdrücklich mit der Bay verknüpfen. Quelle und Servicepunkt müssen zum Bereich gehören. Quellenwechsel ist während einer Reservierung gesperrt.\n\nOPEN erlaubt Nutzung, CLOSED sperrt neue Aufträge. FREE, OCCUPIED und UNKNOWN betreffen die physische Belegung; Reservierungen sind davon getrennt. UNKNOWN bedeutet keine Freigabe. Farmrechte, Maße und Zuordnung werden serverseitig geprüft.\n\nService per Interaktion starten: nach Ankunft und Halt einmal auslösen. AUS für automatisch arbeitende Stationen wie Staffed Workshop/PitStop.\n\nHebebühne halten: nur für den verknüpften Bühnenauslöser einschalten, nicht für den normalen PitStop. Nach dem Halt verzögert anheben, während der Reparatur oben halten, danach vollständig absenken. Erst der untere Endpunkt erlaubt den Abschluss. Verzögerung: 0–10 Sekunden in 0,5-Sekunden-Schritten. Abbruch gibt keine automatische Weiterfahrt frei.\n\nServiceerfolg wird an Schmutz, Schaden bzw. passenden Energiefüllständen geprüft. Auslösen allein genügt nicht. Bei REFUEL müssen Station und Verbrauchstank dieselbe Energieart unterstützen. Gebäude/GIANTS übernehmen Service und Abrechnung. Der Editor konfiguriert nur; er startet selbst keinen Auftrag.",
            "SERVICES\n\nWASH, REPAIR and REFUEL are combinable capabilities; at least one must remain enabled. Select and explicitly link a source to the bay. The source and service point must belong to the area. Source changes are blocked during a reservation.\n\nOPEN permits use; CLOSED blocks new requests. FREE, OCCUPIED and UNKNOWN describe physical occupancy; reservations are separate. UNKNOWN does not mean free. Farm permissions, dimensions and bindings are checked by the server.\n\nStart service by interaction: activate once after arrival and stopping. OFF for automatic stations such as Staffed Workshop/PitStop.\n\nHold lifting platform: enable only for the linked platform interaction, not a regular PitStop. After stopping and the configured delay, raise, hold during repairs and fully lower afterwards. Only the lower endpoint permits completion. Delay: 0–10 seconds in 0.5-second steps. Cancellation never permits automatic departure.\n\nService success is verified using dirt, damage or matching energy fill levels. Activation alone is insufficient. REFUEL requires the station and consumer tank to support the same energy type. Buildings/GIANTS handle service and accounting. The editor configures infrastructure; it does not start a request.")

    }
    help.management=help.management..tr("\n\nBei offenem Service-Tab wird beim Betreten eines eindeutigen Bereichs automatisch dieser Bereich ausgewählt. Überlappende Bereiche bewusst auswählen. Während Dialogen, Ziehen und ungespeicherten Geometrieänderungen bleibt die Auswahl geschützt.",
        "\n\nWith the service tab open, entering an unambiguous area selects that provider automatically. Select overlapping areas explicitly. Selection is protected during dialogs, dragging and unsaved geometry changes.")
    local owner=self.owner;local restore=owner.configCursorOwned==true
    self:resetPanelWheel()
    if restore then owner:setConfigCursorEnabled(false) end
    InfoDialog.show(help[category] or help.management,function()
        if not self.disposed and self.owner==owner and owner.serviceInfrastructure==self and restore and owner.configModeEnabled then owner.serviceDialogRestoreCursor=true end
    end,nil,nil,tr("Verstanden","Understood"))
    return true
end
function S:updatePanelZoomInput(active)
    active=active==true
    local changed=self.panelGeometryHovered~=active
    self.panelGeometryHovered=active
    if self.owner~=nil and (changed or self.owner.configWheelZoomRecord==nil) then self.owner:updateConfigWheelZoom(active) end
end
function S:panelHelpLines(text,width)
    text=tostring(text or ""):gsub("%s+"," ")
    local cache=self.panelHelpCache
    if cache and cache.text==text and cache.width==width and cache.measure==getTextWidth
        and cache.px==g_pixelSizeX and cache.py==g_pixelSizeY then return cache.lines end
    local function fits(value)
        return type(getTextWidth)=="function" and getTextWidth(.008,value)<=width
            or type(getTextWidth)~="function" and #value<=math.floor(width/.0045)
    end
    local lines={};local line="";local truncated=false
    local function push()
        if #lines>=3 then truncated=true;return false end
        lines[#lines+1]=line;line="";return true
    end
    for word in text:gmatch("%S+") do
        local candidate=line=="" and word or line.." "..word
        if fits(candidate) then line=candidate else
            if line~="" and not push() then break end
            if fits(word) then line=word else
                for char in word:gmatch("[%z\1-\127\194-\244][\128-\191]*") do
                    if not fits(line..char) and line~="" then if not push() then break end end
                    line=line..char
                end
                if truncated then break end
            end
        end
    end
    if line~="" and not truncated then push() end
    if truncated and #lines>0 then
        local chars={};for char in lines[#lines]:gmatch("[%z\1-\127\194-\244][\128-\191]*") do chars[#chars+1]=char end
        while #chars>0 and not fits(table.concat(chars).."...") do table.remove(chars) end
        lines[#lines]=table.concat(chars).."..."
    end
    self.panelHelpCache={text=text,width=width,measure=getTextWidth,px=g_pixelSizeX,py=g_pixelSizeY,lines=lines}
    return lines
end
function S:drawPanel()
    local rows=self:panelRows(); local height=self:panelBodyHeight(rows)
    local rect=self.owner:getConfigOverlayRect("panel",W,height+.066,X,Y)
    local X,Y=rect.x,rect.y-.066
    if drawFilledRect~=nil then drawFilledRect(X,Y-height,W,height,.03,.06,.04,.9) end
    setTextAlignment(RenderText.ALIGN_LEFT); setTextBold(false)
    renderText(X+.01,Y-.024,.012,tr("A.S.S. Serviceplätze","A.S.S. Service bays"))
    if drawFilledRect~=nil then drawFilledRect(X+W-.042,Y-.028,.035,.023,.12,.24,.15,.98) end
    setTextAlignment(RenderText.ALIGN_CENTER);renderText(X+W-.0245,Y-.021,.008,tr("Hilfe","Help"));setTextAlignment(RenderText.ALIGN_LEFT)
    local labels=self:panelCategoryLabels()
    local selected=self.panelCategory or (self.bays[self.selectedBay]~=nil and "geometry" or "management")
    for i,label in ipairs(labels) do
        local cx=X+(i-1)*W/4
        if drawFilledRect~=nil then drawFilledRect(cx+.002,Y-.058,W/4-.004,.026,
            selected==CATEGORY_IDS[i] and .22 or .06,selected==CATEGORY_IDS[i] and .38 or .14,.10,.96) end
        setTextAlignment(RenderText.ALIGN_CENTER);renderText(cx+W/8,Y-.049,.0075,label);setTextAlignment(RenderText.ALIGN_LEFT)
    end
    local geometryHovered=false
    for i,row in ipairs(rows) do
        local y=Y-ROW_START-(i-1)*H
        if row.wheel~=nil and self.panelMouseX~=nil and self.panelMouseY~=nil
            and self.panelMouseX>=X+.007 and self.panelMouseX<=X+W-.007 and self.panelMouseY>=y-.005 and self.panelMouseY<=y+.021 then geometryHovered=true end
        if drawFilledRect~=nil then
            if row.capability~=nil then
                drawFilledRect(X+.007,y-.005,W-.014,.026,row.active and .14 or .06,row.active and .28 or .08,row.active and .08 or .07,.95)
            elseif row.action then
                local hovered=call(g_inputBinding,"getShowMouseCursor")==true and self.panelMouseX~=nil and self.panelMouseY~=nil
                    and self.panelMouseX>=X and self.panelMouseX<=X+W and self.panelMouseY>=y-.005 and self.panelMouseY<=y+.021
                -- Inset frame distinguishes commands from arrow selectors.
                drawFilledRect(X+.007,y-.005,W-.014,.026,.34,.48,.37,.95)
                drawFilledRect(X+.008,y-.004,W-.016,.024,hovered and .18 or .06,hovered and .32 or .12,hovered and .20 or .08,.98)
            else drawFilledRect(X+.007,y-.005,W-.014,.026,.08,.14,.10,.95) end
        end
        if row.action then
            if row.disabled and type(setTextColor)=="function" then setTextColor(.55,.55,.55,1) end
            setTextAlignment(RenderText.ALIGN_CENTER)
            renderText(X+W*.5,y+.002,.009,row.label)
            setTextAlignment(RenderText.ALIGN_LEFT)
            if row.disabled and type(setTextColor)=="function" then setTextColor(1,1,1,1) end
        else renderText(X+(row.capability~=nil and .013 or .035),y+.002,.009,row.label) end
        if row.capability==nil and not row.action then
            if row.minusPlus and drawFilledRect~=nil then
                local h=math.max(.0015,tonumber(g_pixelSizeY) or 0)
                drawFilledRect(X+.013,y+.007,.008,h,1,1,1,1)
                drawFilledRect(X+W-.022,y+.007,.008,h,1,1,1,1)
                drawFilledRect(X+W-.019,y+.003,.002,.009,1,1,1,1)
            else
                if row.left then renderText(X+.013,y+.002,.011,"<") end
                if row.right then renderText(X+W-.020,y+.002,.011,">") end
            end
        end
    end
    self:updatePanelZoomInput(geometryHovered and self.owner.configOverlayDrag==nil)
    local hint=self.lastError
    if hint==nil and call(g_inputBinding,"getShowMouseCursor")==true then
        local mx,my=self.panelMouseX,self.panelMouseY
        if mx~=nil and my~=nil and mx>=X and mx<=X+W then
            for i,item in ipairs(rows) do
                local ry=Y-ROW_START-(i-1)*H
                if my>=ry-.005 and my<=ry+.021 then hint=item.help;break end
            end
        end
    end
    if hint=="NO_CAPABILITY" then hint=tr("Mindestens eine Servicefähigkeit muss aktiv bleiben.","At least one service capability must remain enabled.") end
    if hint=="REMOTE_CONFIRM_REQUIRED" then hint=tr("Entfernter Bereich: zuerst bewusst freigeben.","Remote area: unlock explicitly first.") end
    if hint=="REMOTE_ADMIN_REQUIRED" then hint=tr("Entfernte Bearbeitung benötigt Administratorrechte.","Remote editing requires administrator rights.") end
    if hint=="STALE_EDITOR_SELECTION" or hint=="STALE_CONFIG" then hint=tr("Auswahl geändert: Eingabe erneut öffnen.","Selection changed: reopen the input.") end
    local text=hint or tr("Links − / rechts + | Namen: sgServiceName","Left − / right + | Names: sgServiceName")
    -- Every line, including an oversized single word, is width-bounded.
    local help=self:panelHelpLines(text,W-.02)
    for i,line in ipairs(help) do renderText(X+.01,Y-height+.041-(i-1)*.012,.008,line) end
end
function S:drawBounds()
    if type(drawDebugLine)~="function" then return end
    local here=pose(g_localPlayer); if here==nil then return end
    for _,p in pairs(self.providers) do
        local a=p.area or p.visualArea
        if a~=nil and (here.x-a.x)^2+(here.z-a.z)^2<=60^2 then
            local r=box(a.x,a.z,a.yaw,a.width,a.length); local points={}
            for _,sign in ipairs({{-1,-1},{1,-1},{1,1},{-1,1}}) do points[#points+1]={a.x+r.rx*r.w*sign[1]+r.fx*r.l*sign[2],a.z+r.rz*r.w*sign[1]+r.fz*r.l*sign[2]} end
            local red,green,blue=.55,.4,.9
            if p.id==self.selectedProvider then red,green,blue=.85,.65,1 end
            for i=1,4 do local v,n=points[i],points[i%4+1]; drawDebugLine(v[1],a.y+.12,v[2],red,green,blue,n[1],a.y+.12,n[2],red,green,blue,false) end
            if type(project)=="function" then local x,y,d=project(a.x,a.y+.4,a.z)
                if d~=nil and d>0 and d<1 then renderText(x,y,.010,tr("Bereich: ","Provider: ")..self:displayName(p,"provider")) end
            end
        end
    end
    for _,b in pairs(self.bays) do if (here.x-b.x)^2+(here.z-b.z)^2<=60^2 then
        local rect=b.rect; local corners={}
        for _,pair in ipairs({{-1,-1},{1,-1},{1,1},{-1,1}}) do
            corners[#corners+1]={b.x+rect.rx*rect.w*pair[1]+rect.fx*rect.l*pair[2],b.z+rect.rz*rect.w*pair[1]+rect.fz*rect.l*pair[2]}
        end
        local r,g,blue=.2,.9,.25
        if b.occupancy=="UNKNOWN" then r,g,blue=.8,.8,.8 elseif b.reservation~=nil then r,g,blue=.25,.5,1 elseif b.occupancy=="OCCUPIED" then r,g,blue=1,.5,.1 end
        for i=1,4 do local a,c=corners[i],corners[i%4+1]
            for _,y in ipairs({b.y,b.y+b.height}) do drawDebugLine(a[1],y,a[2],r,g,blue,c[1],y,c[2],r,g,blue,false) end
            drawDebugLine(a[1],b.y,a[2],r,g,blue,a[1],b.y+b.height,a[2],r,g,blue,false)
        end
        drawDebugLine(b.x,b.y+.1,b.z,1,1,1,b.x+rect.fx*b.length*.5,b.y+.1,b.z+rect.fz*b.length*.5,1,1,1,false)
        local tipX,tipZ=b.x+rect.fx*b.length*.5,b.z+rect.fz*b.length*.5
        for _,sign in ipairs({-1,1}) do drawDebugLine(tipX,b.y+.1,tipZ,1,1,1,tipX-rect.fx+rect.rx*sign*.5,b.y+.1,tipZ-rect.fz+rect.rz*sign*.5,1,1,1,false) end
        if type(project)=="function" then local x,y,depth=project(b.x,b.y+b.height+.3,b.z)
            if depth~=nil and depth>0 and depth<1 then renderText(x,y,.010,self:displayName(self.providers[b.providerId],"provider").." / "..self:displayName(b,"bay")) end
        end
    end end
end
local oldNew=SmartGate.new
function SmartGate.new(...) local owner=oldNew(...); owner.serviceInfrastructure=S.new(owner); return owner end
g_smartGate.serviceInfrastructure=S.new(g_smartGate)
local oldLoad=SmartGate.loadMap
function SmartGate:loadMap(...)
    if self.serviceInfrastructure~=nil then self.serviceInfrastructure:dispose() end
    self.serviceInfrastructure=S.new(self); oldLoad(self,...)
    if g_server~=nil and self.persistenceConfigMissing then self.serviceInfrastructure.loaded=true end
    if type(addConsoleCommand)=="function" then
        addConsoleCommand("sgServiceName","Rename selected provider/bay: provider|bay name", "consoleServiceName",self)
        addConsoleCommand("sgServiceTarget","Set selected bay AD ID (no route proof)","consoleServiceTarget",self)
    end
end
function SmartGate:consoleServiceName(kind,...)
    local s=self.serviceInfrastructure; if not self.configModeEnabled or s==nil then return "Config mode required" end
    local name=table.concat({...}," "):match("^%s*(.-)%s*$")
    if kind=="provider" then s:request("RENAME_PROVIDER",nil,nil,name) elseif kind=="bay" then s:request("SET_BAY","name",nil,name) else return "provider|bay name" end
    return "Service name requested (server validates farm)"
end
function SmartGate:consoleServiceADDebug(value)
    local s=self.serviceInfrastructure;if s==nil then return "Service editor unavailable" end
    if value~="on" and value~="off" then return "sgServiceADDebug on|off" end
    s.adDebug=value=="on"
    if s.adDebug then s:refreshDestinations(true) end
    return "Service AD diagnostics "..(s.adDebug and "ON: refresh explicitly; see log.txt" or "OFF")
end
function SmartGate:consoleServiceTarget(value)
    local s=self.serviceInfrastructure; if not self.configModeEnabled or s==nil then return "Config mode required" end
    s:request("SET_BAY","adTarget",tonumber(value) or 0); return "AD target requested; reachability UNKNOWN"
end
local oldSaveConfig=SmartGate.saveConfig
function SmartGate:saveConfig(...)
    local ok=oldSaveConfig(self,...)
    if ok and self.serviceInfrastructure~=nil then self.serviceInfrastructure:geometrySaved() end
    return ok
end
local oldToggleConfig=SmartGate.onToggleConfigAction
function SmartGate:onToggleConfigAction(...)
    local before=self.configModeEnabled;oldToggleConfig(self,...)
    if before~=self.configModeEnabled and self.serviceInfrastructure~=nil then
        if self.configModeEnabled and self.serviceConfigView then self.serviceInfrastructure:beginEditor()
        elseif not self.configModeEnabled then
            local service=self.serviceInfrastructure
            service:resetPanelWheel()
            service:request("SAVE_GEOMETRY")
            service.remoteEditProvider=nil;service.remoteEditUntil=nil;service:request("EDIT_CONTEXT")
        end
    end
end
local oldUpdate=SmartGate.update
function SmartGate:update(dt)
    oldUpdate(self,dt)
    if self.serviceDialogRestoreCursor and not guiOpen() then
        self.serviceDialogRestoreCursor=nil
        if self.configModeEnabled then self:setConfigCursorEnabled(true) end
    end
end
local oldDelete=SmartGate.deleteMap
function SmartGate:deleteMap(...)
    if SGServiceTextDialog~=nil then SGServiceTextDialog.cancel(self) end
    oldDelete(self,...)
    if type(removeConsoleCommand)=="function" then removeConsoleCommand("sgServiceName"); removeConsoleCommand("sgServiceTarget"); removeConsoleCommand("sgServiceADDebug") end
    if self.serviceInfrastructure~=nil then self.serviceInfrastructure:dispose() end
    self.serviceConfigView=nil
    self.serviceDialogRestoreCursor=nil
end
local oldPanel=SmartGate.drawConfigPanel
function SmartGate:getConfigEditorRect()
    if self.serviceConfigView then local s=self.serviceInfrastructure;return self:getConfigOverlayRect("panel",W,s:panelBodyHeight(s:panelRows())+.066,X,Y) end
    if self.configPanelGate~=nil then return self:getGatePanelRect(self.configPanelGate) end
    return self:getConfigOverlayRect("panel",W,.18,X,Y)
end
function SmartGate:drawConfigPanel()
    if not self.configModeEnabled or g_dedicatedServer~=nil then return end
    local r=self:getConfigEditorRect()
    if drawFilledRect~=nil then
        drawFilledRect(r.x,r.y-.066,r.w,.066,.04,.08,.06,.95)
        drawFilledRect(r.x,r.y-.028,r.w,.028,.12,.20,.14,.95)
        drawFilledRect(r.x+(self.serviceConfigView and W*.5 or 0),r.y-.060,W*.5,.028,.18,.32,.08,.95)
    end
    local title=self.serviceConfigView and tr("A.S.S. konfigurieren (ziehen)","Configure A.S.S. (drag)")
        or tr("L.E.G.S. Konfiguration (ziehen)","L.E.G.S. configuration (drag)")
    renderText(r.x+.01,r.y-.020,.010,title)
    renderText(r.x+.006,r.y-.051,.009,tr("Tore & Interaktionen","Gates & interactions"))
    renderText(r.x+W*.5+.006,r.y-.051,.009,tr("Serviceplätze","Service bays"))
    if self.serviceConfigView then self.serviceInfrastructure:drawPanel(); self.serviceInfrastructure:drawBounds()
    elseif self.configPanelGate~=nil then oldPanel(self)
    else renderText(r.x+.01,r.y-.10,.009,tr("Kein Objekt in Auswahlreichweite","No object in selection range")) end
end
local oldMouse=SmartGate.handleGateConfigMouseEvent
function SmartGate:handleConfigEditorMouseEvent(x,y,isDown,isUp,button)
    if self.serviceInfrastructure~=nil then self.serviceInfrastructure.panelMouseX=x;self.serviceInfrastructure.panelMouseY=y end
    if not self.configModeEnabled or g_dedicatedServer~=nil or guiOpen() or call(g_inputBinding,"getShowMouseCursor")~=true then
        if self.serviceInfrastructure then self.serviceInfrastructure:resetPanelWheel();self.serviceInfrastructure:updatePanelZoomInput(false) end
        self:finishConfigOverlayDrag(); return
    end
    local r=self:getConfigEditorRect()
    if self:handleConfigOverlayDrag(r,.028,x,y,isDown,isUp,button) then self.serviceInfrastructure:updatePanelZoomInput(false);return end
    local service=self.serviceInfrastructure
    local hovered=service:hoveredGeometryRow()
    service:updatePanelZoomInput(hovered~=nil)
    if hovered==nil or service.panelWheel~=nil and service.panelWheel.key~=hovered.wheelKey..":"..tostring(service.editStep or .1) then service:resetPanelWheel() end
    local wheelDirection=Input~=nil and (button==Input.MOUSE_BUTTON_WHEEL_UP and 1 or button==Input.MOUSE_BUTTON_WHEEL_DOWN and -1) or nil
    if hovered~=nil and wheelDirection~=nil then
        if isUp then service:scrollGeometry(hovered,wheelDirection) end
        return true
    end
    if isDown and (Input==nil or button==Input.MOUSE_BUTTON_LEFT) then
        service:resetPanelWheel()
        if x>=r.x and x<=r.x+r.w and y>=r.y-.060 and y<=r.y-.032 then
            local nextView=x>=r.x+r.w*.5
            if nextView and not self.serviceConfigView then self.serviceInfrastructure:beginEditor();self.serviceInfrastructure:refreshDestinations() end
            self.serviceConfigView=nextView
            return
        end
        if self.serviceConfigView then
            local X,Y=r.x,r.y-.066
            if x>=X+W-.042 and x<=X+W-.007 and y>=Y-.028 and y<=Y-.005 then
                service:openPanelHelp();return
            end
            if x>=X and x<=X+W and y>=Y-.058 and y<=Y-.032 then
                local index=math.max(1,math.min(4,math.floor((x-X)/(W/4))+1))
                self.serviceInfrastructure.panelCategory=CATEGORY_IDS[index]
                return
            end
            for i,row in ipairs(self.serviceInfrastructure:panelRows()) do
                local ry=Y-ROW_START-(i-1)*H
                if x>=X and x<=X+W and y>=ry-.005 and y<=ry+.021 then
                    local action=x<X+W*.5 and row.left or row.right
                    if action then action() end
                    return
                end
            end
            return
        end
    end
    if not self.serviceConfigView then oldMouse(self,x,y,isDown,isUp,button) end
end
-- The old API remains additive. New consumers use explicit schema-2 DTOs.
SmartGateAPI.SERVICE_SCHEMA_VERSION=2
local function serviceCore() return g_smartGate~=nil and g_smartGate.serviceInfrastructure or nil end
function SmartGateAPI.listServiceProviders()
    local s=serviceCore(); if s==nil or s.disposed or not s.persistenceSafe or not s.loaded or (g_server==nil and s.remoteEpoch==nil) then return nil,"UNKNOWN" end
    return s:providerDTOs(),"KNOWN",s.revision,s.epoch
end
function SmartGateAPI.listServiceBays()
    local s=serviceCore(); if s==nil or s.disposed or not s.persistenceSafe or not s.loaded or (g_server==nil and s.remoteEpoch==nil) then return nil,"UNKNOWN" end
    return s:bayDTOs(g_server~=nil),"KNOWN",s.revision,s.epoch
end
function SmartGateAPI.reserveServiceBay(...) local s=serviceCore(); if s==nil then return false,"UNKNOWN" end; return s:reserve(...) end
function SmartGateAPI.releaseServiceBay(...) local s=serviceCore(); if s==nil then return false,"UNKNOWN" end; return s:release(...) end
function SmartGateAPI.renewServiceBay(...) local s=serviceCore(); if s==nil then return false,"UNKNOWN" end; return s:renew(...) end
function SmartGateAPI.inspectServiceBay(...) local s=serviceCore(); if s==nil or g_server==nil then return nil,"UNKNOWN" end; return s:inspect(...),"KNOWN" end
local oldPoints=SmartGateAPI.listServicePoints
function SmartGateAPI.listServicePoints()
    local points,status=oldPoints(); if status~="KNOWN" then return points,status end
    local s=serviceCore(); if s==nil or s.disposed or not s.persistenceSafe then return points,status end
    local unique={}; for _,point in ipairs(points) do if s:getLegacyWashBay(point.id)==nil then unique[#unique+1]=point end end
    points=unique
    for _,b in ipairs(s:bayDTOs(g_server~=nil)) do
        local free=b.occupancy=="FREE" and b.reservationStatus=="FREE"
        points[#points+1]={id=b.id,reference=b.id,provider=b.providerId,name=b.name,farmId=b.farmId,
            capabilities=b.capabilities,dimensions=b.dimensions,position=b.position,
            capacity=1,physicalOccupancy=b.occupancy=="UNKNOWN" and "UNKNOWN" or {not free},
            operational=b.operational,adTarget=b.adTarget,reachable="UNKNOWN",geometrySource="CONFIGURED_SERVICE_BAY"}
    end
    return points,status
end
