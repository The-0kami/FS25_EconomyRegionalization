-- Bounded, synchronous second opinion for folded implements. No triggers,
-- vehicle mutations, persistent size profiles or background physics queries.
local S=SGServiceInfrastructure
local KEY={}
local CLEARANCE=.05
local function finite(v) return type(v)=="number" and v==v and v>-math.huge and v<math.huge end
local function call(o,k,...)
    if type(o)=="table" and type(o[k])=="function" then local ok,a,b,c=pcall(o[k],o,...);if ok then return a,b,c end end
end
local function foldedState(unit)
    local time=call(unit,"getFoldAnimTime")
    if call(unit,"getIsUnfolded")~=false or not finite(time) or (time~=0 and time~=1) then return nil end
    local spec=unit.spec_animatedVehicle
    if type(spec)~="table" or type(spec.animations)~="table" then return nil end
    local state={time=time,animations={}};local count=0
    for name in pairs(spec.animations) do
        count=count+1;if count>32 or type(name)~="string" then return nil end
        local value=call(unit,"getAnimationTime",name)
        if not finite(value) or call(unit,"getIsAnimationPlaying",name)~=false then return nil end
        state.animations[name]=value
    end
    return count>0 and state or nil
end
local function sameState(unit,state)
    local current=foldedState(unit);if current==nil or current.time~=state.time then return false end
    for name,value in pairs(state.animations) do if current.animations[name]~=value then return false end end
    for name in pairs(current.animations) do if state.animations[name]==nil then return false end end
    return true
end
function S:validateFoldedGeometryProof(proof,b,root,consumed)
    if type(proof)~="table" or proof[KEY]~=self or proof.epoch~=self.epoch or proof.bay~=b or root==nil
        or root.vehicle~=proof.vehicle or root.farmId~=proof.farm or not root.complete or #root.units~=proof.count
        or b.width~=proof.width or b.height~=proof.height or b.length~=proof.length then return false end
    if root.dimensions==nil or root.dimensions.height>b.height
        or math.max(root.dimensions.length,proof.dimensions.length)>b.length then return false end
    if not consumed and (proof.consumed or self.clock~=proof.clock) then return false end
    for _,unit in ipairs(root.units) do
        local saved=proof.units[unit];local size=unit.size;local link=root.links[unit] or {}
        if saved==nil or size==nil or saved.width~=size.width or saved.height~=size.height or saved.length~=size.length
            or saved.parent~=link.parent or saved.joint~=link.jointDescIndex or saved.input~=link.inputJointDescIndex
            or saved.folded~=nil and not sameState(unit,saved.folded) then return false end
    end
    return true
end
local function probeUnit(unit,b,budget)
    local state=foldedState(unit);if state==nil then return nil,"UNSTABLE_OR_UNKNOWN_FOLD_STATE" end
    if type(unit.components)~="table" or #unit.components==0 or #unit.components>8 then return nil,"UNKNOWN_COMPONENTS" end
    local originX,_,originZ=getWorldTranslation(unit.rootNode)
    local fx,_,fz=localDirectionToWorld(unit.rootNode,0,0,1)
    if not finite(fx) or not finite(fz) or fx*fx+fz*fz<.001 then return nil,"UNKNOWN_HEADING" end
    local length=math.sqrt(fx*fx+fz*fz);fx,fz=fx/length,fz/length
    local rx,rz=fz,-fx;local yaw=math.atan2(fx,fz)
    local lo={math.huge,math.huge,math.huge};local hi={-math.huge,-math.huge,-math.huge}
    local centresLo={math.huge,math.huge};local centresHi={-math.huge,-math.huge}
    local expected={};local floor=math.huge
    local function include(wx,wy,wz)
        local point={(wx-originX)*rx+(wz-originZ)*rz,wy,(wx-originX)*fx+(wz-originZ)*fz}
        for axis=1,3 do if not finite(point[axis]) then error("INVALID_POINT") end
            lo[axis]=math.min(lo[axis],point[axis]);hi[axis]=math.max(hi[axis],point[axis]) end
    end
    for _,component in ipairs(unit.components) do
        local node=component.node;if node==nil or not entityExists(node) then return nil,"MISSING_COMPONENT" end
        expected[node]=false
        local a,bx,c,d,e,f=getRigidBodyAABB(node)
        if not (finite(a) and finite(bx) and finite(c) and finite(d) and finite(e) and finite(f)) then return nil,"UNKNOWN_BROAD_ENVELOPE" end
        -- Search the UNION of both possible endpoint envelopes. If a runtime
        -- supplies world AABB corners, its whole box is included as well. The
        -- union is only a broad search volume, never an accepted vehicle size.
        for _,wx in ipairs({a,bx}) do for _,wy in ipairs({c,d}) do for _,wz in ipairs({e,f}) do include(wx,wy,wz) end end end
        -- Native scalar and vector APIs return the same opposite endpoints.
        -- Reconstruct the conservative body-space box; never sort world axes.
        local x1,y1,z1=worldToLocal(node,a,c,e);local x2,y2,z2=worldToLocal(node,bx,d,f)
        if not (finite(x1) and finite(x2) and finite(y1) and finite(y2) and finite(z1) and finite(z2))
            or x1>x2 or y1>y2 or z1>z2 then return nil,"UNVERIFIED_BODY_ENVELOPE" end
        for _,x in ipairs({x1,x2}) do for _,y in ipairs({y1,y2}) do for _,z in ipairs({z1,z2}) do
            include(localToWorld(node,x,y,z))
        end end end
        local cx,cy,cz=getWorldTranslation(node)
        local px,pz=(cx-originX)*rx+(cz-originZ)*rz,(cx-originX)*fx+(cz-originZ)*fz
        centresLo[1]=math.min(centresLo[1],px);centresHi[1]=math.max(centresHi[1],px)
        centresLo[2]=math.min(centresLo[2],pz);centresHi[2]=math.max(centresHi[2],pz)
        local ground=getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode,cx,0,cz)
        if not finite(ground) then return nil,"UNKNOWN_GROUND" end;floor=math.min(floor,ground)
    end
    for axis=1,3 do
        lo[axis]=lo[axis]-.02;hi[axis]=hi[axis]+.02
        if hi[axis]-lo[axis]<=0 or hi[axis]-lo[axis]>50 then return nil,"ENVELOPE_LIMIT" end
    end
    local target={hit=false,unknown=false}
    function target:onHit(node)
        budget.callbacks=budget.callbacks+1
        if budget.callbacks>1024 then self.unknown=true;return true end
        local owner=expected[node]~=nil and node or call(unit,"getParentComponent",node)
        if owner~=nil and expected[owner]~=nil then expected[owner]=true;self.hit=true end
        -- nil keeps collecting, matching GIANTS' own overlap callbacks.
    end
    local function query(a,c)
        budget.queries=budget.queries+1;if budget.queries>64 then return nil end
        target.hit=false
        local mx,my,mz=(a[1]+c[1])*.5,(a[2]+c[2])*.5,(a[3]+c[3])*.5
        overlapBox(originX+rx*mx+fx*mz,my,originZ+rz*mx+fz*mz,0,yaw,0,
            (c[1]-a[1])*.5,(c[2]-a[2])*.5,(c[3]-a[3])*.5,"onHit",target,nil,true,true,false,true)
        if target.unknown then return nil end;return target.hit
    end
    if query(lo,hi)~=true then return nil,"NO_REFERENCE_HIT:callbacks="..budget.callbacks end
    local covered=0;for _,seen in pairs(expected) do if seen then covered=covered+1 end end
    if covered~=#unit.components then return nil,"INCOMPLETE_COMPONENT_REFERENCE:"..covered.."/"..#unit.components end
    local midX=(centresLo[1]+centresHi[1])*.5;local midZ=(centresLo[2]+centresHi[2])*.5
    local limits={midX-b.width*.5+CLEARANCE,midX+b.width*.5-CLEARANCE,
        floor+b.height-CLEARANCE,midZ-unit.size.length*.5,midZ+unit.size.length*.5}
    -- All prohibited slabs within the enclosing reference volume must be empty.
    local slabs={{1,lo[1],limits[1]},{1,limits[2],hi[1]},
        {2,limits[3],hi[2]},{3,lo[3],limits[4]},{3,limits[5],hi[3]}}
    local lengthOutside=false
    for _,slab in ipairs(slabs) do
        local axis=slab[1];local a={lo[1],lo[2],lo[3]};local c={hi[1],hi[2],hi[3]}
        a[axis]=math.max(lo[axis],slab[2]);c[axis]=math.min(hi[axis],slab[3])
        if c[axis]-a[axis]>.0001 then
            local hit=query(a,c)
            if hit==nil then return nil,"QUERY_LIMIT" end
            if hit then
                if axis==3 then lengthOutside=true
                else return nil,axis==1 and "PHYSICAL_WIDTH" or "PHYSICAL_HEIGHT" end
            end
        end
    end
    state.lengthUpper=unit.size.length
    if lengthOutside then
        -- Component origins need not be centred on their colliders. A hit
        -- outside that provisional corridor is not proof of excessive length.
        -- Bound both actual ends independently, using only own exact hits.
        local lower,upper=lo[3],hi[3]
        for _=1,11 do
            local middle=(lower+upper)*.5
            local hit=query(lo,{hi[1],hi[2],middle})
            if hit==nil then return nil,"QUERY_LIMIT" end
            if hit then upper=middle else lower=middle end
        end
        local firstLower=lower
        lower,upper=lo[3],hi[3]
        for _=1,11 do
            local middle=(lower+upper)*.5
            local hit=query({lo[1],lo[2],middle},hi)
            if hit==nil then return nil,"QUERY_LIMIT" end
            if hit then lower=middle else upper=middle end
        end
        local spanUpper=upper-firstLower
        -- Metadata describes a nominal device length, not a maximum permitted
        -- collider length. Carry a larger measured bound into the TRAIN check.
        state.lengthUpper=math.max(unit.size.length,spanUpper+.05)
        if state.lengthUpper>b.length then
            return nil,string.format("PHYSICAL_LENGTH:spanUpper=%.3f bayLimit=%.3f",state.lengthUpper,b.length)
        end
    end
    if not sameState(unit,state) then return nil,"FOLD_CHANGED_DURING_PROBE" end
    return state,"EXACT_FOLDED_FIT"
end
function S:probeFoldedServiceSize(id,vehicleId)
    if g_server==nil or self.disposed or not self.loaded or not self.persistenceSafe then return nil,"SERVER_ONLY_OR_DISPOSED" end
    for _,name in ipairs({"overlapBox","getRigidBodyAABB","worldToLocal","localToWorld","getWorldTranslation",
        "localDirectionToWorld","entityExists","getTerrainHeightAtWorldPos"}) do
        if type(_G[name])~="function" then return nil,"API_UNAVAILABLE:"..name end
    end
    if g_currentMission==nil or g_currentMission.terrainRootNode==nil then return nil,"UNKNOWN_GROUND" end
    self:scan()
    local b=self.bays[id];local root=self.roots[vehicleId];local size=root and root.dimensions
    if b==nil or b.operational~="OPEN" or not b.capabilities.WASH or root==nil or not root.complete or size==nil
        or root.farmId~=self.providers[b.providerId].farmId then return nil,"ACCESS_OR_UNKNOWN_SIZE" end
    if size.width<=b.width or size.height>b.height or size.length>b.length or b.width<=CLEARANCE*2 then return nil,"NOT_WIDTH_ONLY" end
    local proof={[KEY]=self,bay=b,vehicle=root.vehicle,farm=root.farmId,epoch=self.epoch,clock=self.clock,
        width=b.width,height=b.height,length=b.length,units={},count=#root.units,
        dimensions={width=0,height=size.height,length=size.length}}
    local budget={queries=0,callbacks=0};local narrowed=0;local declaredAndMeasuredSum=0
    for _,unit in ipairs(root.units) do
        local link=root.links[unit] or {};local s=unit.size
        local saved={width=s.width,height=s.height,length=s.length,parent=link.parent,joint=link.jointDescIndex,input=link.inputJointDescIndex}
        proof.units[unit]=saved
        if s.width>b.width then
            narrowed=narrowed+1;if narrowed>2 then return nil,"UNIT_LIMIT" end
            local ok,state,reason=pcall(probeUnit,unit,b,budget)
            if not ok or state==nil then return nil,ok and reason or "NATIVE_PROBE_ERROR" end
            saved.folded=state
            declaredAndMeasuredSum=declaredAndMeasuredSum+state.lengthUpper
            proof.dimensions.width=math.max(proof.dimensions.width,b.width-CLEARANCE*2)
            proof.dimensions.height=math.max(proof.dimensions.height,b.height-CLEARANCE)
        else
            proof.dimensions.width=math.max(proof.dimensions.width,s.width)
            declaredAndMeasuredSum=declaredAndMeasuredSum+s.length
        end
    end
    proof.dimensions.length=math.max(size.length,declaredAndMeasuredSum)
    if proof.dimensions.length>b.length then
        return nil,string.format("PHYSICAL_TRAIN_LENGTH:bound=%.3f bayLimit=%.3f",proof.dimensions.length,b.length)
    end
    local info=self:inspect(id,vehicleId,{WASH=true})
    info.dimensions=proof.dimensions;info.technicallySuitable=true;info.foldedFitProof=proof
    info.sizeSource="EXACT_FOLDED_COLLISION_CERTIFICATE";info.probeQueries=budget.queries
    return info,"EXACT_FOLDED_FIT"
end
function SmartGateAPI.probeFoldedServiceSize(id,vehicleId)
    local s=g_smartGate~=nil and g_smartGate.serviceInfrastructure or nil
    if s==nil then return nil,"SERVICE_UNAVAILABLE" end
    return s:probeFoldedServiceSize(id,vehicleId)
end
function S:verifyFoldedServiceSize(id,vehicleId,jobId,ownerId)
    if g_server==nil or self.disposed or not self.loaded or not self.persistenceSafe then return false,"SERVER_ONLY_OR_DISPOSED" end
    self:scan()
    local b=self.bays[id];local r=b~=nil and b.reservation
    if not r or r.vehicleId~=vehicleId or r.jobId~=jobId or r.ownerId~=ownerId or not self:admissionValid(b,vehicleId) then return false,"STALE_ADMISSION" end
    local admission=self.admissions[r]
    if admission.foldedProof==nil then return true,"DECLARED" end
    local budget={queries=0,callbacks=0};local declaredAndMeasuredSum=0
    for unit,saved in pairs(admission.foldedProof.units) do
        local bound=saved.length
        if saved.folded~=nil then
            local ok,state,reason=pcall(probeUnit,unit,b,budget)
            if not ok or state==nil then return false,ok and reason or "NATIVE_PROBE_ERROR" end
            bound=state.lengthUpper
        end
        declaredAndMeasuredSum=declaredAndMeasuredSum+bound
    end
    local length=math.max(self.roots[vehicleId].dimensions.length,declaredAndMeasuredSum)
    if length>b.length then return false,string.format("PHYSICAL_TRAIN_LENGTH:bound=%.3f bayLimit=%.3f",length,b.length) end
    admission.foldedProof.dimensions.length=math.max(admission.foldedProof.dimensions.length,length)
    return true,"EXACT_FOLDED_FIT"
end
function SmartGateAPI.verifyFoldedServiceSize(id,vehicleId,jobId,ownerId)
    local s=g_smartGate~=nil and g_smartGate.serviceInfrastructure or nil
    if s==nil then return false,"SERVICE_UNAVAILABLE" end
    return s:verifyFoldedServiceSize(id,vehicleId,jobId,ownerId)
end
