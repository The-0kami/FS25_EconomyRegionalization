-- M1 adapter: explicit persisted wash-template binding, never nearest search.
-- Only the verified AutomaticCarWash trigger/timer contract is supported here.
local function call(o,k,...)
    if o~=nil and type(o[k])=="function" then local ok,a,b=pcall(o[k],o,...);if ok then return a,b end end
end
local function finite(v) return type(v)=="number" and v==v and v>-math.huge and v<math.huge end
-- Read-only source classification shared by the editor and execution adapter.
-- Finding a candidate never activates it or creates a service bay.
local function nativeWashSource(gate)
    if gate==nil or gate.objectType~=1 then return nil,nil,"BOUND_INTERACTION_UNAVAILABLE_OR_DISABLED" end
    local owner=gate.owner;local spec=owner~=nil and owner.spec_automaticCarWash
    if owner==nil or owner.isDeleted or owner.isDeleting then return nil,nil,"SOURCE_OR_FARM_CHANGED" end
    if type(spec)~="table" or spec.initialized~=true or type(spec.vehiclesInTrigger)~="table"
        or type(owner.CleanCar)~="function" or type(owner.CleanOneVehicle)~="function"
        or not finite(spec.dirtAmount) or spec.dirtAmount>=0 or not finite(spec.timerLength) or spec.timerLength<=0
        or spec.damageAmount~=0 or spec.wearAmount~=0 then return nil,nil,"UNSUPPORTED_NATIVE_WASH_CONTRACT" end
    local ao=gate.animatedObject
    if ao==nil or ao.animation==nil or type(ao.setDirection)~="function" then return nil,nil,"NO_NATIVE_CYCLE" end
    return owner,spec
end
function SmartGate:isServiceWashSource(gate)
    local owner=nativeWashSource(gate)
    return owner~=nil
end
local function resolve(id)
    local sg=g_smartGate;local s=sg~=nil and sg.serviceInfrastructure
    if g_server==nil or s==nil or s.disposed or not s.loaded or not s.persistenceSafe then return nil,"SERVICE_UNAVAILABLE" end
    local b=s.bays[id];local p=b~=nil and s.providers[b.providerId]
    if b==nil or p==nil then return nil,"UNKNOWN_BAY" end
    if not b.capabilities.WASH or b.operational~="OPEN" then return nil,"BAY_NOT_OPEN_FOR_WASH" end
    if b.legacyWashGateId==nil then return nil,"NO_EXPLICIT_WASH_BINDING" end
    local gate
    if type(sg.findServiceSource)=="function" then gate=sg:findServiceSource(b.legacyWashGateId) else gate=sg:findGateById(b.legacyWashGateId) end
    if gate==nil or gate.objectType~=1 or gate.blacklisted or gate.mode==0 then return nil,"BOUND_INTERACTION_UNAVAILABLE_OR_DISABLED" end
    local owner,spec,reason=nativeWashSource(gate)
    if owner==nil then return nil,reason end
    if s.serviceSourceInProvider~=nil and not s:serviceSourceInProvider(p,gate) then return nil,"SOURCE_OUTSIDE_PROVIDER" end
    if call(owner,"getOwnerFarmId")~=p.farmId then return nil,"SOURCE_OR_FARM_CHANGED" end
    local fields={b.id,b.providerId,b.legacyWashGateId,b.adTarget,b.x,b.y,b.z,b.yaw,b.width,b.height,b.length,b.operational,
        tostring(b.capabilities.WASH),tostring(b.capabilities.REPAIR),tostring(b.capabilities.REFUEL),gate.mode,tostring(gate.blacklisted),
        spec.dirtAmount,spec.damageAmount,spec.wearAmount,spec.timerLength}
    for i,v in ipairs(fields) do fields[i]=tostring(v) end
    return {s=s,b=b,p=p,gate=gate,owner=owner,spec=spec,signature=table.concat(fields,"|")}
end
function SmartGateAPI.getServiceWashAction(id,vehicleId)
    local a,reason=resolve(id);if a==nil then return nil,reason end
    local b=a.b;local r=b.reservation
    local inNative,foreignNative=false,false;local root=a.s.roots[vehicleId]
    if root~=nil then
        local ownNodes={};for _,unit in ipairs(root.units) do if unit.rootNode~=nil then ownNodes[unit.rootNode]=true end end
        for _,node in pairs(a.spec.vehiclesInTrigger) do
            if ownNodes[node] then inNative=true end
            if not ownNodes[node] then foreignNative=true end
        end
    end
    local positionKnown=root~=nil and root.complete==true and b.rect~=nil
    local positioned=positionKnown
    local overhangWidth,overhangLength=0,0
    if positioned then
        for _,unit in ipairs(root.units) do
            local node,size=unit.rootNode,unit.size
            if node==nil or not entityExists(node) or type(size)~="table" then positioned=false;positionKnown=false;break end
            local x,_,z=getWorldTranslation(node);local fx,_,fz=localDirectionToWorld(node,0,0,1)
            if not finite(x) or not finite(z) or not finite(fx) or not finite(fz) or fx*fx+fz*fz<.001 then positioned=false;positionKnown=false;break end
            x=x+fx*(tonumber(size.lengthOffset) or 0);z=z+fz*(tonumber(size.lengthOffset) or 0)
            for _,sx in ipairs({-1,1}) do for _,sz in ipairs({-1,1}) do
                local dx=x+fz*size.width*.5*sx+fx*size.length*.5*sz-b.x
                local dz=z-fx*size.width*.5*sx+fz*size.length*.5*sz-b.z
                local excessWidth=math.abs(dx*b.rect.rx+dz*b.rect.rz)-b.width*.5
                local excessLength=math.abs(dx*b.rect.fx+dz*b.rect.fz)-b.length*.5
                overhangWidth=math.max(overhangWidth,excessWidth);overhangLength=math.max(overhangLength,excessLength)
                if excessWidth>.05 or excessLength>.05 then positioned=false end
            end end
        end
    end
    return {bayId=id,providerId=b.providerId,interactionId=b.legacyWashGateId,signature=a.signature,
        source=a.owner,adTarget=b.adTarget,epoch=a.s.epoch,revision=b.revision,farmId=a.p.farmId,
        nativeOccupied=inNative,foreignNative=foreignNative,positioned=positioned,positionKnown=positionKnown,
        overhangWidth=positionKnown and overhangWidth or nil,overhangLength=positionKnown and overhangLength or nil,
        running=a.spec.timerId~=nil,animationRunning=(tonumber(a.gate.animatedObject.animation.direction) or 0)~=0,
        reservation=r~=nil and {jobId=r.jobId,vehicleId=r.vehicleId,ownerId=r.ownerId,expiresAt=r.expiresAt} or nil},"KNOWN"
end
function SmartGateAPI.startServiceWash(id,jobId,vehicleId,ownerId,epoch,signature)
    local a,reason=resolve(id);if a==nil then return false,reason end
    if a.signature~=signature or a.s.epoch~=epoch then return false,"BINDING_CHANGED" end
    local b=a.b;local r=b.reservation
    if r==nil or r.jobId~=jobId or r.vehicleId~=vehicleId or r.ownerId~=ownerId or a.s.clock>=r.expiresAt then return false,"NO_OWN_LEASE" end
    local root=a.s.roots[vehicleId];if root==nil or root.farmId~=a.p.farmId then return false,"VEHICLE_OR_FARM_CHANGED" end
    if (call(root.vehicle,"getLastSpeed") or math.huge)>.1 then return false,"VEHICLE_NOT_STOPPED" end
    local observed=SmartGateAPI.getServiceWashAction(id,vehicleId)
    -- Admission dimensions remain strict in reserve(). Only a known positional
    -- overhang of the already admitted, stopped own vehicle is advisory here.
    local info=a.s:inspect(id,vehicleId,{WASH=true})
    if observed==nil or not (observed.positioned or observed.positionKnown==true) or not (b.occupants or {})[vehicleId]
        or info.admissionValid~=true or info.farmAllowed~=true or b.occupancy=="UNKNOWN" then return false,"NOT_IN_BOUND_SERVICE_BAY" end
    if observed.foreignNative then return false,"FOREIGN_NATIVE_TRIGGER_OCCUPANT" end
    for occupant in pairs(b.occupants) do if occupant~=vehicleId then return false,"FOREIGN_BLOCKER" end end
    if not observed.animationRunning then
        local ok,detail=SmartGateAPI.requestInteraction(a.gate.id,a.gate.ownerKey,a.gate.nodeKey,a.gate.x,a.gate.z)
        if not ok then return false,detail end
    end
    -- Never write dirt/damage. The bound placeable owns its native timer.
    -- This station hides its native vehicleTrigger below ground while idle.
    -- The animation raises it; its own trigger callback then starts CleanCar.
    -- Only resume the native timer directly if occupancy is already confirmed.
    if a.spec.timerId==nil and observed.nativeOccupied then
        local ok,err=pcall(a.owner.CleanCar,a.owner)
        if not ok then return false,"NATIVE_START_FAILED:"..tostring(err) end
    end
    local state=SmartGateAPI.getServiceWashAction(id,vehicleId)
    return state~=nil and (state.running or state.animationRunning),state~=nil and "NATIVE_CYCLE" or "SOURCE_LOST"
end
